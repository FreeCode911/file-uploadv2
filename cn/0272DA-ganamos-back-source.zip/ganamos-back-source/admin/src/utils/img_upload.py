import base64
import os
from random import choice
from string import ascii_uppercase
from settings.setup_settings import get_all_settings
from secrets import token_hex

settings = get_all_settings()


def upload_img(image, ext):
    if not image or not ext:
        raise Exception("Image or extentions empty")
    name = ''.join(choice(ascii_uppercase) for i in range(20)) + '.' + ext
    with open(os.path.join(settings.MEDIA_FOLDER, name), "wb") as fh:
        fh.write(base64.decodebytes(image.encode('utf-8')))
    url = "/media/" + name
    return url


def upload_promo(**kwargs):
    ext = kwargs.get('ext')
    file = kwargs.get('file')

    file_name = 'promo-' + str(token_hex(15)) + '.' + str(ext)
    file_path = os.path.join(settings.MEDIA_FOLDER, file_name)

    with open(file_path, 'wb') as F:
        F.write(base64.decodebytes(file.encode('utf-8')))

    return file_name
