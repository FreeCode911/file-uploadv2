from tornado.options import options
from typing import Union


def check_currency_for_real(currency: Union[str, None])-> bool:
    """
    Determine if currency should be converted by real rate
    """
    return currency in ("BRL",)


def are_disabled_currencies(
    from_currency: str,
    to_currency: str,
) -> bool:
    """
        Check if currencies are disabled for recalculation
    """
    banned_currencies = options.RECALCULATION_DISABLED_CURRENCIES

    if from_currency not in banned_currencies:
        return False
    
    banned_currencies_to = banned_currencies.get(from_currency, list())
    return to_currency in banned_currencies_to
        