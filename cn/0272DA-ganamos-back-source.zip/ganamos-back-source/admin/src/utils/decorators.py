import traceback

import jwt
from aiorest_ws.conf import settings
from jwt.exceptions import ExpiredSignatureError

from bookmakers.services.commands import AbstractResult
from settings.setup_settings import get_all_settings
from util.error import InvalidRequestData

settings_local = get_all_settings()


def _check_roles(method, user_role, roles):
    if method == "GET":
        if user_role in roles['GET']:
            return
    elif method == "POST":
        if user_role in roles['CREATE']:
            return
    elif method == "PUT":
        if user_role in roles['UPDATE']:
            return
    elif method == "DELETE":
        if user_role in roles['DELETE']:
            return
    raise Exception("Permission denied")


def permission(handler):
    def wrapper(self, *args, **kwargs):
        try:
            token = kwargs.get('token', None)
            request = args[0]
            method = request.method
            if not token:
                raise Exception('Token is not defined')
            user = jwt.decode(
                token, settings_local.COOKIE_SECRET, algorithms=['HS256'])
            _check_roles(method, user['role'], self.roles)
        except ExpiredSignatureError as e:
            raise Exception('Token not valid')
        return handler(self, *args, **kwargs)

    return wrapper


def session(handler):
    def wrapper(request, *args, **kwargs):
        try:
            session = settings.SQLALCHEMY_SESSION()
            result = handler(request, session=session, *args, **kwargs)
        finally:
            if session:
                session.close()
        return result

    return wrapper


def response(handler):
    def wrapper(request, *args, **kwargs):
        try:
            return AbstractResult(0, handler(request, *args, **kwargs),
                                  None).to_dict()
        except InvalidRequestData as e:
            return AbstractResult(e.status_code, None, str(e), log_error=False).to_dict()
        except Exception as e:
            traceback.print_exc()
            return AbstractResult(1, None, str(e)).to_dict()

    return wrapper
