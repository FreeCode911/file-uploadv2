from aiorest_ws.routers import SimpleRouter as AbstractSimpleRouter
from aiorest_ws.log import logger
from aiorest_ws.exceptions import BaseAPIException, NotSpecifiedHandler
from aiorest_ws.wrappers import Response, Request
from aiorest_ws.renderers import JSONRenderer


class SimpleRouter(AbstractSimpleRouter):
    def process_request(self, request: Request):
        """
        Handle received request from user.

        :param request: request from user.
        """

        logger.info(
            "\"[Request] {method} {url}\". "
            "Args={args}. "
            "Data={data}. "
            "Event name={event_name}.".format(
                method=request.method,
                url=request.url,
                args=request.args or {},
                data=request.data or {},
                event_name=request.event_name)
        )

        response = Response()

        try:
            url = self.extract_url(request)
            handler, args, kwargs = self.search_handler(request, url)

            # Invoke handler for request
            if handler:

                for middleware in self.middlewares:
                    middleware.process_request(request, handler)

                # Search serializer for response
                format = request.get_argument('format')
                serializer = handler.get_renderer(format, *args, **kwargs)

                response.content = handler.dispatch(request, *args, **kwargs)
            else:
                raise NotSpecifiedHandler()

        except BaseAPIException as exc:
            logger.exception(exc)
            response.wrap_exception(exc)
            serializer = JSONRenderer()

        response.append_request(request)
        return serializer.render(response.content)
