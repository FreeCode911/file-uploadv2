# -*- coding: utf-8 -*-
import sqlalchemy
from sqlalchemy.schema import ColumnDefault
from aiorest_ws.views import MethodBasedView
from aiorest_ws.db.orm.exceptions import ValidationError
from aiorest_ws.db.orm.sqlalchemy.serializers import ModelSerializer
from sqlalchemy.schema import ColumnDefault
from tornado.options import options
import time

from betronic_core.db.models.user import UserModel
from betronic_core.manager import IManager
from betronic_core.db.models.base import BaseModel
from ..utils.decorators import permission, response, session
from ..utils.user_mixin import UserMixin
from datetime import datetime as dt
from betronic_core.db.models.money_transfer import MoneyTransferModel
from sqlalchemy import func

from ...settings import settings as SETTINGS
import json


class AbstractView(MethodBasedView):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.CASHIER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.CASHIER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.CASHIER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.CASHIER),
    }

    @response
    def dispatch(self, request, *args, **kwargs):
        return super(AbstractView, self).dispatch(request, *args, **kwargs)


class AdminPermissionsManager(IManager):

    allowed_settings_options = ['filter', 'table', 'weight', 'column_positions']

    roles = {
        "create": (),
        "read": (),
        "update": (),
        "delete": (),
    }

    @staticmethod
    def get_entities_by_role(role):
        entities = list()
        if role == UserModel.CASHIER:
            entities = options.CASHIER_ENTITY
        elif role == UserModel.ADMIN:
            entities = options.ADMIN_ENTITY
        elif role == UserModel.OWNER:
            entities = options.OWNER_ENTITY
        elif role == UserModel.LIMITED_OWNER:
            entities = options.LIMITED_OWNER_ENTITY
        return entities

    def get_entities(self, user_role):
        return self.get_entities_by_role(user_role)

    def check_permissions(self, operation: str, role: str):
        if role not in self.roles[operation]:
            raise Exception('Method not allowed')

    @staticmethod
    def check_updated_data(data, fields):
        for key in data.keys():
            field = fields[key]
            if not field['editable']:
                raise Exception(f"Field {key} not allowed for editable")


class AdminCRUDManager(AdminPermissionsManager):
    model: BaseModel = None
    fields = dict()

    def get_active_fields(self):
        fields = self._get_active_fields()
        return list(fields.keys())

    def get_all_fields(self):
        return list(self.fields.keys())

    def get_query(self):
        return self.db.query(self.model)

    def execute_operation(self, **kwargs):
        operation = kwargs.pop("operation").strip().lower()
        self.check_permissions(operation, kwargs["user_role"])

        method = getattr(self, operation)
        if method:
            return method(**kwargs)

    def create(self, data, **kwargs):
        if not data:
            raise ValueError("You must provide data for creating object!")
        created: BaseModel = self.model().auto_create_from_dict(data)
        if created:
            self.db.add(created)
            self.db.commit()
            return created.to_dict(show=self.get_all_fields())
        else:
            raise Exception("Create operation failed!")

    def read(self, **kwargs):
        if kwargs.get("model_id", None):
            return self._read_by_id(**kwargs)
        else:
            return self._read_all(**kwargs)

    def _read_by_id(self, **kwargs):
        item = self.model.get_by_id(self.db, kwargs.get("model_id", None))
        if not item:
            raise Exception("Not exists")
        return item.to_dict(show=self.get_all_fields())

    def _read_all(self, **kwargs):
        q = self.get_query()
        start = time.monotonic()
        items = self.model().query_by_params(q, self.db, **kwargs)
        print(f'QUERY BY PARAMS {time.monotonic() - start}')
        items = [
            item.to_dict(show=self.get_active_fields()) for item in items
        ]
        return {"items": items}

    def update(self, model_id: int, data: dict, *args, **kwargs):
        if not data:
            raise ValueError("You must provide a data to update!")
        self.check_updated_data(data, self.fields)
        instance = self.model.get_by_id(self.db, model_id)
        if not instance:
            raise ValueError(f"Object with id {model_id} not found!")

        instance.auto_upd_from_dict(data)
        if instance:
            return instance.to_dict(show=self.get_all_fields())
        else:
            raise Exception("Update operation failed!")

    def delete(self, model_id, *args, **kwargs):
        if not model_id:
            raise Exception("Id is not defined")

        instance = self.model.get_by_id(self.db, model_id)
        if not instance:
            raise ValueError(f"Object with id {model_id} not found!")

        self.db.delete(instance)
        self.db.commit()
        return {}


class AbstractCRUDView(AbstractView):
    model: BaseModel = None
    serializer: ModelSerializer = None

    def get_query(self, session):
        return session.query(self.model)

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)
        items, count = self.model.query_by_params(query, session, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    def _get_model_by_id(self, session, id, **kwargs):
        item = self.get_query(session).filter(self.model.id == id).first()
        if not item:
            raise Exception("Resource not exist")
        return self.serializer(item).data

    def set_default_date(self,
                         kwargs: dict, column_name: str='created_at') -> dict:
        if not kwargs['filters'].get(column_name, None):
            today = {'from': dt.today().strftime('%Y-%m-%d')}
            kwargs['filters']['created_at'] = today
            kwargs['order_by'] = '-' + column_name

        return kwargs

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_model_by_id(session, int(id), **kwargs) \
            if id else self._get_model_all(session, **kwargs)
        return result

    @permission
    def post(self, request, *args, **kwargs):
        if not request.data:
            raise ValidationError('You must provide arguments for create.')

        serializer = self.serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        for field in serializer._validated_data:
            if type(serializer._validated_data[field]) == ColumnDefault:
                serializer._validated_data[field] = \
                    serializer._validated_data[field].arg
        serializer.save()
        return serializer.data

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        if not request.data:
            raise ValidationError('You must provide an updated instance.')

        query = kwargs.get('query', None) or self.get_query(session)

        instance = query.filter(self.model.id == id).first()
        if not instance:
            raise ValidationError('Object does not exist')

        serializer = self.serializer()
        model = serializer.update(instance, request.data)
        serializer = self.serializer(model)
        return serializer.data

    @session
    @permission
    def delete(self, request, id=None, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        instance = self.get_query(session).filter(
            self.model.id == int(id)).first()
        if not instance:
            raise ValidationError('Object does not exist')

        session.delete(instance)
        session.commit()
        result = self._get_model_all(session, **kwargs)
        return result


class AbstractDocumentCRUDView(AbstractCRUDView):
    db = None

    def _get_document_list(self):
        result = []
        for root_name in self.db:
            if root_name not in SETTINGS.SETTINGS_TO_NOT_DISPLAY:
                result.append({"settings": root_name, "id": root_name})
        return {"items": result, "count": 1}

    def _get_document(self, id):
        result = self.db[id]
        return {"settings": json.dumps(result, indent=4)}

    def _verify_data_to_save(self, id, data):
        verify_status = True
        return verify_status

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_document(id) \
            if id else self._get_document_list()
        return result

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        if not request.data:
            raise ValidationError('You must provide an updated instance.')
        self.serialize(request.data, id)

        return self.db[id]

    def serialize(self, data: dict, id):
        settings_data = json.loads(data.get('settings'))
        if self._verify_data_to_save(id=id, data=settings_data):
            self.db.save(settings_data)


class AbstractSettingsView(AbstractView, UserMixin):
    view: AbstractCRUDView = None
    fields = {}
    additional_settings = {}

    @session
    def get_enum(self, Model, atr_name, session) -> dict:
        models = session.query(Model).all()

        result = {}
        for model in models:
            result[model.id] = getattr(model, atr_name)
        return result

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)
        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }


class AbstractRedisCRUDView(AbstractCRUDView):
    redis = None

    def _get_document(self, key):
        result = self.redis.get(key)
        if result:
            return json.loads(result.decode('utf8'))
        return None

    def get_model(self, key: str):
        result = self._get_document(key)
        return result

    def get_model_view_list(self, key: str):
        result = self._get_document(key)
        return {"items": [result], "count": 1}

    def _get_document_list(self, key):
        result = self.redis.get(key)
        if result:
            return json.loads(result.decode('utf8'))
        return None

    @session
    @permission
    def get(self, request, token=None, session=None, *args, **kwargs):
        result = self._get_document(request['key']) \
            if token else self._get_document_list(request['key'])
        return result

    @session
    @permission
    def put(self, request):
        self.redis.set(request['key'], ['value'])
        return


class AbstractStatisticsCRUDView(AbstractCRUDView):

    @staticmethod
    def _filter_transactions_by_date(session, transaction_subq, date={}):
        date_from = date.get('from', None)
        date_to = date.get('to', None)

        q = session.query(transaction_subq)

        if date_from and date_to:
            filtered_q = q.filter(
                transaction_subq.c.date.between(date_from, date_to)).subquery()
        elif date_from:
            filtered_q = q.filter(
                transaction_subq.c.date >= date_from).subquery()
        elif date_to:
            filtered_q = q.filter(
                transaction_subq.c.date <= date_to).subquery()
        else:
            filtered_q = q.subquery()

        return filtered_q

    @staticmethod
    def _stat_by_transfer_type(session, users, transaction_subq):
        return session.query(
            users.c.id.label('t_uid'),
            func.sum(transaction_subq.c.value).label('value')
        ) \
            .outerjoin(transaction_subq) \
            .group_by(users.c.id).subquery()

    @staticmethod
    def _extract_specific_users(session, table_name='filtered_users', **filters):
        result = session.query(UserModel)

        if filters:
            for key, value in filters.items():
                if value:
                    result = result.filter(getattr(UserModel, key) == value)

        return result.cte(table_name)

    # @staticmethod
    # def _extract_cashiers_by_phone(session, table_name='default', phone=None):
    #     result = session\
    #         .query(UserModel, AdditionalData.phone).join(AdditionalData)\
    #         .filter(UserModel.role == UserModel.CASHIER)\
    #         .filter(UserModel.is_visible != False)
    #     if phone:
    #         result = result.filter(AdditionalData.phone == phone)
    #     return result.cte(table_name)

    @staticmethod
    def _serialize_query(query_results):
        res = []
        for row in query_results:
            result_row = {}
            if isinstance(row, sqlalchemy.Row):
                row = row._mapping
            for cell_key in row.keys():
                cell_value = getattr(row, cell_key)
                if not cell_value:
                    result_row[cell_key] = 0
                elif isinstance(cell_value, str):
                    result_row[cell_key] = cell_value
                else:
                    result_row[cell_key] = float(cell_value)
            res.append(result_row)

        return res

    def get_transfers_by_type(self, session, users, transfer_type, transfer_direction, date={}):
        c_id = '{}_user_id'.format(transfer_direction)

        # query transfer.values, filter by type
        chain_subq = session.query(
            getattr(MoneyTransferModel, c_id).label('t_uid'),
            MoneyTransferModel.value.label('value'),
            MoneyTransferModel.created_at.label('date')
        ) \
            .filter(MoneyTransferModel.type == transfer_type).subquery()

        # filter by date
        chain_subq = self._filter_transactions_by_date(session, chain_subq, date=date)

        # calculate statistics for column
        chain_subq = self._stat_by_transfer_type(session, users, transaction_subq=chain_subq)

        return chain_subq


class AbstractCRUDViewDefaults(AbstractCRUDView):

    default_filters = {
        'created_at': {
            'from': dt.today().strftime('%Y-%m-%d')
        }
    }

    default_order = 'created_at'

    def _get_model_all(self, session, **kwargs):

        kwargs['filters'] = kwargs['filters'] or self.default_filters
        kwargs['order_by'] = kwargs['order_by'] or self.default_order

        return super()._get_model_all(session, **kwargs)

