from aiorest_ws.db.orm.relations import PKOnlyObject
from aiorest_ws.db.orm.sqlalchemy.serializers import PrimaryKeyRelatedField


class RelationshipSerializer(PrimaryKeyRelatedField):
    def __init__(self, serializer=None, **kwargs):
        super(RelationshipSerializer, self).__init__(**kwargs)
        self.serializer = serializer

    def to_representation(self, value):
        value = value.pk if isinstance(value, PKOnlyObject) else value
        return self.serializer(value).data
