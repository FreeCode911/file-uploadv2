import jwt
from tornado.options import options


class RemoteServicesAPIMixin:
    """
    Should be mixed with UserMixin and other classes.
    """
    def _generate_token_for_remote_service(self, **kwargs):
        admin_user = self.get_user(**kwargs)
        token_data = {
            "id": admin_user["id"],
            "email": admin_user["email"],
            "role": admin_user["role"],
            "currency": admin_user["currency"],
            "partner_name": options.PROJECT_NAME,
        }
        data = jwt.encode(
            payload=token_data,
            key=options.AUTH_RSA_PRIVATE_KEY,
            algorithm="RS512"
        )
        return data
