import jwt
from settings.setup_settings import get_all_settings

settings = get_all_settings()

actions = ['GET', 'CREATE', 'UPDATE', 'DELETE']


class UserMixin(object):
    def get_user(self, **kwargs):
        token = kwargs.get('token')
        if not token:
            raise Exception('Token is not defined')
        return jwt.decode(token, settings.COOKIE_SECRET, algorithms=['HS256'])

    def get_permission(self, user, roles):
        role = user['role']
        return [action for action in actions if role in roles[action]]
