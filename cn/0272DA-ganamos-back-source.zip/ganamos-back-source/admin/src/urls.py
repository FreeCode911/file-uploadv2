from aiorest_ws.routers import SimpleRouter

from .views import (ads, flat_page, user, feedback, money, money_transfers, entity, image_upload, currencies, card,
                    city, withdrawal, slide, inbet_session, email_notification, settings, bonus_transfers, bets,
                    promo_materials, get_user_info, cashier_reports, cashier_collection, cashier_statistics, cashiers,
                    categories, partner_list, partner_transactions, partner_withdrawal, cashbox, admins, tickets,
                    reports, admin_collection, admin_statistics, jackpot, royalty_statistic, security_log,
                    admin_transactions, suadmin_transactions, promo_code, promocode_activations,
                    bonus_royalty_statistic, full_royalty_statistic, website_statistics, revenue_statistic,
                    payment_settings, limit_owner_deposits, limit_owner_deposit_history, transfer_limit_settings,
                    exceeded_transfer, providers, notification)
from .views.auth import LoginView, CheckView

router = SimpleRouter()
router.include(ads.router)
router.include(flat_page.router)
router.include(user.router)
router.include(feedback.router)
router.include(money.router)
router.include(money_transfers.router)
router.include(entity.router)
router.include(image_upload.router)
router.include(currencies.router)
router.include(card.router)
router.include(city.router)
router.include(withdrawal.router)
router.include(slide.router)
router.include(email_notification.router)
router.include(inbet_session.router)
router.include(settings.router)
router.include(bonus_transfers.router)
router.include(bets.router)
router.include(promo_materials.router)
router.include(get_user_info.router)
router.include(cashier_reports.router)
router.include(cashier_statistics.router)
router.include(cashier_collection.router)
router.include(cashiers.router)
router.include(categories.router)
router.include(partner_list.router)
router.include(partner_withdrawal.router)
router.include(partner_transactions.router)
router.include(admins.router)
router.include(cashbox.router)
router.include(reports.router)
router.include(tickets.router)
router.include(admin_collection.router)
router.include(admin_statistics.router)
router.include(jackpot.router)
router.include(royalty_statistic.router)
router.include(security_log.router)
router.include(admin_transactions.router)
router.include(suadmin_transactions.router)
router.include(promo_code.router)
router.include(promocode_activations.router)
router.include(bonus_royalty_statistic.router)
router.include(full_royalty_statistic.router)
router.include(website_statistics.router)
router.include(payment_settings.router)
router.include(revenue_statistic.router)
router.include(limit_owner_deposits.router)
router.include(limit_owner_deposit_history.router)
router.include(transfer_limit_settings.router)
router.include(exceeded_transfer.router)
router.include(providers.router)
router.include(notification.router)

router.register('/login', LoginView, 'POST')
router.register('/check', CheckView, 'GET')
