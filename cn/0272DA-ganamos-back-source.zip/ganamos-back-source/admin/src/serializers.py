from datetime import datetime

from aiorest_ws.db.orm.sqlalchemy import serializers
from aiorest_ws.conf import settings
from sqlalchemy import inspect

from aiorest_ws.db.orm.fields import NullBooleanField, JSONField

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.ads import AdsModel
from betronic_core.db.models.flat_page import FlatPageModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.notifications.email_notification import EmailNotification
from betronic_core.db.models.notification import NotificationModel
from betronic_core.db.models.promo_code import PromoCodeActivationModel
from betronic_core.db.models.additional_data import AdditionalData
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.db.models.inbet import InbetSessionModel
from betronic_core.db.models.feedback_form_question import FeedbackFormQuestionModel
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.slide import Slide
from betronic_core.db.models.city import City
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.promocode_manager.manager import PromocodeManager
from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.terminal.terminal_data import TerminalData
from betronic_core.db.models.terminal.cashbox import CashBox
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.db.models.bet_content_data import BetContentDataModel
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel
from betronic_core.db.models.betroute_registration import BetrouteRegistrationModel
from betronic_core.db.models.partner_materials import PartnerMaterialsModel
from betronic_core.db.models.category import CategoryModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from betronic_core.db.models.terminal.bet_ticket import BetTicketModel
from betronic_core.db.models.cashier_data import CashierDataModel
from betronic_core.db.models.betroute_local_bet import BetStatus
from betronic_core.db.models.outcome_transactions import JackpotModel
from betronic_core.db.models.security_log import SecurityLogModel
from betronic_core.db.models.line1x.bet import BetsLine1xModel, Bet1xStatus
from betronic_core.db.models.permission_details import ProviderModel
from betronic_core.db.models.settings import SettingsModel
from betronic_core.constants import TransferTypes as TT


class AbstractSerializer(serializers.ModelSerializer):
    def update(self, instance, validated_data):
        try:
            session = settings.SQLALCHEMY_SESSION(expire_on_commit=False)
            for row in validated_data:
                if "." in row:
                    key = row[0: row.find(".")]
                    new_instans = session.merge(instance)
                    session.refresh(new_instans)
                    object = getattr(new_instans, key)
                    value = row[row.find(".") + 1:]
                    if not object:
                        object = self.get_class_by_tablename(key)()
                        new_obj = session.merge(object)
                        setattr(new_instans, key, new_obj)
                        setattr(new_obj, value, validated_data[row])
                    else:
                        new_obj = session.merge(object)
                        setattr(new_obj, value, validated_data[row])
                    session.add(new_instans)
                    session.add(new_obj)
            session.commit()
        finally:
            if session:
                session.close()
        return super().update(instance, validated_data)

    @staticmethod
    def get_class_by_tablename(tablename):
        """Return class reference mapped to table.

        :param tablename: String with name of table.
        :return: Class reference or None.
        """
        for c in BaseModel._decl_class_registry.values():
            if hasattr(c, "__tablename__") and c.__tablename__ == tablename:
                return c


class AdsSerializer(serializers.ModelSerializer):
    class Meta:
        model = AdsModel
        fields = ("id", "html", "priority")


class CitySerializer(serializers.ModelSerializer):
    class Meta:
        model = City
        fields = ("id", "name")


class CashboxSerializer(serializers.ModelSerializer):
    class Meta:
        model = CashBox
        fields = ("id", "address", "city_id")


class FlatPageSerializer(serializers.ModelSerializer):
    class Meta:
        model = FlatPageModel
        fields = ("id", "name", "id_name", "lang", "text", "priority", "is_active")


class AdditionalDataField(serializers.RelatedField):
    def to_representation(self, value: AdditionalData):
        return {
            "card": value.card,
            "number_document": value.number_document,
            "address": value.address,
            "phone": value.phone,
        }


class EmailAuthField(serializers.RelatedField):
    def to_representation(self, value: EmailAuthModel):
        return {"email": value.email}


class BetrouteDataField(serializers.RelatedField):
    def to_representation(self, value: BetrouteRegistrationModel):
        return {"remote_email": value.remote_email, "cash_id": value.cash_id}


class BetrouteLocalBetField(serializers.RelatedField):
    def to_representation(self, value: BetrouteLocalBetModel):
        return {
            "id": value.id,
            "betcode": value.betcode,
            "amount": value.amount,
            "amount_out": value.details["AmountOut"] if value.status == 34 else "0",
            "from_user_id": value.from_user_id,
        }


class BetTicketSerializer(serializers.ModelSerializer):
    is_closed = NullBooleanField()
    bet = BetrouteLocalBetField()

    class Meta:
        model = BetTicketModel
        fields = ("id", "bet_id", "bet", "is_closed", "pin", "created_at")


class CashierDataField(serializers.RelatedField):
    def to_representation(self, value: CashierDataModel):
        return (
            {
                "id": value.id,
                "max_balance": value.max_balance,
                "max_withdrawal": value.max_withdrawal,
            }
            if value
            else {}
        )


class ReportsSerializer(serializers.ModelSerializer):
    def to_representation(self, value: MoneyTransferModel):
        result = {
            "id": value.id,
            "type": value.type,
            'real_from_user_id': value.real_from_user_id,
            'real_to_user_id': value.real_to_user_id,
            'real_from_user.role': value.real_from_user.role,
            'real_to_user.role': value.real_to_user.role,
            "value": str(value.value),
            "currency": value.currency,
            "created_at": str(value.created_at),
        }
        return result


class UserSerializer(serializers.ModelSerializer):
    additional_data = AdditionalDataField(many=False)
    email_auth = EmailAuthField(many=False)
    cashier_data = CashierDataField(allow_null=True, many=False)
    is_banned = NullBooleanField()
    is_visible = NullBooleanField()
    betroute_registration = BetrouteDataField(many=False)

    class Meta:
        model = UserModel
        fields = (
            "id",
            "email_auth",
            "first_name",
            "middle_name",
            "last_name",
            "balance",
            "bonus_balance",
            "nickname",
            "role",
            "first_visit",
            "last_visit",
            "currency",
            "original_currency",
            "access_ip",
            "note",
            "additional_data",
            "lang",
            "cashbox_id",
            "cashier_data",
            "promo_code",
            "is_visible",
            "is_banned",
            "is_withdrawal_access",
            "is_deposit_access",
            "parent_cashier_id",
            "parent_admin_id",
            "parent_suadmin_id",
            "betroute_registration",
            "parent_agent_id",
            "structure_path",
            "ban_user_structure",
            "can_create_only_player"
        )

    def to_representation(self, instance: UserModel):
        return {
            'id': instance.id,
            'email_auth.email': instance.email_auth.email,
            'additional_data.email': instance.additional_data.email,
            'first_name': instance.first_name,
            'last_name': instance.last_name,
            'currency': instance.currency,
            'role': instance.role,
            'parent_agent_id': instance.parent_agent_id,
            'structure_path': instance.structure_path.path if instance.structure_path else '',
            'note': instance.note,
            'additional_data.number_document': instance.additional_data.number_document,
            'lang': instance.lang,
            'balance': instance.balance,
            'first_visit': instance.first_visit.strftime("%Y-%m-%d %H:%M:%S") if instance.first_visit else '',
            'is_visible': instance.is_visible,
            'is_withdrawal_access': instance.is_withdrawal_access,
            'is_deposit_access': instance.is_deposit_access,
            'is_banned': instance.is_banned,
            'ban_user_structure': instance.structure_is_banned,
            'can_create_only_player': instance.can_create_only_player
        }


class PartnerSerialzer(serializers.ModelSerializer):
    class Meta:
        model = UserModel
        fields = ("id", "partner_balance", "type_partner_payment")


class TerminalDataField(serializers.RelatedField):
    def to_representation(self, value: TerminalData):
        return {"min_bet_amount": value.min_bet_amount}


class CashboxField(serializers.RelatedField):
    def to_representation(self, value: CashBox):
        return {
            "address": value.address,
            "city": value.city.name,
            "city_id": value.city_id,
        }


class TerminalSerializer(AbstractSerializer):
    terminal_data = TerminalDataField(many=False)
    cashbox = CashboxField(many=False)
    email_auth = EmailAuthField(many=False)

    class Meta:
        model = UserModel
        fields = (
            "id",
            "currency",
            "email_auth",
            "terminal_data",
            "cashbox_id",
            "cashbox",
        )


class FeedbackSerializer(serializers.ModelSerializer):
    class Meta:
        model = FeedbackFormQuestionModel
        fields = ("id", "email", "name", "question", "is_closed")


class PromoCodeSerializer(AbstractSerializer):
    class Meta:
        model = PromoCodeModel
        fields = (
            "id",
            "code",
            "amount",
            "available_to",
            "single_activation",
            "code_type",
            "partner_id",
            "additional_data"
        )

    def to_representation(self, instance: PromoCodeModel):
        return {
            "id": instance.id ,
            "code": instance.code,
            "amount": instance.amount,
            "available_to": str(instance.available_to),
            "single_activation": instance.single_activation,
            "code_type": instance.code_type,
            "partner_id": instance.partner_id,
            "additional_data": instance.additional_data
    }
    def update(self, instance, validated_data):
        next_instance = super().update(instance, validated_data)
        try:
            date = validated_data.get("available_to")
            if type(date) == str:
                date = datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
                setattr(next_instance, "available_to", date)
            session = settings.SQLALCHEMY_SESSION(expire_on_commit=False)
            session.commit()
        finally:
            session.close()

        return instance


class PromocodeField(serializers.RelatedField):
    def to_representation(self, value: PromoCodeModel):
        return {
            "code": value.code,
            "code_type": value.code_type,
            "partner_id": value.partner_id,
            "amount": value.amount,
        }


class CurrencyRateSerializer(serializers.ModelSerializer):
    class Meta:
        model = CurrencyRateModel
        fields = ("id", "from_currency", "to_currency", "rate")


class InbetSessionSerializer(serializers.ModelSerializer):
    class Meta:
        model = InbetSessionModel
        fields = ("id", "session", "user_id", "create_at")


class SlideSerializer(serializers.ModelSerializer):
    class Meta:
        model = Slide
        fields = ("id", "url_image", "url", "priority", "event_id", "lang", "is_mobile")


class PromoMaterialsSerializer(serializers.ModelSerializer):
    is_active = NullBooleanField()

    class Meta:
        model = PartnerMaterialsModel
        fields = (
            "id",
            "name",
            "preview",
            "is_active",
            "category_id",
            "description",
            "created_at",
        )


class MoneyTransferSerializer(serializers.ModelSerializer):
    class Meta:
        model = MoneyTransferModel
        fields = ('id', 'type', 'from_user_id', 'to_user_id', 'value',
                  'currency', 'note', 'created_at', 'additional_data', 'description')

    def to_representation(self, instance: MoneyTransferModel):
        result = {
            'id': instance.id,
            'type': instance.type,
            'from_user_id': instance.from_user_id,
            'to_user_id': instance.to_user_id,
            'value': str(instance.value),
            'currency': instance.currency,
            'note': instance.note,
            'created_at': str(instance.created_at)[:-7],
            'description': instance.description
        }

        if instance.additional_data and instance.additional_data.get(
                'balance_before_from_user') and instance.additional_data.get('balance_before_to_user'):
            result['balance_before'] = str(instance.additional_data['balance_before_from_user']
                                           if instance.from_user_id != -1
                                           else instance.additional_data['balance_before_to_user'])
            result['balance_before'] = str(instance.additional_data['balance_before_to_user']
                                           if instance.to_user_id != -1 and
                                              instance.type not in TT.TYPES_WITHDRAWAL_BY_ADMIN_ROLES
                                           else instance.additional_data['balance_before_from_user'])
        return result


class CashierReportSerializer(serializers.ModelSerializer):
    def to_representation(self, instance: MoneyTransferModel):
        result = {
            "id": instance.id,
            "type": instance.type,
            "value": str(instance.value),
            "created_at": str(instance.created_at),
            "note": instance.note
        }

        if instance.additional_data:
            for key, value in instance.additional_data.items():
                result[key] = value

        return result


class BonusTransferSerializer(serializers.ModelSerializer):
    class Meta:
        model = BonusTransferModel
        fields = (
            "id",
            "type",
            "from_user_id",
            "to_user_id",
            "value",
            "currency",
            "created_at",
        )


class EmailNotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmailNotification
        fields = ("id", "email", "is_closed", "attempt", "context", "lang")


class NotificationSerializer(serializers.ModelSerializer):
    notification = serializers.JSONField()
    is_closed = serializers.NullBooleanField()

    class Meta:
        model = NotificationModel
        fields = ("id", "notification", "is_closed")

    def to_representation(self, instance: NotificationModel):
        result = {
            "id": instance.id,
            "notification": instance.notification.get('notification'),
            "is_closed": instance.is_closed
        }

        return result


class UserField(serializers.RelatedField):
    def to_representation(self, value: UserModel):
        return {"email_auth": {"email": value.email_auth.email}, "id": value.id}


class WithdrawalSerializer(serializers.ModelSerializer):
    class Meta:
        model = WithdrawalModel
        fields = (
            "id",
            "payment_mode",
            "purse",
            "amount",
            "status",
            "currency",
            "user_id",
        )

    def to_representation(self, instance: WithdrawalModel):
        result = {
            "id": instance.id,
            "user_id": instance.user_id,
            "payment_mode": instance.payment_mode,
            "purse": instance.purse,
            "amount": str(instance.amount),
            "currency": instance.currency,
            "status": instance.status,
            "created_at": str(instance.created_at),
            "user.additional_data.phone": instance.user.additional_data.phone,
            "user.parent_admin_id": instance.user.parent_admin_id,
            "user.parent_suadmin_id": instance.user.parent_suadmin_id,
            "user.parent_cashier_id": instance.user.parent_cashier_id,
            "is_closed": str(instance.is_closed)
        }
        return result

    def update(self, instance, validated_data, **kwargs):
        next_instance = super().update(instance, validated_data)
        if (
            int(validated_data.get("status", None)) == instance.CANCELED
            and next_instance.status != instance.CANCELED
        ):
            try:
                session = settings.SQLALCHEMY_SESSION(expire_on_commit=False)
                money_manager = MoneyManager(session)
                transfer = money_manager.withdrawal_transfer_cancel(
                    instance.user_id, instance.amount
                )
                setattr(next_instance, "transfer_cancel_id", transfer.id)
                setattr(next_instance, 'is_closed', True)
                session.add(next_instance)
                session.commit()
            finally:
                session.close()
        return instance


class BetContentSerializer(serializers.ModelSerializer):
    def to_representation(self, instance: BetContentDataModel):
        result = {
            "main_result": instance.betroute_local_bet.status,
            "tournament_name": instance.tournament_name,
            "teams": instance.teams,
            "bet_name": instance.bet_name,
            "coef": str(instance.coef),
            "event_date": str(instance.event_date),
            "betroute_local_bet.betcode": instance.betroute_local_bet.betcode,
            "betroute_local_bet.from_user_id": instance.betroute_local_bet.from_user_id,
        }
        status = BetStatus
        for key, value in status.CALCULATION_STATE_FOR_BETS.items():
            if result["main_result"] == int(value):
                result['main_result'] = key
        return result


class PartnerMoneySerializer(serializers.ModelSerializer):
    class Meta:
        model = PartnerMoneyTransfer
        fields = [
            "id",
            "user_id",
            "value",
            "currency",
            "type",
            "status",
            "method",
            "type_credit",
            "created_at",
        ]


class MoneyTransferField(serializers.RelatedField):

    def to_representation(self, value: MoneyTransferModel):
        return {
            "id": value.id,
            "type": value.type,
            "from_user_id": value.from_user_id,
            "to_user_id": value.to_user_id,
            "value": str(value.value) + ' ' + str(value.currency),
            "note": value.note,
            "created_at": str(value.created_at),
            "additional_data": value.additional_data
        }


class CategorySerializer(serializers.ModelSerializer):
    active = NullBooleanField()

    class Meta:
        model = CategoryModel
        fields = ["id", "name", "active"]


class PromoCodeActivationSerializer(AbstractSerializer):
    user = UserField(many=False)
    promo_code = PromocodeField(many=False)
    is_banned = NullBooleanField()
    additional_data = JSONField()
    transfer = MoneyTransferField(many=False)

    class Meta:
        model = PromoCodeActivationModel
        fields = ['id', 'user', 'promo_code', 'created_at', 'is_banned',
                  'additional_data', 'note', 'transfer']

    def define_is_active(self, info: dict or None,
                         instance: PromoCodeActivationModel):
        if not info:
            return 'Нет'

        if info['hasWithdrawals'] or instance.is_banned or instance.transfer:
            return 'Нет'
        else:
            return 'Да'

    def to_representation(self, instance: PromoCodeActivationModel):
        result = super().to_representation(instance)

        try:

            result['promo_code']['amount'] = instance.get_amount()
            if not result['transfer']:
                result['transfer'] = {}

            session = inspect(instance).session

            promo_manager = PromocodeManager(session)

            cur = instance.user.currency

            info = promo_manager.get_stobonus_info(instance.user_id) if \
                instance.promo_code.code_type == \
                instance.promo_code.TYPE_STOBONUS else {}

            result['personalBonusAmount'] = \
                str(info.get('personalBonusAmount', '?')) + ' ' + cur

            result['betAmount'] = \
                str(info.get('currentBetAmount', '?')) + ' / ' + \
                str(info.get('targetBetAmount', '?')) + ' ' + cur

            result['is_active'] = self.define_is_active(info, instance)

            result['progress'] = str(info.get('progress', '?')) + ' %'

            result['hasWithdrawals'] = \
                str('Да' if info.get('hasWithdrawals') else 'Нет')

            result['transfer']['value'] = instance.get_already_filled()

        except Exception:
            return {}

        return result


class JackpotSerializer(serializers.ModelSerializer):
    class Meta:
        model = JackpotModel
        fields = (
            "id",
            "image",
            "name",
            "amount",
            "is_active",
            "pay",
            "min_amount",
            "min_probability",
            "max_probability",
            "first_amount",
            "amount_percent",
            "timer",
        )


class SecurityLogSerializer(serializers.ModelSerializer):
    def to_representation(self, instance: SecurityLogModel):
        result = {
            "id": instance.id,
            "user_id": instance.user_id,
            "ip_address": instance.ip_address,
            "request_from": instance.request_from,
            "operation": instance.operation,
            "request_body": str(instance.request_body),
            "note": instance.note,
            "created_at": instance.created_at.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3],
        }
        return result


class BetLine1xSerializer(serializers.ModelSerializer):
    def to_representation(self, instance: BetsLine1xModel):
        result = {
            "type": instance.type,
            "sport_id": instance.sport_id,
            "country_id": instance.country_id,
            "champ_name": instance.champ_name,
            "teams": instance.teams,
            "market_name": instance.market_name,
            "bet_name": instance.bet_name,
            "coeff": str(instance.coeff),
            "start_date": instance.start_date.strftime('%Y-%m-%dT%H:%M:%S.%f')[:-3],
            "local_coupon.status": instance.local_coupon.status,
            "bet_status": Bet1xStatus.STATUS_REPRESENTATION.get(instance.status),
            "local_coupon.remote_coupon_id": instance.local_coupon.remote_coupon_id,
            "local_coupon.user_id": instance.local_coupon.user_id,
            "local_coupon.amount": instance.local_coupon.amount,
            "local_coupon.win_transfer.value": float(instance.local_coupon.win_transfer.value) if instance.local_coupon.win_transfer else 0,
            "score": instance.score,
            "remote_bet_code": instance.remote_bet_code,
        }

        additional_data = instance.local_coupon.bet_transfer.additional_data
        if additional_data:
            result['balance_before'] = additional_data['balance_before_from_user']
        return result


class ExceededMoneyTransferSerializer(serializers.ModelSerializer):
    class Meta:
        model = MoneyTransferModel
        fields = ('id', 'type', 'to_user_id', 'value', 'real_value', 'transfer_value', 'transfer_id'
                  'currency', 'note', 'created_at')

    def to_representation(self, instance: MoneyTransferModel):
        result = {
            'id': instance.id,
            'type': instance.type,
            'value': str(instance.value),
            'currency': instance.currency,
            'note': instance.note,
            'created_at': str(instance.created_at),
            'full_value': instance.additional_data.get("full_value") if instance.additional_data else None,
            'user_value': instance.additional_data.get('user_value') if instance.additional_data else None,
            'to_user_id': instance.additional_data.get("transfer_user_id") if instance.additional_data else None,
            'original_note': instance.additional_data.get('original_note') if instance.additional_data else None
        }
        return result
class ProviderSerializer(serializers.ModelSerializer):
    is_active = NullBooleanField()

    class Meta:
        model = ProviderModel
        fields = ("id", "name", "is_active")


class SettingsSerializer(serializers.ModelSerializer):
    class Meta:
        model = SettingsModel
        fields = (
            "id",
            "name",
            "data"
        )

    def to_representation(self, instance: MoneyTransferModel):
        result = {
            "id": instance.id,
            "name": instance.name,
            "data": str(instance.data)
        }
        return result
