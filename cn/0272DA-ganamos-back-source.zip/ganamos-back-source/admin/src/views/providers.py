from aiorest_ws.routers import SimpleRouter

from admin.src.serializers import ProviderSerializer
from betronic_core.blocklist_manager.manager import BlocklistManager
from betronic_core.db.models.permission_details import ProviderModel
from betronic_core.db.models.user import UserModel

from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session


class ProviderCRUDView(AbstractCRUDView):
    model = ProviderModel
    serializer = ProviderSerializer

    roles = {
        "GET": (UserModel.OWNER, UserModel.LIMITED_OWNER),
        "CREATE": (),
        "UPDATE": (UserModel.OWNER, UserModel.LIMITED_OWNER),
        "DELETE": (),
    }


    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)
        items, count = self.model.query_by_params(
            query=query,
            session=session,
            fields=ProviderSettingsCRUDView.fields,
            **kwargs,
        )
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}
    
    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        is_active = request.data.get("is_active", False)
        instance = session.query(self.model).filter(self.model.id == id).first()
        instance.is_active = is_active
        session.add(instance)
        session.commit()

        if not is_active:
            BlocklistManager(session).add_global_block_provider(instance.name)
        else:
            BlocklistManager(session).remove_global_block_provider(instance.name)

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = (
            self._get_model_by_id(session, int(id), **kwargs)
            if id
            else self._get_model_all(session, **kwargs)
        )
        return result


class ProviderSettingsCRUDView(AbstractSettingsView):
    view = ProviderCRUDView

    fields = {
        "name": {
            "type": "text",
            "name": "provider name",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": -1,
        },
        "is_active": {
            "type": "boolean",
            "name": "is_active",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": -1,
        },
    }


router = SimpleRouter()
router.register("/providers/settings", ProviderSettingsCRUDView, "GET")
router.register("/providers/list", ProviderCRUDView, "GET")
router.register("/providers/{id}", ProviderCRUDView, ["GET", "PUT"])
