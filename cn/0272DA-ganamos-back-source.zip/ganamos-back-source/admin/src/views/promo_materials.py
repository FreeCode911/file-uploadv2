from aiorest_ws.routers import SimpleRouter
from betronic_core.db.models.partner_materials import PartnerMaterialsModel
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from admin.src.serializers import PromoMaterialsSerializer
from betronic_core.db.models.user import UserModel
from admin.src.utils.decorators import permission, session
from admin.src.utils.img_upload import upload_promo
from betronic_core.db.models.category import CategoryModel
from datetime import datetime as dt


class PromoMaterialsCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }

    model = PartnerMaterialsModel
    serializer = PromoMaterialsSerializer

    @session
    @permission
    def post(self, request, *args, **kwargs):
        session = kwargs.get('session')

        preview = request.data.get('fileToUpload').get('preview', None)
        filename = request.data.get('fileToUpload').get('filename', None)

        assert preview and filename

        new_material = self.model()
        for key, value in request.data.items():
            if key not in ['fileToUpload']:
                setattr(new_material, key, value)

        new_material.preview = upload_promo(**preview)
        new_material.filename = upload_promo(**filename)
        new_material.created_at = dt.now()
        session.add(new_material)
        session.commit()


class PromoMaterialsSettingsCRUDView(AbstractSettingsView):
    view = PromoMaterialsCRUDView

    @session
    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)
        session = kwargs.get('session')
        categories = session.query(CategoryModel.id, CategoryModel.name)\
            .filter(CategoryModel.active != False).all()
        enum_categories = {}
        for category in categories:
            enum_categories[category.id] = category.name
        self.fields['category_id']['enum'] = enum_categories

        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "name": {
            "type": "text",
            "name": "Имя материала",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "preview": {
            "type": "file",
            "name": "Превью (200x200px, .png, .jpeg)",
            "order": True,
            "filter": False,
            "table": False,
            "editable": True,
        },
        "filename": {
            "type": "file",
            "name": "Материалы (.zip, .png, .jpeg)",
            "order": True,
            "filter": False,
            "table": False,
            "editable": True,
        },
        "category_id": {
            "type": "enum",
            "name": "Категория",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True
        },
        "is_active": {
            "type": "boolean",
            "name": "Активен",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "description": {
            "type": "textarea",
            "name": "Описание",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True
        }
    }


router = SimpleRouter()
router.register('/promo_materials/create', PromoMaterialsCRUDView, ['POST'])
router.register('/promo_materials/settings', PromoMaterialsSettingsCRUDView,
                'GET')
router.register('/promo_materials/list', PromoMaterialsCRUDView, ['GET'])
router.register('/promo_materials/{id}', PromoMaterialsCRUDView,
                ['GET', 'PUT', 'DELETE'])
