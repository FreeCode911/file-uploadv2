import re
import asyncio
from logging import getLogger

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import and_
from sqlalchemy_utils import Ltree
from tornado.options import options

from admin.src.serializers import UserSerializer
from admin.src.utils.user_mixin import UserMixin
from betronic_core.cache_manager.manager import CacheManager, AsyncCacheManager
from betronic_core.digitain_fetcher.fetcher import DigitainFetcher
from betronic_core.user_manager.manager import UserManager
from betronic_core.db.database import DataBase
from betronic_core.host_manager.manager import HostManager
from bookmakers.user.service.handlers.registration import RegisterUserWithUsernameHandler
from betronic_core.db.models.user import UserModel
from util.error import InvalidRequestData
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session
from ..utils.remote_services_api_mixin import RemoteServicesAPIMixin


logger = getLogger(__name__)
event_loop = asyncio.get_event_loop()


class UserListCRUDView(AbstractCRUDView, UserMixin, RemoteServicesAPIMixin):
    model = UserModel
    serializer = UserSerializer

    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.TECHSUPPORT, UserModel.CASHIER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.TECHSUPPORT, UserModel.CASHIER),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.TECHSUPPORT, UserModel.CASHIER),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.TECHSUPPORT, UserModel.CASHIER),
    }

    def __init__(self):
        self.db = DataBase.get()
        self.documents = DataBase.get_settings()

    def get_query(self, session, admin_id=None, admin_role=UserModel.LIMITED_OWNER):
        query = session.query(self.model).filter(
            and_(
                self.model.id > 0,
                self.model.role.in_((UserModel.PARTNER_AGENT, UserModel.USER))
            )
        )

        return query

    def _get_digitain_user(self, user_id: int, **kwargs):
        token = self._generate_token_for_remote_service(**kwargs)
        try:
            digitain_user_info = DigitainFetcher.get_user_info(token=token, user_id=user_id)
        except Exception as e:
            logger.error(f'Digitain "get user settings" error: {e}')
            digitain_user_info = dict()

        return digitain_user_info

    def _get_model_all(self, session, admin_user=None, **kwargs):
        query = self.get_query(session, admin_id=admin_user['id'], admin_role=admin_user['role'])

        items, count = self.model \
            .query_by_params(query, session, **kwargs)

        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    def _get_model_by_id(self, session, id, admin_user=None, **kwargs):
        user = self.get_query(session).filter(self.model.id == id).first()
        if not user:
            raise Exception("Resource not exist")

        data = self.serializer(user).data

        digitain_user = self._get_digitain_user(user.id, **kwargs)
        data.update(digitain_user)
        return data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user, **kwargs) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result

    @permission
    def post(self, request, *args, **kwargs):
        request_data = {**request.data}

        logger.info('register user from arguments: %s' % request.data)

        username = request_data.get('email_auth.email', '').lower()
        password = request_data.get('password')

        parent_agent_id = request_data.get('parent_agent_id')
        role = request_data.get('role', '0')
        note = request_data.get('note', '')
        is_withdrawal_access = request_data.get('is_withdrawal_access', True)
        is_deposit_access = request_data.get('is_deposit_access', True)
        can_create_only_player = request_data.get('can_create_only_player', False)

        extra_email = request_data.get('additional_data.email')
        first_name = request_data.get('first_name')
        last_name = request_data.get('last_name')

        currency = options.AVAILABLE_CURRENCIES[
            int(request_data.get('currency_enum', 0))
        ]

        host_manager = HostManager(self.db)

        if UserModel.get_by_nickname(self.db, username):
            raise Exception(f"User with nickname: {username} - already exist")

        if role == UserModel.USER and not parent_agent_id:
            raise Exception('User cannot be created without an agent parent')

        parent_agent = None
        if parent_agent_id:
            parent_agent: UserModel = UserModel.get_by_id(self.db, user_id=parent_agent_id)
            if not parent_agent:
                raise Exception(f'Parent agent ID {parent_agent_id} '
                                f'does not exists')
            if parent_agent.role != UserModel.PARTNER_AGENT:
                raise Exception(f'You can only link an '
                                f'agent with an agent role')
            if parent_agent.currency != currency:
                raise Exception(f'Currency of the partner agent and '
                                f'the user being created does not match')

        user_create_data = {
            "username": username,
            "password": password,
            "currency": currency,
            "is_user": True if role != UserModel.PARTNER_AGENT else False,
            'domain': None,

            "email": extra_email,
            "first_name": first_name,
            "last_name": last_name
        }

        status, result, error_message, _ = RegisterUserWithUsernameHandler(
            args=user_create_data,
            db=self.db
        ).get_result(with_close_session=False)

        if error_message:
            raise InvalidRequestData(status, error_message)

        user_id = result.get('user_id')
        if not user_id:
            raise Exception(f'User is not created. Response status {status} with result: {result}')

        user: UserModel = UserModel.get_by_id(self.db, user_id)
        if not user:
            raise Exception(f'User with ID {user_id} not found')

        user.note = note
        user.role = role
        user.is_withdrawal_access = is_withdrawal_access
        user.is_deposit_access = is_deposit_access
        user.can_create_only_player = can_create_only_player

        if role == UserModel.PARTNER_AGENT:
            user.changed_password = True

        if parent_agent:
            user.parent_agent_id = parent_agent.id
            user.structure_path = parent_agent.structure_path + Ltree(str(user.id))
            user.currency = parent_agent.currency
            host_manager\
                .create_parent_permissions_for_user(
                    source_user=parent_agent,
                    target_user=user
                )
        else:
            user.structure_path = Ltree(str(user.id))

        self.db.add(user)
        self.db.commit()

        return result

    @permission
    def put(self, request, *args, **kwargs):
        user: UserModel = UserModel.get_by_id(self.db, args[0])
        username = request.data.get('email_auth.email')
        password = request.data.get('password')
        is_banned = request.data.get('is_banned')
        parent_agent_id = request.data.get('parent_agent_id')
        close_all_active_sessions = request.data.get('close_all_active_sessions')
        ban_user_structure = request.data.get('ban_user_structure')
        is_withdrawal_access = request.data.get('is_withdrawal_access')
        is_deposit_access = request.data.get('is_deposit_access')
        can_create_only_player = request.data.get('can_create_only_player')

        user_manager = UserManager(self.db)

        parent_agent_id = int(parent_agent_id) if parent_agent_id else None
        if parent_agent_id and parent_agent_id < 0:
            raise Exception('It is forbidden to install IDs on service accounts')

        if username and username != user.email_auth.email:
            if UserModel.get_by_email(self.db, email=username):
                raise Exception(f'Username {username} already exists')

            user.email_auth.email = username
            user.nickname = username

        if password:
            user.email_auth.set_password(password)
            admin = self.get_user(**kwargs)
            note = f'The user with ID {admin["id"]} changed the password for the user with ID {args[0]}'
            user_manager.security_log(args[0], request.extra_user_ip, "admin", "change password", request.data, note)

        if is_banned != user.is_banned:
            user.is_banned = is_banned

            if not is_banned:
                user.email_auth.email = user.email_auth.email.replace("deleted_", "")

            self.db.add(user)
            self.db.commit()

        if is_withdrawal_access != user.is_withdrawal_access:
            user.is_withdrawal_access = is_withdrawal_access
            self.db.add(user)
            self.db.commit()

        if is_deposit_access != user.is_deposit_access:
            user.is_deposit_access = is_deposit_access
            self.db.add(user)
            self.db.commit()

        if is_banned or close_all_active_sessions or (is_withdrawal_access is False) or (is_deposit_access is False):
            CacheManager.close_all_sessions_by_user_id(user.id)

        if user.structure_is_banned != ban_user_structure:
            banned_users = user_manager.ban_user_ltree_structure(
                source_entity=user,
                ban_status=ban_user_structure
            )
            if ban_user_structure is True:
                event_loop.create_task(
                    AsyncCacheManager.close_all_sessions_by_user_ids(
                        user_ids=[u.id for u in banned_users]
                    )
                )

        if parent_agent_id != user.parent_agent_id:
            if parent_agent_id is not None:
                parent_agent = user_manager.get_user_by_id(
                    user_id=parent_agent_id
                )
                user_manager.set_ltree_user_structure(
                    source_entity=user,
                    target_entity=parent_agent
                )

            elif parent_agent_id is None:
                user_manager.set_ltree_user_structure(
                    source_entity=user,
                    target_entity=None
                )

        if can_create_only_player != user.can_create_only_player:
            user.can_create_only_player = can_create_only_player

        self.db.add(user)
        self.db.commit()

        data = self.serializer(user).data
        return data


    @session
    def delete(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        if not id:
            raise Exception("Id is not defined")

        instance = self.get_query(session).filter(self.model.id == int(id)).first()
        if not instance:
            raise Exception('Object does not exist')

        instance.is_banned = True
        instance.email_auth.email = "deleted_" + instance.email_auth.email
        session.add(instance)
        session.commit()
        CacheManager.close_all_sessions_by_user_id(id)
        return self._get_model_all(session, admin_user, **kwargs)


class UserSettingsView(AbstractSettingsView):
    view = UserListCRUDView

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        fields = self.fields.copy()
        permissions = self.get_permission(user, self.view.roles)

        return {
            "fields": fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "email_auth.email": {
            "type": "text",
            "name": "Логин",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "weight": 2,
            "editableWeight": 1
        },
        "password": {
            "type": "text",
            "name": "Пароль",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 2
        },
        "currency_enum": {
            "type": "enum",
            "name": "Валюта",
            "enum": options.AVAILABLE_CURRENCIES,
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 6
        },
        "role": {
            "type": "enum",
            "name": "Роль",
            "enum": UserModel.ROLES_FOR_BLUE_ADMIN_REGISTRATION,
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "weight": 10,
            "editableWeight": 6
        },
        "parent_agent_id": {
            "type": "number",
            "name": "ID агента",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "editableWeight": 8,
            "weight": 8
        },
        "structure_path": {
            "type": "text",
            "name": "Структура",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 9
        },
        "note": {
            "type": "text",
            "name": "Заметка",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 12
        },
        "lang": {
            "type": "text",
            "name": "Язык",
            "order": False,
            "filter": False,
            "table": False,
            "editable": False
        },
        "additional_data.email": {
            "type": "text",
            "name": "Email",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True
        },
        "first_name": {
            "type": "text",
            "name": "Name ",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True
        },
        "last_name": {
            "type": "text",
            "name": "Surname",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True
        },
        "is_withdrawal_access": {
            "type": "boolean",
            "name": "Разрешен ли вывод?",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 13,
            "editableWeight": 12
        },
        "is_deposit_access": {
            "type": "boolean",
            "name": "Разрешен ли депозит?",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 13,
            "editableWeight": 12
        },
        "balance": {
            "type": "number",
            "name": "Баланс",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 14
        },
        "first_visit": {
            "type": "date",
            "name": "Первый визит",
            "order": True,
            "filter": True,
            "table": False,
            "editable": False,
        },
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 13
        },
        "original_currency": {
            "type": "text",
            "name": "Оригинальная валюта",
            "order": True,
            "filter": True,
            "table": False,
            "editable": False,
        },
        "is_visible": {
            "type": "boolean",
            "name": "Видим",
            "is_checked": True,
            "order": False,
            "filter": False,
            "table": False,
            "editable": False,
        },
        "is_banned": {
            "type": "boolean",
            "name": "Бан",
            "order": True,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 13
        },
        "close_all_active_sessions": {
            "type": "boolean",
            "name": "Закрыть все активные сессии",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 14
        },
        "ban_user_structure": {
            "type": "boolean",
            "name": "Бан всей структуры",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 15
        },
        "digitain_client_id": {
            "type": "text",
            "name": "Digitain client id",
            "order": False,
            "filter": False,
            "table": False,
            "editable": False,
        },
        "can_create_only_player": {
            "type": "boolean",
            "name": "Разрешить создание только игроков ?",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "editableWeight": 16
        }
    }


router = SimpleRouter()
router.register('/user/list', UserListCRUDView, 'GET')
router.register('/user/settings', UserSettingsView, 'GET')
router.register('/user/{id}', UserListCRUDView, ['GET', 'PUT', 'CREATE'])
