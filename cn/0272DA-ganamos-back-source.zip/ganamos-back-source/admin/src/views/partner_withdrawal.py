from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from admin.src.serializers import PartnerMoneySerializer
from betronic_core.constants import PartnerTypePayment, \
    PartnerStatusMoneyTransfer, PartnerTypeMoneyTransfer, TransferTypes
from admin.src.utils.decorators import session, permission
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.db.models.currency_rate import CurrencyRateModel


class PartnerWithdrawals(AbstractCRUDView):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
    }

    model = PartnerMoneyTransfer
    serializer = PartnerMoneySerializer

    def _get_model_all(self, session, **kwargs):
        q = session.query(self.model).filter(
            self.model.type == PartnerTypeMoneyTransfer.TYPE_WITHDRAWAL)
        items, count = self.model.query_by_params(session, query=q, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    @session
    @permission
    def put(self, request, id, *args, **kwargs):
        session = kwargs.get('session')
        status = int(request.data.get('status', None))

        assert status

        withdrawal: self.model = self.model.get_by_id(session, id)

        assert not withdrawal.status == PartnerStatusMoneyTransfer.DENIED
        assert not withdrawal.status == PartnerStatusMoneyTransfer.DONE

        withdrawal.status = status
        session.add(withdrawal)

        money_manager = MoneyManager(session)

        if status == PartnerStatusMoneyTransfer.DONE:

            converted_value = CurrencyRateModel.convert(
                session, withdrawal.value, withdrawal.currency,
                withdrawal.user.currency)

            money_manager.user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=withdrawal.user_id, value=converted_value,
                transfer_type=TransferTypes.TYPE_PARTNER_WITHDRAWAL,
                additional_data={'partner_transfer_id': withdrawal.id})

        if status == PartnerStatusMoneyTransfer.DENIED:
            money_manager.partner_move_money(
                user_id=withdrawal.user_id, value=withdrawal.value,
                type_payment=PartnerTypePayment.DENY_WITHDRAWAL)


    @session
    @permission
    def delete(self, request, id=None, *args, **kwargs):
        session = kwargs.get('session')

        withdrawal: self.model = self.model.get_by_id(session, id)

        assert not withdrawal.status == PartnerStatusMoneyTransfer.DENIED
        assert not withdrawal.status == PartnerStatusMoneyTransfer.DONE

        withdrawal.status = PartnerStatusMoneyTransfer.DENIED
        session.add(withdrawal)

        money_manager = MoneyManager(session)

        money_manager.partner_move_money(
            user_id=withdrawal.user_id, value=withdrawal.value,
            type_payment=PartnerStatusMoneyTransfer.DENIED)


class PartnerWithdrawalsSettings(AbstractSettingsView):
    view = PartnerWithdrawals
    fields = {
        'id': {
            'type': 'number',
            'name': 'ID Транзакции',
            'order': False,
            'filter': False,
            'table': False,
            'editable': False,
        },
        'user_id': {
            'type': 'number',
            'name': 'ID Пользователя',
            'order': False,
            'filter': True,
            'table': True,
            'editable': False,
        },
        'value': {
            'type': 'text',
            'name': 'Сумма вывода',
            'order': True,
            'filter': True,
            'table': True,
            'editable': False,
        },
        'currency': {
            'type': 'text',
            'name': 'Валюта вывода',
            'order': False,
            'filter': True,
            'table': True,
            'editable': False,
        },
        'status': {
            'type': 'enum',
            'name': 'Статус вывода',
            'order': False,
            'filter': True,
            'table': True,
            'editable': True,
            'enum': PartnerStatusMoneyTransfer.StatusesName
        },
        'created_at': {
            'type': 'date',
            'name': 'Дата создания',
            'order': True,
            'filter': True,
            'table': True,
            'editable': False,
        }
    }


router = SimpleRouter()
router.register(
    '/partner_withdrawals/list', PartnerWithdrawals, ['GET'])
router.register(
    '/partner_withdrawals/settings', PartnerWithdrawalsSettings, ['GET'])
router.register(
    '/partner_withdrawals/{id}', PartnerWithdrawals, ['GET', 'PUT', 'DELETE'])
