from datetime import datetime, timedelta

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import func

from betronic_core.db.database import DataBase
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.constants import TransferTypes
from betronic_core.db.models.user import UserModel
from admin.src.serializers import ExceededMoneyTransferSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from admin.src.utils.user_mixin import UserMixin


transfer_types = TransferTypes.TYPES


class ExceededTransferCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }
    model = MoneyTransferModel
    serializer = ExceededMoneyTransferSerializer

    def __init__(self):
        self.db = DataBase.get()

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)
        query = query.filter(self.model.note == 'Win overflow')

        sum_query = session.query(func.sum(self.model.value))
        sum_query = sum_query.filter(self.model.note == 'Win overflow')

        date_from = datetime.today() - timedelta(days=1)

        try:
            if kwargs['filters']['created_at']:
                pass
        except KeyError:
            kwargs['filters']['created_at'] = {
                'from': date_from.strftime('%Y-%m-%d'),
                'to': datetime.today().strftime('%Y-%m-%d')
            }

        if 'order_by' in kwargs:
            if kwargs['order_by'] == '-id':
                kwargs['order_by'] = '-created_at'
            elif kwargs['order_by'] == 'id':
                kwargs['order_by'] = 'created_at'
        sum_value = 0

        if kwargs['filters'].get('type'):
            items, count, sum_value = self.model.query_by_params(
                query,
                session,
                sum_query=sum_query,
                sum="value",
                fields=ExceededTransferSettingsView.fields,
                **kwargs
            )
        else:
            items, count = self.model.query_by_params(
                query,
                session,
                fields=ExceededTransferSettingsView.fields,
                **kwargs
            )

        data = self.serializer(items, many=True).data
        return {"items": data, "count": count, "sum": str(round(sum_value, 3))}


class ExceededTransferSettingsView(AbstractSettingsView):
    view = ExceededTransferCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1,
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": transfer_types,
            "weight": 2
        },
        "to_user_id": {
            "type": "number",
            "name": "К какому пользователя ID",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "value": {
            "type": "number",
            "name": "Превышенная сумма",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4,
        },
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "note": {
            "type": "text",
            "name": "Заметка",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 8,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        }
    }


router = SimpleRouter()
router.register('/exceeded_transfers/settings', ExceededTransferSettingsView, 'GET')
router.register('/exceeded_transfers/list', ExceededTransferCRUDView, 'GET')
router.register('/exceeded_transfers/{id}', ExceededTransferCRUDView, ['GET', 'PUT'])
