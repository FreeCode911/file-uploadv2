from aiorest_ws.routers import SimpleRouter
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from admin.src.serializers import ReportsSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.constants import TransferTypes
from admin.src.utils.user_mixin import UserMixin


class ReportsCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.CASHIER, UserModel.SUPER_ADMIN),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }
    model = MoneyTransferModel
    serializer = ReportsSerializer

    def get_query(self, session, admin):
        query = session.query(self.model).filter(self.model.type.in_(
            TransferTypes.TYPES_REPORT_TYPES.keys()))
        if admin['role'] not in [UserModel.OWNER, UserModel.LIMITED_OWNER]:
            user_list = UserModel.get_binding_users(session, admin['id'], admin['role'])
            if user_list:
                users_id_list = [user.id for user in user_list]
                query = query.filter(self.model.from_user_id.in_(users_id_list) | \
                                     self.model.to_user_id.in_(users_id_list))

        return query

    def _get_model_by_id(self, session, id, **kwargs):
        admin = self.get_user(**kwargs)
        item = self.get_query(session, admin).filter(self.model.id == id).first()
        if not item:
            raise Exception("Resource not exist")
        return self.serializer(item).data

    def _get_model_all(self, session, **kwargs):
        admin = self.get_user(**kwargs)
        query = self.get_query(session, admin)
        items, count, sum_value = self.model.query_by_params(query, session, sum='value', **kwargs)
        data = self.serializer(items, many=True).data
        return {
            'items': data,
            'count': count,
            'sum': str(sum_value)
        }


class ReportsSettingsView(AbstractSettingsView):
    view = ReportsCRUDView
    additional_settings = {
        'manage_rows': True,
    }

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)

        if user['role'] not in [UserModel.OWNER, UserModel.LIMITED_OWNER]:
            cashier_roles = {
                UserModel.USER: 'Пользователь',
                UserModel.CASHIER: 'Кассир',
                UserModel.ADMIN: 'Администратор'
            }
            self.fields['real_from_user.role']['enum'] = \
                self.fields['real_to_user.role']['enum'] = cashier_roles
            self.fields['type']['enum'] = TransferTypes.TYPES_REPORT_TYPES_CA
        else:
            self.fields['type']['enum'] = TransferTypes.TYPES_REPORT_TYPES
            self.fields['real_from_user.role']['enum'] = \
                self.fields['real_to_user.role']['enum'] = UserModel.ROLES

        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": False,
            "filter": False,
            "table": False,
            "editable": False,
            "weight": -1,
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": TransferTypes.TYPES_REPORT_TYPES,
            "weight": 2,
        },
        "real_from_user.role": {
            "type": "enum",
            "name": "От кого роль",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
            "enum": UserModel.ROLES,
            "weight": 2
        },
        "real_to_user.role": {
            "type": "enum",
            "name": "К кому роль",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
            "enum": UserModel.ROLES,
            "weight": 4
        },
        "real_from_user_id": {
            "type": "number",
            "name": "От кого ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 3,
        },
        "real_to_user_id": {
            "type": "number",
            "name": "К кому ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 5,
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1,
            "default": "today"
        },
    }


router = SimpleRouter()
router.register('/reports/settings', ReportsSettingsView, 'GET')
router.register('/reports/list', ReportsCRUDView, 'GET')
router.register('/reports/{id}', ReportsCRUDView, ['GET', 'PUT'])
