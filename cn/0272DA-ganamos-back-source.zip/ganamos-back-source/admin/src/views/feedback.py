from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.feedback_form_question import \
    FeedbackFormQuestionModel
from betronic_core.db.models.user import UserModel
from admin.src.serializers import FeedbackSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class FeedBackListCRUDView(AbstractCRUDView):
    model = FeedbackFormQuestionModel
    serializer = FeedbackSerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class FeedBackSettingsView(AbstractSettingsView):
    view = FeedBackListCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "email": {
            "type": "html",
            "name": "Email",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "name": {
            "type": "number",
            "name": "Имя",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "question": {
            "type": "text",
            "name": "Вопрос",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "is_closed": {
            "type": "boolean",
            "name": "Закрыта",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/feedback/list', FeedBackListCRUDView, 'GET')
router.register('/feedback/settings', FeedBackSettingsView, 'GET')
router.register('/feedback/create', FeedBackListCRUDView, 'POST')
router.register('/feedback/{id}', FeedBackListCRUDView,
                ['GET', 'PUT', 'DELETE'])
