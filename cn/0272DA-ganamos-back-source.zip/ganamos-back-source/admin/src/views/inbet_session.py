from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.inbet import InbetSessionModel
from admin.src.serializers import InbetSessionSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.db.models.user import UserModel


class InbetSessionCRUDView(AbstractCRUDView):
    model = InbetSessionModel
    serializer = InbetSessionSerializer
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class InbetSessionPageSettingsView(AbstractSettingsView):
    view = InbetSessionCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "session": {
            "type": "text",
            "name": "Сессия",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "user_id": {
            "type": "number",
            "name": "Id пользователя",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "create_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
    }


router = SimpleRouter()
router.register('/inbet_session/settings', InbetSessionPageSettingsView, 'GET')
router.register('/inbet_session/list', InbetSessionCRUDView, 'GET')
# router.register('/inbet_session/create', InbetSessionCRUDView, 'POST')
router.register('/inbet_session/{id}', InbetSessionCRUDView, ['GET'])
