from random import choice
from string import ascii_uppercase

import ujson as json
from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from admin.src.serializers import SlideSerializer
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.db.database import DataBase
from betronic_core.db.models.slide import Slide
from betronic_core.db.models.user import UserModel
from betronic_core.s3_fetcher.fetcher import S3CloudBucketFetcher
from settings.setup_settings import get_all_settings
from util.redis import SyncRedisWrapperLocal
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission

settings = get_all_settings()


class SlideCRUDView(AbstractCRUDView):
    model = Slide
    serializer = SlideSerializer

    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
    }

    def __init__(self):
        self.db = DataBase.get()

    @permission
    def post(self, request, *args, **kwargs):
        data = request.data
        image = data.get('image', None)
        ext = data.get('ext', None)

        s3_uploader = S3CloudBucketFetcher(
            access_key=options.CLOUD_AGENT_ACCESS_KEY,
            secret_access_key=options.CLOUD_AGENT_SECRET_ACCESS_KEY,
            base_folder=options.ADMIN_SLIDE_IMAGE_DIRNAME
        )
        img_url = s3_uploader.upload_media_from_b64_data(
            b64_data=image,
            file_ext=ext,
            file_name=''.join(choice(ascii_uppercase) for _ in range(20))
        )

        new_data = {
            'url_image': img_url.replace(options.PROJECT_NAME, ""),
            'url': data.get('url', None),
            'is_mobile': data.get('is_mobile', False),
            'priority': int(data.get('priority', None)),
            'event_id': data.get('event_id', None),
            'lang': data.get('lang', 0)
        }
        request._data = new_data
        new_slide = super(SlideCRUDView, self).post(request, *args, **kwargs)

        cached_slides = SyncRedisWrapperLocal(
            db=options.REDIS_SLIDE_DB,
            connection_data=options.REDIS_REVOLUTION
        ).get(options.SLIDE_CACHING_KEY)
        if cached_slides:
            new_data["lang"] = options.LANGUAGES_FOR_ADMIN[data.get('lang', 0)]
            new_data["id"] = new_slide["id"]

            new_list_of_slide = json.loads(cached_slides)
            new_list_of_slide.append(new_data)
            CacheManager.set_slides_to_cache(new_list_of_slide)

    @permission
    def put(self, request, *args, **kwargs):
        new_slide = super(SlideCRUDView, self).put(request, *args, **kwargs)

        cached_slides = SyncRedisWrapperLocal(
            db=options.REDIS_SLIDE_DB,
            connection_data=options.REDIS_REVOLUTION
        ).get(options.SLIDE_CACHING_KEY)
        cached_slides = json.loads(cached_slides)

        for slide in cached_slides:
            if slide["id"] == new_slide["id"]:
                new_slide["lang"] = options.LANGUAGES_FOR_ADMIN[str(request.data.get('lang', 0))]
                cached_slides.remove(slide)
                cached_slides.append(new_slide)
                CacheManager.set_slides_to_cache(cached_slides)

    @permission
    def delete(self, request, *args, **kwargs):
        super(SlideCRUDView, self).delete(request, *args, **kwargs)

        cached_slides = SyncRedisWrapperLocal(
            db=options.REDIS_SLIDE_DB,
            connection_data=options.REDIS_REVOLUTION
        ).get(options.SLIDE_CACHING_KEY)
        cached_slides = json.loads(cached_slides)

        for slide in cached_slides:
            if slide["id"] == int(args[0]):
                cached_slides.remove(slide)
                CacheManager.set_slides_to_cache(cached_slides)


class SlideView(AbstractSettingsView):

    view = SlideCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "url_image": {
            "type": "img",
            "name": "Изображение",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "url": {
            "type": "text",
            "name": "URL",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "priority": {
            "type": "number",
            "name": "Приоритет",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "lang": {
            "type": "enum",
            "enum": Slide.LANGUAGES_FOR_ADMIN,
            "name": "Язык",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "event_id": {
            "type": "number",
            "name": "Идентификатор события",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        }
    }


router = SimpleRouter()
router.register('/slide/create', SlideCRUDView, 'POST')
router.register('/slide/settings', SlideView, 'GET')
router.register('/slide/list', SlideCRUDView, 'GET')
router.register('/slide/{id}', SlideCRUDView, ['GET', 'PUT', 'DELETE'])
