from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.flat_page import FlatPageModel
from betronic_core.db.models.user import UserModel
from admin.src.serializers import FlatPageSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class FlatPageCRUDView(AbstractCRUDView):
    model = FlatPageModel
    serializer = FlatPageSerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class FlatPageSettingsView(AbstractSettingsView):
    view = FlatPageCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "name": {
            "type": "text",
            "name": "Название страницы",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "id_name": {
            "type": "text",
            "name": "Название url",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "lang": {
            "type": "enum",
            "enum": FlatPageModel.LANGUAGES_FOR_ADMIN,
            "name": "Язык",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "text": {
            "type": "html",
            "name": "Код страницы",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
        },
        "priority": {
            "type": "number",
            "name": "Приоритет",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "is_active": {
            "type": "boolean",
            "name": "Активен",
            "is_checked": True,
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/flat_page/settings', FlatPageSettingsView, 'GET')
router.register('/flat_page/list', FlatPageCRUDView, 'GET')
router.register('/flat_page/create', FlatPageCRUDView, 'POST')
router.register('/flat_page/{id}', FlatPageCRUDView, ['GET', 'PUT', 'DELETE'])
