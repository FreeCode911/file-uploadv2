from aiorest_ws.routers import SimpleRouter
from sqlalchemy import or_

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from admin.src.serializers import CashierReportSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.constants import TransferTypes as tt
from admin.src.utils.user_mixin import UserMixin
from admin.src.utils.decorators import session, permission


class CashierReportsCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.CASHIER, UserModel.ADMIN, ),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }
    model = MoneyTransferModel
    serializer = CashierReportSerializer

    def _get_model_all(self, session, **kwargs):
        subj = self.get_user(**kwargs)
        query = session.query(self.model)\
            .filter(self.model.type.in_(tt.TYPES_CASHIER_REPORT_TYPES.keys()))
        if subj['role'] == UserModel.CASHIER:
            query = query.filter(or_(
                self.model.from_user_id == subj['id'],
                self.model.to_user_id == subj['id']))

        kwargs = self.set_default_date(kwargs)
        items, count = self.model\
            .query_by_params(session, query=query, **kwargs)

        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_model_by_id(session, **kwargs) \
            if id else self._get_model_all(session, **kwargs)
        return result


class CashierReportsSettingsView(AbstractSettingsView):
    view = CashierReportsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": False,
            "filter": False,
            "table": False,
            "editable": False,
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": tt.TYPES_CASHIER_REPORT_TYPES,
            "weight": 1
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": -1
        },
        "user_id": {
            "type": "text",
            "name": "Пользователь ID",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False
        }
    }


router = SimpleRouter()
router.register('/cashier_reports/settings', CashierReportsSettingsView, 'GET')
router.register('/cashier_reports/list', CashierReportsCRUDView, 'GET')
router.register('/cashier_reports/{id}', CashierReportsCRUDView, ['GET', 'PUT'])
