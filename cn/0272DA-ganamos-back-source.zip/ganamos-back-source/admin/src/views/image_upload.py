from aiorest_ws.routers import SimpleRouter

from settings.setup_settings import get_all_settings
from ..utils.abstract_view import AbstractView
from ..utils.decorators import permission
from ..utils.img_upload import upload_img

settings = get_all_settings()

class UploadView(AbstractView):
    @permission
    def post(self, request, *args, **kwargs):
        data = request.data
        image = data.get('image', None)
        ext = data.get('ext', None)
        img_url = upload_img(image, ext)
        return {"url": img_url}



router = SimpleRouter()
router.register('/upload/image', UploadView, 'POST')
