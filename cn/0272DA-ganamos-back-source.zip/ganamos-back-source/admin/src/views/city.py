from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.city import City
from betronic_core.db.models.user import UserModel
from admin.src.serializers import CitySerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView



class CityListCRUDView(AbstractCRUDView):
    model = City
    serializer = CitySerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class CitySettingsView(AbstractSettingsView):
    view = CityListCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "name": {
            "type": "text",
            "name": "Название",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/city/list', CityListCRUDView, 'GET')
router.register('/city/settings', CitySettingsView, 'GET')
router.register('/city/create', CityListCRUDView, 'POST')
router.register('/city/{id}', CityListCRUDView, ['GET', 'PUT', 'DELETE'])
