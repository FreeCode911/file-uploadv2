from typing import List
from aiorest_ws.routers import SimpleRouter

from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.security_log import SecurityLogModel
from ..utils.abstract_view import AbstractCRUDView, \
    AbstractSettingsView
from ..utils.decorators import session, permission
from ..serializers import SecurityLogSerializer


Operation = ["login", "change password", "restore password"]


class SecurityLogCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'DELETE': (),
        'UPDATE': ()
    }
    model = SecurityLogModel
    serializer = SecurityLogSerializer

    def get_query(self, session, admin=None):
        return session.query(self.model)

    def _get_model_all(self, session, admin=None, **kwargs):
        query = self.get_query(session, admin)

        items, count = self.model.query_by_params(query, session, **kwargs)
        data = self.serializer(items, many=True).data
        self._mask_serialized_data_by_role(data, admin)
        return {"items": data, "count": count}

    @staticmethod
    def _mask_serialized_data_by_role(items: List[dict], admin: dict):
        for item in items:
            if str(admin["role"]) == str(UserModel.LIMITED_OWNER) and item["request_from"] == "admin":
                item["ip_address"] = ""

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result


class SecurityLogSettingsCRUDView(AbstractSettingsView):
    view = SecurityLogCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "user_id": {
            "type": "number",
            "name": "ID пользователя",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 2
        },
        "ip_address": {
            "type": "text",
            "name": "IP адрес",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "request_from": {
            "type": "text",
            "name": "Откуда пришел запрос",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "operation": {
            "type": "text",
            "name": "Операция",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": Operation,
            "weight": 5
        },
        "request_body": {
            "type": "text",
            "name": "Тело запроса",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        },
        "note": {
            "type": "text",
            "name": "Заметка",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 7
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 8
        },
    }


router = SimpleRouter()
router.register('/security_log/settings', SecurityLogSettingsCRUDView, 'GET')
router.register('/security_log/list', SecurityLogCRUDView, 'GET')
