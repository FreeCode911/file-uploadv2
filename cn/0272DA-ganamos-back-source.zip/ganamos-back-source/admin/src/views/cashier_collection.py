from aiorest_ws.routers import SimpleRouter
from admin.src.utils.abstract_view import AbstractSettingsView, AbstractCRUDView
from betronic_core.db.models.user import UserModel
from betronic_core.constants import TransferTypes as tt
from admin.src.serializers import CashierReportSerializer
from admin.src.utils.user_mixin import UserMixin
from sqlalchemy import or_
from admin.src.utils.decorators import session, permission
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.money_manager.manager import MoneyManager
from logging import getLogger
from decimal import Decimal
from betronic_core.user_manager.manager import UserManager


logger = getLogger(__name__)


class CashierCollectionCRUDView(UserMixin, AbstractCRUDView):
    roles = {
        'GET': (UserModel.CASHIER, UserModel.ADMIN),  # , UserModel.SUPER_ADMIN, UserModel.OWNER
        'CREATE': (UserModel.ADMIN,),
        'UPDATE': (),
        'DELETE': ()
    }
    model = MoneyTransferModel
    serializer = CashierReportSerializer

    def get_query(self, session, admin_user=None):
        query = session.query(self.model)\
            .filter(self.model.type.in_(tt.TYPES_ADMIN_REPORTS_TYPE.keys())) \
            .filter(or_(
                self.model.from_user_id == admin_user['id'],
                self.model.to_user_id == admin_user['id']))
        return query

    def _get_model_all(self, session, admin_user=None, **kwargs):
        qry = self.get_query(session, admin_user)
        items, count = self.model.query_by_params(qry, session, **kwargs)

        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    def _get_model_by_id(self, session, id, admin_user=None):
        item = self.get_query(session, admin_user)\
            .filter(self.model.id == id).first()
        if not item:
            raise Exception("Resource not exist")

        result = self.serializer(item).data
        return result

    def check_enouth_money(self, session, user_id: int, value: float):
        balance = UserModel.get_by_id(session, user_id).balance
        if Decimal(str(balance)) - Decimal(str(value)) < Decimal("0"):
            raise Exception('Not enough money')

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result

    @session
    @permission
    def post(self, request, id=None, session=None, *args, **kwargs):
        money_manager = MoneyManager(session)
        user = self.get_user(**kwargs)

        transfer_type = int(request.data.get('type', 0))

        cashier_id = request.data.get('cashiers', None) or user['id']
        admin_id = request.data.get('admins', None) or user['id']
        value = float(request.data.get('value', 0.0))
        note = request.data.get('note', None)

        user_manager = UserManager(session)
        cashier = user_manager.get_user_by_id(cashier_id)
        if cashier.role != UserModel.CASHIER or cashier.parent_admin_id != admin_id:
            raise Exception('Wrong cashier/admin for Transfer.')

        if transfer_type == tt.TYPE_ADMIN_TO_CASHIER:
            from_user_id, to_user_id = int(admin_id), int(cashier_id)

        elif transfer_type == tt.TYPE_CASHIER_TO_ADMIN:
            from_user_id, to_user_id = int(cashier_id), int(admin_id)

        else:
            raise Exception('Transfer type {} not valid'.format(transfer_type))

        assert value and value > 0, "Amount must be more than 0!"

        # Minus balance is on now:
        # self.check_enouth_money(session, from_user_id, value)

        additional_data = {'cashier_id': cashier_id, 'admin_id': admin_id}

        money_manager.user_move_money(
            from_user_id=from_user_id, to_user_id=to_user_id,
            transfer_type=transfer_type, value=value, note=note,
            additional_data=additional_data)


class CashierCollectionSettingsCRUDView(AbstractSettingsView):
    view = CashierCollectionCRUDView

    @session
    def fill_users(self, session, role: int, admin_user):
        result = {}

        def fill_user(user):
            username = user.get_full_name()
            phone = user.email_auth.email
            result[user.id] = username + ' // ' + phone
            if role == UserModel.ADMIN:
                result[user.id] += ' // balance: ' + str(user.balance)

        if role == UserModel.CASHIER:
            cashier = session.query(UserModel) \
                .filter(UserModel.id == admin_user['id']).first()
            admin = session.query(UserModel)\
                .filter(UserModel.id == cashier.parent_admin_id).first()
            fill_user(admin)
        else:
            query = session.query(UserModel) \
                .filter(UserModel.role == UserModel.CASHIER, UserModel.parent_admin_id == admin_user['id'])
            for user_ in query.all():
                fill_user(user_)
        return result

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)
        fields = self.fields.copy()
        if user['role'] == UserModel.CASHIER:
            fields['cashiers']['editable'] = False
            fields['cashier_id']['table'] = False
            fields['admin_id']['table'] = True
        else:
            fields['cashiers']['editable'] = True
            fields['cashiers']['enum'] = \
                self.fill_users(role=UserModel.ADMIN, admin_user=user)

        if user['role'] == UserModel.ADMIN:
            fields['admins']['editable'] = False
            fields['cashier_id']['table'] = True
            fields['admin_id']['table'] = False
        else:
            fields['admins']['editable'] = True
            fields['admins']['enum'] = \
                self.fill_users(role=UserModel.CASHIER, admin_user=user)

        return {
            "fields": fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": False,
            "table": False,
            "editable": False,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": -1,
            "default": "today"
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "enum": tt.TYPES_ADMIN_REPORTS_TYPE,
            "weight": 1,
            "editableWeight": -1
        },
        "admins": {
            "type": "enum",
            "name": "Выберите администратора",
            "order": False,
            "filter": False,
            "editable": True,
            "table": False,
            "editableWeight": 1
        },
        "cashiers": {
            "type": "enum",
            "name": "Выберите кассира",
            "order": False,
            "filter": False,
            "editable": True,
            "table": False,
            "editableWeight": 2
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "editableWeight": 3
        },
        "admin_id": {
            "type": "number",
            "name": "ID админа",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "editableWeight": 4
        },
        "cashier_id": {
            "type": "number",
            "name": "ID кассира",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "editableWeight": 5
        },
        "note": {
            "type": "text",
            "name": "Заметка",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "editableWeight": 6
        }
    }


router = SimpleRouter()

router.register(
    '/cashier_collection/settings', CashierCollectionSettingsCRUDView, 'GET')
router.register(
    '/cashier_collection/list', CashierCollectionCRUDView, 'GET')
router.register(
    '/cashier_collection/{id}', CashierCollectionCRUDView, 'GET')