import datetime

from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from betronic_core.db.database import DataBase
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.notification import NotificationModel
from betronic_core.cache_manager.manager import CacheManager
from admin.src.serializers import NotificationSerializer
from ..utils.decorators import permission, session
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class NotificationCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.CASHIER, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.CASHIER, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.CASHIER, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.CASHIER, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }
    model = NotificationModel
    serializer = NotificationSerializer

    def __init__(self):
        self.db = DataBase.get()

    def _get_model_all(self, session, **kwargs):
        # query = self.get_query(session).filter(self.model.is_closed==False) if we need only open notifications
        query = self.get_query(session)
        items, count = self.model.query_by_params(session=session, query=query, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    def _get_model_by_id(self, session, id, **kwargs):
        notification = self.get_query(session).filter(self.model.id == id).first()
        if not notification:
            raise Exception("Resource not exist")
        data = self.serializer(notification).data
        return data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_model_by_id(session, int(id), **kwargs) \
            if id else self._get_model_all(session, **kwargs)
        return result

    @permission
    def post(self, request, *args, **kwargs):
        notification_text = request.data.get('notification', "")
        if len(notification_text) > options.NOTIFICATION_TEXT_LIMIT:
            raise Exception(f"Notification text exceeds {options.NOTIFICATION_TEXT_LIMIT} characters.")
        notification = NotificationModel()
        notification.notification = {
            "notification": notification_text,
            "created_at": datetime.datetime.now().isoformat(),
            "hidden_for_user_ids": tuple(),
            "is_closed": request.data.get('is_closed', False)
        }
        notification.is_closed = request.data.get('is_closed', False)
        self.db.add(notification)
        self.db.commit()
        CacheManager.set_notification_to_cache(notification)

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        notification: NotificationModel = NotificationModel.get_by_id(self.db, id)
        notification.is_closed = request.data.get('is_closed', False)
        notification.notification = {
            "notification": notification.notification['notification'],
            "created_at": datetime.datetime.now().isoformat(),
            "is_closed": request.data.get('is_closed', False)
        }
        self.db.add(notification)
        self.db.commit()
        CacheManager.set_notification_to_cache(notification, is_update=True)

    @session
    @permission
    def delete(self, request, id, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        query = kwargs.get('query', None) or self.get_query(session)

        instance = query.filter(self.model.id == id).first()
        if not instance:
            raise Exception('Object does not exist')
        session.delete(instance)
        session.commit()
        CacheManager.remove_notification_from_cache(id)
        result = self._get_model_all(session, **kwargs)
        return result


class NotificationSettingsView(AbstractSettingsView):
    view = NotificationCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "notification": {
            "type": "text",
            "name": "Notification",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "is_closed": {
            "type": "boolean",
            "name": "Окончена",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        }
    }


router = SimpleRouter()
router.register('/notification/settings', NotificationSettingsView, 'GET')
router.register('/notification/list', NotificationCRUDView, 'GET')
router.register('/notification/create', NotificationCRUDView, 'POST')
router.register('/notification/{id}', NotificationCRUDView, ['GET', 'PUT'])
