from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.terminal.cashbox import CashBox
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.city import City
from admin.src.serializers import CashboxSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session


class CashboxListCRUDView(AbstractCRUDView):
    model = CashBox
    serializer = CashboxSerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }

    @session
    @permission
    def post(self, request, session=None, *args, **kwargs):
        data = request.data
        city_id = int(data.get('city_id'))
        cashbox = CashBox()
        cashbox.city_id = city_id
        cashbox.address = data.get('address')
        session.add(cashbox)
        session.commit()
        return True


class CashboxSettingsView(AbstractSettingsView):
    view = CashboxListCRUDView

    @session
    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        db = kwargs.get('session')
        models = db.query(City).all()
        cities = {}
        for m in models:
            cities[m.id] = m.name

        permissions = self.get_permission(user, self.view.roles)

        self.fields['city_id']['enum'] = cities
        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "address": {
            "type": "text",
            "name": "Адрес",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "city_id": {
            "type": "enum",
            "name": "Город",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True
        },
    }


router = SimpleRouter()
router.register('/cashbox/list', CashboxListCRUDView, 'GET')
router.register('/cashbox/settings', CashboxSettingsView, 'GET')
router.register('/cashbox/create', CashboxListCRUDView, 'POST')
router.register('/cashbox/{id}', CashboxListCRUDView, ['GET', 'PUT', 'DELETE'])
