from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from admin.src.serializers import PartnerMoneySerializer
from betronic_core.constants import PartnerTypePayment, \
    PartnerStatusMoneyTransfer, PartnerTypeMoneyTransfer, TransferTypes
from admin.src.utils.decorators import session, permission
from betronic_core.money_manager.manager import MoneyManager


class PartnerTransactions(AbstractCRUDView):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (),
        'DELETE': (),
    }

    model = PartnerMoneyTransfer
    serializer = PartnerMoneySerializer


    @session
    @permission
    def post(self, request, *args, **kwargs):
        session = kwargs.get('session')

        money_maneger = MoneyManager(session)

        money_maneger.partner_move_money(
            user_id=int(request.data.get('user_id')),
            value=request.data.get('value'),
            type=int(request.data.get('type')),
            type_payment=int(request.data.get('type_credit')))


class PartnerTransactionsSettings(AbstractSettingsView):
    view = PartnerTransactions
    fields = {
        'id': {
            'type': 'number',
            'name': 'ID Транзакции',
            'order': False,
            'filter': False,
            'table': False,
            'editable': False,
        },
        'user_id': {
            'type': 'number',
            'name': 'ID Пользователя',
            'order': False,
            'filter': True,
            'table': True,
            'editable': True,
        },
        'value': {
            'type': 'text',
            'name': 'Сумма',
            'order': True,
            'filter': True,
            'table': True,
            'editable': True,
        },
        # 'currency': {
        #     'type': 'text',
        #     'name': 'Валюта',
        #     'order': False,
        #     'filter': True,
        #     'table': True,
        #     'editable': False,
        # },
        # 'status': {
        #     'type': 'enum',
        #     'name': 'Статус',
        #     'order': False,
        #     'filter': True,
        #     'table': True,
        #     'editable': True,
        #     'enum': PartnerStatusMoneyTransfer.StatusesName
        # }
        'type_credit': {
            'type': 'enum',
            'name': 'Тип оплаты',
            'order': True,
            'filter': True,
            'table': True,
            'editable': True,
            'enum': PartnerTypePayment.TypesName
        },
        'type': {
            'type': 'enum',
            'name': 'Тип',
            'order': True,
            'filter': True,
            'table': True,
            'editable': True,
            'enum': PartnerTypeMoneyTransfer.TypesName
        },
    }


router = SimpleRouter()
router.register('/partner_transactions/list', PartnerTransactions, ['GET'])
router.register('/partner_transactions/settings', PartnerTransactionsSettings, ['GET'])
router.register('/partner_transactions/{id}', PartnerTransactions, ['GET', 'CREATE'])