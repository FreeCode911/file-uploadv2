from logging import getLogger

from aiorest_ws.routers import SimpleRouter

from admin.src.serializers import JackpotSerializer
from betronic_core.db.database import DataBase
from betronic_core.db.models.outcome_transactions import JackpotModel
from betronic_core.db.models.user import UserModel
from betronic_core.jackpot_manager.manager import JackpotManager
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session
from ..utils.img_upload import upload_img

logger = getLogger(__name__)


class JackpotListCRUDView(AbstractCRUDView):
    model = JackpotModel
    serializer = JackpotSerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.CASHIER),
        'CREATE': (UserModel.OWNER, UserModel.ADMIN, UserModel.CASHIER),
        'UPDATE': (UserModel.OWNER, UserModel.ADMIN, UserModel.CASHIER),
        'DELETE': (UserModel.OWNER,),
    }

    def __init__(self):
        self.db = DataBase.get()

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session).filter(self.model.is_deleted == False)
        items, count = self.model.query_by_params(session=session, query=query, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    @permission
    def post(self, request, *args, **kwargs):
        img_url = upload_img(request.data.get('image'), request.data.get('ext'))
        request.data['image'] = img_url

        request.data['amount'] = 0
        request.data['name'] = request.data.get('name', None)
        request.data['is_deleted'] = request.data.get('is_deleted', False)
        request.data['timer'] = int(request.data['timer'])

        if request.data['timer'] and request.data['timer'] < 0:
            raise Exception('Timer cannot be past')

        if float(request.data.get('min_amount')) < 0:
            raise Exception('min_amount will not be < 0')

        if float(request.data.get('first_amount')) < 0:
            raise Exception('first_amount will not be < 0')

        if float(request.data.get('amount')) < 0:
            raise Exception('amount will not be < 0')

        if not 0 < float(request.data.get('min_probability')) <= 1:
            raise Exception('min_probability must be in [0, 1]')

        if not 0 < float(request.data.get('max_probability')) <= 1:
            raise Exception('max_probability must be in [0, 1]')

        if not 0 < float(request.data.get('amount_percent')) < 1:
            raise Exception('amount_percent must be in [0, 1]')

        request.data['amount'] = request.data.get('first_amount')

        query = self.db.query(self.model)
        super().post(request, *args, query=query, **kwargs)

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        query = kwargs.get('query', None) or self.get_query(session)
        instance = query.filter(self.model.id == id).first()

        jackpot_manager = JackpotManager(self.db)
        calculate = request.data['calculate']
        request.data['calculate'] = None
        reset = request.data['reset']
        request.data['reset'] = None

        if reset:
            jackpot_manager.reset_jackpot(instance)
            request.data['is_deleted'] = True

        if calculate:
            jackpot_manager.calculate_jackpot(instance.id)

        # img_url = upload_img(request.data.get('image'), request.data.get('ext'))
        # request.data['image'] = img_url

        request.data['timer'] = int(request.data['timer'])
        request.data['amount'] = instance.amount

        if not instance:
            raise Exception('Object does not exist')

        if request.data['timer'] and request.data['timer'] < 0:
            raise Exception('timer cannot be past')

        if float(request.data.get('min_amount')) < 0:
            raise Exception('min_amount will not be < 0')

        if float(request.data.get('first_amount')) < 0:
            raise Exception('first_amount will not be < 0')

        if float(request.data.get('amount')) < 0:
            raise Exception('amount will not be < 0')

        if not 0 < float(request.data.get('min_probability')) <= 1:
            raise Exception('min_probability must be in [0, 1]')

        if not 0 < float(request.data.get('max_probability')) <= 1:
            raise Exception('max_probability must be in [0, 1]')

        if not 0 < float(request.data.get('amount_percent')) < 1:
            raise Exception('amount_percent must be in [0, 1]')

        query = self.db.query(self.model)
        super().put(request, id, *args, query=query, **kwargs)

    @session
    @permission
    def delete(self, request, id, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        query = kwargs.get('query', None) or self.get_query(session)

        instance = query.filter(self.model.id == id).first()
        if not instance:
            raise Exception('Object does not exist')

        serializer = self.serializer()
        params = {
            'is_deleted': True,
            'is_active': instance.is_active,
            'min_amount': instance.min_amount,
            'timer': instance.timer,
            'first_amount': instance.first_amount,
            'min_probability': instance.min_probability,
            'name': instance.name,
            'amount': instance.amount,
            'max_probability': instance.max_probability,
            'amount_percent': instance.amount_percent,
            'image': instance.image,
        }

        serializer.update(instance, params)

        result = self._get_model_all(session, **kwargs)
        return result


class JackpotSettingsView(AbstractSettingsView):
    view = JackpotListCRUDView
    fields = {
        "calculate": {
            "type": "boolean",
            "name": "Calculate",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "reset": {
            "type": "boolean",
            "name": "Reset",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "image": {
            "type": "img",
            "name": "Изображение",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "name": {
            "type": "text",
            "name": "Название джекпота",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True
        },
        "amount": {
            "type": "number",
            "name": "Сумма в джекпоте",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "is_active": {
            "type": "boolean",
            "name": "Активен",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "pay": {
            "type": "boolean",
            "name": "Платить?",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "min_amount": {
            "type": "number",
            "name": "Сумма начала розыгрыша джекпота",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "min_probability": {
            "type": "number",
            "name": "Минимальная вероятность выпадения",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "max_probability": {
            "type": "number",
            "name": "Максимальная вероятность выпадения",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "first_amount": {
            "type": "number",
            "name": "Начальная сумма",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "amount_percent": {
            "type": "number",
            "name": "Процент отчислений",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "timer": {
            "type": "number",
            "name": "Таймер (в днях)",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/jackpot/list', JackpotListCRUDView, 'GET')
router.register('/jackpot/settings', JackpotSettingsView, 'GET')
router.register('/jackpot/{id}', JackpotListCRUDView, ['GET', 'PUT', 'CREATE'])
