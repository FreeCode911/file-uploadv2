from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from betronic_core.db.database import DataBase
from util.redis import RedisBaseTypes, RedisWrapper
from ..utils.abstract_view import AbstractSettingsView, AbstractCRUDView
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.settings import SettingsModel

from admin.src.serializers import SettingsSerializer
from ..utils.decorators import permission, session
import ast


class SettingsCRUDView(AbstractCRUDView):
    model = SettingsModel
    serializer = SettingsSerializer
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (),
    }

    def __init__(self):
        self.db = DataBase.get()

    def get_query(self, session):
        return session.query(self.model)

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)
        items, count = self.model.query_by_params(query, session, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    def _get_model_by_id(self, session, id, **kwargs):
        item = self.get_query(session).filter(self.model.id == id).first()
        if not item:
            raise Exception("Resource not exist")
        return self.serializer(item).data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_model_by_id(session, int(id), **kwargs) \
            if id else self._get_model_all(session, **kwargs)
        return result

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        setting = SettingsModel.get_by_id(session, id)
        data = request.data.get("data", None)

        if data:
            setting.data = ast.literal_eval(data)

        session.add(setting)
        session.commit()

        RedisWrapper(
            db=RedisBaseTypes.SITE_SETTINGS,
            connection_data=options.REDIS
        ).reset(key=setting.name)

        result = self.serializer(setting).data

        return result


class SettingsView(AbstractSettingsView):
    view = SettingsCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False
        },
        "name": {
            "type": "text",
            "name": "Название",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False
        },
        "data": {
            "type": "text",
            "name": "Данные",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True
        }

    }


router = SimpleRouter()
router.register('/settings/list', SettingsCRUDView, 'GET')
router.register('/settings/settings', SettingsView, 'GET')
router.register('/settings/{id}', SettingsCRUDView, ['GET', 'PUT'])