from tornado.options import options
from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.user import UserModel
from betronic_core.cache_manager.manager import CacheManager

from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session


class TransferLimitSettingsCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.OWNER, ),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, ),
        'DELETE': (),
    }

    keys = ("max_balance_amount", "max_win_amount")

    id_currency_mapper = {
        str(id_): currency
        for id_, currency in enumerate(options.AVAILABLE_CURRENCIES)
    }

    @staticmethod
    def check_value_for_valid(request):
        for key in request.data.keys():
            if key not in TransferLimitSettingsCRUDView.keys:
                raise ValueError("Wrong information in data field")

    def get_currency_by_id(self, id_: str):
        return self.id_currency_mapper.get(id_)

    def _get_model_all(self, session, **kwargs):
        result = []
        for id_, currency in self.id_currency_mapper.items():
            currency_limit_data = CacheManager.get_payment_settings(currency=currency)
            currency_limit_data['currency'] = currency
            currency_limit_data['id'] = id_

            result.append(currency_limit_data)

        return {"items": result}

    def _get_model_by_id(self, session, id, **kwargs):
        currency = self.get_currency_by_id(id)
        result = CacheManager.get_payment_settings(currency=currency)

        return result

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        result = self._get_model_by_id(session, id, **kwargs) \
            if id else self._get_model_all(session, **kwargs)

        return result

    @session
    @permission
    def put(self, request, id, *args, **kwargs):
        self.check_value_for_valid(request)

        currency = self.get_currency_by_id(id)

        settings = CacheManager.get_payment_settings(currency=currency)
        for key, value in request.data.items():
            settings[key] = float(value)

        CacheManager.set_payments_settings(currency=currency, data=settings)

        result = CacheManager.get_payment_settings(currency=currency)

        return result


class TransferLimitSettingsView(AbstractSettingsView):
    view = TransferLimitSettingsCRUDView

    fields = {
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 1,
        },
        "max_balance_amount": {
            "type": "number",
            "name": "Максимальный баланс",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 2,
        },
        "max_win_amount": {
            "type": "number",
            "name": "Максимальный выигрыш",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 3,
        }
    }


router = SimpleRouter()
router.register('/transfer_limit_settings/settings', TransferLimitSettingsView, 'GET')
router.register('/transfer_limit_settings/list', TransferLimitSettingsCRUDView, ['GET', 'PUT'])
router.register('/transfer_limit_settings/{id}', TransferLimitSettingsCRUDView, ['GET'])
