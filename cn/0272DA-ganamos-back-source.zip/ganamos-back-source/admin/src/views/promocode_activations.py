from admin.src.utils.abstract_view import AbstractCRUDView, \
    AbstractSettingsView
from aiorest_ws.routers import SimpleRouter
from betronic_core.db.models.promo_code import PromoCodeActivationModel, \
    PromoCodeModel
from admin.src.serializers import PromoCodeActivationSerializer
from sqlalchemy import or_


class CRUDView(AbstractCRUDView):
    model = PromoCodeActivationModel
    serializer = PromoCodeActivationSerializer

    def get_query(self, session):
        return session.query(self.model).filter(
            or_(self.model.is_hidden == False,
                self.model.is_hidden == None))


class SettingsCRUDView(AbstractSettingsView):
    view = CRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": False,
            "editable": False,
            "weight": 1
        },
        "user.id": {
            "type": "number",
            "name": "User ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1.1
        },
        "user.email_auth.login": {
            "type": "text",
            "name": "Login",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 2
        },
        "promo_code.code": {
            "type": "text",
            "name": "Code",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "promo_code.code_type": {
            "type": "enum",
            "name": "Тип",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": PromoCodeModel.TYPES,
            "weight": 4
        },
        "promo_code.amount": {
            "type": "number",
            "name": "Условия",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 4.1
        },
        "created_at": {
            "type": "date",
            "name": "Дата активации",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 5
        },
        'personalBonusAmount': {
            "type": "text",
            "name": "Размер бонуса",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 6
        },
        'betAmount': {
            "type": "text",
            "name": "Поставлено / Необходимо поставить",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 7
        },
        'progress': {
            "type": "text",
            "name": "Прогресс",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 8
        },
        "transfer.value": {
            "type": "text",
            "name": "Зачислено на счет",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 9
        },
        "is_banned": {
            "type": "enum",
            "name": "Забанен?",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "enum": {True: 'Да', False: 'Нет'},
            "weight": 10
        },
        "hasWithdrawals": {
            "type": "text",
            "name": "Делал вывод",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 11
        },
        "is_active": {
            "type": "text",
            "name": "Активна",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 12
        },
        "note": {
            "type": "text",
            "name": "Комментарий",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "weight": 100
        }
    }


router = SimpleRouter()
router.register('/promocode_activations/list', CRUDView, 'GET')
router.register('/promocode_activations/settings', SettingsCRUDView, 'GET')
router.register('/promocode_activations/{id}',
                CRUDView, ['GET', 'PUT', 'CREATE'])
