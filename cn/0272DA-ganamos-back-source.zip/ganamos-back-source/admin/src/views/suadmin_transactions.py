from datetime import datetime, timedelta

from aiorest_ws.routers import SimpleRouter

import betronic_core.owner_page_manager.sql_queries as queries
from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.user import UserModel
from betronic_core.owner_page_manager.manager import StatisticTypes
from ..utils.abstract_view import AbstractSettingsView, AbstractStatisticsCRUDView
from ..utils.decorators import permission, session


class SuadminTransactionsCRUDView(AbstractStatisticsCRUDView, UserMixin):
    model = BaseModel
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):
        yesterday = datetime.today() - timedelta(days=1)
        tomorrow = datetime.today() + timedelta(days=1)
        date_filters = kwargs['filters'].get('date') if kwargs['filters'].get('date') else {}
        if not date_filters.get('from'):
            date_filters['from'] = yesterday.strftime('%Y-%m-%d')
        if not date_filters.get('to'):
            date_filters['to'] = tomorrow.strftime('%Y-%m-%d')
        # Вторая дата всегда должна быть c 23:59:59
        date_filters['to'] = '%s 23:59:59' % date_filters['to']
        kwargs['filters']['date'] = date_filters

        result = session.execute(queries.GET_ALL_SUPER_ADMINS,
                                 {
                                     "date_from": date_filters['from'],
                                     "date_to": date_filters['to'],
                                     "statistic_type": StatisticTypes.BALANCE,
                                 }).fetchall()
        items = self._convert_to_list_tree(result)

        return {
            'items': items,
            'count': len(items),
        }

    @staticmethod
    def _convert_to_list_tree(row_result):
        """
        Method converts SQLAlchemy RowProxy to dict
        :param row_result: list of RowProxy objects
        :return: {user_id: row_data_dict, ...}
        """
        result = list()
        for r in row_result:
            result.append({key: str(r[key]) for key in r.keys()})
        return result


class SuadminTransactionsSettingsView(AbstractSettingsView):
    view = SuadminTransactionsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "date": {
            "type": "date",
            "name": "Дата",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "default": 'today',
            "weight": -1
        },
        "user_id": {
            "type": "number",
            "name": "id",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "first_name": {
            "type": "text",
            "name": "Имя супер администратора",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "in": {
            "type": "number",
            "name": "Депозит",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "out": {
            "type": "number",
            "name": "Снятие",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "profit": {
            "type": "number",
            "name": "Всего",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        }
    }


router = SimpleRouter()
router.register('/suadmin_transactions/list', SuadminTransactionsCRUDView, 'GET')
router.register('/suadmin_transactions/settings', SuadminTransactionsSettingsView, 'GET')
