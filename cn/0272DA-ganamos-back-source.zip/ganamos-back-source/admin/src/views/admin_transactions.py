from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractSettingsView, AbstractStatisticsCRUDView
from betronic_core.db.models.base import BaseModel
from ..utils.decorators import permission, session
from betronic_core.constants import TransferTypes
from admin.src.utils.user_mixin import UserMixin
from datetime import datetime, timedelta
from betronic_core.db.models.user import UserModel
from itertools import groupby
from operator import itemgetter
from decimal import Decimal


class CashierTransactionsCRUDView(AbstractStatisticsCRUDView, UserMixin):
    model = BaseModel
    roles = {
        'GET': (UserModel.SUPER_ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    def _get_transfers(self, session, items, date_filter):
        cashiers = items.cte('cashiers')

        write_offs = self.get_transfers_by_type(
            session, cashiers,
            TransferTypes.TYPE_USER_TO_CASHIER,
            transfer_direction='to', date=date_filter)

        refills = self.get_transfers_by_type(
            session, cashiers,
            TransferTypes.TYPE_CASHIER_TO_USER,
            transfer_direction='from', date=date_filter)

        result_query = session \
            .query(
            cashiers.c.id,
            cashiers.c.first_name,
            cashiers.c.parent_admin_id,
            refills.c.value.label('refill'),
            write_offs.c.value.label('write_off'),
        ) \
            .join(refills, cashiers.c.id == refills.c.t_uid) \
            .join(write_offs, cashiers.c.id == write_offs.c.t_uid)

        return self._serialize_query(result_query.all())

    def _get_admin_transactions(self, data, admin_names):
        admins_data = {k: list(v) for k, v in groupby(sorted(data, key=itemgetter('parent_admin_id')),
                                                      key=itemgetter('parent_admin_id'))}
        result: list = []
        for id_admin, values in admins_data.items():
            transaction_data = {'refill': Decimal(0), 'write_off': Decimal(0), 'income': Decimal(0),
                                'id': id_admin, 'first_name': admin_names[id_admin]}
            for data in values:
                transaction_data['refill'] += Decimal(data.get('refill'))
                transaction_data['write_off'] += Decimal(data.get('write_off'))
                transaction_data['income'] += Decimal(data.get('refill') - data.get('write_off'))
            result.append(transaction_data)

        items = [{k: str(v) for k, v in item.items()} for item in result]
        return items

    def _get_model_all(self, session, **kwargs):
        admin = self.get_user(**kwargs)
        date_filters = kwargs['filters'].get('date')
        admins = session.query(UserModel.id, UserModel.first_name) \
            .filter(UserModel.role == UserModel.ADMIN).all()
        names_of_admin = dict(admins)

        cashiers = session.query(UserModel.id, UserModel.first_name, UserModel.parent_admin_id) \
            .filter(UserModel.role == UserModel.CASHIER) \
            .filter(UserModel.is_active != True)
        if admin['role'] == UserModel.SUPER_ADMIN:
            cashiers = cashiers.filter(UserModel.parent_suadmin_id == admin['id'])

        result = self._get_transfers(session, cashiers, date_filters)
        items = self._get_admin_transactions(result, names_of_admin)
        return items

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):
        yesterday = datetime.today() - timedelta(days=1)
        tomorrow = datetime.today() + timedelta(days=1)
        date_filters = kwargs['filters'].get('date') if kwargs['filters'].get('date') else {}
        if not date_filters.get('from'):
            date_filters['from'] = yesterday.strftime('%Y-%m-%d')
        if not date_filters.get('to'):
            date_filters['to'] = tomorrow.strftime('%Y-%m-%d')
        kwargs['filters']['date'] = date_filters
        items = self._get_model_all(session, **kwargs)
        return {
            'items': items,
            'count': len(items),
        }


class CashierTransactionsSettingsView(AbstractSettingsView):
    view = CashierTransactionsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "date": {
            "type": "date",
            "name": "Дата",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "default": 'today',
            "weight": -1
        },
        "id": {
            "type": "number",
            "name": "id",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "first_name": {
            "type": "text",
            "name": "Имя администратора",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "refill": {
            "type": "number",
            "name": "Депозит",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "write_off": {
            "type": "number",
            "name": "Снятие",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "income": {
            "type": "number",
            "name": "Всего",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        }
    }


router = SimpleRouter()
router.register('/admin_transactions/list', CashierTransactionsCRUDView, 'GET')
router.register('/admin_transactions/settings', CashierTransactionsSettingsView, 'GET')
