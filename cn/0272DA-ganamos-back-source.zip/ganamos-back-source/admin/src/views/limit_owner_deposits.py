from datetime import date
from dateutil.relativedelta import relativedelta

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import func

from ..utils.abstract_view import AbstractSettingsView, AbstractCRUDView
from ..utils.decorators import permission, session
from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.db.models.bonus_royalty_statistic import BonusRoyaltyStatisticModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.royalty_manager.manager import RoyaltyManager
from betronic_core.constants import TransferTypes
from tornado.options import options
from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.user import UserModel


class LimitOwnerDepositsCRUDView(AbstractCRUDView, UserMixin):
    bonus_model = BonusRoyaltyStatisticModel
    real_model = RoyaltyStatisticModel
    roles = {
        'GET': (UserModel.OWNER, ),
        'CREATE': (UserModel.OWNER, ),
        'UPDATE': (),
        'DELETE': (),
    }

    @permission
    @session
    def post(self, request, id=None, session=None, *args, **kwargs):
        amount = float(request.data.get('amount'))

        if not amount:
            raise Exception("Amount empty")

        if abs(amount) < options.MIN_AMOUNT_FOR_OPERATIONS.get(
                "USD",
                options.DEFAULT_MIN_AMOUNT_FOR_OPERATIONS
        ):
            raise Exception(f'Incorrect amount for operation: {amount}')

        MoneyManager(session).move_money_to_service_user(
            source_user_id=UserModel.ORGANIZATION_ID,
            service_account_id=UserModel.REVENUE_BALANCE_ID,
            amount=abs(amount),
            is_outcome=False if amount > 0 else True,
            transfer_type=TransferTypes.TYPE_REVENUE_TOP_UP if amount > 0 else TransferTypes.TYPE_REVENUE_WRITE_OFF,
            allow_negative_balance=True
        )

        return True

    @staticmethod
    def _get_date_filter() -> dict:
        first_day = date.today().replace(day=1)
        last_day = first_day + relativedelta(months=1)
        return {"from": first_day, "to": last_day}

    def _get_model_all(self, session, **kwargs):
        result = {}
        date_filter = self._get_date_filter()
        result["revenue_share_usd"] = str(RoyaltyManager(session).
                                          get_rev_share_by_date(date_filter['from'],
                                                                date_filter['to']))

        result["total_paid_revenue_share_usd"], result["balance_from_previous_month"] = MoneyManager(session).\
            get_revenue_topups_sum(date_filter['from'], date_filter['to'])

        result["unplayed_revenue_share_usd"] = "{:.2f}".format(float(result["total_paid_revenue_share_usd"]) -
                                                               float(result["revenue_share_usd"]))
        result["number_of_deposits"] = MoneyManager(session).\
            get_revenue_number_of_deposits(date_filter['from'], date_filter['to'])

        interation_status = CacheManager().get_integration_status(raise_exception=False)
        result["website_status"] = "Working" if interation_status else "Not working"
        return [result]

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):

        items = self._get_model_all(session, **kwargs)
        a = {
            'items': items,
            'count': len(items),
        }
        return a


class LimitOwnerDepositsSettingsView(AbstractSettingsView):
    view = LimitOwnerDepositsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "amount": {
            "type": "number",
            "name": "amount",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "weight": 1
        },
        "revenue_share_usd": {
            "type": "number",
            "name": "Rev Share USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 2
        },
        "total_paid_revenue_share_usd": {
            "type": "number",
            "name": "Total paid Rev Share USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "unplayed_revenue_share_usd": {
            "type": "number",
            "name": "Unplayed Rev Share amount left USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "number_of_deposits": {
            "type": "number",
            "name": "Number of deposits",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5,
        },
        "balance_from_previous_month": {
            "type": "number",
            "name": "Balance from previous month USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6,
        },
        "website_status": {
            "type": "text",
            "name": "Website status",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 7
        },
    }


router = SimpleRouter()
router.register('/limit_owner_deposits/list', LimitOwnerDepositsCRUDView, 'GET')
router.register('/limit_owner_deposits/settings', LimitOwnerDepositsSettingsView, 'GET')
router.register('/limit_owner_deposits/{id}', LimitOwnerDepositsCRUDView, 'CREATE')
