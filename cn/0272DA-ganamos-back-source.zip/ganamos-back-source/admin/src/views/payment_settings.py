from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractRedisCRUDView, AbstractSettingsView
from ..utils.decorators import permission
from betronic_core.cache_manager.manager import SyncRedisWrapperLocal, RedisBaseTypes
from ujson import dumps

from tornado.options import options
from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.user import UserModel


class PaymentSettingsCRUDView(AbstractRedisCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.OWNER, ),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, ),
        'DELETE': (),
    }

    redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)

    @staticmethod
    def check_value_for_valid(request):
        for key in request.data.keys():
            if key not in ('emergency_shutdown', 'bypass_operation'):
                raise ValueError("Wrong information in data field")
        if 'emergency_shutdown' in request.data:
            if type(request.data['emergency_shutdown']) != bool:
                raise ValueError("Error emergency_shutdown type")
        if 'bypass_operation' in request.data:
            if type(request.data['bypass_operation']) != bool:
                raise ValueError("Error bypass_operation type")

    @permission
    def get(self, request, id=None, *args, **kwargs):
        result = self.get_model(options.REVENUE_STATUS_KEY) \
            if id else self.get_model_view_list(options.REVENUE_STATUS_KEY)

        return result

    @permission
    def put(self, request, *args, **kwargs):
        self.check_value_for_valid(request)
        current_settings = self.get_model(options.REVENUE_STATUS_KEY)
        current_settings.update(request.data)
        self.redis.set(options.REVENUE_STATUS_KEY, dumps(current_settings))
        return current_settings


class PaymentSettingsSettingsView(AbstractSettingsView):
    view = PaymentSettingsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "emergency_shutdown": {
            "type": "boolean",
            "name": "Emergency shutdown",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 1
        },
        "bypass_operation": {
            "type": "boolean",
            "name": "Bypass operation",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 2
        }
    }


router = SimpleRouter()
router.register('/payment_settings/list', PaymentSettingsCRUDView, 'GET')
router.register('/payment_settings/settings', PaymentSettingsSettingsView, 'GET')
router.register('/payment_settings/{token}', PaymentSettingsCRUDView, ['GET', 'PUT'])
