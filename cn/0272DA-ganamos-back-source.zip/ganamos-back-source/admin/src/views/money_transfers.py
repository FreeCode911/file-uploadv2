from datetime import datetime, timedelta

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import func
from betronic_core.db.database import DataBase
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.constants import TransferTypes
from betronic_core.db.models.user import UserModel
from admin.src.serializers import MoneyTransferSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class MoneyTransferCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER,
                UserModel.TECHSUPPORT, UserModel.CASHIER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    model = MoneyTransferModel
    serializer = MoneyTransferSerializer
    datetime_pattern = "%Y-%m-%d %H:%M"
    datetime_default_timezone = "+00:00"

    def __init__(self):
        self.db = DataBase.get()

    def get_query(self, session):
        return session.query(self.model)\
            .filter(self.model.type.notin_(TransferTypes.HIDDEN_TYPES))

    def get_sum_query(self, session):
        query = session.query(func.sum(self.model.value))
        return query

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)

        date_utc_now = datetime.utcnow()
        date_from_default = datetime.today() - timedelta(hours=2)

        date_from_filter = kwargs['filters'].get('created_at', {}).get('from')
        date_to_filter = kwargs['filters'].get('created_at', {}).get('to')

        date_from: datetime = datetime.strptime(date_from_filter[:-7], self.datetime_pattern) if date_from_filter else date_from_default
        date_to: datetime = datetime.strptime(date_to_filter[:-7], self.datetime_pattern) if date_to_filter else date_utc_now

        date_delta = date_to - date_from
        is_allow_for_return_transfer = False

        if kwargs['filters'].get('note') and date_delta > timedelta(days=5):
            raise Exception("Maximum time interval for request with note: 5 day's")

        if date_from and date_delta < timedelta(days=1):
            is_allow_for_return_transfer = True

        elif date_from and timedelta(days=1) < date_delta < timedelta(days=14):
            if (
                kwargs['filters'].get('from_user_id') is not None or
                kwargs['filters'].get('to_user_id') is not None or
                kwargs['filters'].get('type') is not None
            ):
                is_allow_for_return_transfer = True

        if is_allow_for_return_transfer:
            if 'order_by' in kwargs:
                if kwargs['order_by'] == '-id':
                    kwargs['order_by'] = '-created_at'
                elif kwargs['order_by'] == 'id':
                    kwargs['order_by'] = 'created_at'

            sum_value = 0

            kwargs['filters']['created_at'] = {
                'from': date_from.strftime(self.datetime_pattern) + f" {self.datetime_default_timezone}",
                'to': date_to.strftime(self.datetime_pattern) + f" {self.datetime_default_timezone}"
            }

            if kwargs['filters'].get('type'):
                sum_query = self.get_sum_query(session)
                items, count, sum_value = self.model.query_by_params(query, session, sum='value', sum_query=sum_query, **kwargs)
            else:
                items, count = self.model.query_by_params(query, session, **kwargs)

        else:
            items, count, sum_value = [], 0, 0

        data = self.serializer(items, many=True).data

        return {"items": data, "count": count, "sum": str(round(sum_value, 3))}


class MoneyTransferSettingsView(AbstractSettingsView):
    view = MoneyTransferCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": TransferTypes.TYPES
        },
        "from_user_id": {
            "type": "number",
            "name": "От какого пользователя ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "to_user_id": {
            "type": "number",
            "name": "К какому пользователя ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "note": {
            "type": "text",
            "name": "Заметка",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "created_at": {
            "type": "datetime",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "balance_before": {
            "type": "number",
            "name": "Баланс до трансфера",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "description": {
            "type": "text",
            "name": "Description",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 6
        },
    }


router = SimpleRouter()
router.register('/transfers/settings', MoneyTransferSettingsView, 'GET')
router.register('/transfers/list', MoneyTransferCRUDView, 'GET')
router.register('/transfers/{id}', MoneyTransferCRUDView, ['GET', 'PUT'])
