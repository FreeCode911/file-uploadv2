from aiorest_ws.routers import SimpleRouter

from ..utils.abstract_view import AbstractView
from betronic_core.db.models.user import UserModel
from admin.src.utils.user_mixin import UserMixin
from tornado.options import options


class EntityView(AbstractView, UserMixin):
    ENTITY = {
        UserModel.OWNER: options.OWNER_ENTITY,
        UserModel.LIMITED_OWNER: options.LIMITED_OWNER_ENTITY,
        UserModel.TECHSUPPORT: options.DEFAULT_TECHSUPPORT_ENTITY,
        UserModel.CASHIER: options.DEFAULT_CASHIER_ENTITY,
    }

    def get(self, request, *args, **kwargs):
        user = self.get_user(**kwargs)
        if user['role'] not in self.ENTITY:
            raise Exception('permission denied')
        if user['id'] in options.CASHIERS_CAN_NOTIFY:
            return options.NOTIFICATIONS_CASHIERS_ENTITY

        return self.ENTITY[user['role']]


router = SimpleRouter()
router.register('/entity', EntityView, 'GET')
