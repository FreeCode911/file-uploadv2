from logging import getLogger

import requests
from aiorest_ws.routers import SimpleRouter
from sqlalchemy import or_
from tornado.options import options

from admin.src.serializers import UserSerializer
from admin.src.utils.user_mixin import UserMixin
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.db.database import DataBase
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.manager import UserManager
from util.error import InvalidRequestData

from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session

logger = getLogger(__name__)


class AdminListCRUDView(AbstractCRUDView, UserMixin):
    serializer = UserSerializer
    model = UserModel

    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER,)
    }

    def __init__(self):
        self.db = DataBase.get()

    def get_query(self, session, admin_id=None, admin_role=3):
        query = session.query(self.model).filter(or_(
                self.model.role == self.model.SUPER_ADMIN, self.model.role == self.model.ADMIN))\
            .filter(self.model.id > 0)

        if admin_role == self.model.SUPER_ADMIN:
            query = query.filter(self.model.parent_suadmin_id == admin_id)
        return query

    def _get_model_all(self, session, admin_user=None, **kwargs):
        query = self.get_query(session, admin_id=admin_user['id'], admin_role=admin_user['role'])
        items, count, sum_value = self.model.query_by_params(query, session, sum='balance', **kwargs)
        data = self.serializer(items, many=True).data
        return {'items': data, 'count': count, 'sum': str(sum_value)}

    def _get_model_by_id(self, session, id, admin_user=None):
        user = self.get_query(session).filter(self.model.id == id).first()
        if not user:
            raise Exception("Resource not exist")

        if admin_user['role'] == self.model.SUPER_ADMIN and not\
                user.parent_suadmin_id == admin_user['id']:
            raise Exception("Resource not available")

        return self.serializer(user).data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result

    @permission
    def post(self, request, *args, **kwargs):
        admin = self.get_user(**kwargs)
        if admin['role'] == self.model.OWNER and \
                request.data.get('role') == self.model.ADMIN and not\
                request.data.get('parent_suadmin_id', None):
            raise Exception("Super-admin ID must be specified!")

        if request.data.get('email_auth.email') is None:
            raise Exception(f'Fail to register user: Field email is required')
 
        name = " ".join((request.data.get('last_name', ''),
                         request.data.get('first_name', ''),
                         request.data.get('middle_name', '')))

        data = {
            'username': request.data.get('email_auth.email'),
            'email': request.data.get('email_auth.email'),
            'password': request.data.get('password'),
            'currency': options.AVAILABLE_CURRENCIES[int(request.data.get('currency_enum'))],
            'name': name
        }
        session = requests.Session()
        response = session.post(options.BASE_URL + '/api/user/signup', json=data)
        response_json = response.json()
        if int(response_json['status']):
            raise Exception(f'Fail to register user: {response_json.get("error_message")}')

        user = UserModel.get_by_id(self.db, response_json['result']['user_id'])
        if request.data.get('role') != UserModel.SUPER_ADMIN:
            if admin['role'] == self.model.SUPER_ADMIN:
                user.parent_suadmin_id = admin['id']
            else:
                user.parent_suadmin_id = request.data.get('parent_suadmin_id')

        user.role = request.data.get('role', self.model.ADMIN)
        user.nickname = request.data.get('email_auth.email')
        user.additional_data.phone = request.data.get('additional_data.phone')
        user.additional_data.address = request.data.get('additional_data.address')
        self.db.add(user)
        self.db.commit()
        return response.json()

    @permission
    def put(self, request, *args, **kwargs):
        admin = self.get_user(**kwargs)
        user = UserModel.get_by_id(self.db, args[0])
        is_banned = request.data.get('is_banned')
        close_all_active_sessions = request.data.get('close_all_active_sessions')

        if admin['role'] == self.model.SUPER_ADMIN and \
                int(user.role) != int(request.data.get('role')):
            raise Exception("You can't change the role!")

        if admin['role'] in [self.model.OWNER, self.model.LIMITED_OWNER] and \
                request.data.get('parent_suadmin_id') != user.parent_suadmin_id:
            if not UserModel.check_role_by_id(self.db, request.data.get('parent_suadmin_id'), self.model.SUPER_ADMIN):
                raise InvalidRequestData("Target parent suadmin is not a suadmin")

            logger.warning("Owner want  bind admin to different structures admin_id: %s "
                           " origin admin parent_suadmin_id %s"
                           " target admin parent_suadmin_id %s",
                           user.id, user.parent_suadmin_id, request.data.get("parent_suadmin_id"))
            self.db.query(UserModel).filter(
                UserModel.parent_admin_id == user.id,
                UserModel.parent_suadmin_id == user.parent_suadmin_id
            ).update({UserModel.parent_suadmin_id: request.data["parent_suadmin_id"]})
            user.parent_suadmin_id = request.data['parent_suadmin_id']

            self.db.add(user)

        if request.data.get('email_auth.email'):
            user.email_auth.email = (request.data.pop('email_auth.email'))
            self.db.add(user)
            self.db.commit()
        if request.data.get('password'):
            user.email_auth.set_password(request.data.pop('password'))
            note = f'The user with ID {admin["id"]} changed the password for the user with ID {args[0]}'
            UserManager(self.db).security_log(args[0], None, "admin", "change password", request.data, note)
        if request.data.get('additional_data.phone'):
            user.additional_data.phone = \
                request.data.pop('additional_data.phone')
        if request.data.get('additional_data.address'):
            user.additional_data.address = \
                request.data.pop('additional_data.address')

        if is_banned != user.is_banned:
            user.is_banned = is_banned
            self.db.add(user)

        if is_banned or close_all_active_sessions:
            CacheManager.close_all_sessions_by_user_id(user.id)

        user.first_name = request.data.get('first_name') or user.first_name
        user.last_name = request.data.get('last_name') or user.last_name

        self.db.add(user)
        self.db.commit()

    @session
    @permission
    def delete(self, request, id=None, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        instance = self.get_query(session).filter(
            self.model.id == int(id)).first()
        if not instance:
            raise Exception('Object does not exist')

        count = UserModel.get_binding_users(session, instance.id, instance.role, count=True)
        name = 'admin' if instance.role == UserModel.ADMIN else 'superadmin'
        if count:
            raise Exception(f'You can not delete {name}, he is got {count} users binding to him!')

        instance.is_banned = True
        instance.is_visible = False
        instance.email_auth.email = "deleted_" + instance.email_auth.email + "_" + str(instance.id)
        instance.role = UserModel.USER
        session.add(instance)
        session.commit()
        CacheManager.close_all_sessions_by_user_id(id)
        result = self._get_model_all(session, **kwargs)
        return result


class AdminSettingsView(AbstractSettingsView):
    view = AdminListCRUDView

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)
        fields = self.fields.copy()
        if user['role'] == UserModel.SUPER_ADMIN:
            fields.pop('parent_suadmin_id')
        return {
            "fields": fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "email_auth.email": {
            "type": "text",
            "name": "Логин",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "weight": 2,
            "editableWeight": 1
        },
        "password": {
            "type": "text",
            "name": "Пароль",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 2
        },
        "first_name": {
            "type": "text",
            "name": "Имя",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 3,
            "editableWeight": 3

        },
        "last_name": {
            "type": "text",
            "name": "Фамилия",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 3,
            "editableWeight": 4
        },
        "role": {
            "type": "enum",
            "name": "Роль администратора",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "enum": UserModel.ADMIN_ROLES,
            "editableWeight": 5
        },
        "balance": {
            "type": "number",
            "balance": "Баланс",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "currency_enum": {
            "type": "enum",
            "name": "Валюта",
            "enum": options.AVAILABLE_CURRENCIES,
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 6
        },
        "parent_suadmin_id": {
            "type": "number",
            "name": "ID супер-админа",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "editableWeight": 7
        },
        "city": {
            "type": "text",
            "name": "Город",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "editableWeight": 8
        },
        "is_banned": {
            "type": "boolean",
            "name": "Бан",
            "order": True,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 9
        },
        "close_all_active_sessions": {
            "type": "boolean",
            "name": "Закрыть все активные сессии",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 10
        }
    }


router = SimpleRouter()
router.register('/admins/list', AdminListCRUDView, 'GET')
router.register('/admins/settings', AdminSettingsView, 'GET')
router.register('/admins/{id}', AdminListCRUDView, ['GET', 'PUT', 'CREATE'])
