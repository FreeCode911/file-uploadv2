from datetime import datetime, timedelta
from decimal import Decimal
from typing import Dict

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import func, and_
from tornado.options import options

from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.manager import MoneyManager
from ..utils.abstract_view import AbstractSettingsView, AbstractStatisticsCRUDView
from ..utils.decorators import permission, session


class RoyaltyStatisticCRUDView(AbstractStatisticsCRUDView, UserMixin):
    model = RoyaltyStatisticModel
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    @staticmethod
    def _convert_currency_and_prepare_data(session, data, currency):
        default_currency = options.ROYALTY_STATISTIC_CALCULATION_CURRENCY
        prepared_data = []
        for provider in options.ROYALTY_STATISTIC_TRANSFER_TYPES:
            bet_count = int(0)
            bet_sum = Decimal(0)
            win_sum = Decimal(0)
            total = Decimal(0)
            for row in data:
                if row["provider"] == provider:
                    if row["currency"] != default_currency and not currency:
                        money_manager = MoneyManager(session)
                        bet_sum += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["bet_sum"],
                            allow_negative=True,
                            currency_selected=currency
                        )

                        win_sum += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["win_sum"],
                            allow_negative=True,
                            currency_selected=currency
                        )

                        total += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["total"],
                            allow_negative=True,
                            currency_selected=currency
                        )
                    else:
                        bet_sum += Decimal(row["bet_sum"])
                        win_sum += Decimal(row["win_sum"])
                        total += Decimal(row["total"])
                    bet_count += row['bet_count']
                else:
                    continue
            if provider in options.REVENUE_NEGATIVE_REV_SHARE_PROVIDERS:
                total = str(round(total, 2))
            else:
                total = (
                    str(round(total, 2))
                    if total > 0 else "0"
                )
            prepared_data.append(
                {
                    "provider": provider,
                    "bet_count": str(int(bet_count)),
                    "bet_sum": str(round(bet_sum, 2)),
                    "win_sum": str(round(win_sum, 2)),
                    "total": total
                }
            )
        return prepared_data

    @staticmethod
    def _calculate_summary_total(prepared_data):
        bet_count = 0
        bet_sum = Decimal(0)
        win_sum = Decimal(0)
        total = Decimal(0)
        for provider in prepared_data:
            bet_count += int(provider["bet_count"])
            bet_sum += Decimal(provider["bet_sum"])
            win_sum += Decimal(provider["win_sum"])
            total += Decimal(provider["total"])
        summary = {"provider": "full", "bet_count": str(int(bet_count)),
                   "bet_sum": str(round(bet_sum, 2)), "win_sum": str(round(win_sum, 2)), "total": str(round(total, 2))}
        return summary

    def _get_royalty_data(self, session, date_filter: Dict, currency: str = None):
        result_query = session.query(
            self.model.provider,
            self.model.currency,
            func.sum(self.model.bet_count).label("bet_count"),
            func.sum(self.model.bet_sum).label("bet_sum"),
            func.sum(self.model.win_sum).label("win_sum"),
            func.sum(self.model.total).label("total")). \
            filter(self.model.created_at >= date_filter['from'],
                  self.model.created_at <= date_filter['to'])\
            .group_by(self.model.provider, self.model.currency)

        if currency:
            result_query = result_query.filter(self.model.currency == currency)

        serialize_result = self._serialize_query(result_query.all())
        prepared_data = self._convert_currency_and_prepare_data(session, serialize_result, currency)
        summary_data = self._calculate_summary_total(prepared_data)
        prepared_data.append(summary_data)

        return prepared_data

    def _get_model_all(self, session, **kwargs):
        date_filters = kwargs['filters'].get('date')
        currency_type = kwargs['filters'].get('currency_type', None)
        result = self._get_royalty_data(session, date_filters, currency_type)
        return result

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):
        yesterday = datetime.today() - timedelta(days=1)
        tomorrow = datetime.today() + timedelta(days=1)
        date_filters = kwargs['filters'].get('date') if kwargs['filters'].get('date') else {}
        if not date_filters.get('from'):
            date_filters['from'] = yesterday.strftime('%Y-%m-%d')
        if not date_filters.get('to'):
            date_filters['to'] = tomorrow.strftime('%Y-%m-%d')
        kwargs['filters']['date'] = date_filters
        items = self._get_model_all(session, **kwargs)
        return {
            'items': items,
            'count': len(items),
        }


class RoyaltyStatisticSettingsView(AbstractSettingsView):
    view = RoyaltyStatisticCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "currency_type": {
            "type": "enum",
            "name": "Типы пользователей",
            "enum": {name: name for name in options.AVAILABLE_CURRENCIES},
            "order": False,
            "filter": True,
            "table": False,
            "editable": False
        },
        "date": {
            "type": "date",
            "name": "Дата",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "default": 'today',
            "weight": -1
        },
        "provider": {
            "type": "text",
            "name": "Провайдер",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "bet_count": {
            "type": "number",
            "name": "Количество Ставок",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "bet_sum": {
            "type": "number",
            "name": "Сумма ставок",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "win_sum": {
            "type": "number",
            "name": "Сумма выигрышей",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        },
        "total": {
            "type": "number",
            "name": "Всего",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        }
    }


router = SimpleRouter()
router.register('/royalty_statistic/list', RoyaltyStatisticCRUDView, 'GET')
router.register('/royalty_statistic/settings', RoyaltyStatisticSettingsView, 'GET')
