from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractCRUDView, \
    AbstractSettingsView
from betronic_core.db.models.bet_content_data import BetContentDataModel
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel
from betronic_core.db.models.user import UserModel
from ..serializers import BetContentSerializer
from admin.src.utils.user_mixin import UserMixin
from ..utils.decorators import session, permission


class BetsCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN, UserModel.ADMIN, UserModel.CASHIER),
        'CREATE': (), 'DELETE': (), 'UPDATE': ()
    }
    model = BetContentDataModel
    serializer = BetContentSerializer

    def get_query(self, session, admin=None):
        query = session.query(self.model)
        if admin and admin['role'] == UserModel.CASHIER:
            query = query.filter(
                self.model.local_bet_id == BetrouteLocalBetModel.id,
                BetrouteLocalBetModel.from_user_id == UserModel.id,
                UserModel.parent_cashier_id == int(admin['id'])
            )
        elif admin and admin['role'] == UserModel.ADMIN:
            query = query.filter(
                self.model.local_bet_id == BetrouteLocalBetModel.id,
                BetrouteLocalBetModel.from_user_id == UserModel.id,
                UserModel.parent_admin_id == int(admin['id'])
            )
        elif admin and admin['role'] == UserModel.SUPER_ADMIN:
            query = query.filter(
                self.model.local_bet_id == BetrouteLocalBetModel.id,
                BetrouteLocalBetModel.from_user_id == UserModel.id,
                UserModel.parent_suadmin_id == int(admin['id'])
            )
        return query

    def _get_model_all(self, session, admin=None, **kwargs):
        query = self.get_query(session, admin)

        items, count = self.model.query_by_params(query, session, **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result


class BetsSettingsCRUDView(AbstractSettingsView):
    view = BetsCRUDView
    fields = {
        "main_result": {
            "type": "text",
            "name": "Результат",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "tournament_name": {
            "type": "text",
            "name": "Название события",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "teams": {
            "type": "text",
            "name": "Команды",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "bet_name": {
            "type": "text",
            "name": "Ставка",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "coef": {
            "type": "number",
            "name": "Коэф",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "event_date": {
            "type": "date",
            "name": "Дата события",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "betroute_local_bet.betcode": {
            "type": "text",
            "name": "Ticket barcode",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "betroute_local_bet.from_user_id": {
            "type": "text",
            "name": "UserID",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        }
    }

router = SimpleRouter()
router.register('/bets/settings', BetsSettingsCRUDView, 'GET')
router.register('/bets/list', BetsCRUDView, 'GET')
