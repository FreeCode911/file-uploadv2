from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.ads import AdsModel
from betronic_core.db.models.user import UserModel
from admin.src.serializers import AdsSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class AdsListCRUDView(AbstractCRUDView):
    model = AdsModel
    serializer = AdsSerializer
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class AdsSettingsView(AbstractSettingsView):
    view = AdsListCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "html": {
            "type": "html",
            "name": "Html Код",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "priority": {
            "type": "number",
            "name": "Приоритет",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/ads/list', AdsListCRUDView, 'GET')
router.register('/ads/settings', AdsSettingsView, 'GET')
router.register('/ads/create', AdsListCRUDView, 'POST')
router.register('/ads/{id}', AdsListCRUDView, ['GET', 'PUT', 'DELETE'])
