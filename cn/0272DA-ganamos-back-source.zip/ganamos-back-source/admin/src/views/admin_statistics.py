from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractSettingsView, AbstractStatisticsCRUDView
from betronic_core.db.models.user import UserModel as User
from betronic_core.db.models.base import BaseModel
from ..utils.decorators import permission, session
from betronic_core.constants import TransferTypes
from admin.src.utils.user_mixin import UserMixin
from datetime import datetime
from betronic_core.db.models.user import UserModel


class AdminStatisticsCRUDView(AbstractStatisticsCRUDView, UserMixin):
    model = BaseModel
    roles = {
        'GET': (User.ADMIN, User.SUPER_ADMIN, User.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin = self.get_user(**kwargs)
        default_date = datetime.today().strftime("%Y-%m-%d")[:-2] + "01"

        date_filter = request.args['filters']\
            .get('date', {'from': default_date})

        specific_id = request.args['filters'].get('id')
        cashiers = session.query(UserModel.id, UserModel.first_name,
                                 UserModel.parent_admin_id, UserModel.parent_suadmin_id)\
            .filter(UserModel.role == UserModel.CASHIER)\
            .filter(UserModel.is_active != True)

        parent_suadmin_id = request.args['filters'].get('parent_suadmin_id')
        parent_admin_id = request.args['filters'].get('parent_admin_id')
        if admin['role'] == UserModel.SUPER_ADMIN:
            parent_suadmin_id = admin['id']  # super admin can see only his admins
        elif admin['role'] == UserModel.ADMIN:
            parent_admin_id = admin['id']
            parent_suadmin_id = None  # admin can see only himself

        if parent_suadmin_id:
            cashiers = cashiers.filter(UserModel.parent_suadmin_id == parent_suadmin_id)
        if parent_admin_id:
            cashiers = cashiers.filter(UserModel.parent_admin_id == parent_admin_id)
        cashiers = cashiers.filter(UserModel.id == specific_id) \
            if specific_id else cashiers

        cashiers = cashiers.cte('cashiers')

        refills = self.get_transfers_by_type(
            session, cashiers,
            TransferTypes.TYPE_ORGANIZATION_TO_CASHIER,
            transfer_direction='to', date=date_filter)

        write_offs = self.get_transfers_by_type(
            session, cashiers,
            TransferTypes.TYPE_USER_TO_CASHIER,
            transfer_direction='from', date=date_filter)

        result_query = session \
            .query(
                cashiers.c.id,
                cashiers.c.first_name,
                cashiers.c.parent_admin_id,
                cashiers.c.parent_suadmin_id,
                refills.c.value.label('refill'),
                write_offs.c.value.label('write_off'),
                # (refills.c.value - write_offs.c.value).label('income'),
            ) \
            .join(refills, cashiers.c.id == refills.c.t_uid) \
            .join(write_offs, cashiers.c.id == write_offs.c.t_uid)

        result = self._serialize_query(result_query.all())

        sum_refill = 0
        sum_write_off = 0

        for cashier_data in result:
            sum_refill += cashier_data.get('refill', 0)
            sum_write_off += cashier_data.get('write_off', 0)

        sum_income = sum_refill - sum_write_off

        for row in result:
            row['income'] = row['refill'] - row['write_off']
            for key, value in row.items():
                if value == 0 and key not in ['phone', 'first_name']:
                    row[key] = '0.00'

        return {
            'items': result,
            'count': len(result),
            'additional_field': {
                'Получено всеми кассирами': str(sum_refill),
                'Выплачено всеми кассирами': str(sum_write_off),
                'Общий доход': str(sum_income)
            }
        }


class AdminStatisticsSettingsView(AbstractSettingsView):
    view = AdminStatisticsCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "date": {
            "type": "date",
            "name": "Дата",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "default": 'today',
            "weight": -1
        },
        "id": {
            "type": "number",
            "name": "id",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "first_name": {
            "type": "text",
            "name": "Имя кассира",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "parent_admin_id": {
            "type": "number",
            "name": "Admin's ID",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "parent_suadmin_id": {
            "type": "number",
            "name": "Super Admin's ID",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "refill": {
            "type": "number",
            "name": "Пользователь -> Кассир",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "write_off": {
            "type": "number",
            "name": "Кассир -> Пользователь",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "income": {
            "type": "number",
            "name": "Доход кассира",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        }
    }


router = SimpleRouter()
router.register('/admin_statistics/list', AdminStatisticsCRUDView, 'GET')
router.register('/admin_statistics/settings', AdminStatisticsSettingsView, 'GET')