from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional

from aiorest_ws.routers import SimpleRouter
from sqlalchemy import func
from tornado.options import options

from admin.src.utils.user_mixin import UserMixin
from admin.src.utils.royalty_statistics import (
    check_currency_for_real,
)
from betronic_core.db.models.bonus_royalty_statistic import BonusRoyaltyStatisticModel
from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.manager import MoneyManager
from ..utils.abstract_view import AbstractSettingsView, AbstractStatisticsCRUDView
from ..utils.decorators import permission, session


class RevenueStatisticCRUDView(AbstractStatisticsCRUDView, UserMixin):
    bonus_model = BonusRoyaltyStatisticModel
    real_model = RoyaltyStatisticModel
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    @staticmethod
    def _convert_currency_and_prepare_data(session, data, currency_type: Optional[str] = None):
        prepared_data = []
        default_currency = options.ROYALTY_STATISTIC_CALCULATION_CURRENCY
        currency_selected = True if currency_type else False

        for provider in options.ROYALTY_STATISTIC_TRANSFER_TYPES:
            bet_count = int(0)
            bet_sum = Decimal(0)
            win_sum = Decimal(0)
            total = Decimal(0)
            revenue_share_local_currency = Decimal(0)
            revenue_share_usd = Decimal(0)
            for row in data:
                if row["provider"] == provider:
                    money_manager = MoneyManager(session)
                    if row["currency"] != default_currency and not currency_selected:
                        bet_sum += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["bet_sum"],
                            allow_negative=True,
                            currency_selected=currency_selected
                        )

                        win_sum += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["win_sum"],
                            allow_negative=True,
                            currency_selected=currency_selected
                        )

                        total += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["total"],
                            allow_negative=True,
                            currency_selected=currency_selected
                        )

                        revenue_share_local_currency += money_manager.get_converted_royalty_amount(
                            from_currency=row["currency"],
                            to_currency=default_currency,
                            amount=row["revenue_share_local_currency"],
                            allow_negative=True,
                            currency_selected=currency_selected
                        )
                    else:
                        bet_sum += Decimal(row["bet_sum"])
                        win_sum += Decimal(row["win_sum"])
                        total += Decimal(row["total"])
                        revenue_share_local_currency += Decimal(row["revenue_share_local_currency"])

                    if check_currency_for_real(currency_type):
                        revenue_share_usd = money_manager.calculate_revenue_share_usd(row["currency"], revenue_share_local_currency)
                    else:
                        revenue_share_usd += Decimal(row["revenue_share_usd"])
                    bet_count += row['bet_count']

                else:
                    continue

            if provider in options.REVENUE_NEGATIVE_REV_SHARE_PROVIDERS:
                revenue_share_local_currency = str(round(revenue_share_local_currency, 2))
                revenue_share_usd = str(round(revenue_share_usd, 2))
                total = str(round(total, 2))
            else:
                revenue_share_local_currency = (
                    str(round(revenue_share_local_currency, 2))
                    if revenue_share_local_currency > 0 else "0"
                )
                revenue_share_usd = (
                    str(round(revenue_share_usd, 2))
                    if revenue_share_usd > 0 else "0"
                )
                total = str(round(total, 2)) if total > 0 else "0"

            prepared_data.append(
                {
                    "provider": provider,
                    "bet_count": str(int(bet_count)),
                    "bet_sum": str(round(bet_sum, 2)),
                    "win_sum": str(round(win_sum, 2)),
                    "revenue_share_local_currency": revenue_share_local_currency,
                    "revenue_share_usd": revenue_share_usd,
                    "provider_percent": (
                        str(round(options.ROYALTY_STATISTIC_TRANSFER_TYPES[provider]['revenue_percent'] * 100, 1)) + (
                        " €" if provider in options.PROVIDERS_WITH_FIXED_ROYALTY else " %")
                    ),
                    "total": total
                }
            )

        return prepared_data

    @staticmethod
    def _calculate_summary_total(prepared_data):
        bet_count = 0
        bet_sum = Decimal(0)
        win_sum = Decimal(0)
        total = Decimal(0)
        provider_percent = 0
        provider_share_local = Decimal(0)
        provider_share_usd = Decimal(0)
        for provider in prepared_data:
            bet_count += int(provider["bet_count"])
            bet_sum += Decimal(provider["bet_sum"])
            win_sum += Decimal(provider["win_sum"])
            total += Decimal(provider["total"])
            provider_share_local += Decimal(provider['revenue_share_local_currency'])
            provider_share_usd += Decimal(provider['revenue_share_usd'])
        summary = {"provider": "full", "bet_count": str(int(bet_count)),
                   "bet_sum": str(round(bet_sum, 2)), "win_sum": str(round(win_sum, 2)),
                   "total": str(round(total, 2)), "revenue_share_local_currency": str(round(provider_share_local, 2)),
                   "revenue_share_usd": str(round(provider_share_usd, 2)), "provider_percent": provider_percent
                   }
        return summary

    def _query_revenue_data(self, session, date_filter, currency: str = None):
        result_real_query = session.query(
            self.real_model.provider,
            self.real_model.currency,
            func.sum(self.real_model.bet_count).label("bet_count"),
            func.sum(self.real_model.bet_sum).label("bet_sum"),
            func.sum(self.real_model.win_sum).label("win_sum"),
            func.sum(self.real_model.total).label("total"),
            func.sum(self.real_model.revenue_share_local_currency).label("revenue_share_local_currency"),
            func.sum(self.real_model.revenue_share_usd).label("revenue_share_usd")
        ). \
            filter(self.real_model.created_at >= date_filter['from'],
                   self.real_model.created_at <= date_filter['to']).group_by(self.real_model.provider,
                                                                             self.real_model.currency)

        if currency:
            result_real_query = result_real_query.filter(self.real_model.currency == currency)

        serialize_real_result = self._serialize_query(result_real_query.all())

        result_bonus_query = session.query(
            self.bonus_model.provider,
            self.bonus_model.currency,
            func.sum(self.bonus_model.bet_count).label("bet_count"),
            func.sum(self.bonus_model.bet_sum).label("bet_sum"),
            func.sum(self.bonus_model.win_sum).label("win_sum"),
            func.sum(self.bonus_model.total).label("total"),
            func.sum(self.bonus_model.revenue_share_local_currency).label("revenue_share_local_currency"),
            func.sum(self.bonus_model.revenue_share_usd).label("revenue_share_usd")
        ). \
            filter(self.bonus_model.created_at >= date_filter['from'],
                   self.bonus_model.created_at <= date_filter['to']).group_by(self.bonus_model.provider,
                                                                              self.bonus_model.currency)

        if currency:
            result_bonus_query = result_bonus_query.filter(self.bonus_model.currency == currency)

        serialize_bonus_result = self._serialize_query(result_bonus_query.all())

        serialize_result = serialize_real_result + serialize_bonus_result
        return serialize_result

    def _get_royalty_data(self, session, date_filter, currency_type):
        serialize_result = self._query_revenue_data(session, date_filter, currency_type)
        revenue_prepared_data = self._convert_currency_and_prepare_data(session, serialize_result, currency_type)

        summary_data = self._calculate_summary_total(revenue_prepared_data)
        revenue_prepared_data.append(summary_data)

        return revenue_prepared_data

    def _get_model_all(self, session, **kwargs):
        date_filters = kwargs['filters'].get('date')
        currency_type = kwargs['filters'].get('currency_type', None)
        result = self._get_royalty_data(session, date_filters, currency_type)
        return result

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):
        yesterday = datetime.today() - timedelta(days=1)
        tomorrow = datetime.today() + timedelta(days=1)
        date_filters = kwargs['filters'].get('date') if kwargs['filters'].get('date') else {}
        if not date_filters.get('from'):
            date_filters['from'] = yesterday.strftime('%Y-%m-%d')
        if not date_filters.get('to'):
            date_filters['to'] = tomorrow.strftime('%Y-%m-%d')
        kwargs['filters']['date'] = date_filters
        items = self._get_model_all(session, **kwargs)
        return {
            'items': items,
            'count': len(items),
        }


class RevenueStatisticSettingsView(AbstractSettingsView):
    view = RevenueStatisticCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "currency_type": {
            "type": "enum",
            "name": "Типы пользователей",
            "enum": {name: name for name in options.AVAILABLE_CURRENCIES},
            "order": False,
            "filter": True,
            "table": False,
            "editable": False
        },
        "date": {
            "type": "date",
            "name": "Дата",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "default": 'today',
            "weight": -1
        },
        "provider": {
            "type": "text",
            "name": "Провайдер",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "bet_count": {
            "type": "number",
            "name": "Количество Ставок",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "bet_sum": {
            "type": "number",
            "name": "Сумма ставок",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "win_sum": {
            "type": "number",
            "name": "Сумма выигрышей",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        },
        "total": {
            "type": "number",
            "name": f"Всего({options.ROYALTY_STATISTIC_CALCULATION_CURRENCY})",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 7
        },
        "provider_percent": {
            "type": "number",
            "name": "Provider's share",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 8
        },
        "revenue_share_local_currency": {
            "type": "number",
            "name": f"Rev Share",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 9
        },
        "revenue_share_usd": {
            "type": "number",
            "name": "Rev Share USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 10
        }
    }


router = SimpleRouter()
router.register('/revenue_statistic/list', RevenueStatisticCRUDView, 'GET')
router.register('/revenue_statistic/settings', RevenueStatisticSettingsView, 'GET')
