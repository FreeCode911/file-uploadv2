from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.user import UserModel
from admin.src.serializers import WithdrawalSerializer
from ..utils.abstract_view import AbstractCRUDViewDefaults, AbstractSettingsView
from betronic_core.constants import TransferTypes
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.db.models.currency_rate import CurrencyRateModel
from admin.src.utils.user_mixin import UserMixin
from ..utils.decorators import session, permission
from logging import getLogger
from datetime import datetime as dt

logger = getLogger(__name__)


class WithdrawalCRUDView(AbstractCRUDViewDefaults, UserMixin):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN, UserModel.ADMIN, UserModel.CASHIER),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN, UserModel.ADMIN, UserModel.CASHIER),
        'DELETE': (),
    }
    model = WithdrawalModel
    serializer = WithdrawalSerializer
    cashier_forbidden_statuses = (WithdrawalModel.PROCESSING, WithdrawalModel.CANCELED)

    def get_query(self, session, admin=None):
        query = session.query(self.model).join(self.model.user)
        if admin and admin['role'] == UserModel.CASHIER:
            query = query\
                .filter(UserModel.parent_cashier_id == int(admin['id']))\
                .filter(self.model.status == WithdrawalModel.CREATED)
        elif admin and admin['role'] == UserModel.ADMIN:
            query = query\
                .filter(UserModel.parent_admin_id == int(admin['id']))
        elif admin and admin['role'] == UserModel.SUPER_ADMIN:
            query = query\
                .filter(UserModel.parent_suadmin_id == int(admin['id']))
        return query

    def _get_model_all(self, session, admin=None, **kwargs):
        query = self.get_query(session, admin)

        kwargs['filters'] = kwargs['filters'] or self.default_filters
        kwargs['order_by'] = kwargs['order_by'] or self.default_order

        items, count, sum_value =\
            self.model.query_by_params(query, session, sum='amount', **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count, 'sum': str(sum_value)}

    def _get_model_by_id(self, session, id, admin_user=None):
        item = self.get_query(session).filter(self.model.id == id).first()
        if not item:
            raise Exception("Resource not exist")

        not_available = False
        if admin_user['role'] == UserModel.CASHIER and \
                item.user.parent_cashier_id != admin_user['id']:
            not_available = True
        elif admin_user['role'] == UserModel.ADMIN and \
                item.user.parent_admin_id != admin_user['id']:
            not_available = True
        elif admin_user['role'] == UserModel.SUPER_ADMIN and \
                item.user.parent_suadmin_id != admin_user['id']:
            not_available = True

        if not_available:
            raise Exception("Resource not available")
        return self.serializer(item).data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result

    @session
    def put(self, request, id, session=None, *args, **kwargs):

        withdrawal = WithdrawalModel.get_by_id(session, id)
        if withdrawal.is_closed or withdrawal.status == WithdrawalModel.DONE:
            raise Exception("Withdrawal was already processed previously")

        admin = self.get_user(**kwargs)
        if admin['role'] == UserModel.CASHIER and \
            (withdrawal.status in self.cashier_forbidden_statuses or
             int(request.data['status']) != WithdrawalModel.DONE):

            logger.error("The cashier can't close the withdrawal %s,"
                         "cause withdrawal status is %s", withdrawal.id, withdrawal.status)
            raise Exception("Cashier can only close withdrawal!")

        if admin['role'] == UserModel.CASHIER and \
                int(request.data['status']) == WithdrawalModel.DONE:
            admin_model = UserModel.get_by_id(session, admin['id'])
            max_withdrawal = admin_model.cashier_data.max_withdrawal if \
                admin_model.cashier_data else 0
            if max_withdrawal and max_withdrawal < withdrawal.amount:
                raise Exception("Withdrawal more max count one withdrawal")

            money_manager = MoneyManager(session)
            convert_amount = CurrencyRateModel.convert(session,
                                                       withdrawal.amount,
                                                       withdrawal.currency,
                                                       admin['currency'])

            # balance = UserModel.get_by_id(session, admin['id']).balance

            # Minus balance is on now:
            # if float(balance) < float(convert_amount):
            #     raise Exception("Not enough money!")

            money_manager.user_move_money(admin['id'],
                                          UserModel.ORGANIZATION_ID,
                                          convert_amount,
                                          TransferTypes.TYPE_USER_TO_CASHIER)
            withdrawal.is_closed = True
            session.add(withdrawal)
            session.commit()
            session.close()
        data = super().put(request, id, *args, **kwargs)
        return data


class WithdrawalSettingsView(AbstractSettingsView):
    view = WithdrawalCRUDView

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        fields = self.fields.copy()
        permissions = self.get_permission(user, self.view.roles)

        if user['role'] not in [UserModel.OWNER, UserModel.LIMITED_OWNER]:
            fields.pop('user.parent_cashier_id')
            fields.pop('user.parent_admin_id')
            fields.pop('user.parent_suadmin_id')
        return {
            "fields": fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    additional_settings = {
        'manage_rows': False,
    }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "user_id": {
            "type": "number",
            "name": "ID Пользователя",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "purse": {
            "type": "text",
            "name": "Номер счёта",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 8
        },
        "user.additional_data.phone": {
            "type": "text",
            "name": "Телефон пользователя",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
        },
        "amount": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 5
        },
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 6
        },
        "status": {
            "type": "enum",
            "name": "Статус",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
            "enum": WithdrawalModel.STATUSES,
            "weight": 4
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 2,
            "default": "today",
        },
        "is_closed": {
            "type": "boolean",
            "name": "Is closed",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
        },
        # След. 3 поля - для дебага, вырезать при релизе.
        "user.parent_admin_id": {
            "type": "number",
            "name": "PARENT_ADMIN",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "user.parent_suadmin_id": {
            "type": "number",
            "name": "PARENT_SUADMIN",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "user.parent_cashier_id": {
            "type": "number",
            "name": "PARENT_CASHIER",
            "order": False,
            "filter": True,
            "table": True,
            "editable": False,
        }
    }


router = SimpleRouter()
router.register('/withdrawal/settings', WithdrawalSettingsView, 'GET')
router.register('/withdrawal/list', WithdrawalCRUDView, 'GET')
router.register('/withdrawal/{id}', WithdrawalCRUDView, ['GET', 'PUT'])
