from datetime import date
from dateutil.relativedelta import relativedelta

from aiorest_ws.routers import SimpleRouter

from betronic_core.cache_manager.manager import CacheManager
from ..utils.abstract_view import AbstractSettingsView, AbstractCRUDView
from ..utils.decorators import permission, session
from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.royalty_manager.manager import RoyaltyManager
from tornado.options import options
from admin.src.utils.user_mixin import UserMixin
from betronic_core.db.models.user import UserModel


def generate_months():
    current_date = date.today().replace(day=1)
    prev_date = current_date
    result = {}
    while prev_date != options.START_DATE_FOR_WEBSITE_STATISTIC:
        if prev_date == current_date:
            result[f"date({prev_date.year}, {prev_date.month}, {prev_date.day})"] = f"This month"
        else:
            result[
                f"date({prev_date.year}, {prev_date.month}, {prev_date.day})"] = f"{prev_date.strftime('%B')} {prev_date.year}"
        prev_date -= relativedelta(months=1)

    return result


class WebsiteStatisticCRUDView(AbstractCRUDView, UserMixin):
    model = RoyaltyStatisticModel
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }

    @staticmethod
    def _get_date_filter(month) -> dict:
        first_day = eval(month)
        last_day = first_day + relativedelta(months=1)
        return {"from": first_day, "to": last_day}

    def _get_model_all(self, session, **kwargs):
        result = {}
        try:
            month_filters = kwargs['filters']['month']
            if not month_filters.startswith('date('):
                raise Exception("Invalid month input")
        except KeyError:
            today = date.today().replace(day=1)
            month_filters = f"date({today.year}, {today.month}, {today.day})"

        date_filter = self._get_date_filter(month_filters)

        result["revenue_share_usd"] = str(RoyaltyManager(session).get_rev_share_by_date(date_filter['from'],
                                                                                        date_filter['to']))
        result["total_paid_revenue_share_usd"], result["balance_from_previous_month"] = MoneyManager(session).\
            get_revenue_topups_sum(date_filter["from"], date_filter["to"])
        result["unplayed_revenue_share_usd"] = "{:.2f}".format(float(result["total_paid_revenue_share_usd"]) -
                                                               float(result["revenue_share_usd"]))

        interation_status = CacheManager.get_integration_status(raise_exception=False)
        result["website_status"] = "Working" if interation_status else "Not working"

        return [result]

    @permission
    @session
    def get(self, request, id=None, session=None, *args, **kwargs):

        items = self._get_model_all(session, **kwargs)
        a = {
            'items': items,
            'count': len(items),
            'sum': "Website status: " + f"{items[0]['website_status']}".upper()
        }
        return a


class WebsiteStatisticSettingsView(AbstractSettingsView):
    view = WebsiteStatisticCRUDView

    additional_settings = {
        'manage_rows': False,
    }

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)
        fields = self.fields.copy()
        months = generate_months()
        fields['month']['enum'] = months
        return {
            "fields": fields,
            "additional_settings": self.additional_settings,
            "permissions": permissions,
        }

    fields = {
        "month": {
            "type": "enum",
            "name": "Месяц",
            "order": False,
            "filter": True,
            "table": False,
            "editable": False,
            "enum": {},
        },
        "total_paid_revenue_share_usd": {
            "type": "number",
            "name": "Owner payments USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 2
        },
        "revenue_share_usd": {
            "type": "number",
            "name": "Rev Share USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 3
        },
        "unplayed_revenue_share_usd": {
            "type": "number",
            "name": "Unplayed Rev Share amount left USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 4
        },
        "balance_from_previous_month": {
            "type": "number",
            "name": "Balance from previous month USD",
            "order": False,
            "filter": False,
            "table": True,
            "editable": False,
            "weight": 5,
        },
        "website_status": {
            "type": "text",
            "name": "Website status",
            "order": False,
            "filter": False,
            "table": False,
            "editable": False,
            "weight": 6
        },
    }


router = SimpleRouter()
router.register('/website_statistics/list', WebsiteStatisticCRUDView, 'GET')
router.register('/website_statistics/settings', WebsiteStatisticSettingsView, 'GET')
