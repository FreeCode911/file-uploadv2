from datetime import datetime

from aiorest_ws.db.orm.exceptions import ValidationError
from aiorest_ws.routers import SimpleRouter
from sqlalchemy.orm.attributes import flag_modified
from tornado.options import options

from admin.src.serializers import PromoCodeSerializer
from admin.src.utils.decorators import session
from betronic_core.db.database import DataBase
from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.user import UserModel
from betronic_core.pragmatic_fetcher.fetcher import PragmaticFetcher
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission


class PromoCodeListCRUDView(AbstractCRUDView):
    model = PromoCodeModel
    serializer = PromoCodeSerializer

    def __init__(self):
        self.db = DataBase.get()


    def get_query(self, session):
        return session.query(self.model).filter(self.model.is_banned.is_(False))

    @staticmethod
    def create_pragmatic_freespins_remote(promo_obj: PromoCodeModel):
        response = PragmaticFetcher.create_pragmatic_freespins(promo_obj)
        return response["result"]

    @staticmethod
    def update_pragmatic_freespins_remote(promo_obj: PromoCodeModel):
        response = PragmaticFetcher.patch_update_pragmatic_freespins(promo_obj)
        return response

    @staticmethod
    def cancel_pragmatic_freespins_remote(promo_obj: PromoCodeModel):
        try:
            response = PragmaticFetcher.cancel_pragmatic_freespins(promo_obj)
        except Exception as exc:
            error_message = f"Remote error from pragmatic service. {str(exc)}"
            response = {
                "message": error_message
            }
        return response

    @permission
    @session
    def post(self, request, *args, **kwargs):
        promo_code = PromoCodeModel()
        promo_code.code = request.data.get("code")
        promo_code.amount = request.data.get("amount")
        promo_code.code_type = request.data.get("code_type")
        promo_code.available_to = request.data.get("available_to")
        promo_code.single_activation = request.data.get("single_activation")
        promo_code.additional_data = {}

        if promo_code.code_type == PromoCodeModel.TYPE_SPORT_CASHBACK:
            promo_code.additional_data = {
                "days_for_activation_promo": int(request.data.get("additional_data.days_for_activation_promo"))
            }
        elif promo_code.code_type == PromoCodeModel.TYPE_PRAGMATIC_FREESPINS:
            response = self.create_pragmatic_freespins_remote(promo_code)
            promo_code.additional_data["remote_id"] = response

        self.db.add(promo_code)
        self.db.commit()

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        result = super(PromoCodeListCRUDView, self).put(request, id, *args, **kwargs)
        promo_code = PromoCodeModel.get_by_id(self.db, id)
        if promo_code.code_type == PromoCodeModel.TYPE_PRAGMATIC_FREESPINS:
            remote_result = self.update_pragmatic_freespins_remote(promo_code)
            promo_code.additional_data["update_response"] = remote_result
            flag_modified(promo_code, "additional_data")
            self.db.add(promo_code)
            self.db.commit()

        return result

    @session
    @permission
    def delete(self, request, id=None, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        instance: PromoCodeModel = self.get_query(session).filter(self.model.id == int(id)).first()

        if not instance:
            raise ValidationError('Object does not exist')

        instance.is_banned = True
        instance.count_activation = 0
        instance.available_to = datetime.utcnow()

        if instance.code_type == PromoCodeModel.TYPE_PRAGMATIC_FREESPINS:
            remote_response = self.cancel_pragmatic_freespins_remote(instance)
            instance.additional_data["deletion_response"] = remote_response
            flag_modified(instance, "additional_data")

        session.add(instance)
        session.commit()
        result = self._get_model_all(session, **kwargs)
        return result

    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
    }


class PromoCodeSettingsView(AbstractSettingsView):
    view = PromoCodeListCRUDView

    @session
    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)

        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "code": {
            "type": "text",
            "name": "Код",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "amount": {
            "type": "number",
            "name": "Процент / Количество спинов",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "additional_data.days_for_activation_promo": {
            "type": "number",
            "name": "Дней для активации промокода",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "code_type": {
            "type": "enum",
            "name": "Тип",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "enum": PromoCodeModel.TYPES
        },
        "available_to": {
            "type": "date",
            "name": "Дата окончания",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "single_activation": {
            "type": "boolean",
            "name": "Единоразовая активация",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }
    if options.FEATURES['bonus_program']:
        fields['is_bonus'] = {
            "type": "boolean",
            "name": "На бонусный счет",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
        }


router = SimpleRouter()
router.register('/promo_code/settings', PromoCodeSettingsView, 'GET')
router.register('/promo_code/list', PromoCodeListCRUDView, 'GET')
router.register('/promo_code/create', PromoCodeListCRUDView, 'POST')
router.register('/promo_code/{id}', PromoCodeListCRUDView,
                ['GET', 'PUT', 'DELETE', 'POST'])
