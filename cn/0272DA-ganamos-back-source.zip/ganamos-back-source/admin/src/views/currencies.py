from datetime import datetime, timedelta
from json import dumps as json_dumps
from logging import getLogger

from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from admin.src.serializers import CurrencyRateSerializer
from betronic_core.db.database import DataBase
from betronic_core.db.models.currency_rate import CurrencyRateModel
from util import cache
from betronic_core.db.models.user import UserModel
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session
from ..utils.royalty_statistics import are_disabled_currencies

logger = getLogger(__name__)


class CurrenciesCRUDView(AbstractCRUDView):
    model = CurrencyRateModel
    serializer = CurrencyRateSerializer

    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
    }

    def __init__(self):
        self.db = DataBase.get()

    @staticmethod
    def _check_access_to_recalculation():
        # За 1 час до начала нового месяца перерасчет роялти запрещен
        now = datetime.now()
        next_month = now.replace(day=28) + timedelta(days=4)
        next_month = next_month.replace(day=1, hour=0, minute=0, second=0)
        time_remaining = next_month - now
        hours_remaining = time_remaining.total_seconds() / 3600

        if hours_remaining <= 1:
            return False
        return True

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        from_currency = request.data['from_currency']
        to_currency = request.data['to_currency']
        new_rate = request.data['rate']

        if are_disabled_currencies(from_currency, to_currency):
            logger.info("Disabled currencies for recalc are detected! %s%s", from_currency, to_currency)
            super().put(request, id, *args, **kwargs)
            return
        
        query = kwargs.get('query', None) or self.get_query(session)
        instance = query.filter(self.model.id == id).first()

        if (to_currency == options.REVENUE_DEFAULT_CURRENCY
                and from_currency in options.CURRENCIES_CONVERSION_WITHOUT_GOOGLE
                and to_currency != from_currency
                and float(instance.rate) != float(new_rate)
                and self._check_access_to_recalculation()):
            cache.set_with_endless_ttl(options.ROYALTY_RECALC_KEY % (from_currency,
                                                                     to_currency),
                                       json_dumps(
                                           {
                                               "new_rate": float(new_rate),
                                               "currency": from_currency,
                                           }
                                       ))
            logger.info(f'The exchange rate for currencies '
                        f'{from_currency} and {to_currency} has '
                        f'been changed from {float(instance.rate)} to {float(new_rate)}. '
                        f'The key for royalty recalculation has been set.')

        query = self.db.query(self.model)
        super().put(request, id, *args, query=query, **kwargs)


class CurrencyPageSettingsView(AbstractSettingsView):
    view = CurrenciesCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "from_currency": {
            "type": "text",
            "name": "От Валюты",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "to_currency": {
            "type": "text",
            "name": "К Валюте",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "rate": {
            "type": "number",
            "name": "Курс",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
    }


router = SimpleRouter()
router.register('/currency_rate/settings', CurrencyPageSettingsView, 'GET')
router.register('/currency_rate/list', CurrenciesCRUDView, 'GET')
router.register('/currency_rate/create', CurrenciesCRUDView, 'POST')
router.register('/currency_rate/{id}', CurrenciesCRUDView,
                ['GET', 'PUT', 'DELETE'])
