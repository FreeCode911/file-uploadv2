from aiorest_ws.conf import settings
from aiorest_ws.routers import SimpleRouter

from settings.setup_settings import get_all_settings
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.manager import UserManager

from ..utils.abstract_view import AbstractView
from ..utils.decorators import permission

roles = (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.ADMIN, )
settings_local = get_all_settings()


class CardRegisterView(AbstractView):
    roles = {
        'GET': (),
        'CREATE': (UserModel.OWNER,
                   UserModel.LIMITED_OWNER,
                   UserModel.ADMIN,
                   UserModel.USER),
        'UPDATE': (),
        'DELETE': (),
    }

    @permission
    def post(self, request, *args, **kwargs):
        data = request.data
        name = data.get('name', None)
        phone = data.get('phone', None)
        card = data.get('card', '')
        if not name or not phone or not card:
            raise Exception("Name or Phone or card empty")
        session = settings.SQLALCHEMY_SESSION()
        manager = UserManager(session)
        user = manager.register_terminal(card, name, settings_local.TERMINAL_CURRENCY)
        manager.create_betroute_user(user.id, is_terminal=True)
        return user.id

router = SimpleRouter()
router.register('/user/card/register', CardRegisterView, 'POST')
