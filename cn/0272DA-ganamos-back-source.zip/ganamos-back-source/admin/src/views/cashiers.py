import json
from logging import getLogger

import requests
from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from admin.src.serializers import UserSerializer
from admin.src.utils.user_mixin import UserMixin
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.user_manager.manager import UserManager
from betronic_core.db.database import DataBase
from betronic_core.db.models.cashier_data import CashierDataModel
from betronic_core.db.models.user import UserModel
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission, session
from util.error import InvalidRequestData

logger = getLogger(__name__)


class UserListCRUDView(AbstractCRUDView, UserMixin):
    model = UserModel
    serializer = UserSerializer

    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.SUPER_ADMIN, UserModel.ADMIN),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.ADMIN),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.ADMIN),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER,),
    }

    def __init__(self):
        self.db = DataBase.get()

    def get_query(self, session, admin_id=None, admin_role=UserModel.LIMITED_OWNER):
        query = session.query(self.model) \
            .filter(self.model.role == UserModel.CASHIER, self.model.is_visible)
        if admin_role == self.model.SUPER_ADMIN:
            query = query.filter(self.model.parent_suadmin_id == admin_id)
        elif admin_role == self.model.ADMIN:
            query = query.filter(self.model.parent_admin_id == admin_id)
        return query

    def _get_model_all(self, session, admin_user=None, **kwargs):
        query = self.get_query(session, admin_id=admin_user['id'], admin_role=admin_user['role'])

        items, count, sum_value = self.model\
            .query_by_params(query, session, sum='balance', **kwargs)

        data = self.serializer(items, many=True).data
        return {"items": data, "count": count, "sum": str(round(sum_value, 3))}

    def _get_model_by_id(self, session, id, admin_user=None):
        user = self.get_query(session).filter(self.model.id == id).first()
        if not user:
            raise Exception("Resource not exist")

        not_available = False  # For Limited owner
        if admin_user['role'] == self.model.ADMIN and \
                user.parent_admin_id != admin_user['id']:
            not_available = True
        elif admin_user['role'] == self.model.SUPER_ADMIN and \
                user.parent_suadmin_id != admin_user['id']:
            not_available = True

        if not_available:
            raise Exception("Resource not available")
        return self.serializer(user).data

    @session
    @permission
    def get(self, request, id=None, session=None, *args, **kwargs):
        admin_user = self.get_user(**kwargs)
        result = self._get_model_by_id(session, int(id), admin_user) \
            if id else self._get_model_all(session, admin_user, **kwargs)
        return result

    @permission
    def post(self, request, *args, **kwargs):
        request_data = {**request.data}

        logger.info('register cashier from arguments: %s' % request.data)
        name = " ".join((request.data.get('last_name', ''),
                         request.data.get('first_name', ''),
                         request.data.get('middle_name', '')))

        currency = options.AVAILABLE_CURRENCIES[int(request.data.get(
            'currency_enum', 0))]

        data = {
            "email": request.data.get('email_auth.email'),
            "password": request.data.get('password'),
            "currency": currency,
            "name": name,
        }
        BASE_URL = options.BASE_URL
        session = requests.Session()
        response = session.post(BASE_URL + '/api/user/signup', json=data)
        response_json = json.loads(response.text)
        if int(response_json['status']):
            raise Exception(response_json['error_message'])

        user = UserModel.get_by_id(self.db, response_json['result']['user_id'])
        admin = self.get_user(**kwargs)
        if admin['role'] == self.model.ADMIN:
            user.parent_suadmin_id = admin['parent_suadmin_id']
            user.parent_admin_id = admin['id']
        elif admin['role'] == self.model.SUPER_ADMIN:
            user.parent_suadmin_id = admin['id']
            user.parent_admin_id = request_data['parent_admin_id']
        else:
            user.parent_suadmin_id = request_data['parent_suadmin_id']
            user.parent_admin_id = request_data['parent_admin_id']

        user.role = UserModel.CASHIER
        user.nickname = request.data.get('email_auth.email')
        user.additional_data.phone = request.data.get('additional_data.phone')
        user.additional_data.address = request.data\
            .get('additional_data.address')

        cashier_data = CashierDataModel()
        cashier_data.max_withdrawal = request.data\
            .get('cashier_data.max_withdrawal')
        cashier_data.max_balance = request.data\
            .get('cashier_data.max_balance')
        user.cashier_data = cashier_data

        self.db.add(user)
        self.db.commit()
        return response.json()

    @permission
    def put(self, request, *args, **kwargs):
        user = UserModel.get_by_id(self.db, args[0])
        data = request.data
        is_banned = data.get('is_banned')
        close_all_active_sessions = request.data.get('close_all_active_sessions')

        if data.get('email_auth.email'):
            user.email_auth.email = (data.pop('email_auth.email'))
        if data.get('password'):
            user.email_auth.set_password(data.pop('password'))
            admin = self.get_user(**kwargs)
            note = f'The user with ID {admin["id"]} changed the password for the user with ID {args[0]}'
            UserManager(self.db).security_log(args[0], None, "admin", "change password", request.data, note)
        if data.get('additional_data.phone'):
            user.additional_data.phone = data.pop('additional_data.phone')
        if data.get('additional_data.address'):
            user.additional_data.address = data.pop('additional_data.address')
        if data.get('cashier_data.max_balance') \
                or data.get('cashier_data.max_withdrawal'):
            if not user.cashier_data:
                cashier_data = CashierDataModel()
                user.cashier_data = cashier_data
            user.cashier_data.max_balance = data \
                .get('cashier_data.max_balance')
            user.cashier_data.max_withdrawal = data \
                .get('cashier_data.max_withdrawal')

        if is_banned or close_all_active_sessions:
            CacheManager.close_all_sessions_by_user_id(user.id)

        user.first_name = request.data.get('first_name') or user.first_name
        user.last_name = request.data.get('last_name') or user.last_name

        if int(data["parent_admin_id"]) != user.parent_admin_id or int(data["parent_suadmin_id"]) != user.parent_suadmin_id:
            target_admin = UserModel.get_by_id(self.db, data["parent_admin_id"])
            target_suadmin = UserModel.get_by_id(self.db, data["parent_suadmin_id"])
            if not UserModel.check_role_by_id(self.db, request.data.get('parent_admin_id'), self.model.ADMIN):
                raise InvalidRequestData("Target parent admin is not an admin")
            if target_admin.parent_suadmin_id != target_suadmin.id:
                # Notification about mistakes
                logger.warning("Owner want  bind cashier to different structures: admin_id: %s "
                               " origin admin parent_suadmin_id %s"
                               " target admin parent_suadmin_id %s",
                               target_admin.id, target_admin.parent_suadmin_id, target_suadmin.id)

            self.db.query(UserModel).filter(
                UserModel.parent_cashier_id == user.id,
                UserModel.parent_suadmin_id == user.parent_suadmin_id,
                UserModel.parent_admin_id == user.parent_admin_id
            ).update(
                {UserModel.parent_admin_id: target_admin.id,
                 UserModel.parent_suadmin_id: target_admin.parent_suadmin_id}
            )

            user.parent_admin_id = target_admin.id
            user.parent_suadmin_id = target_admin.parent_suadmin_id

        self.db.add(user)
        self.db.commit()

    @session
    def delete(self, request, id=None, session=None, *args, **kwargs):
        if not id:
            raise Exception("Id is not defined")

        admin_user = self.get_user(**kwargs)
        instance = self.get_query(session, admin_id=admin_user['id'],
                                  admin_role=admin_user['role'])\
            .filter(self.model.id == int(id)).first()

        if not instance:
            raise Exception('Object does not exist')

        count = UserModel.get_binding_users(session, instance.id, instance.role, count=True)
        if count:
            raise Exception(f'You can not delete cashier, he is got {count} users binding to him!')

        instance.is_banned = True
        instance.is_visible = False
        instance.role = self.model.USER
        instance.email_auth.email = "deleted_" + instance.email_auth.email + "_" + str(instance.id)
        session.add(instance)
        session.commit()
        CacheManager.close_all_sessions_by_user_id(id)
        return self._get_model_all(session, **kwargs)


class UserSettingsView(AbstractSettingsView):
    view = UserListCRUDView

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        fields = self.fields.copy()
        if user['role'] == UserModel.ADMIN:
            fields.pop('parent_suadmin_id')
            fields.pop('parent_admin_id')
        elif user['role'] == UserModel.SUPER_ADMIN:
            fields.pop('parent_suadmin_id')

        permissions = self.get_permission(user, self.view.roles)
        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": 1
        },
        "email_auth.email": {
            "type": "text",
            "name": "Логин",
            "order": False,
            "filter": True,
            "table": True,
            "editable": True,
            "weight": 2,
            "editableWeight": 1
        },
        "additional_data.address": {
            "type": "text",
            "name": "Адрес кассира",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 4
        },
        "first_name": {
            "type": "text",
            "name": "Имя",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 4,
            "editableWeight": 3
        },
        "last_name": {
            "type": "text",
            "name": "Фамилия",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
            "weight": 5,
            "editableWeight": 6
        },
        "balance": {
            "type": "number",
            "name": "Баланс",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "currency_enum": {
            "type": "enum",
            "name": "Валюта",
            "enum": options.AVAILABLE_CURRENCIES,
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
        },
        "password": {
            "type": "text",
            "name": "Пароль",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
            "editableWeight": 2
        },
        "cashier_data.max_balance": {
            "type": "text",
            "name": "Максимальный баланс кассира",
            "order": False,
            "table": True,
            "editable": True,
            "editableWeight": 10
        },
        "cashier_data.max_withdrawal": {
            "type": "text",
            "name": "Максимальный вывод",
            "order": False,
            "table": True,
            "editable": True,
            "editableWeight": 11
        },
        "parent_admin_id": {
            "type": "number",
            "name": "ID админа",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "parent_suadmin_id": {
            "type": "number",
            "name": "ID супер-админа",
            "order": False,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "is_banned": {
            "type": "boolean",
            "name": "Бан",
            "order": True,
            "filter": False,
            "table": False,
            "editable": True,
        },
        "close_all_active_sessions": {
            "type": "boolean",
            "name": "Закрыть все активные сессии",
            "order": False,
            "filter": False,
            "table": False,
            "editable": True,
        }
    }


router = SimpleRouter()
router.register('/cashier_list/list', UserListCRUDView, 'GET')
router.register('/cashier_list/settings', UserSettingsView, 'GET')
router.register('/cashier_list/{id}', UserListCRUDView, ['GET', 'PUT', 'CREATE'])
