import jwt
from time import time
from logging import getLogger
from datetime import date
from dateutil.relativedelta import relativedelta

from settings.setup_settings import get_all_settings
from betronic_core.db.converters import user_to_dict
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.user_manager.manager import UserManager
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.royalty_manager.manager import RoyaltyManager
from ..utils.abstract_view import AbstractView

from ..utils.decorators import session
from ..utils.user_mixin import UserMixin

settings_local = get_all_settings()
logger = getLogger(__name__)


class LoginView(AbstractView, UserMixin):
    @session
    def post(self, request, session=None, *args, **kwargs):
        data = request.data
        email, password = data['email'], data['password']
        if not email or not password:
            raise Exception("Empty password or email")

        user_manager = UserManager(session)
        user = user_manager.get_user_by_login(email)
        user_manager.security_log(user.id, request.extra_user_ip, "admin", "login", data)

        email_auth = EmailAuthModel.get_by_email_password(
            session, email, password)
        roles = [UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.CASHIER, UserModel.TECHSUPPORT]
        if email_auth.user.role not in roles:
            raise Exception("You are not an administrator")
        user_dict = user_to_dict(email_auth.user)
        user_dict['timestamp'] = int(time())
        logger.info(f'user_dict ==> {user_dict}')
        encoded = jwt.encode(
            user_dict, settings_local.COOKIE_SECRET, algorithm='HS256')
        return {'token': encoded, "user": user_dict}


class CheckView(AbstractView, UserMixin):
    @staticmethod
    def _get_date_filter() -> dict:
        first_day = date.today().replace(day=1)
        last_day = first_day + relativedelta(months=1)
        return {"from": first_day, "to": last_day}

    @session
    def get(self, request, session=None, *args, **kwargs):
        user = self.get_user(**kwargs)
        user_data = UserModel.get_by_id(session, user['id'])
        marketing_owner_data = UserModel.get_by_id(session, UserModel.MARKETING_OWNER_ID)
        date_filter = self._get_date_filter()

        unplayed_revenue_share_usd = CacheManager.get_unplayed_rev_share()
        if not unplayed_revenue_share_usd:
            unplayed_revenue_share_usd = RoyaltyManager(session).get_current_unplayed_rev_share(date_filter['from'],
                                                                                                date_filter['to'])
            CacheManager.set_unplayed_rev_share(unplayed_revenue_share_usd)

        user['balance'] = float(user_data.balance)
        if user_data.is_banned:
            raise Exception('You are banned')
        if marketing_owner_data:
            user['marketing_balance'] = float(marketing_owner_data.balance)
        if unplayed_revenue_share_usd:
            user["unplayed_revenue_share_usd"] = float(unplayed_revenue_share_usd)

        cookie_salt = CacheManager.get_user_cookie_salt(user['id'])
        if user['cookie_salt'] != cookie_salt:
            raise Exception('Cookie salt not match')

        session.close()

        return user
