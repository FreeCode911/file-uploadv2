from aiorest_ws.routers import SimpleRouter

from admin.src.serializers import BetTicketSerializer
from betronic_core.db.models.user import UserModel
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from ..utils.decorators import permission
from betronic_core.db.models.terminal.bet_ticket import BetTicketModel


class BetTicketsCRUDView(AbstractCRUDView):
    model = BetTicketModel
    serializer = BetTicketSerializer

    roles = {
        'GET': (UserModel.CASHIER, UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (UserModel.CASHIER, UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (),
    }

    @permission
    def update(self, request, session=None, *args, **kwargs):
        pass


class BetTicketsSettingsCRUDView(AbstractSettingsView):
    view = BetTicketsCRUDView

    def get(self, requset, *args, **kwargs):
        user = self.get_user(**kwargs)
        permissions = self.get_permission(user, self.view.roles)

        return {
            "fields": self.fields,
            "permissions": permissions,
            "additional_settings": self.additional_settings,
        }

    fields = {
        "id": {
            "type": "number",
            "name": "Ticket ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "weight": -1
        },
    }


router = SimpleRouter()
router.register('/bettickets/settings', BetTicketsSettingsCRUDView, 'GET')
router.register('/bettickets/list', BetTicketsCRUDView, 'GET')
router.register('/bettickets/{id}', BetTicketsCRUDView, ['GET', 'PUT'])
