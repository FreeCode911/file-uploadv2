from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.notifications.email_notification import \
    EmailNotification
from betronic_core.db.models.user import UserModel
from admin.src.serializers import EmailNotificationSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class EmailNotificationCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (),
    }
    model = EmailNotification
    serializer = EmailNotificationSerializer


class EmailNotificationPageSettingsView(AbstractSettingsView):
    view = EmailNotificationCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "email": {
            "type": "text",
            "name": "Email",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "is_closed": {
            "type": "boolean",
            "name": "Окончена",
            "order": True,
            "filter": False,
            "table": True,
            "editable": True,
        },
        "attempt": {
            "type": "number",
            "name": "Количество попыток",
            "order": True,
            "filter": True,
            "table": True,
            "editable": True,
        },
        "context": {
            "type": "text",
            "name": "Контекст",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "lang": {
            "type": "text",
            "name": "Язык",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
    }


router = SimpleRouter()
router.register('/email_notification/settings', EmailNotificationPageSettingsView, 'GET')
router.register('/email_notification/list', EmailNotificationCRUDView, 'GET')
router.register('/email_notification/create', EmailNotificationCRUDView, 'POST')
router.register('/email_notification/{id}', EmailNotificationCRUDView,
                ['GET', 'PUT'])