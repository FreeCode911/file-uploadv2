from aiorest_ws.routers import SimpleRouter
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from betronic_core.db.models.user import UserModel
from admin.src.serializers import PartnerSerialzer
from betronic_core.constants import PartnerTypePayment
from betronic_core.db.models.click import ClickModel
from sqlalchemy import func
from admin.src.utils.decorators import session, permission
from betronic_core.db.models.betroute_local_bet import \
    BetrouteLocalBetModel, BetStatus
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.constants import TransferTypes
from betronic_core.user_manager.manager import UserManager
from betronic_core.payment_manager.manager import PaymentManager


class PartnerList(AbstractCRUDView):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
    }
    model = UserModel
    serializer = PartnerSerialzer

    def _get_model_all(self, session, **kwargs):

        clicks = session.query(
            ClickModel.partner_id,
            func.count(ClickModel.id).label('clicks')
        ).group_by(ClickModel.partner_id).subquery()

        registrations = session.query(
                UserModel.referral_id,
                func.count(UserModel.id).label('registrations')
            ).group_by(UserModel.referral_id).subquery()

        loss_bets = session\
            .query(UserModel.referral_id,
                   func.sum(BetrouteLocalBetModel.amount).label('loss_bets'))\
            .join(BetrouteLocalBetModel,
                  BetrouteLocalBetModel.from_user_id == UserModel.id)\
            .filter(BetrouteLocalBetModel.status == BetStatus.LOSS)\
            .group_by(UserModel.referral_id).subquery()

        refills = session\
            .query(UserModel.referral_id,
                   func.sum(MoneyTransferModel.value).label('refills'))\
            .join(MoneyTransferModel,
                  MoneyTransferModel.from_user_id == UserModel.id)\
            .filter(MoneyTransferModel.type == TransferTypes.TYPE_REFILL)\
            .group_by(UserModel.referral_id).subquery()

        q = session\
            .query(
                self.model.id, self.model.partner_balance,
                self.model.type_partner_payment, clicks.c.clicks,
                registrations.c.registrations, loss_bets.c.loss_bets,
                refills.c.refills
            ).filter(self.model.is_partner == True)\
            .outerjoin(clicks).outerjoin(registrations)\
            .outerjoin(loss_bets).outerjoin(refills)

        items, count = self.model\
            .query_by_params(session, query=q, **kwargs)

        result = []
        for item in items:
            item = item._asdict()
            for key, value in item.items():
                if not value:
                    value = 0
                item[key] = str(value)
            result.append(item)

        return {"items": result, "count": count}

    @session
    @permission
    def post(self, request, *args, **kwargs):
        session = kwargs.get('session')

        user_id = request.data['id']
        type_partner = request.data['type_partner_payment']

        user_manager = UserManager(session)
        payment_manager = PaymentManager(session)

        user_manager.create_partner(user_id, type_partner)
        payment_manager.create_partner_promo_code(user_id)

    @session
    @permission
    def put(self, request, id, *args, **kwargs):
        session = kwargs.get('session')
        user: UserModel = UserModel.get_by_id(session, id)
        user.type_partner_payment = int(request.data['type_partner_payment'])
        session.add(user)
        session.commit()

    @session
    @permission
    def delete(self, request, id=None, *args, **kwargs):
        session = kwargs.get('session')
        user: UserModel = UserModel.get_by_id(session, id)
        user.is_partner = False
        user.type_partner_payment = None
        session.add(user)
        session.commit()
        return self._get_model_all(**kwargs)


class PartnerListSettings(AbstractSettingsView):
    view = PartnerList
    fields = {
        'id': {
            'type': 'number',
            'name': 'ID Пользователя',
            'order': False,
            'filter': True,
            'table': True,
            'editable': True
        },
        'type_partner_payment': {
            'type': 'enum',
            'name': 'Тип партнера',
            'order': False,
            'filter': True,
            'table': True,
            'editable': True,
            'weight': 2,
            'editableWeight': 2,
            'enum': PartnerTypePayment.TypesName
        },

        'partner_balance': {
            'type': 'text',
            'name': 'Баланс партнера',
            'order': True,
            'filter': False,
            'table': False,
            'editable': False,
            'weight': 3
        },

        'clicks': {
            'type': 'text',
            'name': 'Переходы',
            'order': False,
            'filter': False,
            'table': True,
            'editable': False,
            'weight': 4
        },
        'registrations': {
            'type': 'text',
            'name': 'Регистрации',
            'order': False,
            'filter': False,
            'table': True,
            'editable': False,
            'weight': 5
        },
        'loss_bets': {
            'type': 'text',
            'name': 'Ставки',
            'order': False,
            'filter': False,
            'table': True,
            'editable': False,
            'weight': 6
        },
        'refills': {
            'type': 'text',
            'name': 'Пополнения',
            'order': False,
            'filter': False,
            'table': True,
            'editable': False,
            'weight': 7
        }
    }

router = SimpleRouter()
router.register('/partner_list/settings', PartnerListSettings, ['GET'])
router.register('/partner_list/list', PartnerList, 'GET')
router.register('/partner_list/{id}', PartnerList, ['GET', 'PUT', 'CREATE', 'DELETE'])
