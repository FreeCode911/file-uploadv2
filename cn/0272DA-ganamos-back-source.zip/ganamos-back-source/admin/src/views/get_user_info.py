from aiorest_ws.routers import SimpleRouter

from admin.src.utils.user_mixin import UserMixin
from betronic_core.user_manager.manager import UserManager
from bookmakers.services.commands import AbstractResult

from ..utils.abstract_view import AbstractView
from ..utils.decorators import session
from betronic_core.db.models.user import UserModel


class GetUserInfoView(AbstractView, UserMixin):
    @session
    def get(self, request, session=None, *args, **kwargs):
        asking_user = self.get_user(**kwargs)
        data = request.data
        user_id = int(data.get('user_id'))
        manager = UserManager(session)

        user = manager.get_user_by_id(user_id)
        if asking_user['role'] == UserModel.ADMIN:
            if user.parent_admin_id != asking_user['id']:
                raise Exception("Admin asking for not his user.")
        elif asking_user['role'] == UserModel.SUPER_ADMIN:
            if user.parent_suadmin_id != asking_user['id']:
                raise Exception("Super_Admin asking for not his user.")

        user_data = {
            'id': user.id,
            'firstName': user.first_name,
            'lastName': user.last_name,
            'balance': float(user.balance),
            'bonus_balance': float(user.bonus_balance),
            'currency': user.currency,
        }

        if user_id > 0:
            user_data['email'] = user.email_auth.email

        result = AbstractResult(result=user_data)
        result = result.to_dict()

        return result


router = SimpleRouter()
router.register('/get_user_info/', GetUserInfoView, 'GET')
