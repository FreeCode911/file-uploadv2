from aiorest_ws.routers import SimpleRouter

from betronic_core.db.models.bonus_transfer import BonusTransferModel, \
    BonusTransferTypes
from betronic_core.db.models.user import UserModel
from admin.src.serializers import BonusTransferSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView


class BonusTransferCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.ADMIN, UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, ),
        'DELETE': (),
    }
    model = BonusTransferModel
    serializer = BonusTransferSerializer


class BonusTransferSettingsView(AbstractSettingsView):
    view = BonusTransferCRUDView
    fields = {
        "id": {
            "type": "number",
            "name": "ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": BonusTransferTypes.TYPES
        },
        "from_user_id": {
            "type": "number",
            "name": "От какого пользователя ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "to_user_id": {
            "type": "number",
            "name": "К какому пользователя ID",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "currency": {
            "type": "text",
            "name": "Валюта",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
    }


router = SimpleRouter()
router.register('/bonus_transfers/settings', BonusTransferSettingsView, 'GET')
router.register('/bonus_transfers/list', BonusTransferCRUDView, 'GET')
router.register('/bonus_transfers/{id}', BonusTransferCRUDView, ['GET', 'PUT'])