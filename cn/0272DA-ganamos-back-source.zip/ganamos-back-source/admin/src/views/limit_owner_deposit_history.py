from datetime import datetime, timedelta

from aiorest_ws.routers import SimpleRouter

from betronic_core.db.database import DataBase
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.constants import TransferTypes
from betronic_core.db.models.user import UserModel
from admin.src.serializers import MoneyTransferSerializer
from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from util.admin import check_and_get_data_range, get_interval
from admin.src.utils.user_mixin import UserMixin


class LimitOwnerDepositHistorySettingsViewCRUDView(AbstractCRUDView, UserMixin):
    roles = {
        'GET': (UserModel.OWNER,),
        'CREATE': (),
        'UPDATE': (),
        'DELETE': (),
    }
    model = MoneyTransferModel
    serializer = MoneyTransferSerializer

    def __init__(self):
        self.db = DataBase.get()

    def get_query(self, session):
        query = session.query(self.model)
        return query.filter(self.model.type.in_(TransferTypes.LIMIT_OWNER_DEPOSIT_TYPES))

    def _get_model_all(self, session, **kwargs):
        query = self.get_query(session)
        admin_user = self.get_user(**kwargs)
        interval = get_interval(admin_user["role"], **kwargs)
        kwargs = check_and_get_data_range(filter_key="created_at", interval=interval, **kwargs)
        items, count = self.model.query_by_params(query, session,
                                                  fields=LimitOwnerDepositHistorySettingsView.fields,
                                                  **kwargs)
        data = self.serializer(items, many=True).data
        return {"items": data, "count": count}


class LimitOwnerDepositHistorySettingsView(AbstractSettingsView):
    view = LimitOwnerDepositHistorySettingsViewCRUDView
    fields = {
        "type": {
            "type": "enum",
            "name": "Тип",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
            "enum": TransferTypes.TYPES_LIMIT_OWNER_DEPOSITS
        },
        "value": {
            "type": "number",
            "name": "Сумма",
            "order": True,
            "filter": False,
            "table": True,
            "editable": False,
        },
        "created_at": {
            "type": "date",
            "name": "Дата создания",
            "order": True,
            "filter": True,
            "table": True,
            "editable": False,
        },
    }


router = SimpleRouter()
router.register('/limit_owner_deposit_history/settings', LimitOwnerDepositHistorySettingsView, 'GET')
router.register('/limit_owner_deposit_history/list', LimitOwnerDepositHistorySettingsViewCRUDView, 'GET')
