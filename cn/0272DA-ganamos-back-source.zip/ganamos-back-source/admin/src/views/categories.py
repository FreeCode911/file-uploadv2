from ..utils.abstract_view import AbstractCRUDView, AbstractSettingsView
from aiorest_ws.routers import SimpleRouter
from betronic_core.blocklist_manager.manager import BlocklistManager
from betronic_core.db.models.category import CategoryModel
from betronic_core.db.models.permission_details import ProviderModel
from admin.src.serializers import CategorySerializer
from admin.src.utils.decorators import permission, session
from betronic_core.db.models.user import UserModel
from tornado.options import options

class CategoriesCRUDView(AbstractCRUDView):
    roles = {
        'GET': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'UPDATE': (UserModel.OWNER, UserModel.LIMITED_OWNER),
        'DELETE': (),
    }

    model = CategoryModel
    serializer = CategorySerializer

    @session
    @permission
    def put(self, request, id, session=None, *args, **kwargs):
        PROVIDERS = options.PROVIDERS
        is_active = request.data.get("active", False)
        category = self.model.get_by_id(session, int(id))
        category.active = is_active
        session.add(category)

        providers = PROVIDERS.get(category.name)

        provs = (
            session.query(ProviderModel).filter(ProviderModel.name.in_(providers)).all()
        )

        for prov in provs:
            prov.is_active = is_active
        session.add_all(provs)
        session.commit()

        manager = BlocklistManager(session)

        if is_active:
            manager.remove_global_block_category(category.name)
        else:
            manager.add_global_block_category(category.name)

        for provider in providers:
            if is_active:
                manager.remove_global_block_provider(provider)
            else:
                manager.add_global_block_provider(provider)
        return {"status": 0}

class CategoriesSettingsView(AbstractSettingsView):
    view = CategoriesCRUDView
    fields = {
        'id': {
            'type': 'text',
            'name': 'id',
            'table': False,
            'order': False,
            'filter': False,
            'editable': False
        },
        'name': {
            'type': 'text',
            'name': 'Название категории',
            'table': True,
            'order': False,
            'filter': True,
            'editable': True
        },
        'active': {
            'type': 'boolean',
            'name': 'Активна',
            'table': False,
            'order': False,
            'filter': False,
            'editable': True
        }
    }


router = SimpleRouter()
router.register('/categories/list', CategoriesCRUDView, 'GET')
router.register('/categories/settings', CategoriesSettingsView, 'GET')
router.register('/categories/{id}', CategoriesCRUDView, ['GET', 'PUT',])

