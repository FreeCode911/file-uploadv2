from aiorest_ws.routers import SimpleRouter
from tornado.options import options

from admin.src.utils.user_mixin import UserMixin
from betronic_core.constants import TransferTypes
from betronic_core.db.database import DataBase
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.payment_manager.manager import PaymentManager
from betronic_core.settings_manager.manager import SettingsManager
from betronic_core.user_manager.manager import UserManager
from ..utils.abstract_view import AbstractView
from ..utils.decorators import permission, session
from betronic_core.db.models.money_transfer import MoneyTransferModel

class MoneyAddView(AbstractView, UserMixin):
    roles = {
        'GET': (),
        'CREATE': (UserModel.OWNER, UserModel.LIMITED_OWNER, UserModel.CASHIER),
        'UPDATE': (),
        'DELETE': (),
    }

    def __init__(self):
        self.db = DataBase.get()

    @permission
    @session
    def post(self, request, session=None, *args, **kwargs):
        subj = self.get_user(**kwargs)
        user_id = int(request.data.get('user_id', None))
        amount = float(request.data.get('amount', None))
        is_bonus = bool(request.data.get('is_bonus', False))
        note = str(request.data.get('note', ''))
        is_outcome = bool(request.data.get('is_outcome', None))

        if amount < options.MIN_AMOUNT_FOR_OPERATIONS.get(
                subj['currency'],
                options.DEFAULT_MIN_AMOUNT_FOR_OPERATIONS
        ):
            raise Exception(f'Incorrect amount for deposit/withdrawal operation: {amount}')

        if not user_id or not amount:
            raise Exception("User id or Amount empty")

        if is_bonus and subj['role'] == UserModel.LIMITED_OWNER:
            raise Exception("Limited owner can't interact with bonus balance")

        user_manager = UserManager(session)

        user = user_manager.get_user_by_id(user_id, allow_prohibited=False)
        if not user:
            raise Exception("User is not exist")

        if user.role == UserModel.OWNER:
            raise Exception("Can't interact with OWNER")

        manager = MoneyManager(session)

        if user_id < 0 and subj['role'] != UserModel.CASHIER:
            source_user_id = UserModel.ORGANIZATION_ID if \
                subj['role'] == UserModel.OWNER else subj['id']
            service_account_id = user_id
            setting = SettingsManager(self.db).get_setting_by_name("MarketingOwnerSettings")
            access_deposit_role_details = setting['access_deposit_by_role']
            if subj['role'] in access_deposit_role_details.keys():
                role_detail = access_deposit_role_details.get(subj['role'], {})

                role_is_enabled = role_detail.get('is_enable', False)
                user_is_excluded = subj['id'] in role_detail.get('exclude_ids', [])

                if not role_is_enabled or user_is_excluded:
                    raise Exception("You don't have enough permissions to perform this operation")

                if user_id != UserModel.REVENUE_BALANCE_ID:
                    manager.move_money_to_service_user(
                        source_user_id=source_user_id,
                        service_account_id=service_account_id,
                        amount=amount,
                        note=note,
                        is_outcome=is_outcome
                    )

                return True

            else:
                raise Exception(f"Role {subj['role']} is not declared in settings.")

        if is_bonus and subj['role'] == UserModel.OWNER:
            if not is_outcome:
                manager.move_marketing_money(
                    user_id=user.id,
                    value=amount,
                    transfer_type=TransferTypes.TYPE_BONUS_REFILL,
                    note=note,
                    is_bonus=True,
                    is_outcome=False
                )

            else:
                manager.move_marketing_money(
                    user_id=user.id,
                    value=amount,
                    transfer_type=TransferTypes.TYPE_BONUS_WRITE_OFF,
                    note=note,
                    is_bonus=True,
                    is_outcome=True
                )

            return True

        if subj['role'] == UserModel.LIMITED_OWNER:
            assert not subj['id'] == user.id
            assert int(user.id) > 0
            limited_owner = UserModel.get_by_id(session, subj['id'])
            transfer = manager.move_money_LIMITED_OWNER_TO_USER(
                limited_owner=limited_owner, user=user, amount=amount, note=note, is_outcome=is_outcome)
            self._create_payment_record(user, transfer, is_outcome, is_bonus)

            return True

        if subj['role'] == UserModel.CASHIER:
            assert not subj['id'] == user.id
            assert int(user.id) > 0

            cashier = UserModel.get_by_id(session, subj['id'])
            transfer = manager.move_money_CASHIER_to_USER(
                cashier=cashier,
                user=user,
                amount=amount,
                note=note,
                is_outcome=is_outcome,
            )
            self._create_payment_record(user, transfer, is_outcome, is_bonus)

            return True

        if not is_outcome:
            transfer = manager.user_move_money(UserModel.ORGANIZATION_ID, user.id, amount,
                                    TransferTypes.TYPE_REFILL, note)
            self._create_payment_record(user, transfer, is_outcome, is_bonus)

        else:
            assert (amount <= user.balance), "User does not have enough money"
            transfer = manager.user_move_money(user.id, UserModel.ORGANIZATION_ID, amount,
                                    TransferTypes.TYPE_WITHDRAWAL, note)
            self._create_payment_record(user, transfer, is_outcome, is_bonus)

        return True

    def _create_payment_record(self, user: UserModel, transfer: MoneyTransferModel,
                               is_outcome_flag: bool, is_bonus: bool):
        payment_manager = PaymentManager(self.db)

        if not is_bonus and user.role == UserModel.USER:
            if is_outcome_flag:
                payment_manager.create_completed_withdrawal(transfer)
            else:
                payment_manager.create_completed_payment(transfer)





router = SimpleRouter()
router.register('/user/bonus/add', MoneyAddView, 'POST')
