from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from settings.setup_settings import get_all_settings

settings = get_all_settings()

SQLALCHEMY_ENGINE = create_engine('postgresql://{}:{}@{}:{}/{}'.format(
    settings.DATABASE["user"],
    settings.DATABASE["password"],
    settings.DATABASE["host"],
    settings.DATABASE["port"],
    settings.DATABASE["name"], ))

session = sessionmaker(bind=SQLALCHEMY_ENGINE)


def get_session(**kwargs):
    return session(**kwargs)


SQLALCHEMY_SESSION = get_session
