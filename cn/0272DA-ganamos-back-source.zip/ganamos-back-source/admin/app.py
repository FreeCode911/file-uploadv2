import os
import json
from base64 import b64decode
from logging import getLogger

os.environ.setdefault("AIORESTWS_SETTINGS_MODULE", "admin.settings")
from aiorest_ws.app import Application
from aiorest_ws.request import RequestHandlerProtocol, Request

from settings.setup_settings import get_all_settings, setup_logger

from admin.src.urls import router
from admin.src.utils.abstract_router import SimpleRouter

from util.crypto import __define_auth_keys


settings_project = get_all_settings()
setup_logger()

main_router = SimpleRouter()
main_router.include(router)

logger = getLogger(__name__)


class CustomRequestHandlerProtocol(RequestHandlerProtocol):
    def _decode_message(self, payload, isBinary=False):
        """
        Decoding input message to Request object.
            :param payload: input message.
            :param isBinary: boolean value,
            means that received data had a binary format.
        """
        # Message was taken in base64
        if isBinary:
            payload = b64decode(payload)
        input_data = json.loads(payload.decode('utf-8'))
        self._extract_and_set_user_ip(input_data)
        return Request(**input_data)

    def _extract_and_set_user_ip(self, input_data: dict):
        user_ip = self.http_headers.get("x-real-ip", "Empty header X-Real-IP")
        input_data["extra_user_ip"] = user_ip  # set extra_user_ip as attr of Request object

        if not input_data.get("args"):
            input_data["args"] = {}

        # set extra_user_ip as key of args dict (see logs)
        input_data["args"].update(extra_user_ip=user_ip) if input_data["args"] else None
        return input_data


def start():
    __define_auth_keys()
    app = Application(protocol=CustomRequestHandlerProtocol)
    app.run(
        host=settings_project.ADMIN_SERVER['host'],
        port=settings_project.ADMIN_SERVER['port'],
        router=main_router
    )
    logger.info("Start admin with port %s" % settings_project.ADMIN_SERVER['port'])
