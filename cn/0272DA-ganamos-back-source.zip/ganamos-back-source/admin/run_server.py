import os


def get_module_content(filename):
    with open(filename, 'r') as module:
        return module.read()


def start():
    os.environ.set("AIORESTWS_SETTINGS_MODULE", "settings")
    exec(get_module_content(os.path.realpath(__package__) + '/app.py'))
