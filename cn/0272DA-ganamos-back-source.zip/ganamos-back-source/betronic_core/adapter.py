from abc import ABCMeta


class AdapterBase:
    __metaclass__ = ABCMeta

    def __init__(self, instance):
        self.instance = instance
