from logging import getLogger
from typing import List

from sqlalchemy import and_, or_

from betronic_core.constants import TransferTypes
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.commission_percents import CommissionBalances
from betronic_core.manager import IManager
from datetime import datetime as dt
from datetime import timedelta

logger = getLogger(__name__)

default_report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}


class AdminPanelManager(IManager):
    def get_transfer_types_by_provider(self, provider: str) -> dict:
        """
        :param provider: name of provider( sport, live-casino, slots)
        :return: dict of lists with transfer types
        """
        if provider == 'sport':
            result = {'win': [TransferTypes.WIN_BET_BETSSTORE, ], 'set': [TransferTypes.SET_BET_BETSSTORE, ]}
        elif provider == 'slots':
            result = {'win': [TransferTypes.TYPE_OUTCOMEBET_PRIZE, ], 'set': [TransferTypes.TYPE_OUTCOMEBET_BET, ]}
        elif provider == 'live-casino':
            result = {'win': [TransferTypes.TYPE_EZUGI_WIN, TransferTypes.TYPE_TVBET_PRISE],
                      'set': [TransferTypes.TYPE_EZUGI_BET, TransferTypes.TYPE_TVBET_BET]}

        result['income'] = [TransferTypes.TYPE_CASHIER_TO_USER, ]
        result['outcome'] = [TransferTypes.TYPE_USER_TO_CASHIER, ]
        return result

    @staticmethod
    def create_default_report(transfer: MoneyTransferModel, types: dict):
        """
        Depending on the type of transfer, returns a dictionary where the key is the from_user_id/to_user_id
        from the transfer
        :param transfer: MoneyTransferModel object
        :param types: dict of lists with transfer types
        :return:  dict
        """
        default_report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        if transfer.type in types['win'] or transfer.type in types['income']:
            result = {transfer.real_to_user_id: default_report}
            result[transfer.real_to_user_id]['username'] = transfer.real_to_user.email_auth.email
        if transfer.type in types['set'] or transfer.type in types['outcome']:
            result = {transfer.real_from_user_id: default_report}
            result[transfer.real_from_user_id]['username'] = transfer.real_from_user.email_auth.email
        return result

    def get_cashier_report(self, user_id, provider, date_from, date_to):
        cashier = UserModel.get_by_id(self.db, user_id)
        types = self.get_transfer_types_by_provider(provider)
        user_role = UserModel.CASHIER
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}
        users = UserModel.get_descendants(self.db, user_id, user_role)

        types_for_query = [val for sublist in list(types.values()) for val in sublist]
        transfers_by_date = self.db.query(MoneyTransferModel).filter(and_(
            MoneyTransferModel.created_at > date_from,
            MoneyTransferModel.created_at < date_to
        ))
        transfers = transfers_by_date.filter(and_
                                             (or_(
                                                 MoneyTransferModel.real_from_user_id.in_(users),
                                                 MoneyTransferModel.real_to_user_id.in_(users))),
                                             MoneyTransferModel.type.in_(types_for_query)).all()
        for transfer in transfers:
            result = self.create_default_report(transfer, types)
            if not set(result.keys()) & set(children.keys()):
                children.update(result)

            if transfer.type in types['win']:
                report['total_winnings'] += transfer.value
                children[transfer.real_to_user_id]['total_winnings'] += transfer.value

            if transfer.type in types['set']:
                report['total_stake'] += transfer.value
                children[transfer.real_from_user_id]['total_stake'] += transfer.value

            if transfer.type in types['income']:
                report['positive_profit'] += transfer.value
                children[transfer.real_to_user_id]['positive_profit'] += transfer.value

            if transfer.type in types['outcome']:
                report['negative_profit'] += transfer.value
                children[transfer.real_from_user_id]['negative_profit'] += transfer.value

        report['children'] = children
        report['username'] = cashier.email_auth.email
        return report

    def get_admin_report(self, user_id, provider, date_from, date_to):
        admin = UserModel.get_by_id(self.db, user_id)
        user_role = UserModel.ADMIN
        users = UserModel.get_descendants(self.db, user_id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}

        for user_id in users:
            cashier_result = self.get_cashier_report(user_id, provider, date_from, date_to)
            children[user_id] = cashier_result
            report['total_stake'] += cashier_result['total_stake']
            report['total_winnings'] += cashier_result['total_winnings']
            report['negative_profit'] += cashier_result['negative_profit']
            report['positive_profit'] += cashier_result['positive_profit']
        report['children'] = children
        report['username'] = admin.email_auth.email
        return report

    def get_super_admin_report(self, user_id, provider, date_from, date_to):
        super_admin = UserModel.get_by_id(self.db, user_id)
        user_role = UserModel.SUPER_ADMIN
        users = UserModel.get_descendants(self.db, user_id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}

        for user_id in users:
            admin_result = self.get_admin_report(user_id, provider, date_from, date_to)
            children[user_id] = admin_result
            report['total_stake'] += admin_result['total_stake']
            report['total_winnings'] += admin_result['total_winnings']
            report['negative_profit'] += admin_result['negative_profit']
            report['positive_profit'] += admin_result['positive_profit']
        report['children'] = children
        report['username'] = super_admin.email_auth.email
        return report

    def get_owner_report(self, user_id, provider, date_from, date_to):
        owner = UserModel.get_by_id(self.db, user_id)
        user_role = UserModel.OWNER
        users = UserModel.get_descendants(self.db, user_id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}

        for user_id in users:
            super_admin_result = self.get_super_admin_report(user_id, provider, date_from, date_to)
            children[user_id] = super_admin_result
            report['total_stake'] += super_admin_result['total_stake']
            report['total_winnings'] += super_admin_result['total_winnings']
            report['negative_profit'] += super_admin_result['negative_profit']
            report['positive_profit'] += super_admin_result['positive_profit']
        report['children'] = children
        report['username'] = owner.email_auth.email
        return report

    def add_day_to_filters_date_to(self, to_date: str):
        filter_to = to_date.split("-")
        date_to = dt(int(filter_to[0]), int(filter_to[1]),
                     int(filter_to[2])) + timedelta(days=1)
        date_to = date_to.strftime('%Y-%m-%d')
        return date_to

    def recalculate_commissions(
            self,
            date_from: dt,
            date_to: dt,
            to_user_id: int,
            new_percent: int
    ):
        logger.info(f"Recalculating commissions for user_id: {to_user_id} from {date_from} to {date_to}")
        commissions: List[CommissionBalances] = CommissionBalances.get_commissions_by_date_and_user_id(self.db,
                                                                                                       date_from,
                                                                                                       date_to,
                                                                                                       to_user_id)

        for commission in commissions:
            commission.commission_amount = commission.netwin * new_percent * 0.01
            commission.commission_percent = new_percent
            self.db.add(commission)
