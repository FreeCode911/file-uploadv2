from logging import getLogger

logger = getLogger(__name__)


class CheckHandler:
    def __init__(self, db, *a, **kw):
        self.db = db

    def auto_recognize_checks(self):
        return [getattr(self, method) for method in
                              dir(self) if method.startswith('check_')]


class ChecksChain:

    HANDLERS: dict = {}
    handler: CheckHandler

    def __init__(self, db, *args, **kwargs):
        self.db = db

    def set_handler(self, key, *a, **kw):
        self.handler = self.HANDLERS[key](self.db, *a, **kw)

    def do_checks(self):
        for check in self.handler.auto_recognize_checks():
            check()
