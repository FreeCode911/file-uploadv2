from json import dumps
from logging import getLogger
from typing import List

from requests import get, post, put, codes, Response
from tornado.options import options

logger = getLogger(__name__)


class DigitainFetcher:
    REMOTE_USER_URL = f'{options.DIGITAIN_SERVICE_DOMAIN}/api/back/user'


    @classmethod
    def _check_response(cls, response: Response):
        if response.status_code != codes.ok:
            logger.error(f'Bad response from Digitain: {response.status_code}; {response.text}')
            raise Exception(f'Bad response from Digitain: {response.status_code}; {response.text}')

    @classmethod
    def get_user_info(cls, token: str, user_id: int) -> dict:
        headers = {
            'x-partner-authorization': token,
            'x-partner-name': options.DIGITAIN_PROJECT_NAME
        }
        response = get(
            cls.REMOTE_USER_URL,
            params={
                'user_id': user_id,
            },
            headers=headers
        )
        cls._check_response(response)

        body = response.json()

        body = body['result']
        body['digitain_client_id'] = f"{options.DIGITAIN_ID}\\{body['digitain_client_id']}"

        return body
