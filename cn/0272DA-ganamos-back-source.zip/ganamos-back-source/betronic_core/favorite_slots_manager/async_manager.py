from logging import getLogger
from typing import Optional

from pydantic import create_model
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.models.favorite_slots import FavoriteSlots

logger = getLogger(__name__)


class AsyncFavoriteSlotsManager:
    @classmethod
    async def get_favorite_games_by_user_id(
            cls,
            user_id: int,
            connection: AsyncSession = None
    ) -> Optional[create_model]:
        return await FavoriteSlots.async_get_favorite_games_by_user_id(
            user_id=user_id,
            connection=connection
        )

    @classmethod
    async def update_user_favorite_games(
            cls,
            user_id: int,
            favorite_games: dict,
            connection: AsyncSession = None
    ):
        return await FavoriteSlots.async_update_user_favorite_games(
            user_id=user_id,
            favorite_games=favorite_games,
            connection=connection
        )

    @classmethod
    async def add_user_favorite_slots(
            cls,
            user_id: int,
            favorite_games: dict,
            connection: AsyncSession
    ):
        new_user = FavoriteSlots(
            user_id=user_id,
            favorite_games=favorite_games
        )
        connection.add(new_user)
        await connection.flush()

        return new_user
