from datetime import datetime
from decimal import Decimal
from typing import Optional, Union

from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.payments import PaymentTransactionModel, WAIT, CANCELED
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.withdrawal import WithdrawalModel


class AsyncPaymentManager:

    @classmethod
    async def get_withdrawals_sum_by_period_user_id(
            cls, user_id: int, from_date: datetime, to_date: datetime, connection: AsyncSession
    ) -> Union[float, Decimal]:
        withdrawals_sum_q = select(
            func.sum(WithdrawalModel.amount)
        ).where(
            WithdrawalModel.user_id == user_id,
            WithdrawalModel.updated_at.between(from_date, to_date),
            WithdrawalModel.status == WithdrawalModel.DONE
        )
        withdrawals_sum_raw = await connection.execute(withdrawals_sum_q)
        return withdrawals_sum_raw.scalar() or 0

    @classmethod
    async def get_payment_by_transaction_id(
            cls, transaction_id: str, connection: AsyncSession, with_lock: bool = False
    ) -> Optional[PaymentTransactionModel]:
        return await PaymentTransactionModel.async_get_by_transaction_id(
            transaction_id=transaction_id,
            connection=connection,
            with_lock=with_lock
        )

    @classmethod
    async def get_withdrawal_by_transaction_id(
            cls, transaction_id: str, connection: AsyncSession, with_lock: bool = False
    ) -> Optional[WithdrawalModel]:
        return await WithdrawalModel.async_get_by_transaction_id(
            transaction_id=transaction_id,
            connection=connection,
            with_lock=with_lock
        )

    @classmethod
    async def create_payment(
            cls, user: UserModel, payment_system: str, payment_mode: str,
            transfer: MoneyTransferModel, status: int = WAIT, connection: AsyncSession = None
    ) -> PaymentTransactionModel:
        payment = PaymentTransactionModel(
            payment_mode=payment_mode, payment_system=payment_system, currency=user.currency,
            user_amount=transfer.value, status=status, transfer_id=transfer.id, user_id=user.id,
            external_id=transfer.transaction_id,
        )
        connection.add(payment)
        await connection.flush()
        return payment

    @classmethod
    async def cancel_payment(
            cls, payment: PaymentTransactionModel, canceled_transfer: MoneyTransferModel, connection: AsyncSession
    ) -> PaymentTransactionModel:
        payment.status = CANCELED
        payment.details = {"canceled_transfer_id": canceled_transfer.id}
        connection.add(payment)
        return payment

    @classmethod
    async def create_withdrawal(
            cls, user: UserModel, payment_system: str, payment_mode: str,
            transfer: MoneyTransferModel, is_auto_withdrawal_flag: bool,
            connection: AsyncSession = None
    ) -> WithdrawalModel:
        withdrawal_status = WithdrawalModel.PROCESSING if is_auto_withdrawal_flag else WithdrawalModel.CREATED
        withdrawal = WithdrawalModel(
            payment_system=payment_system, payment_mode=payment_mode, amount=transfer.value,
            status=withdrawal_status, currency=user.currency, transfer_id=transfer.id, user_id=user.id,
            external_id=transfer.transaction_id, is_closed=False
        )
        connection.add(withdrawal)
        await connection.flush()
        return withdrawal

    @classmethod
    async def cancel_withdrawal(
            cls, withdrawal: WithdrawalModel, canceled_transfer: MoneyTransferModel, connection: AsyncSession
    ) -> WithdrawalModel:
        withdrawal.transfer_cancel_id = canceled_transfer.id
        withdrawal.status = WithdrawalModel.CANCELED
        withdrawal.is_closed = True
        connection.add(withdrawal)
        return withdrawal

    @classmethod
    async def done_withdrawal(
            cls, withdrawal: WithdrawalModel, connection: AsyncSession
    ) -> WithdrawalModel:
        withdrawal.status = WithdrawalModel.DONE
        withdrawal.is_closed = True
        connection.add(withdrawal)
        return withdrawal

    @classmethod
    async def processing_withdrawal(
            cls, withdrawal: WithdrawalModel, connection: AsyncSession
    ) -> WithdrawalModel:
        withdrawal.status = WithdrawalModel.PROCESSING
        connection.add(withdrawal)
        return withdrawal
