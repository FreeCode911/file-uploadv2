from logging import getLogger
from typing import List, Union

from sqlalchemy import and_, or_
from tornado.options import options

from betronic_core.constants import PartnerTypeMoneyTransfer, \
    PartnerStatusMoneyTransfer
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from betronic_core.db.models.payments import PaymentTransactionModel, WAIT, \
    CONFIRM
from betronic_core.db.models.promo_code import PromoCodeModel, \
    PromoCodeActivationModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.manager import IManager
from betronic_core.notification_manager.manager import EmailNotificationManager
from util.error import InvalidRequestData, ProgrammingError
from . import error_codes
from ..settings_manager.manager import SettingsManager

logger = getLogger(__name__)


class PaymentManager(IManager):
    def init_payment(
            self, user: UserModel, value, payment_system, payment_mode,
            payment_currency=None) -> PaymentTransactionModel:
        try:
            user_currency = user.get_currency
            payment = PaymentTransactionModel()
            payment.user_id = user.id
            payment.payment_mode = payment_mode
            payment.payment_system = payment_system
            currencies = options.PAYMENTS[payment_system]['currencies'].get(
                payment_mode)
            if not payment_currency:
                if user_currency in currencies:
                    currency = user_currency
                else:
                    currency = options.PAYMENTS[payment_system][
                        'default_currency']
                payment.user_amount = value
                payment_amount = CurrencyRateModel.convert(
                    self.db, value, user_currency, currency)
                if currency:
                    payment.currency = currency
                else:
                    raise ProgrammingError("Can't find currency i n OPTIONS.")
            else:
                payment.currency = payment_currency
                payment_amount = value
                payment.user_amount = CurrencyRateModel.convert(
                    self.db, value, payment_currency, user_currency)
            if payment_amount:
                payment.payment_amount = payment_amount
            else:
                raise ProgrammingError(
                    "Can't convert currency on payment creating")
            self.db.add(payment)
            self.db.commit()

            if options.NEED_PAYMENT_EMAIL:
                email_manager = EmailNotificationManager(self.db)
                email_manager.create_payment_email_to_owner(payment)

            return payment
        except Exception as e:
            logger.warning("Can't create u:%s payment e:%s" % (user.id, e))
            raise ProgrammingError(e)

    def set_payment_external_id(self,
                                payment: PaymentTransactionModel,
                                external_id) -> PaymentTransactionModel:
        payment.external_id = external_id
        self.db.add(payment)
        self.db.commit()
        return payment

    def set_payment_details(
            self, payment: PaymentTransactionModel,
            details: dict) -> PaymentTransactionModel:
        payment.details = details
        self.db.add(payment)
        self.db.commit()
        return payment

    def convert_currency(self, amount, from_currency='USD', to_currency='RUB', allow_negative=False)\
            -> CurrencyRateModel:
        converted_amount = CurrencyRateModel.convert(
                self.db, amount, from_currency, to_currency, allow_negative=allow_negative)
        return converted_amount

    def close_payment(
            self, payment: PaymentTransactionModel) -> PaymentTransactionModel:
        payment.status = CONFIRM
        self.db.add(payment)
        self.db.commit()
        return payment

    def check_and_get_payment(self, payment_id,
                              value) -> PaymentTransactionModel:
        payment = PaymentTransactionModel.get_by_id(self.db, payment_id)
        if payment is None:
            raise InvalidRequestData(error_codes.INCORRECT_PAYMENT_ID,
                                     "Incorrect payment id on top up")
        if float(value) != float(payment.payment_amount):
            raise InvalidRequestData(
                error_codes.INCORRECT_AMOUNT_ON_TOPUP,
                "Incorrect amount on top up %s and %s" %
                (value, payment.payment_amount))
        if payment.transfer_id:
            raise InvalidRequestData(error_codes.TRANSACTION_ALREADY_COMPLETE,
                                     "Transaction already complete")
        return payment

    def get_payment_by_id(self, payment_id) -> PaymentTransactionModel:
        return PaymentTransactionModel.get_by_id(self.db, payment_id)

    def get_payment_by_external_id(self,
                                   external_id) -> PaymentTransactionModel:
        return PaymentTransactionModel.get_by_external_id(self.db, external_id)

    @staticmethod
    def check_payment_payed(payment: PaymentTransactionModel) -> bool:
        if payment.transfer_id:
            return False
        if payment.status != WAIT:
            return False
        return True

    def init_withdrawal(self,
                        user: UserModel,
                        value: float,
                        cashier_id: int,
                        payment_mode: str,
                        requisites: str,
                        transfer: MoneyTransferModel) -> WithdrawalModel:
        try:
            withdrawal = WithdrawalModel()
            withdrawal.user_id = user.id
            withdrawal.payment_mode = payment_mode
            withdrawal.amount = value
            withdrawal.cashier_id = cashier_id
            withdrawal.purse = requisites
            withdrawal.transfer = transfer
            withdrawal.currency = user.currency
            withdrawal.status = WithdrawalModel.CREATED if \
                options.READY_TO_CASHIER_WITHDRAWAL_AFTER_CREATION and \
                value < options.MAX_WITHDRAWAL_WITHOUT_ADMIN_ACCEPT else \
                WithdrawalModel.PROCESSING
            self.db.add(withdrawal)
            self.db.commit()
            return withdrawal
        except Exception as e:
            logger.warning("Can't create u:%s withdrawal e:%s" % (user.id, e))
            raise ProgrammingError(e)

    def check_close_withdrawal(self, withdrawal_id: int) -> WithdrawalModel:
        withdrawal = WithdrawalModel.get_by_id(self.db, withdrawal_id)
        if withdrawal.status != withdrawal.CREATED:
            raise InvalidRequestData(
                error_codes.STATUS_WITHDRAWAL_IS_NOT_CREATED,
                "Incorrect withdrawal, status withdrawal in not created")
        return withdrawal

    def close_withdrawal(self,
                         user_id: int,
                         withdrawal_id: int,
                         transfer: MoneyTransferModel) -> WithdrawalModel:
        try:
            withdrawal = WithdrawalModel.get_by_id(self.db, withdrawal_id)
            withdrawal.status = withdrawal.CANCELED
            withdrawal.transfer_cancel = transfer
            self.db.add(withdrawal)
            self.db.commit()
            return withdrawal
        except Exception as e:
            logger.warning("Can't cancel u: %s withdrawal: %s, e:%s" %
                           (user_id, withdrawal_id, e))
            raise ProgrammingError(e)

    def get_payments(
            self, user_id, begin, end) -> List[MoneyTransferModel]:
        return MoneyTransferModel.get_payments(
            self.db, user_id, begin, end)

    def get_withdrawals(self, user_id, begin, end) -> List[MoneyTransferModel]:
        return MoneyTransferModel.get_withdrawals(self.db, user_id, begin, end)

    def get_payments_by_user_id(self, user_id, begin, end, statuses):

        return PaymentTransactionModel.get_payments(self.db, user_id, begin, end, statuses)

    def get_withdrawal_by_user_id(self, user_id, begin, end, statuses):
        return WithdrawalModel.get_withdrawals_by_user_id(self.db, user_id, begin, end, statuses)

    def get_promo_code_by_code(self, code: str) -> PromoCodeModel:
        promo_code = PromoCodeModel.get_by_code(self.db, code)
        return promo_code

    def check_user_promo_code(self, user_id: int,
                              promo_code: PromoCodeModel)->\
            Union[None, PromoCodeActivationModel]:
        promo_code = PromoCodeActivationModel.get_by_user_and_promo_code(
            self.db, user_id, promo_code.id) if not \
            promo_code.single_activation else PromoCodeActivationModel\
            .get_by_promo_code(self.db, promo_code.id)
        return promo_code

    def checked_promo_code_bonus(self, user_id: int, promo_code_id: int,
                                 transfer_id=None, bonus_transfer_id=None) -> \
            PromoCodeActivationModel:
        try:
            checked = PromoCodeActivationModel()
            checked.user_id = user_id
            checked.promo_code_id = promo_code_id

            checked.transfer_id = transfer_id if transfer_id else None
            checked.bonus_transfer_id = bonus_transfer_id if bonus_transfer_id\
                else None
            self.db.add(checked)
            self.db.commit()
            return checked
        except Exception as e:
            logger.warning("Can't get u:%s Checked_promo_code e:%s" %
                           (user_id, e))
            raise ProgrammingError(e)

    def check_allow_withdrawal(self, user_id, amount):
        user = UserModel.get_by_id(self.db, user_id)
        setting = SettingsManager(self.db).get_setting_by_name("PaymentSettings")
        withdrawal_minimum = setting['min_withdrawal'].get(user.currency, 1)
        withdrawal_maximum = setting['max_withdrawal'].get(user.currency, 1)
        if amount < withdrawal_minimum:
            raise InvalidRequestData(
                error_codes.INSUFFICIENT_BALANCE,
                "Amount less than the minimum %s %s" % (amount, user.currency))
        if amount > withdrawal_maximum:
            raise Exception("Amount more than allowed max withdrawal")

        bet_check = BetrouteLocalBetModel.check_min_count_bet(self.db, user_id)

        pay_check = MoneyTransferModel.check_payment_user(self.db, user_id) \
            if options.CHECK_ALLOW_CASH_WITHDRAWAL else True

        if bet_check and pay_check:
            return True
        else:
            raise InvalidRequestData(
                error_codes.WITHDRAWAL_NOT_ALLOW,
                "Withdrawal not allowed for user_id: %s" % user_id)

    def get_bonus_registration_amount(self, user: UserModel):
        setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
        bonus_amount = float(self.convert_currency(
            setting['registration_bonus'],
            'USD',
            user.currency
        ))
        return bonus_amount

    def get_max_bonus_by_user(self, user: UserModel):
        setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
        bonus_amount = float(self.convert_currency(
            setting['max_bonus_size'],
            'USD',
            user.currency
        ))
        return bonus_amount

    def create_partner_withdrawal(
            self, user: UserModel, min_amount: float,  amount: float,
            currency: str, type_credit: int) -> PartnerMoneyTransfer:

        if min_amount > amount or amount > user.partner_balance:
            raise InvalidRequestData(
                error_codes.PARTNER_AMOUNT_LESS_MINIMUM,
                "Amount withdrawal less minimum")

        transfer = PartnerMoneyTransfer(
            amount, currency, user, PartnerTypeMoneyTransfer.TYPE_WITHDRAWAL,
            PartnerStatusMoneyTransfer.CREATED, type_credit)

        self.db.add(transfer)
        self.db.commit()
        return transfer

    def get_partner_withdrawals(
            self, user_id: int) -> List[PartnerMoneyTransfer]:
        return PartnerMoneyTransfer.get_withdrawal_by_user_id(self.db, user_id)

    def create_partner_promo_code(self, user_id: int) -> PromoCodeModel:
        promo_code_amount = self.convert_currency(
            options.PARTNER_PROMO_CODE_PRICE,
            options.PARTNER_CURRENCY,
            options.PROMOCODE_CURRENCY
        )
        while True:
            partner_promo_code = PromoCodeModel.new_partner_promo_code(user_id, promo_code_amount)
            if not PromoCodeModel.get_by_code(self.db, partner_promo_code.code):
                break

        self.db.add(partner_promo_code)
        self.db.commit()

        return partner_promo_code

    def create_completed_payment(self, transfer: MoneyTransferModel) -> PaymentTransactionModel:
        payment = PaymentTransactionModel(
            transfer_id=transfer.id,
            user_id=transfer.to_user_id,
            payment_mode="",
            payment_system="",
            currency=transfer.currency,
            payment_amount=transfer.value,
            user_amount=transfer.value,
            status=CONFIRM
        )
        self.db.add(payment)
        self.db.commit()

    def create_completed_withdrawal(self, transfer: MoneyTransferModel) -> PaymentTransactionModel:
        withdrawal = WithdrawalModel(
            purse="",
            payment_mode="",
            amount=transfer.value,
            status=WithdrawalModel.DONE,
            currency=transfer.currency,
            is_closed=True,
            transfer_id=transfer.id,
            user_id=transfer.from_user_id
        )
        self.db.add(withdrawal)
        self.db.commit()
