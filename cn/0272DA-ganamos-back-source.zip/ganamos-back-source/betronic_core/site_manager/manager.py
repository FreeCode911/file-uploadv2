from typing import List
from betronic_core.manager import IManager
from betronic_core.db.models.flat_page import FlatPageModel
from util.error import InvalidRequestData
from betronic_core.db.models.feedback_form_question import \
                                                    FeedbackFormQuestionModel
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.ads import AdsModel
from betronic_core.db.models.slide import Slide

from . import error_codes

from logging import getLogger
logger = getLogger(__name__)


class SiteManager(IManager):
    def get_flatpage_list(self, lang=None) -> list:
        if not lang:
            page_list = FlatPageModel.get_all(self.db)
        else:
            page_list = FlatPageModel.get_by_lang(self.db, lang)
        if not page_list:
            return []
        return [item.auto_dict for item in page_list]

    def get_flatpage_by_name(self, name) -> FlatPageModel:
        page = FlatPageModel.get_by_name(self.db, name)
        if not page:
            raise InvalidRequestData(
                error_codes.CANT_GET_FLATPAGE,
                "Can't get flatpage by name {}".format(name))
        return page

    def get_flatpage_by_name_by_lang(self, name, lang) -> FlatPageModel:
        page = FlatPageModel.get_by_name_by_lang(self.db, name, lang)
        if not page:
            raise InvalidRequestData(
                error_codes.CANT_GET_FLATPAGE,
                "Can't get flatpage by name by lang {}".format(name))
        return page

    def get_ads(self) -> List[AdsModel]:
        ads = AdsModel.get_by_priority(self.db)
        return ads

    def get_slides(self, lang: str = None) -> List[Slide]:
        slides = Slide.get_slides_by_priority(self.db, lang)
        return slides

    def get_slides_by_lang_and_priority(self, lang: str = 'es') -> List[Slide]:
        slides = Slide.get_slides_by_priority_and_lang(self.db, lang=lang)
        return slides

    def send_question(self, args):
        question = FeedbackFormQuestionModel().auto_from_dict(args)
        self.db.add(question)
        self.db.commit()
        return question



