"""
For site handler use error codes with prefix 20:
like 201, 202 .. 20100 etc.
"""
CANT_GET_FLATPAGE = 201
CANT_GET_FLATPAGE_LIST = 202
