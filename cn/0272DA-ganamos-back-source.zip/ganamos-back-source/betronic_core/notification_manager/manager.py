from logging import getLogger
from tornado.options import options

from betronic_core.manager import IManager
from betronic_core.db.models.notifications.email_notification import EmailNotification
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.db.models.payments import PaymentTransactionModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer

logger = getLogger(__name__)


class EmailNotificationManager(IManager):
    def get_active_emails(self) -> [EmailNotification]:
        return EmailNotification.get_open_emails(self.db)

    def close_notification(self, notification: EmailNotification) -> None:
        notification.is_closed = True
        self.db.add(notification)
        self.db.commit()

    def _create_email_notification(self, template, context, email,
                                   lang='ru-ru') -> EmailNotification:
        notification = EmailNotification()
        notification.email = email
        notification.set_context(context)
        notification.template_name = template
        notification.lang = lang
        self.db.add(notification)
        self.db.commit()
        return notification

    def create_verification_email_to_user(self, user: UserModel, url=None) \
            -> EmailNotification:
        email_registration = user.email_auth
        return self._create_email_notification(
            options.VERIFICATION_EMAIL_TEMPLATE, {
                "code": email_registration.get_encoded_verification_key(),
                "domain": url,
            }, email_registration.email, user.lang)

    def create_change_email_to_user(self, user: UserModel, new_email: str, url=None) -> EmailNotification:
        email_registration = user.email_auth

        return self._create_email_notification(
            "mobet1_verification_email", {
                "code": email_registration.get_encoded_verification_key(),
                "domain": url,
            }, new_email, user.lang
        )

    def create_restore_password_email_to_user(self, request, lang, url=None) \
            -> EmailNotification:
        return self._create_email_notification("restore_password", {
            "code": request.get_encoded_verification_key(),
            "domain": url,
        }, request.email_auth_email, lang)

    def create_withdrawal_email_to_user(self, withdrawal: WithdrawalModel) \
            -> EmailNotification:
        email_registration = withdrawal.user.email_auth
        lang = withdrawal.user.lang if withdrawal.user.lang else 'ru-ru'
        payload = {
            "name": withdrawal.user.get_full_name(),
            "amount": withdrawal.amount,
            "currency": withdrawal.currency,
            "purse": withdrawal.purse,
            "payment_mode": withdrawal.payment_mode
        }
        return self._create_email_notification(
            "withdrawal_user_notification", payload, email_registration.email, lang)

    def create_withdrawal_email_to_owner(
            self, withdrawal: WithdrawalModel) -> EmailNotification:
        email = options.WITHDRAWAL_EMAIL_NOTIFICATION
        lang = withdrawal.user.lang if withdrawal.user.lang else 'ru-ru'
        payload = {
            "withdrawal_id": withdrawal.id,
            "user_id": withdrawal.user.id,
            "name": withdrawal.user.get_full_name(),
            "paymode": withdrawal.payment_mode,
            "purse": withdrawal.purse,
            "amount": withdrawal.amount,
            "currency": withdrawal.currency
        }
        return self._create_email_notification(
            "withdrawal_owner_notification", payload, email, lang)

    def create_payment_email_to_owner(self, payment: PaymentTransactionModel):
        email = options.WITHDRAWAL_EMAIL_NOTIFICATION
        lang = payment.user.lang or 'ru-ru'
        payload = {
            "payment_id": payment.id,
            "user_id": payment.user.id,
            "name": payment.user.get_full_name(),
            "paymode": payment.payment_mode,
            "amount": payment.payment_amount,
            "currency": payment.currency
        }

        return self._create_email_notification(
            "payment_owner_notification", payload, email, lang)

    def create_email_for_bet_error(
            self, data: dict, error: Exception) -> EmailNotification:
        email = options.SMTP_LOGIN
        payload = {
            "data": data,
            "error": error,
        }
        return self._create_email_notification(
            "bet_error_notification", payload, email)

    def create_email_for_partner_withdraw(self, partner: UserModel, transfer: PartnerMoneyTransfer) \
            -> EmailNotification:
        email_registration = partner.email_auth
        lang = partner.lang if partner.lang else 'ru-ru'
        payload = {
            "amount": transfer.value,
            "name": partner.first_name,
            "date": transfer.created_at.ctime(),
            "currency": transfer.currency,
            "contacts": options['PARTNER_WITHDRAWAL_CONTACTS'],
        }
        return self._create_email_notification(
            "withdrawal_partner_notification", payload, email_registration.email, lang)

    def increment_attempt(self, notification: EmailNotification):
        if not notification.attempt:
            notification.attempt = 1
        notification.attempt += 1
        if notification.attempt == 10:
            notification.is_closed = True
        self.db.add(notification)
        self.db.commit()
