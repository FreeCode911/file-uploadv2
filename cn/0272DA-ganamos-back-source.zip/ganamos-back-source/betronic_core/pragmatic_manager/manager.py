from datetime import datetime
from decimal import Decimal
from logging import getLogger

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.pragmatic_models import PragmaticPlaySessionModel
from betronic_core.db.models.pragmatic_models import PragmaticTransactionsModel
from betronic_core.db.models.user import UserModel
from betronic_core.manager import IManager
from betronic_core.money_manager.manager import MoneyManager

logger = getLogger(__name__)


class PragmaticManager(IManager):

    def check_similar_transaction(self, external_transaction_id: str) -> PragmaticTransactionsModel:
        return PragmaticTransactionsModel.get_by_external_id(self.db, external_transaction_id)

    def get_or_create_user_session_pragmatic(self, user_id: int, session_id=None) -> PragmaticPlaySessionModel:
        session = PragmaticPlaySessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            session.session = session_id
            session.create_at = datetime.now()
            self.db.add(session)
            self.db.commit()
            return session

        session = PragmaticPlaySessionModel()
        session.user_id = user_id
        session.session = session_id
        session.create_at = datetime.now()
        self.db.add(session)
        self.db.commit()

        return session

    def get_pragmatic_user_by_token(self, user_token: str) -> UserModel or None:
        session = PragmaticPlaySessionModel.get_by_session(self.db, session=user_token)
        if session:
            return session.user

    def create_pragmatic_transaction(self,
                                     from_user_id: int = None,
                                     to_user_id: int = None,
                                     amount: float or Decimal = None,
                                     transaction_type: int = PragmaticTransactionsModel.REFUND,
                                     external_transaction_id: str = None,
                                     round_id: int = None,
                                     game_id: str = None,
                                     bonus_code: str = None) -> PragmaticTransactionsModel:

        transaction = PragmaticTransactionsModel(type=transaction_type,
                                                 game_id=game_id,
                                                 round_id=round_id,
                                                 provider_transaction_id=external_transaction_id,
                                                 bonus_code=bonus_code)

        note_for_transfer = "game: %s round:%s" % (game_id, round_id) if (game_id or round_id) else None

        transfer = MoneyManager(self.db).user_move_money(int(from_user_id),
                                                         int(to_user_id),
                                                         amount,
                                                         transaction_type,
                                                         note_for_transfer)

        transaction.transfer = transfer
        self.db.add(transaction)
        self.db.commit()

        return transaction

    def get_free_round_sum(self, user_id: int, bonus_code: str) -> float or Decimal:
        return PragmaticTransactionsModel.get_free_round_sum(self.db, user_id, bonus_code)
        pass
