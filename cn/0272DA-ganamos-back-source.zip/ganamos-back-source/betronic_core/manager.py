from abc import ABCMeta

from sqlalchemy.ext.asyncio.session import AsyncSession
from sqlalchemy.orm import Session

from betronic_core.db.async_database import session

class IManager:
    __metaclass__ = ABCMeta

    def __init__(self, db, documents=None):
        self.db: Session = db
        self.documents = documents

class IAsyncManager:
    __metaclass__ = ABCMeta

    def __init__(self, connection: AsyncSession = None):
        self.db = connection if connection else session()
