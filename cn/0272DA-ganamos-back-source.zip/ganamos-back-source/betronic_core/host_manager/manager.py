import collections
from typing import List, Dict

from betronic_core.manager import IManager
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.host import Host, UserHostPermission
from util.error import InvalidRequestData
from . import error_codes


class HostManager(IManager):
    def check_is_can_visit_host(self, user_id: int, host: str) -> None:
        domain = Host.get_by_domain(self.db, host)
        if not domain:
            return

        can_visit = UserHostPermission.is_can_visit(self.db, user_id, domain.id)
        if not can_visit:
            raise InvalidRequestData(
                error_codes.VISIT_PERMISSION_ERROR,
                'the user does not have permission to visit this domain'
            )

    def get_all_user_host_permissions(self, user_id: int):
        domains = Host.get_all(self.db)

        permissions = UserHostPermission.get_by_use_id(self.db, user_id)
        permissions_dict = {x.host_id: x.can_visit for x in permissions}

        result = []

        for domain in domains:
            permission = permissions_dict.get(domain.id)
            if permission is None:
                result.append(
                    {
                        'domain_id': domain.id,
                        'domain_name': domain.domain,
                        'can_visit': True
                    }
                )
            else:
                result.append(
                    {
                        'domain_id': domain.id,
                        'domain_name': domain.domain,
                        'can_visit': permission
                    }
                )
        return result

    def get_permissions_by_users_list(self, user_ids: List[int]):
        """
        return {user_id: [{domain_id: int, domain: str, can_visit: bool}]}
        """
        result = {}
        domains = Host.get_all(self.db)
        permissions = UserHostPermission.get_by_users_list(self.db, user_ids)
        permissions_dict = {str(x.host_id) + '_' + str(x.user_id): x.can_visit for x in permissions}

        for user_id in user_ids:
            for domain in domains:
                key = str(domain.id) + '_' + str(user_id)
                if key not in permissions_dict:
                    permission_data = {
                        'domain_id': domain.id,
                        'domain_name': domain.domain,
                        'can_visit': True
                    }
                else:
                    permission_data = {
                        'domain_id': domain.id,
                        'domain_name': domain.domain,
                        'can_visit': permissions_dict[key]
                    }
                if user_id not in result:
                    result[user_id] = [permission_data]
                else:
                    result[user_id].append(permission_data)
        return result

    def change_permission(self, user: UserModel, host_id: int, can_visit: bool, descendants: List[int]):
        host = Host.get_by_id(self.db, host_id)
        if host is None:
            raise InvalidRequestData(
                error_codes.HOST_NOT_EXIST,
                'host not found'
            )

        user_permission = UserHostPermission.get(self.db, user.id, host_id)

        if not user_permission:
            user_permission = UserHostPermission.create(self.db, user.id, host_id, can_visit, commit=False)
        elif user_permission.can_visit != can_visit:
            user_permission.can_visit = can_visit
            self.db.add(user_permission)

        permissions = {x.user_id: x for x in UserHostPermission.get_by_users_list(self.db, descendants, host_id)}
        for uid in descendants:
            if uid not in permissions:
                permission = UserHostPermission.create(self.db, uid, host_id, can_visit, commit=False)
            else:
                permission = permissions[uid]
                permission.can_visit = can_visit
                self.db.add(permission)

        self.db.commit()
        return user_permission

    def create_parent_permissions_for_user(self, source_user: UserModel, target_user: UserModel):
        user_permissions: Dict[int, List[UserHostPermission]] = collections.defaultdict(lambda: [])

        host_permissions = UserHostPermission.get_by_users_list(self.db, [source_user.id, target_user.id])
        for host_permission in host_permissions:
            user_permissions[host_permission.user_id].append(host_permission)

        target_host_permission_ids = {
            host_permission.id for host_permission in
            user_permissions.get(target_user.id, [])
        }
        for source_host_permission in user_permissions.get(source_user.id, []):
            if source_host_permission.host_id not in target_host_permission_ids:
                parent_host_permission = UserHostPermission\
                    .create_from_parent(parent_permission=source_host_permission)

                parent_host_permission.user_id = target_user.id
                self.db.add(parent_host_permission)

        self.db.commit()
