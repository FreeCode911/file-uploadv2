import hashlib
import random
import string
from datetime import datetime, timedelta
from logging import getLogger
from time import time
from typing import List, Optional, Tuple, Union
from sqlalchemy import func
from sqlalchemy_utils import Ltree
from tornado.options import options
from betronic_core.constants import PartnerTypePayment, UserTypePaymentTransfer
from betronic_core.db.models.additional_data import AdditionalData
from betronic_core.db.models.betroute_registration import BetrouteRegistrationModel
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.db.models.golden_race_session import GoldenRaceSessionModel
from betronic_core.db.models.inbet import InbetSessionModel
from betronic_core.db.models.outcomebet import OutComeBetSessionModel
from betronic_core.db.models.restore_password_requests import RestorePasswordRequest
from betronic_core.db.models.social_auth import BaseSocialMixin, SOCIAL_CLASSES
from betronic_core.db.models.mascot import MascotSessionModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.security_log import SecurityLogModel
from betronic_core.manager import IManager
from betronic_core.user_manager.handlers.register import (UserRegistrationHandler, EmailRegistrationHandler,
                                                          PhoneRegistrationHandler, UsernameRegistrationHandler)
from util.error import InvalidRequestData, ProgrammingError, PermissionsError
from util.validators import ltree_to_list
from . import error_codes
import zlib
from ..db.models.user_provider_statistic import UserProviderStatisticModel
from ..settings_manager.manager import SettingsManager

logger = getLogger(__name__)


class UserManager(IManager):
    def get_user_by_id(self, user_id: int, allow_prohibited: bool = False) -> UserModel:
        try:
            user = UserModel.get_by_id(self.db, user_id)
            if not user or (
                not allow_prohibited and
                user_id in UserModel.EXCLUDE_USER_IDS_FOR_INTERACTION
            ):
                raise InvalidRequestData(
                    error_codes.USER_NOT_EXIST, "User not found")
        except Exception:
            raise ProgrammingError(
                "Can't get user by user_id: {}".format(user_id))

        return user

    def get_partner_by_id(self, partner_id: int) -> UserModel:
        partner = UserModel.get_partner_by_id(self.db, partner_id)
        if not partner:
            raise InvalidRequestData(
                error_codes.USER_IS_NOT_PARTNER, "Partner not found")
        return partner

    def get_user_by_id_with_lock(self, user_id: int) -> Optional[UserModel]:
        return UserModel.get_by_id_with_lock(self.db, user_id)

    def get_referrals_by_partner_id(self, user_id: int, begin=datetime.min, end=datetime.max) -> List['UserModel']:
        user = UserModel.get_referrals_by_user_id(self.db, user_id, begin, end)
        return user

    def get_user_by_email_for_social(self, email: str,
                                     social: BaseSocialMixin) -> UserModel:
        user = UserModel.get_by_email(self.db, email)
        if user:
            social.user = user
            self.db.add(social)
            self.db.commit()
        return user

    def register_user_by_email(
            self, username: str, name: str, password: str, currency: str,
            email: str, referral_id: int = None, document_number=None, lang: str =
            'ru-ru', need_activation: bool = True, is_user: bool = False
    ) -> UserModel:
        logger.info('Register user by email')
        user_handler = UserRegistrationHandler(
            self.db, name, currency, referral_id, lang)
        user = user_handler.get_new_user()
        user.nickname = username
        self.db.add(user)
        self.db.flush()

        personal_data = user_handler.get_new_personal_data(user)
        personal_data.number_document = document_number
        personal_data.email = email

        email_reg_handler = EmailRegistrationHandler(
            self.db, user, username, password, need_activation=need_activation)

        email_register = email_reg_handler.register_email(is_user)
        self.db.add(email_register)
        self.db.add(personal_data)
        self.db.commit()
        return user

    def register_user_by_phone(
            self, phone: str, password: str, name: str, currency: str,
            lang: str = 'ru-ru', referral_id: int = None, document_number=None,
            need_activation: bool = False) -> UserModel:

        logger.info('Register user by phone')
        user_handler = UserRegistrationHandler(
            self.db, name, currency, referral_id, lang)
        user = user_handler.get_new_user()
        self.db.add(user)
        personal_data = user_handler.get_new_personal_data(user)
        personal_data.number_document = document_number
        personal_data.phone = phone

        phone_reg_handler = PhoneRegistrationHandler(
            self.db, user, phone, password, need_activation=need_activation)

        phone_register = phone_reg_handler.register_phone()
        self.db.add(phone_register)
        self.db.add(personal_data)
        self.db.commit()
        return user

    def register_user_by_username(
            self, username: str, password: str, currency: str, is_user: bool,
            first_name: str, last_name: str, email: str
    ) -> UserModel:
        logger.info('Register user by username')
        user_handler = UserRegistrationHandler(self.db, currency=currency, name=first_name,
                                               middle_name=last_name, email=email)
        user = user_handler.get_new_user()
        user.nickname = username
        user.changed_password = False
        self.db.add(user)
        personal_data = user_handler.get_new_personal_data(user)

        email_reg_handler = UsernameRegistrationHandler(
            self.db, user, username, password, need_activation=False, is_user=is_user
        )

        email_register = email_reg_handler.register_email()
        self.db.add(email_register)
        self.db.add(personal_data)
        self.db.commit()
        return user

    def create_convert_user(self, email, name, password, currency) -> UserModel:
        logger.info('Register convert user')
        user_handler = UserRegistrationHandler(self.db, name, currency)
        user = user_handler.get_new_user()
        self.db.add(user)
        personal_data = user_handler.get_new_personal_data(user)
        email_register = EmailRegistrationHandler(self.db, user, email,
                                                  password).register_email()
        self.db.add(email_register)
        self.db.add(personal_data)
        self.db.commit()
        return user

    def register_terminal(self, login=None, name=None, currency=None,
                          type_terminal=UserModel.USER_TYPES['CARD'], password=None) -> UserModel:
        user_handler = UserRegistrationHandler(self.db, name, currency)
        user = user_handler.get_new_user(type_terminal)
        self.db.add(user)
        email_register = EmailRegistrationHandler(
            self.db, user, login, password,
            type_terminal).register_email()
        self.db.add(email_register)
        self.db.commit()
        return user

    def create_user_social(self, method: int, uid: int) -> BaseSocialMixin:
        social = SOCIAL_CLASSES[method]()
        social.external_id = uid
        self.db.add(social)
        self.db.commit()
        return social

    def get_user_social(self, method: int, uid: str) -> BaseSocialMixin:
        social = SOCIAL_CLASSES[method].get_by_external_id(self.db, uid)
        return social

    def set_user_social(self, user: UserModel,
                        social: BaseSocialMixin) -> BaseSocialMixin:
        social.user = user
        user.email_auth.verification_key = ""
        self.db.add(user.email_auth)
        self.db.add(social)
        self.db.commit()
        return social

    def change_type_partner_payment(self, user: UserModel, type_partner_payment: int):
        user.type_partner_payment = type_partner_payment
        user.last_change_type_partner_payment = datetime.utcnow()
        self.db.add(user)
        self.db.commit()
        return user.type_partner_payment

    def create_betroute_user(self, user_id: int, is_terminal=False) -> \
            BetrouteRegistrationModel:
        user = UserModel.get_by_id(self.db, user_id)

        registration = BetrouteRegistrationModel()
        registration.user = user
        time_ = int(time())
        registration.remote_email = '{}.{}@{}'.format(
            user.id, time_, options.BETROUTE_REGISTER_SUFFIX)
        if user.currency not in options.BETROUTE_CASH_FOR_CURRENCY:
            raise InvalidRequestData(
                error_codes.REMOTE_BETROUTE_ERROR,
                "Currency %s not recognized BETROUTE_CASH_FOR_CURRENCY" % user.currency)
        registration.cash_id = options.BETROUTE_CASH_FOR_CURRENCY[user.currency]
        registration.set_remote_password(BetrouteRegistrationModel.generate_password())

        if is_terminal:
            registration.is_register = False

        self.db.add(registration)
        self.db.commit()
        return registration

    def create_verification_phone_data(self, phone: str, code: str):
        email_auth = EmailAuthModel().get_by_email(self.db, phone)
        if not email_auth:
            data = EmailAuthModel()
            data.email = phone
            data.verification_key = code
            self.db.add(data)
            self.db.commit()
            return data
        if email_auth.email and not email_auth.verification_key:
            raise InvalidRequestData(
                error_codes.USER_ALREADY_EXIST, "User with this phone already exist")
        if email_auth.email and email_auth.verification_key:
            email_auth.verification_key = code
            self.db.add(email_auth)
            self.db.commit()
            return email_auth

    def set_old_betroute_user(self, user_id: int, remote_email: str,
                              remote_password: str, cash_id: int, ):
        user = UserModel.get_by_id(self.db, user_id)

        registration = BetrouteRegistrationModel()
        registration.user = user
        registration.remote_email = remote_email
        if user.currency not in options.BETROUTE_CASH_FOR_CURRENCY:
            raise InvalidRequestData(
                error_codes.REMOTE_BETROUTE_ERROR,
                "Currency {} not recognized BETROUTE_CASH_FOR_CURRENCY"
                    .format(user.currency))
        registration.cash_id = cash_id
        registration.remote_password = remote_password

        self.db.add(registration)
        self.db.commit()
        return registration

    @staticmethod
    def _check_email_auth_password(
            email_auth: EmailAuthModel, password: str) -> EmailAuthModel:
        if not email_auth.has_password(password):
            raise InvalidRequestData(
                error_codes.INVALID_PASSWORD,
                "Invalid password for email {} for user_id {}".format(
                    email_auth.email, email_auth.user_id))
        if not email_auth.is_verified:
            raise InvalidRequestData(
                error_codes.USER_IS_NOT_VEREFIED,
                "User is not verefied. User_id {}".format(email_auth.user_id))
        return email_auth

    def _check_email_password(self, email, password) -> EmailAuthModel:
        email_auth = EmailAuthModel.get_by_email(self.db, email)
        if not email_auth:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST,
                "User with email {} doesn't exist".format(email))
        return self._check_email_auth_password(email_auth, password)

    def _check_user_id_password(self, user_id, password) -> EmailAuthModel:
        email_auth = EmailAuthModel.get_by_user_id(self.db, user_id)
        if not email_auth:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST,
                "User with user_id {} doesn't exist".format(user_id))
        return self._check_email_auth_password(email_auth, password)

    def auth_email_user(self, email, password) -> UserModel:
        logger.info("Try to auth user with email {}".format(email))
        email_auth = self._check_email_password(email, password)
        return email_auth.user

    @staticmethod
    def check_is_user(user) -> bool:
        if user.type != UserModel.USER_TYPES['USER']:
            raise InvalidRequestData(
                error_codes.USER_IS_TERMINAL, "Terminal auth as normal user")
        return True

    def auth_social(self, method, uid) -> BaseSocialMixin:
        logger.info("Try to auth user with social uid: %s" % uid)
        result = SOCIAL_CLASSES[method].get_by_external_id(self.db, uid)
        if not result:
            return self.create_user_social(method, uid)
        return result

    def get_email_auth_by_verification_code(self, code) -> EmailAuthModel:
        email, key = EmailAuthModel.decode_verification_key(code)
        logger.info("Verify by code {} email {}".format(key, email))
        auth = EmailAuthModel.get_by_email(self.db, email)
        if not auth:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST, "User not exist")
        if auth.is_verified:
            raise InvalidRequestData(error_codes.ALREADY_VERIFIED,
                                     "Verification code already activated")
        if auth.verification_key != key:
            raise InvalidRequestData(
                error_codes.INVALID_VERIFY_KEY, "Invalid key on verification")
        if auth.is_verification_key_expired():
            raise InvalidRequestData(error_codes.VERIFY_KEY_IS_EXPIRED,
                                     "Verification key is expired")
        auth.verification_key = None
        self.db.add(auth)
        self.db.commit()
        return auth

    def create_restore_password_request(self, email) -> \
            [RestorePasswordRequest, str]:
        logger.info(
            "Try to create restore password with email {}".format(email))
        email_auth = EmailAuthModel.get_by_email(self.db, email)
        if not email_auth:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST,
                "User with email {} doesn't exist".format(email))
        RestorePasswordRequest.disable_all_previous_by_email(self.db, email)
        request = RestorePasswordRequest()
        request.set_verification_key()
        request.email_auth = email_auth
        self.db.add(request)
        self.db.commit()
        lang = request.email_auth.user.lang
        user_lang = lang if lang else 'ru-ru'
        return request, user_lang

    def get_restore_password_request_by_code(
            self, code) -> RestorePasswordRequest:
        logger.info("Try to get restore password with code {}".format(code))
        email, key = RestorePasswordRequest.decode_verification_key(code)
        email_auth = EmailAuthModel.get_by_email(self.db, email)
        if not email_auth:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST,
                "User with email {} doesn't exist".format(email))

        request = RestorePasswordRequest.get_by_verification_code(self.db, key)
        if not request or request.email_auth_email != email:
            raise InvalidRequestData(
                error_codes.PASSWORD_REQUEST_NOT_EXIST,
                "Password restore request doesn't exist for user {}".format(
                    email))

        if request.is_verification_key_expired():
            raise InvalidRequestData(
                error_codes.PASSWORD_REQUEST_IS_EXPIRED,
                "Password restore is expired for user {}, create new request".
                    format(email))

        return request

    def set_new_password_by_code(
            self, new_pass, code) -> RestorePasswordRequest:
        logger.info("Try to set new pass on restore password with")
        request = self.get_restore_password_request_by_code(code)
        request.email_auth.set_password(new_pass)
        request.verification_key = None
        self.db.add(request)
        self.db.commit()
        return request

    @staticmethod
    def user_check_can_auth(user: UserModel) -> None:
        logger.info("Try to check user can auth user {}".format(user.id))
        if user.is_banned:
            raise InvalidRequestData(error_codes.USER_IS_BANNED,
                                     "User {} is banned".format(user.id))

    def check_user_is_banned(self, user_id: int) -> bool:
        return True if UserModel.get_by_id(self.db, user_id).is_banned else False

    def change_password(
            self, user_id: int, password: str,
            new_password: str) -> EmailAuthModel:
        user = self.get_user_by_id(user_id)
        logger.info("Change password by email: {}".format(user_id))
        email_auth = self._check_user_id_password(user_id, password)
        email_auth.set_password(new_password)
        if not user.changed_password:
            user.changed_password = True
        self.db.add(email_auth)
        self.db.add(user)
        self.db.commit()
        return email_auth

    def set_password(
            self, user_id: int, password: str
        ) -> EmailAuthModel:
        user = self.get_user_by_id(user_id)
        email_auth = user.email_auth
        email_auth.set_password(password)
        self.db.add(email_auth)
        self.db.commit()
        return email_auth

    def required_set_password(
            self, user_id: int, password: str
        ) -> EmailAuthModel:
        user = self.get_user_by_id(user_id)
        if user.changed_password:
            raise PermissionsError(f"You (user_id: {user_id}) cannot "
                                   f"change your password using this method")
        email_auth = user.email_auth
        email_auth.set_password(password)
        user.changed_password = True

        self.db.add(email_auth)
        self.db.add(user)
        self.db.commit()
        return email_auth

    def get_or_create_additional_user_data(self, user_id) -> AdditionalData:
        data = AdditionalData.get_by_user_id(self.db, user_id)
        if not data:
            data = AdditionalData()
            data.user_id = user_id
            self.db.add(data)
        return data

    def update_personal_data(self, user_id: int, main: dict, additional: dict):
        logger.info(f"Update profile by user id: {user_id},"
                    f" main_data: {main}, additional_data: {additional}")
        main_data = UserModel.get_by_id(self.db, user_id)
        for field in main:
            setattr(main_data, field, main[field])

        additional_data = self.get_or_create_additional_user_data(user_id)
        for field in additional:
            setattr(additional_data, field, additional[field])

        self.db.add(additional_data)
        self.db.add(main_data)

    def create_partner(self, user_id: int,
                       type_partner: PartnerTypePayment) -> UserModel:
        user = self.get_user_by_id(user_id)

        if user.is_partner:
            raise InvalidRequestData(
                error_codes.USER_IS_ALREADY_PARTNER, "User already partner")

        user.is_partner = True
        user.type_partner_payment = type_partner

        return user

    def get_all_partners(self) -> List[UserModel]:
        return UserModel.get_all_partners(self.db)

    def get_partners_by_type_payment(
            self, type_payment: PartnerTypePayment) -> List[UserModel]:
        return UserModel.get_partners_by_payment(self.db, type_payment)

    def set_user_referral_id(
            self, user: UserModel, partner_id: int) -> UserModel:
        user.referral_id = partner_id
        self.db.add(user)
        self.db.commit()
        return user

    def get_or_create_user_session(self, user_id) -> InbetSessionModel:
        session = InbetSessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            if not session.create_at or \
                    session.create_at.day != datetime.now().day:
                session.session = self.gen_session(session.id, user_id)
                session.create_at = datetime.now()
                self.db.add(session)
                self.db.commit()
            return session

        session = InbetSessionModel()
        session.user_id = user_id
        self.db.add(session)
        self.db.commit()

        session.session = self.gen_session(session.id, user_id)

        self.db.commit()

        return session

    def get_or_create_user_session_outcome(self, user_id, session_id=None) -> OutComeBetSessionModel:
        session = OutComeBetSessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            if not session.create_at or \
                    session.create_at.day != datetime.now().day:
                session.session = session_id
                session.create_at = datetime.now()
                self.db.add(session)
                self.db.commit()
            return session

        session = OutComeBetSessionModel()
        session.user_id = user_id
        session.session = session_id
        session.create_at = datetime.now()
        self.db.add(session)
        self.db.commit()

        return session

    def gen_session(self, session_id: int, user_id: int):
        session = hashlib.md5(
            ':'.join([str(session_id), str(user_id),
                      self.gen_salt()]).encode("utf-8")
        ).hexdigest()
        return session

    def gen_salt(self):
        available_chars = string.ascii_letters + string.digits
        salt = ''.join([random.choice(available_chars) for _ in range(10)])
        return salt

    def get_user_by_phone(self, phone: str) -> UserModel:
        try:
            user = UserModel.get_by_phone(self.db, str(phone))
            if not user:
                raise InvalidRequestData(
                    error_codes.USER_NOT_EXIST, "User not found")
        except Exception:
            raise ProgrammingError(
                "Can't get user by phone: {}".format(phone))
        return user

    def verify_phone_auth_code(self, phone, code):
        data = EmailAuthModel.get_by_phone(self.db, phone)
        logger.info("Verify by code {} phone {}".format(data.verification_key, data.email))
        if not data:
            raise InvalidRequestData(
                error_codes.PHONE_NOT_EXIST, "Phone not exist")
        if data.verification_key != code:
            raise InvalidRequestData(
                error_codes.INVALID_VERIFY_CODE, "Invalid code on verification")
        data.verification_key = None
        self.db.add(data)
        self.db.commit()

    def get_or_create_golden_race_session(self, user_id: int, new_session: str or None) -> str:
        session = GoldenRaceSessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            session.session = new_session
            session.create_at = datetime.now()
            self.db.add(session)
            self.db.commit()
            return session
        session = GoldenRaceSessionModel()
        session.user_id = user_id
        session.session = new_session
        session.create_at = datetime.now()
        self.db.add(session)
        self.db.commit()
        return session

    def get_golden_race_user_by_session(self, session: str) -> UserModel or None:
        session_object = GoldenRaceSessionModel.get_by_session(self.db, session=session)
        if not session_object:
            return None
        return session_object.user

    def get_user_by_login(self, login: str) -> UserModel:
        email_model = EmailAuthModel.get_by_email(self.db, login)
        return email_model.user if email_model else None

    def get_user_by_login_with_lock(self, login: str) -> UserModel:
        return UserModel.get_by_login_with_lock(self.db, login)

    def get_user_by_partial_nickname(self, nickname: str, source_user: UserModel) -> UserModel:
        user_model = UserModel.get_by_partial_nickname(self.db, nickname, source_user)
        return user_model if user_model else None

    def get_users_by_logins(self, logins: list) -> List[UserModel]:
        email_models = EmailAuthModel.get_by_emails(self.db, logins)
        if email_models:
            return [model.user for model in email_models]

    def get_user_email_by_phone_or_nickname(self, login):
        try:
            user_id = AdditionalData. \
                get_by_user_phone(self.db, login).user_id
            print(user_id)
            return EmailAuthModel.get_by_user_id(self.db, user_id).email
        except AttributeError:
            pass
        try:
            return UserModel. \
                get_by_nickname(self.db, login).email_auth.email
        except AttributeError:
            return None

    def set_last_visit(self, user: UserModel) -> UserModel:
        user.last_visit = datetime.utcnow()
        self.db.add(user)
        self.db.commit()
        return user

    def get_or_create_user_session_mascot(self, user_id, session_id=None) -> MascotSessionModel:
        session = MascotSessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            if not session.create_at or \
                    session.create_at.day != datetime.now().day:
                session.session = session_id
                session.create_at = datetime.now()
                self.db.add(session)
                self.db.commit()
            return session

        session = MascotSessionModel()
        session.user_id = user_id
        session.session = session_id
        session.create_at = datetime.now()
        self.db.add(session)
        self.db.commit()

        return session

    def security_log(self, user_id, ip_address, request_from, operation, request_body, note=None):
        if 'password' in request_body:
            request_body['password'] = hex(zlib.crc32(request_body['password'].encode('utf-8')) & 0xffffffff)
        if 'new_password' in request_body:
            request_body['new_password'] = hex(zlib.crc32(request_body['new_password'].encode('utf-8')) & 0xffffffff)
        if 'data' in request_body:
            request_body['data']['password'] = hex(zlib.crc32(request_body['data']['password'].encode('utf-8')) & 0xffffffff)
        new_activity = SecurityLogModel(user_id, ip_address, request_from, operation, request_body, note)
        self.db.add(new_activity)
        self.db.commit()

    def check_structure_user(self,
                             child_id: int,
                             creator_id: int,
                             creator_role: str,
                             future_user_role: str):
        child = self.get_user_by_id(child_id)

        # Проверка роли админа/кассира и урла на который пришел запрос
        if child.role != UserModel.ROLES_FOR_MINI_ADMIN_URLS[future_user_role]:
            raise InvalidRequestData(
                error_codes.INVALID_DATA_REQUEST,
                "An invalid parameter was received for the request."
            )

        if creator_role == UserModel.SUPER_ADMIN:
            if child.parent_suadmin_id != creator_id:
                raise InvalidRequestData(
                    error_codes.USER_IS_NOT_CHILD,
                    f"User with id {child_id} is not a child of user {creator_id}."
                )

        return child.role

    @staticmethod
    def check_for_ltree_if_exists(
            source_entity: UserModel = None,
            target_entity: UserModel = None
    ):
        if source_entity and not source_entity.structure_path:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_IS_MISSING,
                f'Ltree structure of {source_entity.id} does not exists'
            )
        if target_entity and not target_entity.structure_path:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_IS_MISSING,
                f'Ltree structure of {target_entity.id} does not exists'
            )

        return

    @classmethod
    def check_for_ltree_relation(
            cls,
            source_entity: UserModel,
            target_entity: UserModel
    ):
        cls.check_for_ltree_if_exists(
            source_entity=source_entity,
            target_entity=target_entity
        )
        if source_entity.structure_path.path not in target_entity.structure_path.path:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_FORBIDDEN_ERROR,
                f'User ID {source_entity.id} is not in '
                f'user ID {target_entity.id} structure'
            )

        return

    @classmethod
    def check_for_ltree_transfer(
            cls,
            source_entity: UserModel = None,
            target_entity: UserModel = None
    ):
        cls.check_for_ltree_if_exists(
            source_entity=source_entity,
            target_entity=target_entity
        )

        if target_entity and target_entity.role != UserModel.PARTNER_AGENT:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_FORBIDDEN_ERROR,
                f'Parent agent ID {target_entity.id} '
                f'cannot be in the user substructure'
            )

        if (source_entity and target_entity) and \
                source_entity.structure_path.path in target_entity.structure_path.path:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_FORBIDDEN_ERROR,
                f'Parent agent ID {target_entity.id} '
                f'in substructure of {source_entity.id} user'
            )

        if source_entity and \
                source_entity.role == UserModel.USER and target_entity is None:
            raise InvalidRequestData(
                error_codes.USER_STRUCTURE_FORBIDDEN_ERROR,
                f'User ID {source_entity.id} '
                f'cannot be a root structure'
            )

        return

    def get_list_user_by_parent_agent_id(
            self,
            parent_agent: UserModel,
            role: str = None,
            username: str = None,
            is_banned: bool = None,
            is_visible: bool = None,
            skip: int = None,
            limit: int = None,
            order_by: str = None,
            date_from: datetime = None,
            date_to: datetime = None
    ) -> Tuple[List[UserModel], int, float]:

        users, user_total_count, total_balances = UserModel.get_list_with_parent_by_parent_agent_id(
            db=self.db,
            parent_agent=parent_agent,
            username=username,
            role=role,
            is_banned=is_banned,
            is_visible=is_visible,
            skip=skip,
            limit=limit,
            order_by=order_by,
            date_from=date_from,
            date_to=date_to
        )

        return users, user_total_count, total_balances

    def get_list_user_by_structure_path(
            self,
            structure_path: Ltree,
            role: str = None,
            username: str = None,
            is_banned: bool = None,
            is_direct_structure: bool = None,
            is_visible: bool = None,
            skip: int = None,
            limit: int = None,
            order_by: str = None,
            date_from: datetime = None,
            date_to: datetime = None,
            parent_agent_id: int = None,
    ) -> Tuple[List[UserModel], int, float]:

        users, user_total_count, sum_balances = UserModel.get_list_with_parent_by_structure_path(
            db=self.db,
            structure_path=structure_path,
            username=username,
            role=role,
            is_banned=is_banned,
            is_direct_structure=is_direct_structure,
            is_visible=is_visible,
            skip=skip,
            limit=limit,
            order_by=order_by,
            date_from=date_from,
            date_to=date_to,
            parent_agent_id=parent_agent_id
        )

        return users, user_total_count, sum_balances

    def get_list_user_descendants(
            self,
            source_entity: UserModel,
            max_ltree_level: int = None,
            target_role: str = None,
            username: str = None,
            is_like_username: bool = True
    ):
        self.check_for_ltree_if_exists(source_entity)

        entity_descendants = UserModel.get_descendant_list_by_ltree_path(
            db=self.db,
            ltree_path=source_entity.structure_path,
            source_entity_id=source_entity.id,
            max_ltree_level=max_ltree_level,
            target_role=target_role,
            is_banned=False,
            username=username,
            is_like_username=is_like_username
        )

        return entity_descendants

    def get_paginated_user_descendants(
            self,
            source_entity: UserModel,
            max_ltree_level: int = None,
            target_role: str = None,
            skip: int = None,
            limit: int = None
    ):
        entity_descendants, count = UserModel.get_paginated_descendant_list_by_ltree_path(
            db=self.db,
            ltree_path=source_entity.structure_path,
            source_entity_id=source_entity.id,
            max_ltree_level=max_ltree_level,
            target_role=target_role,
            skip=skip,
            limit=limit
        )
        return entity_descendants, count

    def get_list_user_ancestors(
            self,
            source_entity: UserModel
    ):
        self.check_for_ltree_if_exists(source_entity)

        entity_ancestors = UserModel.get_ancestor_list_by_ltree_path(
            db=self.db,
            ltree_path=source_entity.structure_path
        )

        return entity_ancestors

    def set_ltree_user_structure(
            self,
            source_entity: UserModel,
            target_entity: Optional[UserModel] = None
    ):
        self.check_for_ltree_transfer(
            source_entity=source_entity,
            target_entity=target_entity
        )

        if target_entity:
            old_user_structure = source_entity.structure_path
            new_user_structure = (target_entity.structure_path + Ltree(str(source_entity.id))) \
                if target_entity.structure_path else (Ltree(str(target_entity.id)) + Ltree(str(source_entity.id)))
        else:
            old_user_structure = source_entity.structure_path
            new_user_structure = Ltree(str(source_entity.id))

        source_entity.parent_agent_id = target_entity.id if target_entity else None
        source_entity.structure_path = new_user_structure

        UserModel.update_structure(
            self.db,
            source_entity_id=source_entity.id,
            new_path=new_user_structure,
            old_path=old_user_structure,
        )

        self.db.add(source_entity)
        self.db.commit()

    def ban_user_ltree_structure(
            self,
            source_entity: UserModel,
            ban_status: bool
    ):
        source_entity.structure_is_banned = ban_status

        banned_users = UserModel.set_ban_status_structure_by_ltree_path(
            db=self.db,
            source_entity_id=source_entity.id,
            ltree_path=source_entity.structure_path,
            ban_status=ban_status
        )

        self.db.add(source_entity)
        self.db.commit()

        return banned_users

    def get_substructure_user_by_nickname(
            self,
            source_user: UserModel,
            target_nickname: str
    ):
        user_db = self.get_user_by_partial_nickname(nickname=target_nickname.lower(), source_user=source_user)
        if not user_db:
            raise InvalidRequestData(
                error_codes.USER_NOT_EXIST, "User not found")

        if source_user.role != UserModel.SUPER_ADMIN:
            self.check_for_ltree_relation(
                source_entity=source_user,
                target_entity=user_db
            )
        return user_db

    def get_substructure_user(
            self,
            source_user: UserModel,
            target_user_id: int,
            with_lock: bool = False
    ):
        if with_lock:
            user_db = self.get_user_by_id_with_lock(user_id=target_user_id)
        else:
            user_db = self.get_user_by_id(user_id=target_user_id)
        if source_user.role != UserModel.SUPER_ADMIN:
            self.check_for_ltree_relation(
                source_entity=source_user,
                target_entity=user_db
            )

        return user_db

    def check_for_availability_deposit_withdraw(
            self,
            user: UserModel,
            operation_type: int
    ):
        setting = SettingsManager(self.db).get_setting_by_name("AgentsSettings")
        if user.id not in setting['deposit_withdrawal_allowed_agent_ids']:
            if operation_type == UserTypePaymentTransfer.TYPE_WITHDRAWAL and \
                    user.is_withdrawal_access is False:
                raise InvalidRequestData(
                    error_codes.USER_WITHDRAW_NOT_ALLOWED,
                    f'Withdraw for user {user.id} ID is prohibited'
                )

            if operation_type == UserTypePaymentTransfer.TYPE_DEPOSIT and \
                    user.is_deposit_access is False:
                raise InvalidRequestData(
                    error_codes.USER_DEPOSIT_NOT_ALLOWED,
                    f'Deposit for user {user.id} ID is prohibited'
                )

        return

    def get_users_emails_from_ltree(self, structure_path: Ltree):
        target_ids = ltree_to_list(structure_path)
        emails = EmailAuthModel.get_by_user_ids(self.db, target_ids)
        return emails

    def delete_user_ltree_structure(self, user):
        deleteid_ids = UserModel.delete_structure_by_ltree_path(
            self.db,
            source_entity_id=user.id,
            ltree_path=user.structure_path,
        )
        return deleteid_ids

    def get_main_agents(self):
        return UserModel.get_main_agents(self.db)

    def get_list_with_parent(self, role: str, skip: int, limit: int, username: str = None):
        return UserModel.get_list_with_parent(self.db, role, skip, limit, username)

    def set_agent_access(
            self, user: UserModel,
            is_withdrawal_access: bool,
            is_deposit_access: bool
    ):
        setting = SettingsManager(self.db).get_setting_by_name("AgentsSettings")
        if user.id in setting['deposit_withdrawal_allowed_agent_ids']:
            if is_withdrawal_access is False or is_deposit_access is False:
                raise InvalidRequestData(
                    error_codes.USER_CHANGE_ACCESS_NOT_ALLOWED,
                    f"cannot disable withdrawal_access or deposit access for agent {user.id}"
                )

        if is_withdrawal_access is not None and is_withdrawal_access != user.is_withdrawal_access:
            user.is_withdrawal_access = is_withdrawal_access

        if is_deposit_access is not None and is_deposit_access != user.is_deposit_access:
            user.is_deposit_access = is_deposit_access

        self.db.add(user)

    def get_ip_from_security_log_by_user_id(self, user_id: int) -> List[str]:
        result = (
            self.db.query(SecurityLogModel.ip_address).distinct()
            .where(SecurityLogModel.user_id == user_id)
            .all()
        )
        ip_list = [row.ip_address for row in result]
        return ip_list

    def check_for_allow_user_creating(self, user_db: UserModel, major: bool = True):
        settings_dict = SettingsManager(self.db).get_setting_by_name("MaxUserCreatingCountLimit")
        if major:
            settings = settings_dict['major']
            period = settings['hours']
            timedelta_period = timedelta(hours=period)
        else:
            settings = settings_dict['minor']
            period = settings['minutes']
            timedelta_period = timedelta(minutes=period)

        last_created_users = (
            self.db.query(
                UserModel.get_list_by_parent_agent_id_subq(
                    self.db,
                    parent_agent_id=user_db.id,
                    limit=settings['limit'],
                    is_descending_order_id=True
                )
            ).all()
        )

        min_datetime_created_at = datetime.utcnow() - timedelta_period

        last_created_users = list(
            filter(
                lambda user: user.first_visit >= min_datetime_created_at,
                last_created_users
            )
        )

        if len(last_created_users) >= settings['limit']:
            raise InvalidRequestData(
                error_codes.MAX_USER_CREATE_COUNT_IN_RANGE,
                f"user reached max limit {settings['limit']} "
                f"of creating user in range time {period} {'hour(s)' if major else 'minute(s)'}"
            )

        return True

    def get_total_balance_statistic_for_agent_by_id(self, user_db: UserModel):
        base_balance_query = self.db.query(
            func.coalesce(func.sum(UserModel.balance), 0)
        ).where(UserModel.structure_path.descendant_of(user_db.structure_path), UserModel.id != user_db.id)

        user_balance = base_balance_query.where(UserModel.role == UserModel.USER).first()
        agent_balance = base_balance_query.where(UserModel.role.in_([UserModel.PARTNER_AGENT])).first()
        substructure_count = self.db.query(
            func.count(UserModel.id)
        ).where(
            UserModel.structure_path.descendant_of(user_db.structure_path), UserModel.id != user_db.id
        ).first()

        return user_balance[0], agent_balance[0], substructure_count[0]

    def get_players_ranked_by_netwin(
            self,
            user_db: UserModel,
            date_from: datetime = None,
            date_to: datetime = None
    ) -> list[dict[str, Union[str, float, int]]]:
        user_ranking_statistic = UserProviderStatisticModel.get_users_ranked_by_netwin(
            self.db,
            user=user_db,
            date_from=date_from,
            date_to=date_to
        )
        data = [
            {
                "user_id": user_id,
                "number": index + 1,
                "username": username,
                "bets_count": bet_count,
                "wins_count": win_count,
                "wins_sum": win_sum,
                "bets_sum": bet_sum,
                "profit": profit
            }
            for index, (user_id, username, bet_count, win_count, win_sum, bet_sum,
                        profit) in enumerate(user_ranking_statistic)
        ]

        return data
