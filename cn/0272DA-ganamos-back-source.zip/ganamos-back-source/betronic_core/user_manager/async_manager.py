from logging import getLogger
from typing import Optional

from pydantic import create_model

from betronic_core.db.models.user import UserModel
from sqlalchemy.ext.asyncio import AsyncSession


logger = getLogger(__name__)


class AsyncUserManager:
    @classmethod
    async def get_user_general_data(
            cls,
            user_id: int,
            with_lock: bool = False,
            connection: AsyncSession = None
    ) -> Optional[create_model]:
        if not user_id:
            raise ValueError('user_id not found')

        result = await UserModel.async_get_general_data(
            user_id=int(user_id),
            with_lock=with_lock,
            connection=connection
        )

        return result