# -*- coding: utf-8 -*-
from logging import getLogger
import base64
import datetime

from tornado.options import options

from betronic_core.db.models.email_auth import EmailAuthModel
from bookmakers.user.user.handlers.auth import AuthHandler
from betronic_core.notification_manager.notification import smtp_notifier
from betronic_core.db.models.partner import PartnerMoneyTransfer
from bookmakers.user.service.handlers import unisender

logger = getLogger(__name__)

VERIFY_STATUS_OK = 0
VERIFY_STATUS_UNKNOWN_ERROR = 1
VERIFY_STATUS_INVALID_CODE = 10
VERIFY_STATUS_CODE_EXPIRED = 11
VERIFY_STATUS_USER_NOT_FOUND = 20
VERIFY_STATUS_ALREADY_VERIFIED = 30
VERIFY_STATUS_REMOTE_ERROR = 40


class VerifyError(Exception):
    pass


class EmailAuthVerificationHandler():
    def __init__(self, db, code, ip):
        self._db = db
        self._code = code
        self._ip = ip
        self._cookies = None
        self._auth = None

    def _check_code(self):
        try:
            email, key = self.decode_verification_key(self._code)
        except Exception as e:
            logger.warn('Failed to decode verification code (%s): %s',
                        self._code, e)
            raise VerifyError(VERIFY_STATUS_INVALID_CODE)
        auth = EmailAuthModel.get_by_email(self._db, email)
        if not key or not auth:
            logger.warn('Failed to get auth by email (%s) with code (%s)',
                        email, self._code)
            raise VerifyError(VERIFY_STATUS_INVALID_CODE)
        if auth.is_verified():
            logger.warn('User (%s) is already verified', email)
            raise VerifyError(VERIFY_STATUS_ALREADY_VERIFIED)
        if auth.is_verification_key_expired():
            logger.warn('Verification key expired for user (%s) code (%s)',
                        email, self._code)
            raise VerifyError(VERIFY_STATUS_CODE_EXPIRED)
        if not auth.is_verification_key_valid(key):
            logger.warn('Verification key does not match (%s) != (%s)',
                        auth.verification_key, key)
            raise VerifyError(VERIFY_STATUS_INVALID_CODE)
        self._auth = auth

    def _credit_partner_by_register(self, user):
        PartnerMoneyTransfer.credit_registration_by_user(self._db, user)

    def check(self):
        self._check_code()

    def save(self):
        auth = self._auth
        if not auth:
            raise Exception('Auth not found')
        auth.clear_verification_key()
        self._db.add(auth)
        user = auth.user
        if not user.is_verified:
            user.is_verified = True
            if user.referral:
                self._credit_partner_by_register(user)
            user.first_visit = datetime.datetime.utcnow()
            if options.UNISENDER_API_KEY:
                unisender.subscribe_user_to_unisender(auth.email, ' '.join(
                    (user.first_name or '', user.last_name or
                     '')), user.original_currency or user.currency, self._ip)
            self._db.add(user)
        try:
            logger.info('Authenticate user (%s) on remote server', user.email)
            self._cookies = AuthHandler.authenticate_user_on_remote_server(
                user)
        except Exception as e:
            logger.warning('Got remote auth error: %s', e)
            raise VerifyError(VERIFY_STATUS_REMOTE_ERROR)

        self._db.add(user)
        logger.info('User "%s" was verified with code "%s"', user.email,
                    self._code)

    def get_cookies(self):
        return self._cookies

    def get_auth(self):
        return self._auth
