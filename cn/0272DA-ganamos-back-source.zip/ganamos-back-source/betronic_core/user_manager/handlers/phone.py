import random
import re
import string

from betronic_core.db.models.user import UserModel

PHONE_STATUS_OK = 0
PHONE_STATUS_UNKNOWN_ERROR = 1
PHONE_STATUS_INVALID_NUMBER = 10
PHONE_STATUS_USER_NOT_FOUND = 20


class SetPhoneError(Exception):
    pass


class SetPhoneNumberHandler(object):

    VERIFICATION_CODE_LENGTH = 6

    @staticmethod
    def get_normalized_phone(phone):
        if phone and isinstance(phone, str):
            phone = re.sub(r'[\(\)\s-]+', '', phone)
        return phone

    @staticmethod
    def is_phone_valid(phone):
        if not re.match(r"^\+\d{8,16}$", phone):
            return False
        return True

    def __init__(self, db, user_id, phone):
        self._db = db
        self._user_id = user_id
        self._phone = phone

    def check(self):
        self._check_user()
        self._check_phone()

    def _check_user(self):
        user = UserModel.get_by_id(self._db, self._user_id)
        if not user:
            raise SetPhoneError(PHONE_STATUS_USER_NOT_FOUND)

    def _check_phone(self):
        if not self._phone:
            raise SetPhoneError(PHONE_STATUS_INVALID_NUMBER)
        if not SetPhoneNumberHandler.is_phone_valid(self._phone):
            raise SetPhoneError(PHONE_STATUS_INVALID_NUMBER)

    def set(self):
        user = UserModel.get_by_id(self._db, self._user_id)
        user.phone = self._get_normalized_phone()
        user.verification_code = self._get_verification_code()
        self._db.add(user)

    def _get_normalized_phone(self):
        if self._phone.startswith("+"):
            return self._phone
        if self._phone.startswith("8") and len(self._phone) == 11:
            return "+7%s" % self._phone[1:]
        return "+7%s" % self._phone

    def _get_verification_code(self):
        return "".join(
            random.choice(string.digits)
            for _ in range(UserModel.VERIFICATION_CODE_LENGTH))
