from tornado.options import options

from betronic_core.db.models.additional_data import AdditionalData
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager import error_codes
from util import email as email_util
from util import phone as phone_util
from util.error import InvalidRequestData


class UserRegistrationHandler:
    def __init__(
            self, db, name: str, currency: str, referral_id: int = None, lang='ru-ru',
            middle_name: str = None, first_name: str = None, email: str = None
    ):
        self._db = db
        self._currency = currency
        self._name = name
        self._referral_id = referral_id
        self._lang = lang
        self._last_name = middle_name
        self._first_name = first_name
        self._email = email
        self.check_currency_is_available()

    def get_new_user(self, user_type=UserModel.USER_TYPES['USER']) -> UserModel:
        user = UserModel()
        user.first_name = self._first_name
        user.last_name = self._last_name
        user.currency = self._currency
        user.type = user_type
        user.referral_id = self._referral_id
        user.lang = self._lang
        return user

    def get_new_personal_data(self, user: UserModel) -> AdditionalData:
        personal_data = AdditionalData()
        personal_data.user = user
        personal_data.email = self._email
        return personal_data

    def check_phone(self, phone):
        if AdditionalData.check_user_phone(self._db, phone):
            raise InvalidRequestData(
                error_codes.PHONE_ALREADY_EXIST,
                "User with phone {} already exist".format(phone))
        else:
            return None

    def check_currency_is_available(self):
        if self._currency not in options.AVAILABLE_CURRENCIES:
            raise Exception("This currency is not available for registration!")
        else:
            return True


class EmailRegistrationHandler:
    def __init__(self, db, user: UserModel, email, password,
                 type_user=UserModel.USER_TYPES['USER'], need_activation=True):
        self._db = db
        self._user = user
        self._email = email
        self._password = password
        self._type = type_user
        self._auth = None
        self._need_activation = need_activation

    def check_already_registered(self):
        if EmailAuthModel.get_by_email(self._db, self._email):
            raise InvalidRequestData(
                error_codes.USER_ALREADY_EXIST,
                "User with email {} already exist".format(self._email))

    def is_user(self):
        return self._type == UserModel.USER_TYPES['USER']

    def check_email_validity(self):
        if self.is_user():
            self._email = email_util.normalize_and_check(self._email)
        if not self._email:
            raise InvalidRequestData(error_codes.INVALID_EMAIL, 'Invalid email')

    def create_new_auth(self, is_user: bool = False):
        self._auth = EmailAuthModel(email=self._email, user=self._user)
        self._auth.set_password(self._password, is_user)
        if self.is_user() and \
                options.NEED_ACTIVATION_EMAIL and self._need_activation:
            self._auth.set_verification_key()

    def register_email(self, is_user: bool = False):
        self.check_already_registered()
        # self.check_email_validity()
        self.create_new_auth(is_user)
        return self._auth


class PhoneRegistrationHandler:
    def __init__(self, db, user: UserModel, phone, password,
                 type_user=UserModel.USER_TYPES['USER'], need_activation=True):
        self._db = db
        self._user = user
        self._phone = phone
        self._password = password
        self._type = type_user
        self._auth = None
        self._need_activation = need_activation

    def check_already_registered(self):
        if EmailAuthModel.get_by_email(self._db, self._phone):
            raise InvalidRequestData(
                error_codes.USER_ALREADY_EXIST,
                "User with phone {} already exist".format(self._phone))

    def is_user(self):
        return self._type == UserModel.USER_TYPES['USER']

    def check_phone_validity(self):
        self._phone = phone_util.check_phone(self._phone)
        if not self._phone:
            raise InvalidRequestData(error_codes.INVALID_PHONE, 'Invalid phone')

    def create_new_auth(self):
        self._auth = EmailAuthModel(email=self._phone, user=self._user)
        self._auth.set_password(self._password)
        if self.is_user() and \
                options.NEED_ACTIVATION_EMAIL and self._need_activation:
            self._auth.set_verification_key()

    def create_new_phone_auth(self):
        self._auth = EmailAuthModel.get_by_email(self._db, self._phone)
        self._auth.email = self._phone
        self._auth.user = self._user
        self._auth.set_password(self._password)

    def register_phone(self):
        self.create_new_phone_auth()
        return self._auth


class UsernameRegistrationHandler:
    def __init__(self, db, user: UserModel, username, password,
                 type_user=UserModel.USER_TYPES['USER'], need_activation=True, is_user: bool = True):
        self._db = db
        self._user = user
        self._username = username
        self._password = password
        self._type = type_user
        self._auth = None
        self._need_activation = need_activation
        self._is_user = is_user

    def check_already_registered(self):
        if EmailAuthModel.get_by_email(self._db, self._username):
            raise InvalidRequestData(
                error_codes.USER_ALREADY_EXIST,
                "User with Username {} already exist".format(self._username))

    def is_user(self):
        return self._type == UserModel.USER_TYPES['USER']

    def create_new_auth(self):
        self._auth = EmailAuthModel(email=self._username, user=self._user)
        self._auth.set_password(self._password, is_user=self._is_user)

    def register_email(self):
        self.check_already_registered()
        self.create_new_auth()
        return self._auth
