from logging import getLogger

from sqlalchemy import and_, or_

from betronic_core.constants import TransferTypes
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.manager import IManager

logger = getLogger(__name__)

default_report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}


class MiniAdminManager(IManager):
    def __init__(self, db, provider):
        self.db = db
        self.types = self.get_transfer_types_by_provider(provider)
        self.types_for_query = [val for sublist in list(self.types.values()) for val in sublist]
        self.i = 0

    @staticmethod
    def get_transfer_types_by_provider(provider: str) -> dict:
        """
        :param provider: name of provider( sport, live-casino, slots)
        :return: dict of lists with transfer types
        """
        if provider == 'sport':
            result = {'win': [TransferTypes.WIN_BET_BETSSTORE, ], 'set': [TransferTypes.SET_BET_BETSSTORE, ]}
        elif provider == 'slots':
            result = {'win': [TransferTypes.TYPE_OUTCOMEBET_PRIZE, ], 'set': [TransferTypes.TYPE_OUTCOMEBET_BET, ]}
        elif provider == 'live-casino':
            result = {'win': [TransferTypes.TYPE_EZUGI_WIN, TransferTypes.TYPE_TVBET_PRISE],
                      'set': [TransferTypes.TYPE_EZUGI_BET, TransferTypes.TYPE_TVBET_BET]}

        return result

    @staticmethod
    def create_default_report(transfer: MoneyTransferModel, types: dict):
        """
        Depending on the type of transfer, returns a dictionary where the key is the from_user_id/to_user_id
        from the transfer
        :param transfer: MoneyTransferModel object
        :param types: dict of lists with transfer types
        :return:  dict
        """
        default_report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        if transfer.type in types['win']:
            result = {transfer.real_to_user_id: default_report}
            result[transfer.real_to_user_id]['username'] = transfer.real_to_user.email_auth.email
        if transfer.type in types['set']:
            result = {transfer.real_from_user_id: default_report}
            result[transfer.real_from_user_id]['username'] = transfer.real_from_user.email_auth.email
        return result

    def get_cashier_report(self, cashier, date_from, date_to):
        user_role = UserModel.CASHIER
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}
        users = UserModel.get_descendants(self.db, cashier.id, user_role)

        transfers_by_date = self.db.query(MoneyTransferModel).filter(and_(
            MoneyTransferModel.created_at > date_from,
            MoneyTransferModel.created_at < date_to
        ))
        transfers = transfers_by_date.filter(and_
                                             (or_(
                                                 MoneyTransferModel.real_from_user_id.in_(users),
                                                 MoneyTransferModel.real_to_user_id.in_(users))),
                                             MoneyTransferModel.type.in_(self.types_for_query)).all()
        for transfer in transfers:
            result = self.create_default_report(transfer, self.types)
            if not set(result.keys()) & set(children.keys()):
                children.update(result)

            if transfer.type in self.types['win']:
                report['total_winnings'] += transfer.value
                children[transfer.real_to_user_id]['total_winnings'] += transfer.value

            if transfer.type in self.types['set']:
                report['total_stake'] += transfer.value
                children[transfer.real_from_user_id]['total_stake'] += transfer.value

        report['children'] = children
        report['username'] = cashier.email_auth.email
        return report

    def get_admin_report(self, admin, date_from, date_to):
        user_role = UserModel.ADMIN
        cashiers = UserModel.get_descendants_objects(self.db, admin.id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}
        for cashier in cashiers:
            self.i += 1
            cashier_result = self.get_cashier_report(cashier, date_from, date_to)
            children[cashier.id] = cashier_result
            report['total_stake'] += cashier_result['total_stake']
            report['total_winnings'] += cashier_result['total_winnings']
            report['negative_profit'] += cashier_result['negative_profit']
            report['positive_profit'] += cashier_result['positive_profit']
            print(f'{self.i} cashier is ready')
        report['children'] = children
        report['username'] = admin.email_auth.email
        return report

    def get_super_admin_report(self, super_admin, date_from, date_to):
        user_role = UserModel.SUPER_ADMIN
        admins = UserModel.get_descendants_objects(self.db, super_admin.id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}

        for admin in admins:
            admin_result = self.get_admin_report(admin, date_from, date_to)
            children[admin.id] = admin_result
            report['total_stake'] += admin_result['total_stake']
            report['total_winnings'] += admin_result['total_winnings']
            report['negative_profit'] += admin_result['negative_profit']
            report['positive_profit'] += admin_result['positive_profit']
        report['children'] = children
        report['username'] = super_admin.email_auth.email
        return report

    def get_owner_report(self, user_id, date_from, date_to):
        owner = UserModel.get_by_id(self.db, user_id)
        user_role = UserModel.OWNER
        super_admins = UserModel.get_descendants_objects(self.db, user_id, user_role)
        report = {'total_stake': 0, 'total_winnings': 0, 'negative_profit': 0, 'positive_profit': 0}
        children = {}

        for super_admin in super_admins:
            super_admin_result = self.get_super_admin_report(super_admin, date_from, date_to)
            children[user_id] = super_admin_result
            report['total_stake'] += super_admin_result['total_stake']
            report['total_winnings'] += super_admin_result['total_winnings']
            report['negative_profit'] += super_admin_result['negative_profit']
            report['positive_profit'] += super_admin_result['positive_profit']
        report['children'] = children
        report['username'] = owner.email_auth.email
        return report
