CALCULATE_USER_REAL_TRANSFER_STATISTIC = """
SELECT t.type, t.currency, sum(t.value) as amount, count(t.id), t.from_user_id, t.to_user_id
FROM transfer as t
WHERE t.type = :transfer_type
AND t.created_at between :date_from AND :date_to
AND t.currency = :transfer_currency
GROUP BY t.type, t.currency, t.from_user_id, t.to_user_id;
"""

CALCULATE_USER_REAL_TRANSFER_STATISTIC_NULL_CURRENCY = """
SELECT t.type, t.currency, sum(t.value) as amount, count(t.id), t.from_user_id, t.to_user_id
FROM transfer as t
WHERE t.type = :transfer_type
AND t.created_at between :date_from AND :date_to
AND t.currency is :transfer_currency
GROUP BY t.type, t.currency, t.from_user_id, t.to_user_id;
"""


GET_TRANSFER_CURRENCIES = """
SELECT currency from public.transfer as t
WHERE t.type = :types
AND created_at between :start_date AND :end_date
GROUP BY currency
"""