import logging
from typing import Union, List
from datetime import datetime

from sqlalchemy import or_, and_, func, text

from betronic_core.manager import IManager
from betronic_core.owner_page_manager.copy_helper import bulk_copy
from betronic_core.db.database import DataBase
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.agent_payment_statistic import AgentPaymentStatisticModel
from betronic_core.constants import TransferTypes as TT

from .sql_queries import *
from sqlalchemy import select, delete

logger = logging.getLogger(__name__)


class AgentPaymentStatisticBotManager(IManager):

    def calculate_agent_payment_statistic(self, start_date, end_date, is_manual=False):
        self.check_already_calculated_statistic(start_date, is_manual)

        for transfer_type in TT.AGENT_PAYMENT_STATISTIC_TYPES:
            get_real_currencies = self.db.execute(
                text(GET_TRANSFER_CURRENCIES),
                {
                    "types": transfer_type,
                    "start_date": start_date,
                    "end_date": end_date,
                }
            ).mappings().fetchall()
            if transfer_type in TT.LIMITED_OWNER_PAYMENT_TYPES:
                get_real_currencies = [{"currency": None}]

            for row in get_real_currencies:
                currency = row["currency"]

                self._calculate_agent_payment_statistic_by_currency(
                    currency=currency,
                    start_date=start_date,
                    end_date=end_date,
                    transfer_type=transfer_type
                )

    def _calculate_agent_payment_statistic_by_currency(self, currency, start_date, end_date, transfer_type):
        logger.info(f'Start calculate agent payment statistic '
                    f'from {start_date} to {end_date} for transfer type {transfer_type}.')

        if currency is None:
            real_transfer_data = self.db.execute(
                text(CALCULATE_USER_REAL_TRANSFER_STATISTIC_NULL_CURRENCY),
                {
                    "date_from": start_date,
                    "date_to": end_date,
                    "transfer_type": transfer_type,
                    "transfer_currency": currency
                }
            ).mappings().fetchall()
        else:
            real_transfer_data = self.db.execute(
                text(CALCULATE_USER_REAL_TRANSFER_STATISTIC),
                {
                    "date_from": start_date,
                    "date_to": end_date,
                    "transfer_type": transfer_type,
                    "transfer_currency": currency
                }
            ).mappings().fetchall()

        real_insert_data = self._prepare_user_provider_statistic_data_to_insert(
            transfer_type=transfer_type,
            sql_data=real_transfer_data,
            created_at_time=end_date,
            currency=currency
        )

        if real_insert_data:
            self._insert_user_provider_statistic_data(real_insert_data)

    @staticmethod
    def _insert_user_provider_statistic_data(calculated_data):
        eng = DataBase.get_engine()
        bulk_copy(eng, AgentPaymentStatisticModel.__table__, calculated_data)

    @classmethod
    def _prepare_user_provider_statistic_data_to_insert(
            cls,
            sql_data,
            transfer_type: str,
            currency: str,
            created_at_time: str
    ):
        insert_data = []
        for row in sql_data:
            insert_data.append(
                {
                    "type": transfer_type,
                    "amount": row["amount"],
                    "count": row["count"],
                    "currency": currency,
                    "from_user_id": row['from_user_id'],
                    "to_user_id": row['to_user_id'],
                    "created_at": created_at_time,
                }
            )

        return insert_data

    def get_transfers_by_date_and_type_for_single_user(
            self,
            user_db: UserModel,
            admin_id: int,
            date_from: Union[datetime, str],
            date_to: Union[datetime, str],
            transfer_types: List[int],
            currency: str = None,
            skip: int = None,
            limit: int = None,
            with_username: bool = False,
            decreasing_by_id: bool = False,
            only_user_transfers: bool = False,
            only_personal_higher_transfers: bool = False,
            is_deposit: bool = False,
            is_withdrawal: bool = False,
    ):
        transfers_subq = AgentPaymentStatisticModel.get_transfers_by_date_type_currency_subq(
            db=self.db,
            date_from=date_from,
            date_to=date_to,
            transfer_types=transfer_types,
            currency=currency,
            with_username=with_username
        )
        if user_db.id != admin_id:
            query = self.db.query(transfers_subq).filter(
                or_(and_(transfers_subq.c.from_user_id == admin_id,
                         transfers_subq.c.to_user_id == user_db.id),
                    and_(transfers_subq.c.from_user_id == user_db.id,
                         transfers_subq.c.to_user_id == admin_id))
            )
            withdrawals_sum = self.db.query(func.sum(transfers_subq.c.amount)).filter(
                transfers_subq.c.from_user_id == user_db.id,
                transfers_subq.c.to_user_id == admin_id
            ).scalar()

            deposits_sum = self.db.query(func.sum(transfers_subq.c.amount)).filter(
                transfers_subq.c.from_user_id == admin_id,
                transfers_subq.c.to_user_id == user_db.id
            ).scalar()
        else:
            if only_user_transfers:
                if is_deposit:
                    filter_param = transfers_subq.c.from_user_id == admin_id
                if is_withdrawal:
                    filter_param = transfers_subq.c.to_user_id == admin_id
                if is_deposit == is_withdrawal:
                    filter_param = or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )
                query = self.db.query(transfers_subq).filter(
                    filter_param,
                    or_(
                        transfers_subq.c.from_user_id.notin_(user_db.structure_path.path.split('.')),
                        transfers_subq.c.to_user_id.notin_(user_db.structure_path.path.split('.'))
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.to_user_id == admin_id
                ).scalar()
                deposits_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.from_user_id == admin_id
                ).scalar()

            if only_personal_higher_transfers:
                if is_deposit:
                    filter_param = transfers_subq.c.to_user_id == admin_id
                if is_withdrawal:
                    filter_param = transfers_subq.c.from_user_id == admin_id
                if is_deposit == is_withdrawal:
                    filter_param = or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )

                # Вынес то что было в фильтрах from_user_id и to_user_id
                user_ids = user_db.structure_path.path.split('.')[:-1]

                # Берём айдишники лмитированного овнера и кассира. Овнера (бога) не берём, трансферы его идут с id=-1
                # Techsupport не может пополнять/списывать
                lct_ids = self.db.query(UserModel.id).filter(
                    UserModel.role.in_([UserModel.LIMITED_OWNER,
                                        UserModel.CASHIER])
                ).all()

                # Добовление адйишников лимитированного овнера, кассиров и овнера (ORGANIZATION)
                user_ids += [id[0] for id in lct_ids]
                user_ids.append(UserModel.ORGANIZATION_ID)

                query = self.db.query(transfers_subq).filter(
                    filter_param,
                    or_(
                        transfers_subq.c.from_user_id.in_(user_ids),
                        transfers_subq.c.to_user_id.in_(user_ids)
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.from_user_id == admin_id
                ).scalar()
                deposits_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.to_user_id == admin_id
                ).scalar()

            if only_user_transfers == only_personal_higher_transfers:
                query = self.db.query(transfers_subq).filter(
                    or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.type.in_(TT.WITHDRAWAL_TYPES)
                ).scalar()

                deposits_sum = self.db.query(func.sum(query_subq.c.amount)).filter(
                    query_subq.c.type.notin_(TT.WITHDRAWAL_TYPES)
                ).scalar()

        total_count = query.count()

        if decreasing_by_id:
            query = query.order_by(transfers_subq.c.id.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return (query.all(), total_count, withdrawals_sum if withdrawals_sum else 0,
                deposits_sum if deposits_sum else 0)

    def check_already_calculated_statistic(self, start_date, is_manual_mode=False):
        result = self.db.execute(
            select(1).select_from(
                AgentPaymentStatisticModel
            ).where(
                AgentPaymentStatisticModel.created_at > start_date
            )
        )
        if not is_manual_mode and result.scalars().first():
            self.db.execute(
                delete(AgentPaymentStatisticModel).where(AgentPaymentStatisticModel.created_at > start_date)
            )
            self.db.execute(
                delete(AgentPaymentStatisticModel).where(AgentPaymentStatisticModel.created_at > start_date)
            )
            self.db.commit()
