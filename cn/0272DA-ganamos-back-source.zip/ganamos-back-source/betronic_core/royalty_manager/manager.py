from logging import getLogger
from decimal import Decimal
from datetime import date, datetime
from typing import Union
from tornado.options import options

from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.manager import IManager

logger = getLogger(__name__)


class RoyaltyManager(IManager):
    def get_rev_share_by_date(
            self,
            start_date: Union[date, datetime, str],
            end_date: Union[date, datetime, str]
    ) -> Decimal:
        providers_rev_share = RoyaltyStatisticModel\
            .get_rev_share_by_date_grouped_by_partner(
                db=self.db,
                start_date=start_date,
                end_date=end_date
            )

        rev_share_by_provider = {
            provider: Decimal(rev_share)
            for rev_share, provider in providers_rev_share
        }


        provider_share_usd = Decimal(0)
        for provider, rev_share in rev_share_by_provider.items():
            if provider in options.REVENUE_STATISTICS_ALLOW_NEGATIVE_PROVIDERS:
                provider_share_usd += rev_share
            else:
                provider_share_usd += max(0, rev_share)

        return provider_share_usd

    def get_current_unplayed_rev_share(
            self,
            start_date: Union[date, datetime, str],
            end_date: Union[date, str]
    ) -> float:
        provider_share_usd = RoyaltyManager(self.db)\
            .get_rev_share_by_date(
                start_date=start_date,
                end_date=end_date
            )

        total_paid_revenue_share_usd, _ = MoneyManager(self.db)\
            .get_revenue_topups_sum(
                start_date=start_date,
                end_date=end_date
            )

        return round(float(total_paid_revenue_share_usd) - float(provider_share_usd), 2)
