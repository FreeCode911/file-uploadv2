from logging import getLogger
from typing import Optional, Union

from bsw.balance_client.models import (
    BatchChangeBalanceModel,
    ChangeBalanceModel,
    CreateSportBetModel,
    CreateSportCouponModel,
    SportBetStatusesRaw,
    SportCouponStatusesRaw,
    UpdateSportBetModel,
    UpdateSportCouponModel,
)
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.sport_games_history import (
    SportBetHistoryModel,
    SportCouponHistoryModel,
)
from betronic_core.manager import IAsyncManager
from util.date import DateTimeStrConverter

logger = getLogger(__name__)


class AsyncGamesHistoryManager(IAsyncManager):
    @classmethod
    async def process_history_data(
        cls,
        transfer: MoneyTransferModel,
        data: Union[ChangeBalanceModel, BatchChangeBalanceModel],
        connection: AsyncSession,
    ):
        if hasattr(data, "sport_coupon_data"):
            if isinstance(data.sport_coupon_data, CreateSportCouponModel):
                await cls.create_sport_coupon_data(
                    transfer, data.sport_coupon_data, connection
                )
            elif isinstance(data.sport_coupon_data, UpdateSportCouponModel):
                await cls.update_sport_coupon_data(data.sport_coupon_data, connection)

    @classmethod
    async def create_sport_coupon_data(
        cls,
        transfer: MoneyTransferModel,
        coupon_data: CreateSportCouponModel,
        connection: AsyncSession,
    ):
        if not coupon_data:
            return

        coupon_body = cls._convert_create_body_to_coupon_db_fields(
            transfer, coupon_data
        )
        coupon_for_create = SportCouponHistoryModel(**coupon_body)
        coupon = await SportCouponHistoryModel.create_coupon(
            coupon_for_create, connection
        )

        await cls.create_sport_bet_data(coupon, coupon_data.bets)

    @classmethod
    async def create_sport_bet_data(
        cls,
        local_coupon: SportCouponHistoryModel,
        bets: Optional[list[CreateSportBetModel]],
    ):
        bets_for_create = []

        for bet_dto in bets:
            bet_for_create = cls._convert_create_body_to_bet_db_fields(
                local_coupon, bet_dto
            )
            bets_for_create.append(SportBetHistoryModel(**bet_for_create))

        bets = await SportBetHistoryModel.create_bets(bets_for_create)
        return bets

    @classmethod
    async def update_sport_coupon_data(
        cls, coupon_data: UpdateSportCouponModel, connection: AsyncSession
    ):
        if not coupon_data:
            return
        if coupon_data.status in (
            SportCouponStatusesRaw.CASHED_OUT,
            SportBetStatusesRaw.LOST,
        ):
            for bet in coupon_data.bets:
                bet.status = (
                    SportBetStatusesRaw.NOT_RESULTED
                    if bet.status == SportBetStatusesRaw.ACCEPTED
                    else bet.status
                )

        coupon_body = cls._convert_update_body_to_coupon_db_fields(coupon_data)
        local_coupon = await SportCouponHistoryModel.update_fields_by_remote_coupon_id(
            coupon_data.coupon_id, coupon_body, connection
        )
        if local_coupon:
            await cls.update_sport_bet_data(
                local_coupon.id, coupon_data.bets, connection
            )

    @classmethod
    async def update_sport_bet_data(
        cls,
        local_coupon_id: int,
        bets: Optional[list[UpdateSportBetModel]],
        connection: AsyncSession,
    ):
        bets_body = cls._convert_update_body_to_bet_db_fields(local_coupon_id, bets)
        await SportBetHistoryModel.bulk_update_by_remote_bet_ids(bets_body, connection)

    @classmethod
    def _convert_update_body_to_coupon_db_fields(
        cls, coupon_data: UpdateSportCouponModel
    ) -> dict:
        return {SportCouponHistoryModel.status: coupon_data.status}

    @classmethod
    def _convert_update_body_to_bet_db_fields(
        cls, local_coupon_id: int, bets: list[UpdateSportBetModel]
    ):
        return [
            {
                "id": local_coupon_id,
                "_local_coupon_id": local_coupon_id,
                "_remote_bet_id": bet.bet_id,
                "status": bet.status,
                "score": bet.score,
            }
            for bet in bets
        ]

    @classmethod
    def _convert_create_body_to_coupon_db_fields(
        cls, transfer: MoneyTransferModel, coupon_data: CreateSportCouponModel
    ):
        return dict(
            remote_coupon_id=coupon_data.coupon_id,
            user_id=coupon_data.user_id,
            created_at=transfer.created_at,
            provider=coupon_data.provider,
            status=coupon_data.status,
            is_express=coupon_data.is_express,
            amount=coupon_data.amount,
            currency=transfer.currency,
            coef=coupon_data.coef,
            possible_win_amount=coupon_data.possible_win_amount,
            transfer_id=transfer.id,
        )

    @classmethod
    def _convert_create_body_to_bet_db_fields(
        cls, coupon: SportCouponHistoryModel, bet: CreateSportBetModel
    ):
        converter = DateTimeStrConverter()
        return dict(
            remote_bet_id=bet.bet_id,
            status=bet.status,
            score=bet.score,
            coef=bet.coef,
            is_live=bet.is_live,
            participant_1=bet.participant_1,
            participant_2=bet.participant_2,
            sport_id=bet.sport_id,
            sport_name=bet.sport_name,
            country_id=bet.country_id,
            country_name=bet.country_name,
            tournament_id=bet.tournament_id,
            tournament_name=bet.tournament_name,
            event_id=bet.event_id,
            event_name=bet.event_name,
            outcome=bet.outcome,
            bet_date=converter.convert_from_str(
                bet.bet_date, raise_exc=False, return_default=None
            ),
            local_coupon_id=coupon.id,
        )

    async def get_bets_by_coupon_id(self, coupon_id: int) -> list[SportBetHistoryModel]:
        query = select(SportBetHistoryModel).where(
            SportBetHistoryModel.local_coupon_id == coupon_id
        )
        bets_raw = await self.db.execute(query)
        return bets_raw.scalars().all()
