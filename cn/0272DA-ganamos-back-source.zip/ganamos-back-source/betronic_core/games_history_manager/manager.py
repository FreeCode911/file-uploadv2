from datetime import date
from typing import Optional, Union

from sqlalchemy.sql import Subquery

from betronic_core.db.models.sport_games_history import (
    SportBetHistoryModel,
    SportCouponHistoryModel,
)
from betronic_core.db.models.user import UserModel
from betronic_core.manager import IManager


class GamesHistoryManager(IManager):
    result_keys = {"CASHED_OUT", "ACCEPTED", "WON", "LOST", "RETURNED"}

    def fetch_coupons(
        self,
        start_date: date,
        end_date: date,
        user_id: Optional[Union[int, Subquery]] = None,
        coupon_id: Optional[int] = None,
        type: Optional[str] = None,
        status: Optional[str] = None,
        offset: Optional[int] = 0,
        limit: Optional[int] = 10,
    ) -> tuple[list[SportCouponHistoryModel], int]:

        query = self.db.query(SportCouponHistoryModel)

        if user_id is not None:
            if isinstance(user_id, int):
                query = query.filter(SportCouponHistoryModel.user_id == user_id)
            else:
                query = query.filter(SportCouponHistoryModel.user_id.in_(user_id))

            query = query.join(UserModel, SportCouponHistoryModel.user_id == UserModel.id)
            query = query.add_columns(UserModel.nickname.label('username'))

        query = query.filter(
            SportCouponHistoryModel.created_at.between(start_date, end_date),
        )

        if coupon_id:
            query = query.filter(SportCouponHistoryModel.remote_coupon_id == str(coupon_id))

        if type == "single":
            query = query.filter(SportCouponHistoryModel.is_express.is_(False))
        elif type == "express":
            query = query.filter(SportCouponHistoryModel.is_express.is_(True))

        if status and status.upper() in self.result_keys:
            query = query.filter(SportCouponHistoryModel.status == status.upper())

        total_count = query.count()

        query = query.order_by(SportCouponHistoryModel.created_at.desc())

        query = query.limit(limit).offset(offset)

        return query.all(), total_count

    def fetch_bets(self, coupon_id: int) -> list[SportBetHistoryModel]:
        query = self.db.query(SportBetHistoryModel).filter(
            SportBetHistoryModel.local_coupon_id == coupon_id
        )
        return query.all()
