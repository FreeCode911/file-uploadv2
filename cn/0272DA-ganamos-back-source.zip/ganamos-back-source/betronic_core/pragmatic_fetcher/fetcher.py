from typing import List

import requests
from tornado.options import options

from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.user import UserModel
from util.error import PragmaticError
from logging import getLogger

logger = getLogger(__name__)


class PragmaticServiceResponseStatus:
    OK = 0
    FREESPINS_OBJ_NOT_FOUND = 100
    FREESPINS_OBJ_ALREADY_ACTIVATED = 101
    PARTNER_NOT_EXIST = 1002
    REMOTE_SERVER_ERROR = 1003
    INVALID_SESSION_TOKEN = 1004


class PragmaticFetcher:
    API_URL = options.PRAGMATIC_SERVICE_URL

    @classmethod
    def _validate_response(cls, response: dict):
        status = response["status"]

        if status == PragmaticServiceResponseStatus.OK:
            return
        else:
            logger.error(f"Error response from pragmatic service: {response}")
            raise PragmaticError(status_code=status, error_message=response["error_message"])

    @classmethod
    def create_pragmatic_freespins(cls, promo_obj: PromoCodeModel):
        body = {
          "partner_name": options.PROJECT_NAME,
          "code": promo_obj.code,
          "spins_count": promo_obj.amount,
          "available_to": str(promo_obj.available_to),
          "currencies": [
            {
              "currency": currency,
              "default_bet": options.DEFAULT_BET_VALUE_FOR_FREESPINS[currency]
            }
              for currency in options.AVAILABLE_CURRENCIES
          ]
        }

        session = requests.Session()
        headers = {"Authorization": f"Bearer {options.PRAGMATIC_BEARER_TOKEN}"}
        raw_response = session.post(
            url=cls.API_URL + "/freespins",
            json=body,
            headers=headers

        )
        response = raw_response.json()
        cls._validate_response(response)
        return response



    @classmethod
    def patch_update_pragmatic_freespins(cls, promo_obj: PromoCodeModel, user: UserModel = None) -> List[dict]:
        body = {
          "partner_name": options.PROJECT_NAME,
          "spins_count": promo_obj.amount,
          "available_to": str(promo_obj.available_to)
        }
        freespins_ids = []
        result = []
        if user:
            body["project_uid"] = user.id
            freespins_ids.append(promo_obj.additional_data['remote_id'][user.currency])
        else:

            freespins_ids = [promo_obj.additional_data['remote_id'][currency]
                             for currency in options.AVAILABLE_CURRENCIES]

        session = requests.Session()

        for freespins_id in freespins_ids:
            headers = {"Authorization": f"Bearer {options.PRAGMATIC_BEARER_TOKEN}"}
            raw_response = session.patch(
                url=cls.API_URL + f"/freespins/{freespins_id}",
                json=body,
                headers=headers
            )
            response = raw_response.json()
            cls._validate_response(response)
            result.append(response)

        return result

    @classmethod
    def cancel_pragmatic_freespins(cls, promo_obj: PromoCodeModel):
        result = []
        freespins_ids = [promo_obj.additional_data['remote_id'][currency] for currency in options.AVAILABLE_CURRENCIES]

        session = requests.Session()
        headers = {"Authorization": f"Bearer {options.PRAGMATIC_BEARER_TOKEN}"}

        for freespins_id in freespins_ids:
            raw_response = session.delete(url=cls.API_URL + f"/freespins/{freespins_id}", headers=headers)
            response = raw_response.json()
            cls._validate_response(response)
            result.append(response)

        return result

