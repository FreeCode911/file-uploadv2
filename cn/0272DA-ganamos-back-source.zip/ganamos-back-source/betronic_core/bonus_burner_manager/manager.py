import datetime
from typing import List
from logging import getLogger

from betronic_core.db.models.user import UserModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.bonus_balance_burn import BonusBalanceBurnModel
from betronic_core.manager import IManager


logger = getLogger(__name__)


class BonusBurnerManager(IManager):

    def create_bonus_burn_date(
            self,
            user: UserModel,
            bonus_transfer: BonusTransferModel,
            expire_at: datetime.datetime
    ) -> BonusBalanceBurnModel:
        bonus_burn_model = BonusBalanceBurnModel(
            user_id=user.id,
            bonus_transfer_id=bonus_transfer.id,
            expire_at=expire_at
        )

        self.db.add(bonus_burn_model)

        return bonus_burn_model

    def get_active_bonus_burns(self) -> List[BonusBalanceBurnModel]:
        query = self.db.query(BonusBalanceBurnModel).filter(
            BonusBalanceBurnModel.is_active == True
        )

        return query.all()
