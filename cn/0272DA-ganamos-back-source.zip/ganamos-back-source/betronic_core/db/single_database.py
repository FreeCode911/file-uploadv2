from sqlalchemy import event
from sqlalchemy.orm import scoped_session, sessionmaker, mapper
from tornado.options import options

from .get_engine import get_single_connection_engine
from .models.base import setup_schema


class SingleConnectionDataBase:
    _engine = None

    @classmethod
    def get_engine(cls, database_config_data: dict = options.DATABASE):
        if not cls._engine:
            cls._engine = get_single_connection_engine(database_config_data)
        return cls._engine

    @classmethod
    def get(cls, database_config_data: dict = options.DATABASE):
        """
        Рекомендуется использовать только в ботах. Возможность передачи параметра дана, чтобы выбирать разные конфиги.
        Использовать класс точно так же как и простой Database singleton: то есть в контексте одного приложения один и
        тот же database_config_data.
        """
        engine = cls.get_engine(database_config_data)
        return scoped_session(sessionmaker(bind=engine))

    @classmethod
    def setup(cls, session):
        event.listen(mapper, 'after_configured', setup_schema(session))
