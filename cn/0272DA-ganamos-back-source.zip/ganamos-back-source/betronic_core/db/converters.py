import calendar
from datetime import datetime

from betronic_core.db.models.user import UserModel
from betronic_core.cache_manager.manager import CacheManager

DATETIME_FORMAT = "%Y-%m-%d %H-%M-%S"


def datetime_to_timestamp(date):
    if date is None:
        return None
    return calendar.timegm(date.timetuple())


def datetime_to_js_timestamp(dt):
    ts = datetime_to_timestamp(dt)
    if not ts:
        return None
    return int(ts * 1000)


def timestamp_to_datetime(timestamp):
    if timestamp is None:
        return None
    return datetime.utcfromtimestamp(timestamp)


def user_to_dict(user: UserModel):
    return {
        "id": user.id,
        'username': user.nickname,
        'email': user.email_auth.email,
        'currency': user.currency,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'role': user.role,
        'is_partner': user.is_partner,
        'parent_agent_id': user.parent_agent_id,
        'type_partner_payment': int(user.type_partner_payment) if
        user.type_partner_payment else 0,
        'cookie_salt': CacheManager.get_user_cookie_salt(user.id),
        'is_withdrawal_access': user.is_withdrawal_access,
        'is_deposit_access': user.is_deposit_access,
        'changed_password': user.changed_password
    }
