from sqlalchemy.orm import scoped_session, sessionmaker, mapper
from sqlalchemy import event
from .models.base import setup_schema
from .get_engine import get_engine
from .get_engine import get_settings


class DataBase(object):

    _engine = None
    _engine_couch = None
    _settings = None

    @classmethod
    def get_engine(cls):
        if not cls._engine:
            cls._engine = get_engine()
        return cls._engine

    @classmethod
    def get(cls):
        engine = cls.get_engine()
        return scoped_session(sessionmaker(bind=engine))

    @classmethod
    def get_settings(cls):
        if not cls._settings:
            cls._settings = get_settings()
        return cls._settings

    @classmethod
    def setup(cls, session):
        event.listen(mapper, 'after_configured', setup_schema(session))
