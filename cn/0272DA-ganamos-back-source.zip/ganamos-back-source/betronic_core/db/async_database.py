import os
import pwd
import socket
import sys
from contextvars import ContextVar, Token
from typing import Union
from uuid import uuid4

from asyncpg.connection import Connection
from sqlalchemy.ext.asyncio import (
    AsyncSession,
    create_async_engine,
    async_scoped_session,
)
from sqlalchemy.orm import sessionmaker
from tornado.options import options

session_context: ContextVar[str] = ContextVar("session_context")


def get_application_name():
    prog = os.path.basename(sys.argv[0]) or 'unnamed_job'
    username = pwd.getpwuid(os.getuid()).pw_name
    hostname = socket.gethostname().split(".")[0]
    return "%s:%s@%s" % (prog, username, hostname)


class DatabaseConnectionClass(Connection):
    def _get_unique_id(self, prefix: str) -> str:
        return f'__asyncpg_{prefix}_{uuid4()}__'


def get_session_context() -> str:
    return session_context.get()


def set_session_context(session_id: str) -> Token:
    return session_context.set(session_id)


def reset_session_context(context: Token) -> None:
    session_context.reset(context)


engine = create_async_engine(
    options.DATABASE_CONNECTION_URL, pool_recycle=3600,
    pool_size=options.DATABASE_MIN_POOL_SIZE, max_overflow=options.DATABASE_MAX_POOL_SIZE,
    echo=True if os.environ.get('db_echo') is not None else False,
    connect_args={
        "statement_cache_size": 0,
        "prepared_statement_cache_size": 0,
        # "connection_class": DatabaseConnectionClass,
        "server_settings": {"application_name": get_application_name()},

    },
)

async_session_factory = sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)
session: Union[AsyncSession, async_scoped_session] = async_scoped_session(
    session_factory=async_session_factory,
    scopefunc=get_session_context
)


async def init_async_db_pool_alchemy():
    return session
