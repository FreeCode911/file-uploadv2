first_deposit_bonus_settings = dict(
    bonus_is_active=False,
    bonus_system_cashback_percent=1,
    max_first_deposit_bonus={
        "ARS": 50_000,
        "USD": 100
    },
    days_to_use_the_bonus_balance=14,
    total_bets_percent_multiplier=20
)
