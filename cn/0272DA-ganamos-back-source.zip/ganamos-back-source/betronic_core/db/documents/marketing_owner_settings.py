marketing_owner_settings = {
    "marketing_alert_state": True,
    "revenue_alert_state": True,
    "marketing_balance_alerting": 30000,
    "revenue_balance_alerting": 3000,
    "revenue_balance_super_alerting": 1000,
    "revenue_balance_super_alerting_seconds_expire": 1800,
    "access_deposit_by_role": {
        "4": {
            "name": "LIMITED_OWNER",
            "is_enable": True,
            "exclude_ids": []
        },
        "5": {
            "name": "OWNER",
            "is_enable": True,
            "exclude_ids": []
        },
    }
}
