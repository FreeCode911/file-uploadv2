max_user_creating_count_limit = {
    "major": {
        "hours": 24,
        "limit": 1500
    },
    "minor": {
        "minutes": 1,
        "limit": 10
    }
}
