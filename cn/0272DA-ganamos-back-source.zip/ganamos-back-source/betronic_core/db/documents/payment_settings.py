from tornado.options import options

payment_settings = dict(
    min_withdrawal=options.MIN_WITHDRAWAL,
    min_payment=options.MIN_PAYMENT,
    max_withdrawal=options.MAX_WITHDRAWAL
)
