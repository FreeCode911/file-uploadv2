deposit_level_settings = {
    "bronze": {
        "from": 100,
        "to": 140,
    },
    "silver": {
        "from": 141,
        "to": 700,
    },
    "gold": {
        "from": 701,
        "to": 1390,
    },
    "black": {
        "from": 1391,
        "to": 1000000000,
    },
}