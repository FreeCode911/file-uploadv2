feed_settings = {
    "line1x_enabled": True
}
