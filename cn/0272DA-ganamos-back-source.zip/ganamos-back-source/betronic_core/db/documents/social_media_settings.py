social_media_settings = {
    "agent": {
        "telegram": ""
    },
    "player": {

    }
}
