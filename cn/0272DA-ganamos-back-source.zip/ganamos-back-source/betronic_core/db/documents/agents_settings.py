agents_settings = dict(
    deposit_withdrawal_allowed_agent_ids=[312]
)
