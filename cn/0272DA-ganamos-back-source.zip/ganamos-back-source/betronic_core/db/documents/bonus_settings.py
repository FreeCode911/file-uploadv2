bonus_settings = dict(
    cashback_payment=0.05,
    cashback_bet=0.05,
    min_coef=1.7,
    max_bonus_percent=0.2,
    max_bet_count=50,
    registration_bonus=5,
    registration_bonus_currency='USD',
    max_bonus_size=5,
    first_deposit_bonus_cashback=0.2
)
