from typing import List, Optional
from sqlalchemy_utils import LtreeType, Ltree
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, and_
from sqlalchemy.orm import Session
from sqlalchemy.orm.exc import NoResultFound
from .base import BaseModel


class Host(BaseModel):
    __tablename__ = "host"
    id = Column(Integer, autoincrement=True, primary_key=True)
    domain = Column(String(50), unique=True)

    @classmethod
    def get_all(cls, db: Session):
        return db.query(cls.id, cls.domain).all()

    @classmethod
    def get_by_domain(cls, db: Session, domain: str):
        try:
            return db.query(cls).filter_by(domain=domain).one()
        except NoResultFound:
            return None


class UserHostPermission(BaseModel):
    __tablename__ = "user_host_permission"
    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    host_id = Column(Integer, ForeignKey("host.id"), nullable=True, index=True)
    can_visit = Column(Boolean, nullable=False)

    @classmethod
    def create_from_parent(cls, parent_permission: "UserHostPermission"):
        instance = cls(
            host_id=parent_permission.host_id,
            can_visit=parent_permission.can_visit
        )

        return instance

    @classmethod
    def is_can_visit(cls, db: Session, user_id: int, host_id: int):
        try:
            permission = db.query(cls).filter_by(user_id=user_id, host_id=host_id).one()
            return permission.can_visit
        except NoResultFound:
            return True

    @classmethod
    def get(cls, db: Session, user_id: int, host_id: int):
        try:
            return db.query(cls).filter_by(user_id=user_id, host_id=host_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_use_id(cls, db: Session, user_id: int):
        try:
            return db.query(cls).filter_by(user_id=user_id).all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_users_list(cls, db: Session, user_ids: List[int], host_id: Optional[int] = None):
        query = db.query(cls)
        if host_id:
            query = query.filter(cls.host_id == host_id)

        return query.filter(cls.user_id.in_(user_ids)).all()

    @classmethod
    def create(cls, db: Session, user_id: int, host_id: int, can_visit: bool, commit=True):
        permission = cls(
            user_id=user_id,
            host_id=host_id,
            can_visit=can_visit,
        )
        db.add(permission)
        if commit:
            db.commit()
        return permission
