import base64
import datetime
import uuid
from hashlib import sha512
from typing import List
from uuid import uuid4

from sqlalchemy import Column, String, ForeignKey, DateTime
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.user_manager import error_codes
from util.error import InvalidRequestData
from util.validators import is_password_valid
from util.redis import SyncRedisWrapperLocal, RedisBaseTypes
from uuid import uuid4
from .base import BaseModel

KEY_EXPIRY_DAYS = 3


class EmailAuthModel(BaseModel):
    __tablename__ = "email_auth"

    SALT = "4#g0Y/Qvd)Cy?p"

    email = Column(String(256), primary_key=True)
    password_hash = Column(String(128))
    user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    user: Mapped['UserModel'] = relationship(
        "UserModel", back_populates="email_auth", foreign_keys=[user_id])

    verification_key = Column(String(64))
    verification_expiry = Column(DateTime)

    @classmethod
    def get_by_email(cls, db, email) -> 'EmailAuthModel':
        try:
            return db.query(cls).filter_by(email=email).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_email_with_lock(cls, db, email) -> 'EmailAuthModel':
        try:
            return db.query(cls).with_for_update().filter_by(email=email).one()
        except NoResultFound:
            return None


    @classmethod
    def get_by_emails(cls, db, emails: list) -> List['EmailAuthModel']:
        return db.query(cls).filter(cls.email.in_(emails)).all()

    @classmethod
    def get_by_user_id(cls, db, user_id):
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except NoResultFound:
            return None

    @classmethod
    def generate_verification_key(cls):
        return uuid.uuid4().hex

    def _get_password_hash(self, password):
        hasher = sha512()
        hasher.update((password + self.SALT + self.email).encode('utf-8'))
        return hasher.hexdigest()

    def set_password(self, password: str, is_user: bool = False):
        if is_password_valid(password, is_user):
            self.password_hash = self._get_password_hash(password)
            SyncRedisWrapperLocal(RedisBaseTypes.COOKIE_SALTS)\
                .set(key=f"cookie_salt_{self.user_id}",
                     value=uuid.uuid4().hex[:16])
        else:
            raise InvalidRequestData(
                error_codes.TOO_EASY_PASSWORD,
                "Password not verified"
            )

    def has_password(self, password: str) -> bool:
        return self.password_hash == self._get_password_hash(password)

    @classmethod
    def get_by_email_password(cls, db, email, password) -> 'EmailAuthModel':
        email_auth = cls.get_by_email(db, email)
        if not email_auth or not email_auth.has_password(password):
            raise Exception("Not password or user")
        return email_auth

    @property
    def is_verified(self):
        return not self.verification_key

    def clear_verification_key(self):
        self.verification_key = None

    def is_verification_key_expired(self):
        if not self.verification_expiry:
            return True
        return self.verification_expiry < datetime.datetime.utcnow()

    def is_verification_key_valid(self, key):
        return self.verification_key and self.verification_key == key

    def set_verification_key(self):
        self.verification_key = EmailAuthModel.generate_verification_key()
        self.verification_expiry = datetime.datetime.utcnow(
        ) + datetime.timedelta(days=KEY_EXPIRY_DAYS)

    @staticmethod
    def decode_verification_key(code):
        s = base64.b64decode(code).decode('utf-8')
        parts = s.rsplit('_', 1)
        return parts[0], parts[1]  # email, key

    @staticmethod
    def _encode_verification_key(email, key):
        s = '%s_%s' % (email, key)
        return base64.b64encode(s.encode('utf-8')).decode("utf-8")

    def get_encoded_verification_key(self):
        return self._encode_verification_key(self.email, self.verification_key)

    @classmethod
    def get_by_phone(cls, db, phone):
        try:
            return db.query(cls).filter(cls.email == phone).first()
        except NoResultFound:
            return None

    @classmethod
    def get_by_user_ids(cls, db, ids: list):
        query = db.query(cls).filter(cls.user_id.in_(ids))
        return query.all()
