from sqlalchemy import (
    Column,
    ForeignKey,
    Boolean,
    ARRAY,
    String,
    Integer,
    insert,
    update,
)
from sqlalchemy.orm import Session
from sqlalchemy.sql import expression, bindparam

from betronic_core.db.models.base import BaseModel
from sqlalchemy.orm.exc import NoResultFound

class PermissionDetailsModel(BaseModel):

    __tablename__ = 'permission_details'

    user_id = Column(ForeignKey("user.id"), nullable=False, primary_key=True)
    providers = Column(ARRAY(String, dimensions=1), default=[])

    categories = Column(ARRAY(String, dimensions=1), default=[])
    is_full_branch = Column(Boolean, default=False, server_default=expression.false())

    @classmethod
    def get_by_id(cls, db: Session, _id: int) -> 'BaseModel':
        try:
            return db.query(cls).filter_by(user_id =_id).one()
        except NoResultFound:
            return None
        
    @classmethod
    def get_by_user_ids(cls, db: Session, ids: list[int]) -> list:
        return db.query(cls).filter(
                cls.user_id.in_(ids)
        ).all()

    @classmethod
    def batch_insert(cls, db: Session, data: list[dict]):
        insert_query = (
            insert(cls)
            .values(
                data
            )
        )
        db.connection().execute(insert_query)

    @classmethod
    def batch_update(cls, db: Session, data: list[dict]):
        """
        Used to batch update model,
        scheme of dicts should be same!
        """
        insert_query = (
            update(cls)
            .where(
                cls.user_id == bindparam("id")
            )
            .values(
                {
                    getattr(cls, item): bindparam(item)
                    for item in data[0] if item not in ["id", "user_id"]
                }
            )
        )            
        db.connection().execute(insert_query, data)


class ProviderModel(BaseModel):
    __tablename__ = "providers"
    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String(60))
    is_active = Column(Boolean, default=True, nullable=True)