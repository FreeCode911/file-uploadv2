from sqlalchemy import Column, Integer, ForeignKey, \
    SmallInteger, Numeric
from sqlalchemy.orm import relationship

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.money_horse.bet import MoneyHorseBetModel
from betronic_core.db.models.money_horse.horse import MoneyHorseHorseModel


class MoneyHorseParticipantModel(BaseModel):
    __tablename__ = "moneyhorse_participants"

    id = Column(Integer, autoincrement=True, primary_key=True)
    race_id = Column(ForeignKey("moneyhorse_races.id"))
    horse_id = Column(ForeignKey("moneyhorse_horses.id"))
    horse = relationship(MoneyHorseHorseModel)
    number = Column(SmallInteger)
    coeff = Column(Numeric(6, 3, asdecimal=False))
    place = Column(SmallInteger)
    bets = relationship(MoneyHorseBetModel)

    def get_bet_count(self):
        return len(self.bets)

    def has_bets(self):
        return self.get_bet_count() != 0
