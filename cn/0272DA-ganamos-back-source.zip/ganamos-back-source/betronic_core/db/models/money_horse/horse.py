from random import choice, shuffle

from sqlalchemy import Column, Integer, SmallInteger, \
    String

from betronic_core.db.models.base import BaseModel


class MoneyHorseHorseModel(BaseModel):
    __tablename__ = "moneyhorse_horses"

    id = Column(Integer, autoincrement=True, primary_key=True)
    family = Column(SmallInteger)
    language = Column(String(2))  # ISO 639-1
    name = Column(String(30))

    @classmethod
    def _get_families(cls, db, language):
        families = {}
        for horse in db.query(cls).filter_by(language=language).all():
            family = horse.family
            if family not in families:
                families[family] = []
            families[family].append(horse)
        return list(families.values())

    @classmethod
    def get_random(cls, db, language, count):
        horses = map(choice, cls._get_families(db, language))[:count]
        shuffle(horses)
        return horses
