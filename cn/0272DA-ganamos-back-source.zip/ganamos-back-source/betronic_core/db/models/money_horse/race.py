from sqlalchemy import Column, Integer, ForeignKey, \
    DateTime, SmallInteger, desc, Sequence
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.money_horse.participant import \
    MoneyHorseParticipantModel


class MoneyHorseRaceModel(BaseModel):
    __tablename__ = "moneyhorse_races"

    GAME_MODE_FREE = 0
    GAME_MODE_MONEY = 1

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("users.id"))
    mode = Column(SmallInteger)
    created_at = Column(DateTime)
    participants = relationship(MoneyHorseParticipantModel)

    @classmethod
    def get_last_by_user_id_and_mode(cls, db, user_id, mode):
        return db.query(cls).filter_by(
            user_id=user_id, mode=mode).order_by(desc(cls.created_at)).first()

    @staticmethod
    def get_next_id(db):
        return db.execute(Sequence('moneyhorse_races_id_seq'))

    @classmethod
    def get_by_id(cls, db, race_id):
        try:
            return db.query(cls).filter_by(id=race_id).one()
        except NoResultFound:
            return None

    def _get_bet_count(self):
        return sum(participant.get_bet_count()
                   for participant in self.participants)

    def has_bets(self):
        return self._get_bet_count() != 0

    def get_participant_by_id(self, participant_id):
        for participant in self.participants:
            if participant.horse.id == participant_id:
                return participant

    def get_payout_amount(self):
        for p in self.participants:
            for bet in p.bets:
                if bet.prize:
                    return bet.prize
        return 0

    @classmethod
    def get_history(cls, db, user_id, race_id=None, get_last=False):
        query = db.query(cls).filter(
            cls.user_id == user_id, cls.mode == cls.GAME_MODE_MONEY,
            MoneyHorseParticipantModel.bets.any()).join(
                MoneyHorseParticipantModel).order_by(cls.created_at.desc())
        if race_id:
            try:
                return [query.filter(cls.id == race_id).one()]
            except NoResultFound:
                return []
        result = [query.first()] if get_last else query.all()
        return [] if None in result else result
