from sqlalchemy import Column, Integer, ForeignKey, \
    DateTime, Table, Numeric, func
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.money_transfer import MoneyTransferModel

Base = declarative_base()

moneyhorse_bet_transfers = Table(
    "moneyhorse_bet_transfers",
    BaseModel.metadata,
    Column("bet_id", Integer, ForeignKey("moneyhorse_bets.id")),
    Column("transfer_id", Integer, ForeignKey("transfers.id")), )


class MoneyHorseBetModel(BaseModel):
    __tablename__ = "moneyhorse_bets"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("users.id"))
    participant_id = Column(ForeignKey("moneyhorse_participants.id"))
    value = Column(Numeric(10, 2, asdecimal=False))
    prize = Column(Numeric(10, 2, asdecimal=False))
    created_at = Column(DateTime)
    transfers = relationship(
        MoneyTransferModel,
        backref="moneyhorse_bets",
        secondary=moneyhorse_bet_transfers)

    @classmethod
    def get_user_bet_balance(cls, db, user_id, begin, end):
        income = db.query(func.sum(cls.value)).filter_by(
            user_id=user_id).filter(
                cls.created_at > begin, cls.created_at < end,
                cls.participant_id != None).join(cls.transfers).scalar() or 0
        outcome = db.query(func.sum(cls.prize)).filter_by(
            user_id=user_id).filter(
                cls.created_at > begin, cls.created_at < end,
                cls.participant_id != None).join(cls.transfers).scalar() or 0
        return income - outcome
