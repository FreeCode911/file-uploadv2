from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Text, SmallInteger
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import relationship, backref
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound
from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from datetime import datetime
from sqlalchemy.sql import and_
from sqlalchemy import Date, cast, desc
from datetime import date
from sqlalchemy import func
from logging import getLogger

logger = getLogger(__name__)


class ForecastModel(BaseModel):

    __tablename__ = "forecast"

    TYPE_SINGLE = 1
    TYPE_EXPRESS = 2
    TYPE_SYSTEM = 3

    TYPES = {
        TYPE_SINGLE: "single",
        TYPE_EXPRESS: "express",
        TYPE_SYSTEM: "system"
    }

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("users.id"))
    created = Column(DateTime, default=datetime.utcnow)
    early_begin = Column(DateTime, default=datetime.utcnow)
    user = relationship(
        UserModel,
        backref=backref("forecast"),
        uselist=False,
        foreign_keys=[user_id])
    type = Column(SmallInteger)
    kf = Column(Float)
    comment = Column(Text)
    betslipJSON = Column(Text)
    received = Column(Integer, default=0)

    @classmethod
    def get_all(cls, db):
        return db.query(cls).all()

    @classmethod
    def get_all_by_sort(cls, db, sortfield):
        return db.query(cls).order_by(sortfield).all()

    @classmethod
    def get_range(cls, db, from_forecast, to_forecast):
        return db.query(cls, func.count(cls.user_id)).filter(
            and_(cls.id >= from_forecast, cls.id <= to_forecast)).all()

    @classmethod
    def get_range_by_sort(cls, db, from_forecast, to_forecast, sortfield,
                          own_forecasts_only, user_id):
        now = datetime.now()
        try:
            query = db.query(cls).join(UserModel.forecast).order_by(sortfield)\
                .filter(and_(UserModel.nickname != '',UserModel.nickname.isnot(None),\
                    cls.early_begin > now))\
                .limit(to_forecast-from_forecast).offset(from_forecast)

            if own_forecasts_only:
                query = db.query(cls).join(UserModel.forecast).order_by(sortfield)\
                .filter(and_(UserModel.nickname != '', UserModel.nickname.isnot(None),\
                    cls.early_begin > now, cls.user_id == user_id))\
                .limit(to_forecast-from_forecast).offset(from_forecast)

            return query.all()
        except Exception as e:
            logger.error('Forecast Model Get Range By Sort Error: %s', e)

    @classmethod
    def get_by_id(cls, db, forecast_id):
        now = datetime.now()
        try:
            return db.query(cls).filter(cls.id == forecast_id).\
                filter(and_(UserModel.nickname != '',UserModel.nickname.isnot(None),\
                cls.early_begin > now)).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def delete_by_id(cls, db, forecast_id):
        try:
            db.query(ForecastEventModel).filter(
                ForecastEventModel.forecast_id == forecast_id).delete()
            return db.query(cls).filter(cls.id == forecast_id).delete()
        except Exception as e:
            logger.error("Forecast delete by id error: %s", e)

    @classmethod
    def get_user_forecast_count(cls, db, user_id):
        try:
            return db.query(cls).filter(cls.user_id == user_id).count()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user(cls, db, user_id):
        try:
            b = db.query(
                cls.user_id.label('cnt_user_id'),
                func.count(cls.user_id).label('cnt')).group_by(
                    cls.user_id).subquery()
            return db.query(cls, b.c.cnt).outerjoin(
                b, b.c.cnt_user_id == cls.user_id).filter(
                    cls.user_id == user_id).order_by(cls.created.desc()).all()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_count_today(cls, db):
        try:
            return db.query(cls).filter(
                cast(cls.created, Date) == date.today()).count()
        except (NoResultFound, MultipleResultsFound):
            return None


class ForecastEventModel(BaseModel):

    __tablename__ = "forecast_event"

    id = Column(Integer, autoincrement=True, primary_key=True)
    forecast_id = Column(ForeignKey("forecast.id"))
    forecast = relationship(
        "ForecastModel",
        backref=backref("forecast_event"),
        uselist=False,
        foreign_keys=[forecast_id])
    sport = Column(Integer)
    title = Column(String(300))
    team_1 = Column(String(100))
    team_2 = Column(String(100))
    start_date = Column(DateTime)
    result = Column(String(100))
    kf = Column(Float)
    eid = Column(Integer)
    bid = Column(Integer)

    @classmethod
    def get_all(cls, db):
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id):
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_forecast(cls, db, forecast_id):
        try:
            return db.query(cls).filter_by(forecast_id=forecast_id).all()
        except (NoResultFound, MultipleResultsFound):
            return None


class ForecastBetModel(BaseModel):

    __tablename__ = "forecast_bet"

    id = Column(Integer, autoincrement=True, primary_key=True)
    created = Column(DateTime, default=datetime.utcnow)
    user_id = Column(ForeignKey("users.id"))
    user = relationship(
        "UserModel",
        backref=backref("forecast_bet"),
        uselist=False,
        foreign_keys=[user_id])
    forecast_id = Column(ForeignKey("forecast.id"))
    forecast = relationship(
        "ForecastModel",
        backref=backref("forecast_bet"),
        uselist=False,
        foreign_keys=[forecast_id])

    @classmethod
    def get_all(cls, db):
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id):
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_forecast(cls, db, forecast_id):
        try:
            return db.query(cls).filter_by(forecast_id=forecast_id).all()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def exist_user_forecast(cls, db, user_id, forecast_id):
        try:
            qr = db.query(cls).filter(
                and_(cls.forecast_id == forecast_id, cls.user_id ==
                     user_id)).all()
        except (NoResultFound, MultipleResultsFound):
            return False
        if qr:
            return True
        else:
            return False

    @classmethod
    def get_count_received(cls, db, forecast_id):
        try:
            return db.query(cls).filter_by(forecast_id=forecast_id).count()
        except (NoResultFound, MultipleResultsFound):
            return 0
