from datetime import datetime
from decimal import Decimal
from betronic_core.db.models.odd import OddModel
from betronic_core.db.models.types import FORECAST_EVENT
from sqlalchemy import and_, not_


class EventWillOccurOddModel(OddModel):
    __mapper_args__ = {
        'polymorphic_identity': FORECAST_EVENT.ODDS.EVENT_WILL_OCCUR.id
    }

    def __init__(self, event_id, title):
        super(EventWillOccurOddModel, self).__init__(
            FORECAST_EVENT.ODDS.EVENT_WILL_OCCUR, event_id, title, float(0))

    @classmethod
    def get_betting_available_odds(cls, db, group_id, ids):
        from betronic_core.db.models.forecasts.event import ForecastEventModel
        from betronic_core.db.models.forecasts.event_group import ForecastEventGroupModel
        return db.query(cls)\
            .join(ForecastEventModel, and_(ForecastEventModel.id == cls.event_id,
                                           ForecastEventModel.start_date > datetime.utcnow()))\
            .join(ForecastEventGroupModel, and_(ForecastEventGroupModel.id == ForecastEventModel.event_group_id,
                                                ForecastEventGroupModel.id == group_id))\
            .filter(OddModel.id.in_(ids), not_(OddModel.is_calculated), not_(OddModel.is_blocked)).all()

    @classmethod
    def from_dict(cls, dct):
        model = cls(dct.get('event_id'), dct.get('title'))
        return super(EventWillOccurOddModel, cls)._from_dict(model, dct)
