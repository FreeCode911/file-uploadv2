from betronic_core.db.models.event_group import EventGroupModel
from betronic_core.db.models.forecasts.event import ForecastEventModel
from betronic_core.db.models.odd import OddModel
from betronic_core.db.models.types import FORECAST_EVENT
from sqlalchemy import desc, String
from sqlalchemy.ext.hybrid import hybrid_property


class ForecastEventGroupModel(EventGroupModel):
    __mapper_args__ = {'polymorphic_identity': FORECAST_EVENT.id}

    def __init__(self, *args, **kwargs):
        super(ForecastEventGroupModel, self).__init__(*args, **kwargs)
        self.type = FORECAST_EVENT.id
        self.forecast_type = kwargs.get('forecast_type')

    def add_event(self, title=None, start_date=None, **kwargs):
        if None in (title, start_date):
            raise ValueError()
        event = ForecastEventModel(title)
        event.start_date = start_date
        return super(ForecastEventGroupModel, self)._add_event(event)

    @classmethod
    def get_all(cls,
                db,
                exclude_passed_events=False,
                exclude_empty=False,
                forecast_type=None,
                **kwargs):
        import logging
        logging.error(forecast_type)
        query = cls._get_by_type(db, exclude_passed_events, exclude_empty)\
            .order_by(ForecastEventModel.id).order_by(OddModel.id)
        if forecast_type:
            query = query.filter(cls.forecast_type == forecast_type)
        return query.all()[:20]  #count event group

    @classmethod
    def from_dict(cls, dct):
        model = super(ForecastEventGroupModel, cls).from_dict(dct)
        model.events = [
            ForecastEventModel.from_dict(event)
            for event in dct.get('events', [])
        ]
        model.previous_group_id = dct.get('previous_group_id')
        model.forecast_type = dct.get('forecast_type')
        return model

    def to_dict(self):
        dct = super(ForecastEventGroupModel, self).to_dict()
        dct['previous_group_id'] = self.previous_group_id
        dct['forecast_type'] = self.forecast_type
        return dct

    @hybrid_property
    def previous_group_id(self):
        return self._details.get('previous_group_id')

    @previous_group_id.setter
    def previous_group_id(self, value):
        self._details['previous_group_id'] = value

    @hybrid_property
    def forecast_type(self):
        return self._details.get('forecast_type')

    @forecast_type.setter
    def forecast_type(self, value):
        self._details['forecast_type'] = value

    @forecast_type.expression
    def forecast_type(cls):
        return cls._details['forecast_type'].cast(String)

    def update(self, db, previous_group_id=None, forecast_type=None, **kwargs):
        self.previous_group_id = previous_group_id
        self.forecast_type = forecast_type
        super(ForecastEventGroupModel, self).update(db, **kwargs)
