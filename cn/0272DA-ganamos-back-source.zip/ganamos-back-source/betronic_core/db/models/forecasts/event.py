from betronic_core.db.models.event import EventModel
from betronic_core.db.models.forecasts.odds import EventWillOccurOddModel
from betronic_core.db.models.types import FORECAST_EVENT


class ForecastEventModel(EventModel):
    __mapper_args__ = {'polymorphic_identity': FORECAST_EVENT.id}

    def __init__(self, title):
        super(ForecastEventModel, self).__init__(FORECAST_EVENT, title)

    def add_odds_by_type(self, type, *args, **kwargs):
        if type == FORECAST_EVENT.ODDS.EVENT_WILL_OCCUR.id:
            return self.add_event_will_occur_odd(*args, **kwargs)

    def add_event_will_occur_odd(self, title=None, **kwargs):
        if None in (title, ):
            raise ValueError()
        odd = EventWillOccurOddModel(self.id, title)
        self.odds.append(odd)
        return odd

    @classmethod
    def from_dict(cls, dct):
        model = super(ForecastEventModel, cls).from_dict(dct)
        model.odds = [
            EventWillOccurOddModel.from_dict(odd)
            for odd in dct.get('odds', [])
        ]
        return model

    def to_dict(self):
        dct = super(ForecastEventModel, self).to_dict()
        return dct
