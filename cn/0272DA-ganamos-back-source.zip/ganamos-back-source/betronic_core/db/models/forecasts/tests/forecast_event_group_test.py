from unittest import TestCase
from datetime import datetime, timedelta
from betronic_core.db.database import DataBase
from betronic_core.db.models.forecasts.event_group import ForecastEventGroupModel


class ModelsCreator(object):

    models = None

    @classmethod
    def create_models(cls, db):
        if cls.models is not None:
            return cls.models
        group1 = ForecastEventGroupModel(title='group1')

        event11 = group1.add_event(
            title='event11',
            start_date=datetime.utcnow() + timedelta(minutes=5))
        odd111 = event11.add_event_will_occur_odd('odd111')
        odd112 = event11.add_event_will_occur_odd('odd112')

        event12 = group1.add_event(
            title='event12',
            start_date=datetime.utcnow() - timedelta(minutes=1))
        odd121 = event12.add_event_will_occur_odd('odd121')

        event13 = group1.add_event(
            title='event13',
            start_date=datetime.utcnow() + timedelta(minutes=1))
        odd131 = event13.add_event_will_occur_odd('odd131')

        event14 = group1.add_event(
            title='event14',
            start_date=datetime.utcnow() + timedelta(minutes=3))

        group2 = ForecastEventGroupModel(title='group2')
        db.add_all((group1, group2))
        db.commit()
        cls.models = group1, group2, event11, event12, event13, event14, odd111, odd112, odd121, odd131
        return cls.models


class TestForecastEventGroupModel(TestCase):
    def setUp(self):
        self.db = DataBase.get()

    def tearDown(self):
        self.db.rollback()

    def test_get_all_exclude_all(self):
        group1, group2, event11, event12, event13, event14, odd111, odd112, odd121, odd131 = \
            ModelsCreator.create_models(self.db)
        #
        # group_order = [group1.id, ]
        # result = ForecastEventGroupModel.get_all(self.db, True, True)
        # self.assertListEqual(group_order, [group.id for group in result])
        #
        # events_order = [event13.id, event11.id]
        # self.assertListEqual(events_order, [event.id for event in result[0].events])
        #
        # odds13_order = [odd131.id]
        # self.assertListEqual(odds13_order, [odd.id for odd in result[0].events[0].odds])
        #
        # odds11_order = [odd112.id, odd111.id]
        # self.assertListEqual(odds11_order, [odd.id for odd in result[0].events[1].odds])

    def test_get_all_include_all(self):
        group1, group2, event11, event12, event13, event14, odd111, odd112, odd121, odd131 = \
            ModelsCreator.create_models(self.db)
        #
        # group_order = [group2.id, group1.id]
        # result = ForecastEventGroupModel.get_all(self.db, False, False)
        # self.assertListEqual(group_order, [group.id for group in result])
        #
        # events_order = [event14.id, event13.id, event12.id, event11.id]
        # self.assertListEqual(events_order, [event.id for event in result[1].events])
        #
        # odds11_order = [odd112.id, odd111.id]
        # self.assertListEqual(odds11_order, [odd.id for odd in result[1].events[3].odds])
