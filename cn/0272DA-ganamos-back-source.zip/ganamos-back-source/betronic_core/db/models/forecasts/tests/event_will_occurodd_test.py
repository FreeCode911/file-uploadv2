from unittest import TestCase
from datetime import timedelta, datetime
from betronic_core.db.database import DataBase
from betronic_core.db.models.constants import CALCULATION_STATE
from betronic_core.db.models.forecasts.event_group import ForecastEventGroupModel
from betronic_core.db.models.forecasts.odds import EventWillOccurOddModel


class TestEventWillOccurOddModel(TestCase):
    def _add_odds(self, db, date):
        group = ForecastEventGroupModel(title='group')
        event = group.add_event('event', date)
        odd = event.add_event_will_occur_odd('odd')
        db.add(group)
        db.commit()
        return group, event, odd

    def test_get_betting_available_odds_return_odds(self):
        db = DataBase.get()
        group, event, odd = self._add_odds(
            db, datetime.utcnow() + timedelta(minutes=5))
        result = EventWillOccurOddModel.get_betting_available_odds(
            db, group.id, (odd.id, ))
        self.assertEqual(len(result), 1)
        self.assertEqual(odd.id, result[0].id)

    def test_get_betting_available_fails_with_wrong_invalid_group(self):
        db = DataBase.get()
        group, event, odd = self._add_odds(
            db, datetime.utcnow() + timedelta(minutes=5))
        result = EventWillOccurOddModel.get_betting_available_odds(
            db, 939393, (odd.id, ))
        self.assertEqual(len(result), 0)

    def test_get_betting_available_fails_with_passed_event(self):
        db = DataBase.get()
        group, event, odd = self._add_odds(
            db, datetime.utcnow() - timedelta(minutes=5))
        result = EventWillOccurOddModel.get_betting_available_odds(
            db, group.id, (odd.id, ))
        self.assertEqual(len(result), 0)

    def test_get_betting_available_fails_with_calculated_odd(self):
        db = DataBase.get()
        group, event, odd = self._add_odds(
            db, datetime.utcnow() - timedelta(minutes=5))
        odd.calculation_state = CALCULATION_STATE['WON']
        result = EventWillOccurOddModel.get_betting_available_odds(
            db, group.id, (odd.id, ))
        self.assertEqual(len(result), 0)

    def test_get_betting_available_fails_with_blocked_odd(self):
        db = DataBase.get()
        group, event, odd = self._add_odds(
            db, datetime.utcnow() - timedelta(minutes=5))
        odd.is_blocked = True
        result = EventWillOccurOddModel.get_betting_available_odds(
            db, group.id, (odd.id, ))
        self.assertEqual(len(result), 0)
