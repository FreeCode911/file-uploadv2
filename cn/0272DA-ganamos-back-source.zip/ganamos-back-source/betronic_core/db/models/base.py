import sqlalchemy
import ujson
from logging import getLogger
from datetime import datetime, timedelta, time
from typing import List

from marshmallow import fields
from sqlalchemy.sql.expression import cast
from sqlalchemy import Column, DateTime, func
from sqlalchemy import desc
from sqlalchemy.orm import DeclarativeBase
from decimal import Decimal
import functools

from betronic_core.db import field_dict
from ..get_engine import get_engine
from sqlalchemy.orm.exc import NoResultFound
from marshmallow_sqlalchemy import ModelConversionError, SQLAlchemyAutoSchema
from marshmallow_sqlalchemy.convert import ModelConverter
from sqlalchemy_utils import LtreeType


engine = get_engine()
logger = getLogger(__name__)


class BaseModel(DeclarativeBase):
    __abstract__ = True

    # def __init__(self, *args, **kwargs):
    #     super(BaseModel, self).__init__(self, *args, **kwargs)

    @staticmethod
    def clean_order_by(order_by: str) -> str:
        return order_by.replace('-', '')

    @staticmethod
    def order_by_is_desc(order_by):
        if order_by[0] == '-':
            return True
        return False

    @classmethod
    def get_all(cls, db) -> List['BaseModel']:
        try:
            return db.query(cls).all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_id(cls, db, _id) -> 'BaseModel':
        try:
            return db.query(cls).filter_by(id=_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_ids(cls, db, ids) -> List['BaseModel']:
        return db.query(cls).filter(cls.id.in_(ids)).all()

    @classmethod
    def remove_all(cls, db) -> None:
        try:
            [db.delete(x) for x in db.query(cls).all()]
        except NoResultFound:
            pass
        return None

    @classmethod
    def query_by_params(cls,
                        query,
                        session,
                        offset=None,
                        count=100,
                        order_by=None,
                        filters=None,
                        sum=None,
                        sum_query=None,
                        fields=None,  # - dict of fields from settings
                        **kwargs):
        _query = query
        sum_counter = 0
        if sum:
            if not sum_query:
                sum_query = session.query(func.sum(getattr(cls, sum)))
        if filters:
            for field, _filter in filters.items():
                if type(_filter) is not dict:
                    # for avoid relation fields.
                    if field in ["id", "from_user_id", "to_user_id", "real_from_user_id", "real_to_user_id", "type"]:
                        _query = _query.filter(
                            getattr(cls, field) == int(_filter))
                        if sum_query:
                            sum_query = sum_query.filter(getattr(cls, field) == int(_filter))
                    else:
                        if "." in field:
                            _query, sum_query = cls._filter_by_nested_relation(
                                _query, field, _filter, sum_query
                            )
                        else:
                            filter_recognized = False
                            if fields and fields.get(field) and fields[field].get("type"):
                                filter_recognized = True
                                if fields[field]["type"] == "number":
                                    if "." in _filter:
                                        _filter = float(_filter)
                                    else:
                                        _filter = int(_filter)
                                elif fields[field]["type"] == "text":
                                    _filter = _filter if isinstance(_filter, str) else str(_filter)
                                elif fields[field]["type"] == "enum":
                                    _filter = int(_filter)
                                elif fields[field]["type"] == "boolean":
                                    _filter = bool(_filter)
                                else:
                                    filter_recognized = False
                            if filter_recognized:
                                _query = _query.filter(getattr(cls, field) == _filter)
                                if sum_query:
                                    sum_query = sum_query.filter(getattr(cls, field) == _filter)
                            else:
                                _query = _query.filter(cast(getattr(cls, field), sqlalchemy.String).like(str(_filter)))
                                if sum_query:
                                    sum_query = sum_query.filter(
                                        cast(getattr(cls, field), sqlalchemy.String).like(str(_filter)))
                else:
                    _query = cls._filter_by_date(_query, field, _filter)
                    if sum_query:
                        sum_query = cls._filter_by_date(sum_query, field, _filter)

        if order_by:
            cleaned_order = cls.clean_order_by(order_by)
            split_order = cleaned_order.split('.')
            if len(split_order) == 2:
                _query = cls._ord_by_relation(
                    _query, session,
                    relation_column_ids=split_order[0],
                    relation_column_values=split_order[1]
                )
            else:
                _query = _query.order_by(desc(cleaned_order)) if \
                    cls.order_by_is_desc(order_by) else _query.order_by(
                    cleaned_order)
        count_items = cls.get_count(_query)
        if sum:
            sum_result = sum_query.all()
            sum_counter = sum_result[0][0]
            if not sum_counter:
                sum_counter = 0
        if offset:
            _query = _query.offset(offset)
        if count:
            _query = _query.limit(count)
        value_to_return = [_query.all(), count_items]
        if sum:
            value_to_return.append(sum_counter)
        return value_to_return

    @classmethod
    def _filter_by_nested_relation(cls, query, field: str, value, sum_query):
        split_field = field.split('.')
        parent_model = cls
        while len(split_field) > 1:
            child_model_name = split_field.pop(0)
            children_model = getattr(parent_model, child_model_name).mapper.class_
            query = query.join(children_model, getattr(parent_model, child_model_name))
            if sum_query:
                sum_query = sum_query.join(children_model, getattr(parent_model, child_model_name))
            parent_model = children_model
        if sum_query:
            sum_query = sum_query.filter(getattr(parent_model, split_field[0]) == value)
        return query.filter(getattr(parent_model, split_field[0]) == value), sum_query

    @classmethod
    def _ord_by_relation(cls, query, session, relation_column_ids, relation_column_values):
        rc_ids, rc_values = \
            relation_column_ids, relation_column_values
        r_model = getattr(cls, rc_ids).mapper.class_

        rel_subq = session.query(
            getattr(r_model, 'id'),
            getattr(r_model, rc_values).label('rel_field')
        ).subquery()

        query_to_return = query \
            .join(rel_subq, getattr(cls, relation_column_ids)) \
            .order_by(rel_subq.c.rel_field)

        return query_to_return

    @staticmethod
    def get_count(q):
        count_q = q.statement.with_only_columns(func.count()).order_by(None)
        count = q.session.execute(count_q).scalar()
        return count

    def _update(self, db, fields) -> 'BaseModel':
        db.query(self.__class__).filter_by(id=self.id).update(fields)

    @property
    def auto_dict(self, **kwargs) -> dict:
        return self.__class__.__marshmallow__(**kwargs).dump(self)

    def auto_dict_by_fields(self, fields: List[str]) -> dict:
        return {
            key: value
            for key, value in self.auto_dict.items() if key in fields
        }

    @property
    def fields(self):
        return {key: value for key, value in self.__dict__.items() if not key.startswith('_')}

    def auto_upd_from_dict(self, data, **kwargs):
        return self.__class__.__marshmallow__(**kwargs).load(data, partial=True)

    def auto_from_dict(self, data, **kwargs):
        return self.__class__.__marshmallow__(**kwargs).load(data, partial=True)

    @staticmethod
    def handle_date(date: str or None, format: str = "%Y-%m-%d"):
        return datetime.strptime(date, format).date() if date else None

    @staticmethod
    def is_equal_date_format(date_str: str, date_format: str = '%Y-%m-%d') -> bool:
        try:
            datetime.strptime(date_str, date_format)
        except Exception:
            return False
        return True

    @classmethod
    def _filter_by_date(cls, query, field: str, filter: dict):
        today_date = datetime.today()
        yesterday = today_date - timedelta(days=1)

        date_from = filter.get('from')
        date_to = filter.get('to')

        if date_from and cls.is_equal_date_format(date_from[:-7], '%Y-%m-%d %H:%M'):
            try:
                time_zone = datetime.strptime(date_from[-5:], "%H:%M")
                time_zone = timedelta(hours=time_zone.hour, minutes=time_zone.minute)
                date_from = date_from[:-7]
                date_from = datetime.strptime(date_from, '%Y-%m-%d %H:%M') - time_zone

            except Exception:
                logger.warning(f'error extracting timezone from {date_from}. Set default date: {yesterday}')
                date_from = yesterday.strftime('%Y-%m-%d %H:%M')

        if date_to and cls.is_equal_date_format(date_to[:-7], '%Y-%m-%d %H:%M'):
            try:
                time_zone = datetime.strptime(date_to[-5:], "%H:%M")
                time_zone = timedelta(hours=time_zone.hour, minutes=time_zone.minute)
                date_to = date_to[:-7]
                date_to = datetime.strptime(date_to, '%Y-%m-%d %H:%M') - time_zone
            except Exception:
                logger.warning(f'error extracting timezone from {date_to}. Set default today max day')
                date_to = datetime.combine(today_date, time.max)

        if date_from and date_to:
            query = query.filter(getattr(cls, field) >= date_from,
                                 getattr(cls, field) <= date_to)
        elif date_from:
            query = query.filter(getattr(cls, field) >= date_from)
        elif date_to:
            query = query.filter(getattr(cls, field) <= date_to)

        return query

    @classmethod
    def join_relations_and_load_only(cls, db, relations_fields):
        """
            :param
                relations_fields: dict of relationships which will be joined in result cls
                    relations_fields = {relation: fields, relation: fields, ...}
                    relation - None or str of Class relationship
                    fields - None or list or dict:
                        fields = {relation: fields, relation: fields, ...}
                        fields = ['field1', 'field2', ...]  # - simple fields, not relations
                        fields = None # - means all fields to load.
                    if relation None: # means: using current class
                         {None: ['field1', 'field2', ...], ...}  # fields always list of str with None

                    example:
                        cls = UserModel
                        relations_fields = {None: ['id', 'first_name', 'middle_name'], # None means UserModel class
                                           'additional_data' : ['id', 'number_document'],
                                           'cashier_data': { None: ['id', 'phone'], # None means CashierData class
                                                            'user': ['id', 'balance']
                                                            },
                                            'betroute_registration': None, # None here means all fields
                                            }
            :returns  query
        """

        from sqlalchemy.orm import Load

        def join_options(relation, fields, load):
            options = None
            if not fields:
                if relation:
                    options = load.joinedload(relation)
            else:
                if not relation:  # None
                    if isinstance(fields, list):
                        options = load.load_only(*fields)
                else:
                    if isinstance(fields, dict):
                        options = []
                        for _relation, _fields in fields.items():
                            _load = load.joinedload(relation)
                            _load = join_options(_relation, _fields, _load)
                            if isinstance(_load, list):
                                options.extend(_load)
                            else:
                                options.append(_load)
                    elif isinstance(fields, list):
                        options = load.joinedload(relation).load_only(*fields)
            return options

        options = []
        for relation, fields in relations_fields.items():
            option = join_options(relation, fields, Load(cls))
            if isinstance(option, list):
                options.extend(option)
            else:
                options.append(option)
        return db.query(cls).options(*options)

    @classmethod
    def get_relations_and_filter(cls, db, relations_fields, str_filters=None, cls_filters=None, first=True):
        """
            :param
                relations_fields: See join_relations_and_load_only - relations_fields
                str_filters: dict, add to cls like: {cls.<filter.key>: <filter.value>}
                cls_filters: dict, got class already and alike: cls_filters = {UserModel.id: 25}
            :returns
                    None or
                if first:
                    returns first
                if first=False:
                    returns all()"""

        query = cls.join_relations_and_load_only(db, relations_fields)
        query = cls.filter_query(query, str_filters, cls_filters)
        try:
            if first:
                return query.first()
            return query.all()
        except NoResultFound:
            return None

    @classmethod
    def filter_query(cls, query, str_filters: dict = None, cls_filters: dict = None):
        if str_filters:
            query = query.filter_by(**str_filters)
        if cls_filters:
            for field, value in cls_filters.items():
                query = query.filter(field == value)
        return query

    def to_dict(self, show=None, hide=None):
        """ Return a dictionary representation of the model
        """
        if not show:
            show = []
        if not hide:
            hide = []
        hidden = list()
        # hidden_fields can be setted as Model attr
        if hasattr(self, 'hidden_fields'):
            hidden = self.hidden_fields

        columns = self.__table__.columns.keys()
        relationships = self._get_relationships(show)
        ret_data = dict()

        def clear_meta_info(data):
            if data is None:
                ret_data['meta_info'] = "empty"
                return
            if ret_data.get('from_user_id', 0) == -1:
                ret_data['meta_info'] = data.get('balance_before_to_user', "empty")
            else:
                ret_data['meta_info'] = data.get('balance_before_from_user', "empty")

        for key in columns:
            if key in hide or key in hidden:
                continue
            if key in show:
                data = getattr(self, key)
                if key == 'meta_info':
                    clear_meta_info(data)
                    continue
                if isinstance(data, datetime):
                    ret_data[key] = data.isoformat()
                elif isinstance(data, Decimal):
                    ret_data[key] = float(data)
                else:
                    ret_data[key] = data

        for rel in relationships:

            def rgetattr(obj, attr):
                """
                Function gets required attribute of object, coming through relationship recursively
                Example: rgetattr(UserModel, 'user.additional_data.address'
                :param obj:  instance of BaseModel's child.
                :param attr: (str) path to required attribute.
                :return:     required attribute's value
                """

                def _getattr(obj, attr):
                    return getattr(obj, attr)

                return functools.reduce(_getattr, [obj] + attr.split('.'))

            try:
                ret_data[field_dict[rel]] = rgetattr(self, rel)
            except AttributeError:
                ret_data[field_dict[rel]] = None

        return ret_data

    @staticmethod
    def _get_relationships(fields: list):
        """
        Procedure Generates list of relationships.
        By checking if the field IS relationship (by.words.count)

        :param fields: list of (str)required_fields
        :return: list of (str)relationships
        """
        return [item for item in filter(lambda x: len(x.split(".")) > 1, fields)]

    @classmethod
    def update(cls, db, _id, fields: dict):
        return db.query(cls).filter(cls.id == _id).update({**fields})


class TimestampMixin:
    created_at = Column(DateTime, default=func.now())


class UpdateMixin:
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())


class SQLATypeConverter(ModelConverter):
    SQLA_TYPE_MAPPING = dict(
        list(ModelConverter.SQLA_TYPE_MAPPING.items()) +
        [(LtreeType, fields.Str), ]
    )


def setup_schema(session):
    def setup_schema_fn():
        for mapper in BaseModel.registry.mappers:
            class_ = mapper.class_
            if hasattr(class_, '__tablename__'):
                if class_.__name__.endswith('Schema'):
                    raise ModelConversionError(
                        "For safety, setup_schema can not be used when a"
                        "Model class ends with 'Schema'")

                class Meta(object):
                    model = class_
                    sqla_session = session
                    load_instance = True
                    json_module = ujson
                    model_converter = SQLATypeConverter

                schema_class_name = '%sSchema' % class_.__name__

                schema_class = type(schema_class_name, (SQLAlchemyAutoSchema,),
                                    {'Meta': Meta})

                setattr(class_, '__marshmallow__', schema_class)

    return setup_schema_fn
