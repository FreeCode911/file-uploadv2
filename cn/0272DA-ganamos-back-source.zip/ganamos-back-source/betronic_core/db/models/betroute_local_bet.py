from datetime import datetime

from sqlalchemy import (
    Column, Integer, DateTime,
    ForeignKey, Numeric, Boolean,
    String, SmallInteger, func, 
    Index,
)
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship, Mapped
from tornado.options import options
from typing import List

from betronic_core.db.models.bet_content_data import BetContentDataModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from .base import BaseModel

"""
Wait - Ожидание
Win - Игрок выиграл ставку
Loss - Игрок проиграл ставку
Return - Возврат ставки (матч начался раньше и т.д.)
Ignory - Ординар не расчитан, и не влияет на статус экспресса
MoneyOut - Выигрыш по ставке выплачен игроку
OfficeFund - Фонд конторы
ReturnHand - Возврат ставки (попадание в фору или тотал)
ReturnAsianHandOne - Частичный возврат ставки, один возврат
ReturnAsianHandThird - Частичный возврат ставки, один возврат и выигрыш
ManualChangeOdd - Изменение коэффициента букмекером
NewTimeEvent - Расход по ставке, сделаной после начала матча
Rollback - Ставки, отменненные поставщиком, 
                    и по этим ставкам, ещё не принято решение 
                    букмекером. (не рассчитанная ставка)
PointerBonus - Бонус кассы 5,7,9
CashOut - Удаленная ставка по CashOut
"""


class BetStatus(object):
    WAIT = 1
    WIN = 2
    LOSS = 4
    RETURN = 8
    IGNORY = 16
    MONEY_OUT = 32
    OFFICE_FUND = 64
    RETURN_HAND = 128
    RETURN_ASIAN_HAND_ONE = 256
    RETURN_ASIAN_HAND_THIRD = 512
    MANUAL_CHANGE_ODD = 1024
    NEW_TIME_EVENT = 2048
    ROLLBACK = 4096
    POINTER_BONUS = 8192
    CASH_OUT = 16384

    # "---" = не требуется для нашей системы
    # Документ БР с описанием статусов: https://drive.google.com/open?id=1PRjPL-vGgi5je_4U9UPrmyj88tap8BLl
    STATUS_NAMES = {
        WAIT: "Ожидание рассчета",                                # Не рассчитана
        WIN: "Выигрыш",                                           # Игрок выиграл ставку
        LOSS: "Проигрыш",                                         # Игрок проиграл ставку
        RETURN: "Возврат ставки",                                 # Матч начался раньше и т.д.)
        IGNORY: "Ординар не рассчитан",                           # Ординар не расчитан, и не влияет на статус экспресса
        MONEY_OUT: "Выигрыш выплачен игроку",                     # ---
        OFFICE_FUND: "Фонд конторы",                              # ---
        RETURN_HAND: "Возварт ставки",                            # --- Попадание в фору или тотал
        RETURN_ASIAN_HAND_ONE:
            "Частичный возврат - один возврат",                   # ---
        RETURN_ASIAN_HAND_THIRD:
            "Частичный возврат - возврат+выигрыш",                # ---
        MANUAL_CHANGE_ODD:
            "Изменение коэф-а букмекером",                        # ---
        NEW_TIME_EVENT:
            "Расход по ставке, сделаной после начала матча",      # ---
        ROLLBACK: "Отмена поставщиком",                           # ---
        POINTER_BONUS: "Бонус кассы",                             # ---
        CASH_OUT: "Ставка продана"                                # Cash out...
    }

    CALCULATION_STATE = {
        'Wait': '1',
        'Win': '2',
        'Loss': '3',
    }
    CALCULATION_STATE_FOR_BETS = {
        'Ожидание': '1',
        'Выигрыш': '2',
        'Проигрыш': '4',
        'Возврат': '8',
        'Выигрыш и выплата': '34'
    }

    @classmethod
    def get_statuses_list(cls, betroute_status: int):
        active = list()
        for status in cls.STATUS_NAMES.keys():
            if bool(status & betroute_status):
                active.append(status)
        return active

    @classmethod
    def is_wait_status(cls, betroute_status):
        return bool(betroute_status & cls.WAIT or betroute_status & cls.ROLLBACK or betroute_status & cls.IGNORY)

    @classmethod
    def is_loss_status(cls, betroute_status):
        return bool(betroute_status & cls.LOSS)

    @classmethod
    def is_return_status(cls, betroute_status: int):
        return betroute_status == cls.RETURN

    @classmethod
    def is_win_status(cls, betroute_status: int):
        return betroute_status & cls.WIN

    @classmethod
    def is_cashed_out(cls, betroute_status: int):
        return betroute_status & cls.CASH_OUT

class BetrouteLocalBetModel(BaseModel):
    __tablename__ = "betroute_local_bet"
    __table_args__ = (
        Index("betroute_local_bet_transfer_return_id_ix", "transfer_return_id"),
        Index("betroute_local_bet_transfer_win_id_ix", "transfer_win_id"),
        Index("betroute_local_bet_transfer_id_ix", "transfer_id"),
        Index("betroute_local_bet_bonus_transfer_id_ix", "bonus_transfer_id"),
        Index("betroute_local_bet_bonus_transfer_return_id_ix", "bonus_transfer_return_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    from_user_id = Column(ForeignKey("user.id"), nullable=False)
    from_account = relationship(
        "UserModel", backref='send_transfers_bet', foreign_keys=[from_user_id])
    created_at = Column(DateTime, default=datetime.utcnow)
    status = Column(SmallInteger, default=BetStatus.WAIT)
    amount = Column(Numeric(10, 2, asdecimal=False), default=0)
    details = Column(JSONB, name='details')
    betcode = Column(String, name='betcode')

    bets_content: Mapped['BetContentDataModel'] = relationship(
        'BetContentDataModel',
        backref='betroute_local_bet'
    )

    transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer: Mapped['MoneyTransferModel'] = relationship(
        "MoneyTransferModel",
        backref='betroute_bet_set',
        foreign_keys=[transfer_id])

    bonus_transfer_id = Column(ForeignKey("bonus_transfer.id"), nullable=True)
    bonus_transfer = relationship(
        "BonusTransferModel",
        backref='bonus_transfers_local_bet',
        foreign_keys=[bonus_transfer_id])

    transfer_win_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer_win: Mapped["MoneyTransferModel"] = relationship(
        "MoneyTransferModel",
        backref='betroute_bet_win',
        foreign_keys=[transfer_win_id])

    transfer_return_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer_return: Mapped['MoneyTransferModel'] = relationship(
        "MoneyTransferModel",
        backref='transfers_return_local_bet',
        foreign_keys=[transfer_return_id])

    bonus_transfer_return_id = Column(ForeignKey("bonus_transfer.id"), nullable=True)
    bonus_transfer_return = relationship(
        BonusTransferModel,
        backref='bonus_transfers_return_local_bet',
        foreign_keys=[bonus_transfer_return_id])

    responses = relationship("BetrouteLocalBetResponseModel",
                             back_populates="bet",
                             order_by="desc(BetrouteLocalBetResponseModel.id)")

    is_referral_close = Column(Boolean, default=False)

    @property
    def converted_status(self):
        if self.status is None:
            return None
        return BetStatus.convert_status(self.status)

    def is_loss_bet(self):
        return self.converted_status == BetStatus.CALCULATION_STATE['Loss']

    def is_wait_bet(self):
        return self.converted_status == BetStatus.CALCULATION_STATE['Wait']

    @classmethod
    def get_open_bets_referrals_ids(cls, db, referrals_ids: List[int]) -> List['BetrouteLocalBetModel']:
        result = db.query(cls).filter(
            cls.from_user_id.in_(referrals_ids),
            cls.status != BetStatus.WAIT,
            cls.is_referral_close == False
        ).all()

        return result

    @classmethod
    def get_bets_active_by_user_id(cls, db, user_id: int):
        active_bets = db.query(cls).filter(cls.from_user_id == user_id)
        active_bets = active_bets.filter(cls.is_closed == False)
        return active_bets.all()

    @classmethod
    def get_bet_count(cls, db, user_id: int):
        res = db.query(cls).filter(cls.from_user_id == user_id).count()
        return res

    @classmethod
    def win_bets(cls, db):
        return db.query(cls).filter(cls.transfer_win_id != None).all()

    @classmethod
    def get_loss_bets_by_ids(cls, db, ids, begin=datetime.min, end=datetime.max):
        q = db.query(func.sum(cls.amount)
                     .filter(cls.from_user_id.in_(ids))
                     .filter(cls.created_at > begin)
                     .filter(cls.created_at < end)
                     .filter(cls.status == BetStatus.LOSS)).scalar()
        return q or 0

    @classmethod
    def get_bet_by_code_single(cls, db, betcode: str):
        q = db.query(cls).filter(cls.betcode == str(betcode))
        return q.first()

    @classmethod
    def check_min_count_bet(cls, db, user_id):
        count = db.query(cls).filter_by(from_user_id=user_id).count()
        return count >= options.MIN_COUNT_BET

    @property
    def win_amount(self):
        return self.details["AmountOut"]

    @property
    def need_to_pay_out(self):
        return (self.status == 2 or self.status == 4) and not self.transfer_win_id

    def as_dict(self):
        t_win = {
            "id": self.transfer_win.id,
            "value": self.transfer_win.value,
            "from": self.transfer_win.from_user_id,
        } if self.transfer_win_id else None

        return {
            "id": self.id,
            "from_user_id": self.from_user_id,
            "is_live": self.is_live,
            "created_at": self.created_at,
            "status": self.status,
            "amount": self.amount,
            "details": self.details,
            "betcode": self.betcode,
            "transfer": {
                "id": self.transfer.id,
                "value": self.transfer.value,
                "from": self.transfer.from_user_id,
            },
            "transfer_win": t_win,
        }

    @staticmethod
    def clean_timestamp(s: str):
        """Cleaner of timestamps that looks like '/Date(1490713200000)/'
        """
        timestamp = ''.join([ss for ss in s if ss.isdigit()])
        d = datetime.fromtimestamp(int(timestamp) / 1000)
        return d

    def place_content(self, content_array, bet_details):
        content_array = content_array or []
        for item in content_array:
            content = BetContentDataModel()

            content.lines_id = item.get('LinesId')
            content.count_results = item.get('CountResults')
            content.outcome = item.get('Outcome')
            content.tournament_name = item.get('TournamentName')
            content.is_bonus = item.get('IsBonus')
            content.coef_orig = item.get('CoefOrig')
            content.coef = item.get('Coef')
            content.bet_name = item.get('BetName')
            content.sport_id = item.get('SportId')
            content.is_live = item.get('IsLive')
            content.event_date = self.clean_timestamp(item.get('EventDate'))
            content.site_bet_id = item.get('SiteBetId')
            content.teams = item.get('Teams')
            content.main_result = item.get('MainResult')
            if bet_details['CountEvents'] > 1:
                content.is_express = True
            else:
                content.is_express = False

            self.bets_content.append(content)


class BetrouteLocalBetResponseModel(BaseModel):
    __tablename__ = "betroute_local_bet_response"
    __table_args__ = (
        Index("betroute_local_bet_response_bet_id_ix", "bet_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    bet_id = Column(ForeignKey("betroute_local_bet.id"), nullable=True)
    bet = relationship(
        BetrouteLocalBetModel, back_populates='responses', foreign_keys=[bet_id])
    details = Column(JSONB, name='details')
