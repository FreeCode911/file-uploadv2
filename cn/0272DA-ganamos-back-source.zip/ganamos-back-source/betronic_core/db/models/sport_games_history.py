from datetime import datetime
from typing import List

from sqlalchemy import (Column, Integer, String, Numeric, DateTime, update, Boolean, Index, ForeignKey)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import relationship
from sqlalchemy.sql import bindparam, expression

from betronic_core.db.async_database import session
from .base import BaseModel


class SportCouponHistoryModel(BaseModel):
    __tablename__ = "sport_coupon_history"
    __table_args__ = (
        Index("sport_coupon_history_transfer_id_ix", "transfer_id"),
        Index("sport_coupon_history_remote_coupon_id_ix", "remote_coupon_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    remote_coupon_id = Column(String)
    user_id = Column(ForeignKey("user.id"), index=True)
    user = relationship("UserModel", foreign_keys=[user_id])
    created_at = Column(DateTime, default=datetime.utcnow)
    provider = Column(String(30))
    status = Column(String(30))
    is_express = Column(Boolean)
    amount = Column(Numeric(10, 2, asdecimal=False))
    currency = Column(String(5))
    coef = Column(Numeric(13, 5))
    possible_win_amount = Column(Numeric(10, 2))
    transfer_id = Column(ForeignKey("transfer.id"))

    @classmethod
    async def create_coupon(cls, coupon_for_create: 'SportCouponHistoryModel', connection: AsyncSession = None):
        connection = connection if connection else session()
        connection.add(coupon_for_create)
        await connection.flush([coupon_for_create])

        return coupon_for_create

    @classmethod
    async def update_fields_by_remote_coupon_id(
            cls,
            remote_coupon_id: str,
            fields: dict,
            connection: AsyncSession = None
    ):
        connection = connection if connection else session()
        update_stmt = update(cls).where(cls.remote_coupon_id == remote_coupon_id).values(fields).returning(cls)
        result_raw = await connection.execute(update_stmt)

        return result_raw.scalars().first()


class SportBetHistoryModel(BaseModel):
    __tablename__ = "sport_bet_history"

    __table_args__ = (
        Index("sport_bet_history_coupon_remote_bet_id_ix", "local_coupon_id", "remote_bet_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    remote_bet_id = Column(String)

    status = Column(String(30))
    score = Column(String(300))
    coef = Column(Numeric(13, 5))

    is_live = Column(Boolean, server_default=expression.false(), default=False)

    participant_1 = Column(String, nullable=True)
    participant_2 = Column(String, nullable=True)

    sport_id = Column(Integer, nullable=True)
    sport_name = Column(String, nullable=True)
    country_id = Column(Integer, nullable=True)
    country_name = Column(String, nullable=True)
    tournament_id = Column(Integer, nullable=True)
    tournament_name = Column(String, nullable=True)
    event_id = Column(Integer, nullable=True)
    event_name = Column(String, nullable=True)

    outcome = Column(String, nullable=True)

    bet_date = Column(DateTime, nullable=False)

    local_coupon_id = Column(Integer)

    @classmethod
    async def create_bets(cls, bets: List['SportBetHistoryModel'], connection: AsyncSession = None):
        connection = connection if connection else session()

        for bet_for_create in bets:
            connection.add(bet_for_create)

        return bets

    @classmethod
    async def bulk_update_by_remote_bet_ids(cls, bets: List[dict], connection: AsyncSession = None):
        connection = connection if connection else session()
        update_stmt = (
            update(cls)
            .where(
                cls.remote_bet_id == bindparam("_remote_bet_id"),
                cls.local_coupon_id == bindparam("_local_coupon_id")
            )
            .values(
                {cls.status: bindparam("status"),
                cls.score: bindparam("score"),}
            )
            .execution_options(synchronize_session=False)
        )
        await connection.execute(update_stmt, bets)

    @classmethod
    def bet_history_query_by_params(cls,
                                    query,
                                    coupon_history_filters,
                                    bet_history_filters):
        for field, value in coupon_history_filters.dict().items():
            parts = field.split("__")
            if len(parts) == 2 and value is not None:
                field_name, operator = parts

                if hasattr(coupon_history_filters, field):

                    if operator == "gte":
                        query = query.where(getattr(SportCouponHistoryModel, field_name) >= value)
                    elif operator == "lte":
                        query = query.where(getattr(SportCouponHistoryModel, field_name) <= value)

        if any(bet_history_filters.dict().values()):
            query = query.join(
                cls, cls.local_coupon_id == SportCouponHistoryModel.id
            )
            for field, value in bet_history_filters.dict().items():
                if value is not None:
                    query = query.where(getattr(cls, field) == value)

        for field, value in coupon_history_filters.dict().items():
            if "__" not in field and value is not None and hasattr(coupon_history_filters, field):
                query = query.where(getattr(SportCouponHistoryModel, field) == value)

        return query
