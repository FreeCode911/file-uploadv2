from datetime import datetime
from typing import List, Tuple, Union

from sqlalchemy import Column, Integer, SmallInteger, String, Numeric, \
    DateTime, ForeignKey, and_, or_, Index, update, select, BigInteger
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session, Query, aliased
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql import func
from sqlalchemy.sql.selectable import Subquery

from betronic_core.constants import TransferTypes
from betronic_core.db.async_database import session
from .base import BaseModel
from .email_auth import EmailAuthModel
from .user import UserModel as U


class MoneyTransferModel(BaseModel):
    __tablename__ = "transfer"

    __table_args__ = (
        Index('ix_transfer_created_at_type', "created_at", "type"),
    )

    id = Column(BigInteger, autoincrement=True, primary_key=True)
    type = Column(SmallInteger)
    from_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    to_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    from_account = relationship(
        "UserModel", backref='sent_transfers', foreign_keys=[from_user_id])
    to_account = relationship(
        "UserModel", backref='received_transfers', foreign_keys=[to_user_id])
    real_from_user_id = Column(ForeignKey("user.id"), nullable=True,
                               index=True)
    real_from_user = relationship(
        "UserModel", backref='real_sent_transfers', foreign_keys=[
            real_from_user_id])
    real_to_user_id = Column(ForeignKey("user.id"), nullable=True,
                             index=True)
    real_to_user = relationship(
        "UserModel", backref='real_received_transfers', foreign_keys=[
            real_to_user_id])
    value = Column(Numeric(15, 2, asdecimal=False))
    currency = Column(String(5))
    note = Column(String(100), index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    additional_data = Column(JSONB, nullable=True)
    transaction_id = Column(String(), nullable=True, index=True)
    description = Column(String(), nullable=True)

    def get_type(self):
        try:
            return MoneyTransferModel.TYPES[self.type]
        except KeyError:
            return None

    @classmethod
    def get_by_id(cls, db, transfer_id):
        try:
            return db.query(cls).filter_by(id=transfer_id).one()
        except NoResultFound:
            return None

    @classmethod
    def has_deposits_by_user_id(cls, db, user_id):
        res = db.query(cls). \
            filter(
            cls.to_user_id == user_id,
            cls.type.in_(MoneyTransferModel.PAYMENT_TYPES)
        ).first()
        return True if res else False

    @classmethod
    def get_payments(cls, db, user_id, begin, end):
        q = db.query(cls)
        q = q.filter(
            cls.to_user_id == user_id,
            cls.type.in_(TransferTypes.INCOMING_TYPES))
        if begin:
            q = q.filter(and_(cls.created_at >= begin))
        if end:
            q = q.filter(and_(cls.created_at <= end))
        return q.all()

    @classmethod
    def get_sum_payments_by_user_id(cls, db, user_id, begin=datetime.min, end=datetime.max):
        if not begin:
            begin = datetime.min
        if not end:
            end = datetime.max
        q = db.query(func.sum(cls.value)
                     .filter(cls.created_at > begin)
                     .filter(cls.created_at < end)
                     .filter(cls.type.in_(TransferTypes.PAYMENT_TYPES))
                     .filter(cls.to_user_id == user_id)).scalar()
        return q

    @classmethod
    def get_withdrawals(cls, db, user_id, begin, end):
        q = db.query(cls) \
            .filter(cls.from_user_id == user_id) \
            .filter(cls.type.in_(TransferTypes.WITHDRAWAL_TYPES)) \
            .filter(and_(cls.created_at >= begin, cls.created_at <= end))
        return q.all()

    @classmethod
    def check_payment_user(cls, db, user_id):
        count = db.query(cls.id).filter(
            cls.to_user_id == user_id,
            cls.type.in_(TransferTypes.PAYMENT_TYPES)).count()
        return count > 0

    def __str__(self):
        return str(self.id)

    @classmethod
    def get_user_slots_bet_history(
            cls,
            db,
            user_id: int,
            from_date: datetime,
            to_date: datetime,
            slots_types: list = None,
            skip: int = None,
            limit: int = None
    ) -> Tuple[list, int]:
        if not slots_types:
            slots_types = TransferTypes.SLOTS_TYPES

        q = db.query(cls).filter(
            or_(
                cls.from_user_id == user_id,
                cls.to_user_id == user_id
            ),
            and_(
                cls.type.in_(slots_types),
                cls.created_at.between(from_date, to_date)
            )
        )

        count = q.count()

        q = q.order_by(cls.id.desc())
        if skip is not None and limit is not None:
            q = q.offset(skip).limit(limit)

        return q.all(), count

    @classmethod
    def get_users_slots_bet_history(
            cls,
            db,
            user_ids: Union[list, Query],
            from_date: datetime,
            to_date: datetime,
            slots_types: list = None,
            decreasing_by_id: bool = False,
            transfers_direction: str = None,
            skip: int = None,
            limit: int = None
    ) -> Tuple[list, int]:
        if not slots_types:
            return [], 0

        query = db.query(cls).filter(
            and_(
                cls.type.in_(slots_types),
                cls.created_at.between(from_date, to_date)
            )
        )

        if transfers_direction:
            query = query.filter(getattr(cls, f"{transfers_direction}_user_id").in_(user_ids),)
        else:
            query = query.filter(or_(
                cls.from_user_id.in_(user_ids),
                cls.to_user_id.in_(user_ids)
            )
            )

        count = query.count()

        if decreasing_by_id:
            query = query.order_by(cls.created_at.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return query.all(), count

    @staticmethod
    def get_slots_bet_status_by_transaction_type(transaction_type, status):
        for key in status:
            if transaction_type in status[key]:
                return int(key)

    @staticmethod
    def get_slots_provider_by_transaction_type(transaction_type, providers):
        for provider in providers:
            if transaction_type in providers[provider]:
                return provider

    @staticmethod
    def get_provider_type_by_provider(provider, provider_types):
        for provider_type in provider_types:
            if provider in provider_types[provider_type]:
                return provider_type

    @classmethod
    def get_by_transaction_id(cls, db, transaction_id):
        try:
            return db.query(cls).filter_by(transaction_id=transaction_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_transfer_by_note(cls, db, note):
        try:
            return db.query(cls).filter(cls.note == note).one()
        except NoResultFound:
            return None

    @classmethod
    def get_query_total_credit_by_ids_role(cls, db: Session, admins_id, admin_role, from_date: str, to_date: str):
        roles_q = cls.prepare_query_for_total_by_roles(db, admin_role, admins_id)

        q_by_date = roles_q.filter(cls.created_at.between(from_date, to_date))

        q_by_user = q_by_date.join(U, cls.real_to_user_id == U.id).filter(U.role == U.USER)

        q_by_type_credit = q_by_user.filter(cls.type.in_((TransferTypes.TYPE_CASHIER_TO_USER,
                                                          TransferTypes.TYPE_REFILL)))
        return q_by_type_credit

    @classmethod
    def get_query_total_debit_by_ids_role(cls, db: Session, admins_id, admin_role, from_date: str, to_date: str):
        roles_q = cls.prepare_query_for_total_by_roles(db, admin_role, admins_id)

        q_by_date = roles_q.filter(cls.created_at.between(from_date, to_date))
        q_by_user = q_by_date.join(U, cls.real_from_user_id == U.id).filter(U.role == U.USER)

        q_by_type_credit = q_by_user.filter(cls.type.in_((TransferTypes.TYPE_USER_TO_CASHIER,)))
        return q_by_type_credit

    @classmethod
    def prepare_query_for_total_by_roles(cls, db: Session, admin_role: str, admins_id: List[int]):
        if admin_role == U.CASHIER:
            q = db.query(U.parent_cashier_id.label("admin_id"), func.sum(cls.value).label('sum'))
            q_by_role = q.filter(U.parent_cashier_id.in_(admins_id))
            q_grouping = q_by_role.group_by(U.parent_cashier_id)
        elif admin_role == U.ADMIN:
            q = db.query(U.parent_admin_id.label("admin_id"), func.sum(cls.value).label('sum'))
            q_by_role = q.filter(U.parent_admin_id.in_(admins_id))
            q_grouping = q_by_role.group_by(U.parent_admin_id)
        elif admin_role == U.SUPER_ADMIN:
            q = db.query(U.parent_suadmin_id.label("admin_id"), func.sum(cls.value).label('sum'))
            q_by_role = q.filter(U.parent_suadmin_id.in_(admins_id))
            q_grouping = q_by_role.group_by(U.parent_suadmin_id)

        return q_grouping

    @classmethod
    def _prepare_query_for_agent_structure_total(
            cls,
            db: Session,
            users_subq: Subquery,
            is_higher_transaction_only: bool = False,
            transfer_direction: str = "from"
    ):
        q = db.query(
            func.coalesce(func.sum(cls.value), 0).label('sum')
        ).select_from(cls)

        transfer_direction_field = getattr(cls, f"{transfer_direction}_user_id")

        q_by_users = q.filter(transfer_direction_field.in_(users_subq))

        q_by_initiators = q_by_users.filter(
            or_(
                cls.from_user_id != cls.real_from_user_id,
                cls.to_user_id != cls.real_to_user_id
            ) if is_higher_transaction_only else
            and_(
                cls.from_user_id == cls.real_from_user_id,
                cls.to_user_id == cls.real_to_user_id
            )
        )

        return q_by_initiators

    @classmethod
    def get_query_structure_total_by_entity_user(
            cls,
            db: Session,
            users_subq,
            date_from: Union[str, datetime],
            date_to: Union[str, datetime],
            transfer_types: List[int],
            is_higher_transaction_only: bool = False,
            transfer_direction: str = "from"
    ):
        q = cls._prepare_query_for_agent_structure_total(
            db=db,
            users_subq=users_subq,
            is_higher_transaction_only=is_higher_transaction_only,
            transfer_direction=transfer_direction
        )

        q_by_date = q.filter(
            cls.created_at >= date_from,
            cls.created_at <= date_to)

        q_by_type = q_by_date.filter(
            cls.type.in_(transfer_types))

        return q_by_type

    @classmethod
    async def async_create_transfer(cls, transfer: 'MoneyTransferModel', connection: AsyncSession = None):
        """
        use "connection" for transaction
        """
        connection = connection if connection else session()
        connection.add(transfer)
        await connection.flush()

        return transfer

    @classmethod
    async def async_update_transaction_id(
            cls,
            user_id: int,
            original_txn_id: str,
            new_txn_id: str,
            connection: AsyncSession = None
    ):
        """
        user "connection" for transaction
        """
        connection = connection if connection else session()

        statement = (
            update(cls).
            where(cls.from_user_id == user_id).
            where(cls.note == original_txn_id).
            values(note=new_txn_id)
        )

        await connection.execute(statement)

    @classmethod
    async def async_get_by_transaction_id(cls, connection: AsyncSession, transaction_id: Union[str, int]):
        query = (select(
            cls.id, cls.type, cls.from_user_id,
            cls.to_user_id, cls.value, cls.transaction_id
        ).where(cls.transaction_id == transaction_id))

        raw_result = await connection.execute(query)

        return raw_result.fetchone()

    @classmethod
    def _prepare_query(
            cls,
            db,
            with_username: bool = False,
            with_real_username: bool = False
    ):
        query = db.query(cls).select_from(cls)
        query = cls.apply_usernames_to_query(query, cls, with_username, with_real_username)

        return query

    @classmethod
    def get_structure_transfers_by_user_ids(
            cls,
            db,
            user_ids: Union[List[int]],
            date_from: datetime,
            date_to: datetime,
            transfer_types: List[int],
            is_higher_transaction_only: bool = False,
            with_username: bool = False,
            with_real_username: bool = False,
            decreasing_by_id: bool = False,
            skip: str = 0,
            limit: str = 20
    ) -> Tuple[List['MoneyTransferModel'], int]:
        subq = cls.get_transfers_by_date_type_currency_subq(
            db=db,
            date_from=date_from,
            date_to=date_to,
            transfer_types=transfer_types,
            with_username=False,
            with_real_username=False
        )
        from_user_subq = db.query(subq).filter(subq.c.from_user_id.in_(user_ids))
        to_user_subq = db.query(subq).filter(subq.c.to_user_id.in_(user_ids))

        query = from_user_subq.union(to_user_subq)
        if is_higher_transaction_only:
            query = query.filter(
                or_(
                    subq.c.from_user_id != subq.c.real_from_user_id,
                    subq.c.to_user_id != subq.c.real_to_user_id
                )
            )
        else:
            query = query.filter(
                and_(
                    subq.c.from_user_id == subq.c.real_from_user_id,
                    subq.c.to_user_id == subq.c.real_to_user_id
                )
            )

        query = cls.apply_usernames_to_query(query, subq, with_username, with_real_username)

        total_count = query.count()

        if decreasing_by_id:
            query = query.order_by(subq.c.id.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return query.all(), total_count

    @staticmethod
    def apply_usernames_to_query(main_query, selectable_model, with_username: bool, with_real_username: bool):
        query = main_query

        if with_username:
            username_from_user_aliased = aliased(EmailAuthModel)
            username_to_user_aliased = aliased(EmailAuthModel)

            from_user_id_field = (selectable_model.c.from_user_id
                                  if type(selectable_model) == Subquery else selectable_model.from_user_id)
            to_user_id_field = (selectable_model.c.to_user_id
                                if type(selectable_model) == Subquery
                                else selectable_model.to_user_id)

            query = query.add_columns(
                username_from_user_aliased.email.label('from_user_username'),
                username_to_user_aliased.email.label('to_user_username')
            )

            query = query.join(
                username_from_user_aliased,
                username_from_user_aliased.user_id == from_user_id_field,
                isouter=True
            )
            query = query.join(
                username_to_user_aliased,
                username_to_user_aliased.user_id == to_user_id_field,
                isouter=True
            )

        if with_real_username:
            username_real_from_user_aliased = aliased(EmailAuthModel)
            username_real_to_user_aliased = aliased(EmailAuthModel)

            real_from_user_id_field = (selectable_model.c.real_from_user_id
                                  if type(selectable_model) == Subquery else selectable_model.real_from_user_id)
            real_to_user_id_field = (selectable_model.c.real_to_user_id
                                if type(selectable_model) == Subquery else selectable_model.real_to_user_id)

            query = query.add_columns(
                username_real_from_user_aliased.email.label('real_from_user_username'),
                username_real_to_user_aliased.email.label('real_to_user_username')
            )

            query = query.join(
                username_real_from_user_aliased,
                username_real_from_user_aliased.user_id == real_from_user_id_field,
                isouter=True
            )
            query = query.join(
                username_real_to_user_aliased,
                username_real_to_user_aliased.user_id == real_to_user_id_field,
                isouter=True
            )

        return query


    @classmethod
    def get_transfers_by_date_type_currency_subq(
            cls,
            db,
            date_from: Union[datetime, str],
            date_to: Union[datetime, str],
            transfer_types: List[int] = None,
            currency: str = None,
            with_username: bool = False,
            with_real_username: bool = False
    ):
        query = cls._prepare_query(
            db=db,
            with_username=with_username,
            with_real_username=with_real_username
        )

        if date_from:
            query = query.filter(cls.created_at >= date_from)
        if date_to:
            query = query.filter(cls.created_at <= date_to)
        if transfer_types:
            query = query.filter(cls.type.in_(tuple(transfer_types)))
        if currency:
            query = query.filter(cls.currency == currency)

        return query.subquery()

    @classmethod
    def count_transactions_for_deposit_bonus(cls, db, user_id: int):
        q = db.query(cls.id) \
            .filter(cls.to_user_id == user_id) \
            .filter(cls.type.in_(TransferTypes.PAYMENT_TYPES))

        return q.count()
