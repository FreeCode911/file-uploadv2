from sqlalchemy import Column, Integer, String, DateTime, Numeric, ForeignKey, and_, Index
from sqlalchemy.dialects.postgresql import JSON
from sqlalchemy.orm import relationship, backref
from sqlalchemy.orm.exc import NoResultFound
from .user import UserModel
from .base import BaseModel
from .money_transfer import MoneyTransferModel
from .base import TimestampMixin, UpdateMixin
from sqlalchemy.ext.asyncio import AsyncSession


WAIT = "0"
CANCELED = "1"
CONFIRM = "2"

QIWI_SYSTEM = "qiwi"


class PaymentMixin(TimestampMixin, UpdateMixin):
    id = Column(Integer, autoincrement=True, primary_key=True)
    payment_mode = Column(String(30))
    payment_system = Column(String(30))
    currency = Column(String(5))
    payment_amount = Column(Numeric(15, 2, asdecimal=False))
    user_amount = Column(Numeric(15, 2, asdecimal=False))
    details = Column(JSON, name='details')
    date_expiration = Column(DateTime, nullable=True)
    status = Column(String(20), default=WAIT)


class PaymentTransactionModel(PaymentMixin, BaseModel):
    __tablename__ = 'payment_transaction'
    __table_args__ = (
        Index("payment_transaction_transfer_id_ix", "transfer_id"),
    )

    external_id = Column(String(30), nullable=True)
    transfer_id = Column(ForeignKey('transfer.id'), nullable=True)
    transfer = relationship(
        "MoneyTransferModel",
        backref="payment_transaction",
        foreign_keys=[transfer_id])

    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(
        "UserModel", backref="payments", foreign_keys=[user_id])

    @classmethod
    def get_by_transaction_id(cls, db,
                              transaction_id) -> 'PaymentTransactionModel':
        try:
            return db.query(cls).filter_by(id=transaction_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_transfer_id(cls, db, transfer_id) -> 'PaymentTransactionModel':
        try:
            return db.query(cls).filter_by(transfer_id=transfer_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_external_id(cls, db, external_id) -> 'PaymentTransactionModel':
        try:
            return db.query(cls).filter_by(external_id=str(external_id)).one()
        except NoResultFound:
            return None

    @classmethod
    def get_payments(cls, db, user_id, begin, end, statuses):
        q = db.query(cls).filter(
            cls.user_id == user_id
        )
        if statuses:
            q = q.filter(cls.status.in_(statuses))
        if begin:
            q = q.filter(and_(cls.created_at >= begin))
        if end:
            q = q.filter(and_(cls.created_at <= end))
        return q.all()

    @classmethod
    def count_closed_payments(cls, db, user_id: int):
        q = db.query(cls.id)\
            .filter(cls.user_id == user_id)\
            .filter(cls.transfer_id is not None)
        return q.count()

    @classmethod
    async def async_get_by_transaction_id(cls, transaction_id: str, connection: AsyncSession, with_lock: bool = False):
        select_q = select(cls).where(cls.external_id == transaction_id)
        if with_lock:
            select_q = select_q.with_for_update()
        result = await connection.execute(select_q)
        return result.scalar()

