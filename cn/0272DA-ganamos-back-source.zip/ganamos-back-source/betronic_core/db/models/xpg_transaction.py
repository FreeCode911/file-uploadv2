from datetime import datetime
from typing import List

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, SmallInteger, BigInteger, Index
from sqlalchemy.orm.session import Session
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.sql import or_

from .base import BaseModel
from .money_transfer import MoneyTransferModel
from .user import UserModel
from .email_auth import EmailAuthModel
from betronic_core.constants import TransferTypes


class XPGTransactionModel(BaseModel):
    __tablename__ = 'xpg_transactions'
    __table_args__ = (
        Index("xpg_transactions_transfer_id_ix", "transfer_id"),
        Index("xpg_transactions_cancel_transfer_id_ix", "cancel_transfer_id"),
    )

    XPG_SEQUENCE_TIP = 1001
    XPG_NOT_EXISTING_TRANSACTION = 232

    id = Column(Integer, autoincrement=True, primary_key=True)
    type = Column(SmallInteger)
    game_id = Column(BigInteger(), nullable=True)
    round_id = Column(BigInteger(), nullable=True)
    sequence = Column(SmallInteger, nullable=True)
    provider_id = Column(SmallInteger, nullable=True)
    external_transaction_id = Column(String())
    created_at = Column(DateTime, default=datetime.utcnow)

    user_id = Column(ForeignKey("user.id"), nullable=True)
    user: Mapped[UserModel] = relationship(
        UserModel,
        backref='xpg_transaction',
        foreign_keys=[user_id]
    )
    transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer: Mapped[MoneyTransferModel] = relationship(
        MoneyTransferModel,
        backref='xpg_transaction',
        foreign_keys=[transfer_id])

    cancel_transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    cancel_transfer: Mapped[MoneyTransferModel] = relationship(
        MoneyTransferModel,
        backref='xpg_cancel_transaction',
        foreign_keys=[cancel_transfer_id])

    @classmethod
    def get_by_unique_params(cls, session_db: Session, game_id: str, round_id: str,
                             user_id: int, sequence: int, provider_id: int,
                             transfer_types: list):
        query = session_db.query(cls).filter(
            cls.round_id == round_id,
            cls.game_id == game_id,
            cls.user_id == user_id,
        )
        if provider_id:
            query = query.filter(cls.provider_id == provider_id)
        if sequence:
            query = query.filter(cls.sequence == sequence)
        if transfer_types:
            query = query.filter(cls.type.in_(transfer_types))
        return query.first()

    @classmethod
    def get_by_provider_transaction_id(cls, session_db: Session, user_id: int,
                                       external_transaction_id: str) -> 'XPGTransactionModel' or None:
        if not external_transaction_id:
            return
        return session_db.query(cls).filter(cls.user_id == user_id,
                                            cls.external_transaction_id == external_transaction_id).first()

    @classmethod
    def get_canceled_transactions(cls,
                                  session_db: Session,
                                  game_id: int,
                                  round_id: int) -> List['XPGTransactionModel'] or None:
        query = session_db.query(cls) \
                .filter(cls.round_id == round_id,
                        cls.game_id == game_id,
                        cls.type.in_([TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT,
                                     TransferTypes.TYPE_XPG_CANCEL_ROUND_CREDIT]))
        return query.all()

    @classmethod
    def get_transactions_for_cancel(cls, session_db: Session,
                                    game_id: int,
                                    round_id: int,
                                    logins: List[str]) -> List['XPGTransactionModel'] or None:
        sub_query_user_ids = session_db.query(EmailAuthModel.user_id).filter(EmailAuthModel.email.in_(logins))
        query = session_db.query(cls) \
            .join(EmailAuthModel, EmailAuthModel.user_id == cls.user_id) \
            .filter(cls.round_id == round_id, cls.game_id == game_id) \
            .filter(or_(cls.sequence < cls.XPG_SEQUENCE_TIP, cls.sequence == None)) \
            .filter(cls.type.notin_([TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT,
                                     TransferTypes.TYPE_XPG_CANCEL_ROUND_CREDIT])) \
            .filter(cls.user_id.in_(sub_query_user_ids)) \
            .order_by(cls.type)
        return query.all()
