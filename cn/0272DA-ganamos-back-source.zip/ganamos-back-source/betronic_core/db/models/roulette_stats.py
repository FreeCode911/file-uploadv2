from sqlalchemy import Column
from sqlalchemy.dialects.postgresql import JSONB
from .base import BaseModel
from sqlalchemy import Date
from datetime import date


class RouletteStatsModel(BaseModel):
    __tablename__ = "roulette_stats"
    date = Column(Date, default=date.today(), primary_key=True)
    users_entered = Column(JSONB, nullable=True)
    users_played = Column(JSONB, nullable=True)
    # created_at = Column(DateTime, default=datetime.utcnow)
