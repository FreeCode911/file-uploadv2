from sqlalchemy import Column, Integer, Boolean, String, Text
from .base import BaseModel, TimestampMixin


class FeedbackFormQuestionModel(BaseModel, TimestampMixin):
    __tablename__ = "feedback_form_question"

    id = Column(Integer, autoincrement=True, primary_key=True)
    email = Column(String)
    name = Column(String)
    question = Column(Text)
    is_closed = Column(Boolean, default=False)
