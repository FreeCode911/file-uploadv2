from sqlalchemy import Column, String, ForeignKey, Integer
from sqlalchemy.orm import relationship

from .base import BaseModel
from .user import UserModel

KEY_EXPIRY_DAYS = 3


class UserPaymentsDataModel(BaseModel):

    __tablename__ = "user_payments_data"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"))
    user = relationship(
        UserModel,
        uselist=False,
        backref='payments_data',
        foreign_keys=[user_id])

    yandex_purse = Column(String, default="")
    visa_card = Column(String, default="")
    document_number = Column(String, default="")
    location = Column(String, default="")
    phone_number = Column(String, default="")
