from datetime import datetime

from sqlalchemy import Column, Integer, String, ForeignKey, DateTime
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql import func

from .base import BaseModel


class ClickModel(BaseModel):

    __tablename__ = "click"

    def __init__(self, partner_id=None, ip=None):
        self.partner_id = partner_id
        self.ip = ip

    id = Column(Integer, autoincrement=True, primary_key=True)
    partner_id = Column(ForeignKey("user.id"), nullable=False, index=True)
    ip = Column(String)
    date = Column(DateTime, default=datetime.utcnow)

    @classmethod
    def get_by_partner_id(cls, db, user_id, begin=datetime.min, end=datetime.max):
        try:
            if not begin:
                begin = datetime.min
            if not end:
                end = datetime.max
            return db.query(cls).filter(cls.partner_id == user_id)\
                .filter(cls.date > begin)\
                .filter(cls.date < end)\
                .all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_ip(cls, db, client_ip):
        try:
            return db.query(cls).filter(cls.ip == client_ip).one()
        except NoResultFound:
            return None

    @classmethod
    def get_count_by_id(cls, db, user_id):
        try:
            q = db.query(cls)
            q.filter(cls.partner_id == user_id)
            count = q.with_entities(func.count(cls.id)).scalar()
            return count
        except NoResultFound:
            return None

    @classmethod
    def registration_click(cls, db, partner_id: int, client_ip: str):
        click = ClickModel(partner_id, client_ip)
        db.add(click)
        db.commit()
