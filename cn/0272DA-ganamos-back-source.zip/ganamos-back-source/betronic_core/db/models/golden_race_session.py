from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from .base import BaseModel
from .user import UserModel


class GoldenRaceSessionModel(BaseModel):

    __tablename__ = 'golden_race_session'

    id = Column(Integer, autoincrement=True, primary_key=True)
    session = Column(String(500))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="golden_race_session", uselist=False,
                        foreign_keys=[user_id])
    create_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_by_session(cls, db, session) -> 'GoldenRaceSessionModel' or None:
        try:
            return db.query(cls).filter_by(session=session).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_user(cls, db, user_id) -> 'GoldenRaceSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None
