from datetime import datetime

from sqlalchemy import Column, String, Integer, ForeignKey, Numeric, DateTime, and_, func, or_
from sqlalchemy.exc import NoResultFound
from sqlalchemy.orm import relationship
from sqlalchemy_utils import Ltree
from .base import BaseModel
from betronic_core.db.models.user import UserModel


class CommissionPercents(BaseModel):
    __tablename__ = 'commission_percents'

    id = Column(Integer, autoincrement=True, primary_key=True)
    to_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    commission_percent = Column(Integer, nullable=True, default=0, server_default='0')

    to_account = relationship("UserModel", remote_side='UserModel.id',
                              uselist=False, foreign_keys=[to_user_id])

    def __init__(self, user_id: int, commission_percent: int):
        self.to_user_id = user_id,
        self.commission_percent = commission_percent

    @classmethod
    def get_by_user_id(cls, db, user_id):
        try:
            commission_percent = (db.query(cls)
                                  .filter(cls.to_user_id == user_id).one())
            return commission_percent
        except NoResultFound:
            return None


class CommissionBalances(BaseModel):
    __tablename__ = 'commission_balances'

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"), nullable=True, index=True)

    commission_amount = Column(Numeric(15, 2, asdecimal=False), default=0)
    netwin = Column(Numeric(15, 2, asdecimal=False), default=0)
    commission_percent = Column(Integer, nullable=True, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)

    user_account = relationship("UserModel", remote_side='UserModel.id',
                                uselist=False, foreign_keys=[user_id])
    to_user_id = Column(ForeignKey("user.id"), nullable=True)

    @classmethod
    def get_commission_balance(cls, db, date_from, date_to, admin_id, user_id, is_direct_only=True):
        if admin_id != user_id:
            total_commission = db.query(func.sum(cls.commission_amount)).filter(
                and_(cls.created_at > date_from,
                     cls.created_at <= date_to,
                     cls.to_user_id == user_id)).scalar() or 0
        elif is_direct_only:
            agents_id = [admin.id for admin in db.query(UserModel.id).filter(and_(
                UserModel.parent_agent_id == user_id,
                UserModel.role == UserModel.PARTNER_AGENT)).all()]
            total_commission = db.query(func.sum(cls.commission_amount)).filter(
                and_(cls.created_at > date_from,
                     cls.created_at <= date_to,
                     cls.to_user_id.in_(agents_id))).scalar() or 0
        else:
            total_commission = db.query(func.sum(cls.commission_amount)).filter(
                and_(cls.created_at > date_from,
                     cls.created_at <= date_to,
                     cls.user_id == user_id)).scalar() or 0

        return total_commission

    @classmethod
    def get_commissions_by_date_and_user_id(
            cls,
            db,
            date_from: datetime,
            date_to: datetime,
            to_user_id: int
    ):
        query = db.query(cls) \
            .filter(cls.created_at >= date_from) \
            .filter(cls.created_at < date_to) \
            .filter(cls.to_user_id == to_user_id)
        return query.all()