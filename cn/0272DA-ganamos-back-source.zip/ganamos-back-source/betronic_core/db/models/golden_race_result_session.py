from datetime import datetime

from sqlalchemy import Column, Integer, String, Boolean, \
    DateTime
from sqlalchemy.orm.exc import NoResultFound

from .base import BaseModel


class GoldenRaceGameCycleModel(BaseModel):
    """
        gr = golden_race
    """
    __tablename__ = 'gr_game_cycle_session'
    id = Column(Integer, autoincrement=True, primary_key=True)
    game_cycle_id = Column(String())
    is_closed = Column(Boolean, default=False, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)

    def __init__(self, game_cycle=None):
        self.game_cycle_id = game_cycle

    @classmethod
    def check_is_closed(cls, db, game_cycle_id) -> 'GoldenRaceGameCycleModel' or None:
        try:
            return db.query(cls). \
                filter(cls.game_cycle_id == game_cycle_id,
                       cls.is_closed != True).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_game_cycle_id(cls, db, game_cycle_id) -> 'GoldenRaceGameCycleModel' or None:
        try:
            return db.query(cls).filter(cls.game_cycle_id == game_cycle_id).one()
        except NoResultFound:
            return None
