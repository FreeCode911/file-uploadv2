from sqlalchemy import Integer, Column, ForeignKey, String
from .base import BaseModel, TimestampMixin
from sqlalchemy.orm import relationship


class LimitTourneyModel(BaseModel, TimestampMixin):

    __tablename__ = "betgames_auth"

    id = Column(Integer, autoincrement=True, primary_key=True)
    betgames_token = Column(String(500), nullable=True)

    user_id = Column(ForeignKey("UserModel.id"), nullable=False)
    user = relationship(
        "UserModel", backref='betgames_auth', foreign_keys=[user_id])

    @classmethod
    def get_by_ids(cls, db, ids):
        return db.query(cls).filter(cls.id.in_(ids)).all()
