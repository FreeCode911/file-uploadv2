import random
import string
from hashlib import sha512

from sqlalchemy import Integer, Column, ForeignKey, String, Boolean
from sqlalchemy.orm import relationship

from .base import BaseModel, TimestampMixin

KEY = 'ASDFSDFGDHGF'


class BetrouteRegistrationModel(BaseModel, TimestampMixin):
    __tablename__ = "betroute_registration"

    id = Column(Integer, autoincrement=True, primary_key=True)

    cash_id = Column(String, nullable=False)
    remote_password = Column(String(1024), nullable=False)
    remote_email = Column(String, nullable=False)

    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(
        "UserModel",
        back_populates="betroute_registration",
        foreign_keys=[user_id])
    is_register = Column(Boolean, default=True)

    @classmethod
    def get_by_ids(cls, db, ids):
        return db.query(cls).filter(cls.id.in_(ids)).all()

    @staticmethod
    def generate_password():
        available_chars = string.ascii_letters + string.digits + string.punctuation
        return ''.join([random.choice(available_chars) for _ in range(30)])

    def set_remote_password(self, password=None):
        hasher = sha512()
        hasher.update((password + KEY).encode('utf-8'))
        self.remote_password = hasher.hexdigest()

    def get_remote_password(self):
        if not self.remote_password:
            return None
        hasher = sha512()
        hasher.update((self.remote_password + KEY).encode('utf-8'))
        return hasher.hexdigest()
