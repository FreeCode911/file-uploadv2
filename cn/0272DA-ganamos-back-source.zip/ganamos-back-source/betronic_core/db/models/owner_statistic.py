import math
from typing import List, Optional
from datetime import datetime

from sqlalchemy import Column, Integer, SmallInteger, Numeric, \
    DateTime, ForeignKey, text, Index
from sqlalchemy import func, and_, select
from sqlalchemy.orm import Session
from sqlalchemy.sql.selectable import Subquery

from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.db.models.user import UserModel
from .base import BaseModel


class StatisticTypes:
    BALANCE = 0
    SPORT = 1
    SLOTS = 2
    LIVE_CASINO = 3
    ALL_GAMES = 4
    BONUS_BALANCE = 5
    HIGHER_BALANCE = 6

    STATS_NAMES = {
        'balance': BALANCE,
        'bonus_balance': BONUS_BALANCE,
        'higher_balance': HIGHER_BALANCE,
        'sport': SPORT,
        'slots': SLOTS,
        'all': ALL_GAMES
    }


class OwnerStatisticModel(BaseModel):
    __tablename__ = "owner_statistic"
    id = Column(Integer, autoincrement=True, primary_key=True)
    date = Column(DateTime, nullable=False, server_default=text('NOW()'))
    type = Column(SmallInteger, nullable=False, index=True)
    user_id = Column(ForeignKey("user.id"), nullable=False)
    amount_in = Column(Numeric(20, 2, asdecimal=True))
    amount_out = Column(Numeric(20, 2, asdecimal=True))
    profit = Column(Numeric(20, 2, asdecimal=True))
    transfers_count = Column(Integer)

    __table_args__ = (
        Index('ix_owner_statistic_user_id_date', 'user_id', 'date'),
    )

    def __str__(self):
        return str(self.id)

    @classmethod
    def get_statistic_by_user_ids_and_date(
            cls,
            db,
            user_ids: List[int],
            date_from: str = None,
            date_to: str = None,
            types: Optional[List[int]] = None,
            skip: int = 0,
            limit: int = 20,
    ):

        query = db.query(
            UserModel.id.label('user_id'),
            EmailAuthModel.email.label('email'),
            func.coalesce(func.sum(cls.amount_in), 0).label('amount_in'),
            func.coalesce(func.sum(cls.amount_out), 0).label('amount_out'),
            UserModel.balance.label("total")
        ).select_from(
            UserModel
        ).join(
            EmailAuthModel,
            UserModel.id == EmailAuthModel.user_id,
            isouter=True
        ).join(
            cls,
            and_(
                UserModel.id == cls.user_id,
                cls.date >= date_from,
                cls.date <= date_to
            ),
            isouter=True
        ).filter(
            UserModel.id.in_(user_ids)
        )

        if types:
            query = query.filter(cls.type.in_(types))

        query = query.group_by(UserModel.id, EmailAuthModel.email)
        total_count = query.count()
        query = query.order_by(UserModel.id)

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return query.all(), total_count

    @classmethod
    def remove_by_date(cls, db, date) -> None:
        db.query(cls).filter(cls.date == date.strftime("%Y-%m-%d")).delete()
        db.commit()
        return
    
    @classmethod
    def remove_by_date_in_portions(cls, db, date_from, date_to, chunk_size: int) -> None:
        user_count = UserModel.get_total_count(db)
        number = math.ceil(user_count / chunk_size)
        for i in range(number):
            user_ids_subquery = select(UserModel.id).limit(chunk_size).offset(chunk_size * i)
            db.query(cls).filter(
                and_(
                    cls.date >= date_from,
                    cls.date <= date_to,
                    cls.user_id.in_(user_ids_subquery)
                )
            ).delete(synchronize_session='fetch')
            db.commit()

    @classmethod
    def get_total_deposits_by_user_id(cls, db, user_id):
        total_deposits = db.query(
            func.coalesce(func.sum(cls.amount_in), 0)
        ).filter(
            and_(
                cls.user_id == user_id,
                cls.type == 0
            )
        ).scalar()

        return total_deposits
    
    @classmethod
    def prepare_query_for_agent_structure_total(
        cls,
        db: Session,
        users_subq: Subquery,
        date_from: datetime,
        date_to: datetime,
        is_higher_transaction_only: bool = False,
        is_bonus_deposits: bool = False,
        is_deposit_transfers: bool = False,
        is_withdrawal_transfers: bool = False
    ):
        q = db.query(
            func.coalesce(func.sum(cls.amount_in), 0).label('deposits_sum'),
            func.coalesce(func.sum(cls.amount_out), 0).label('withdrawals_sum')
        ).select_from(cls)

        q_by_users = q.filter(cls.user_id.in_(users_subq))

        types = []
        if is_higher_transaction_only:
            types.append(StatisticTypes.HIGHER_BALANCE)

        if is_deposit_transfers or is_withdrawal_transfers:
            types.append(StatisticTypes.BALANCE)

        if is_bonus_deposits:
            types.append(StatisticTypes.BONUS_BALANCE)

        q_by_types = q_by_users.filter(cls.type.in_(types))

        q_by_date = q_by_types.filter(
            cls.date >= date_from,
            cls.date < date_to
        )
        return q_by_date
