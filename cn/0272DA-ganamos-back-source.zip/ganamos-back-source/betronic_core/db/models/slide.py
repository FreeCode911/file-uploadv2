from datetime import datetime

from sqlalchemy import Column, Integer, String, Boolean, or_
from sqlalchemy.exc import NoResultFound
from tornado.options import options

from betronic_core.db.models.base import BaseModel


class Slide(BaseModel):

    LANGUAGE = options['LANGUAGES']
    LANGUAGES_FOR_ADMIN = options['LANGUAGES_FOR_ADMIN']

    __tablename__ = "slide"

    id = Column(Integer, autoincrement=True, primary_key=True)
    url_image = Column(String)
    url = Column(String)
    priority = Column(Integer, default=0)
    event_id = Column(Integer, default=0)
    lang = Column(Integer, nullable=True, default=LANGUAGE['es'])
    is_mobile = Column(Boolean, default=False, nullable=False)

    @classmethod
    def get_slide_by_id(cls, db, slide_id):
        try:
            return db.query(cls).filter_by(id=slide_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_slides_by_priority(cls, db, lang):
        query = db.query(cls).order_by(cls.lang, cls.priority.desc())

        if lang:
            query = query.filter(cls.lang == cls.LANGUAGE[lang])

        return query.all()

    @classmethod
    def get_slides_by_priority_and_lang(cls, db, lang: str):
        return db.query(cls) \
            .filter(cls.lang == cls.LANGUAGE[lang]) \
            .order_by(cls.priority.desc()).all()
