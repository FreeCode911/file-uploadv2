from sqlalchemy import Integer, Column, Numeric, String
from .base import BaseModel


class LimitGroupModel(BaseModel):

    __tablename__ = "limit_group"

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String)
    max_limit = Column(Numeric(10, 2, asdecimal=False))

    @classmethod
    def get_by_ids(cls, db, ids):
        return db.query(cls).filter(cls.id.in_(ids)).all()
