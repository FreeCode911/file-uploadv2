from datetime import datetime, timedelta
from typing import List

from sqlalchemy import Column, Integer, String, ForeignKey, Float, DateTime, Boolean, Index
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from .base import BaseModel


class Association(BaseModel):
    __tablename__ = "outcome_transaction_jackpot"
    outcome_transaction_id = Column(Integer, ForeignKey("outcome_transaction.id"), primary_key=True, index=True)
    jackpot_id = Column(Integer, ForeignKey("outcome_jackpot.id"), primary_key=True)
    attachments = Column(Float, nullable=False)
    outcome_transaction = relationship("OutComeTransactionModel", back_populates="jackpots")
    jackpot = relationship("JackpotModel", back_populates="transactions")
    win_jackpot = Column(Boolean, nullable=False)
    is_shown = Column(Boolean, nullable=False)

    @classmethod
    def get_record_by_jackpot_id(cls, db, jackpot_id):
        result = db.query(cls).filter(cls.win_jackpot == True, cls.jackpot_id == jackpot_id).one()
        return result


class OutComeTransactionModel(BaseModel):
    __tablename__ = "outcome_transaction"

    __table_args__ = (
        Index("outcome_transaction_transfer_id_ix", "transfer_id"),
    )
    
    id = Column(Integer, autoincrement=True, primary_key=True)
    opid = Column(String(25))
    operation_type = Column(String(10))
    amount = Column(Integer)
    player_id = Column(Integer, index=True)
    transfer_id = Column(ForeignKey("transfer.id"))
    jackpots = relationship("Association", back_populates="outcome_transaction")

    def __init__(self, opid: str, operation_type: str, amount: int, player_id: int, transfer_id: int):
        self.opid = opid
        self.operation_type = operation_type
        self.amount = amount
        self.player_id = player_id
        self.transfer_id = transfer_id

    @classmethod
    def get_jackpot_attachments_by_user(cls, db, from_user_id, jackpot):
        result = db.query(func.sum(Association.attachments)) \
            .select_from(cls) \
            .join(Association) \
            .filter(cls.player_id == from_user_id, Association.jackpot_id == jackpot.id).one()
        return result


class JackpotModel(BaseModel):
    __tablename__ = "outcome_jackpot"

    id = Column(Integer, autoincrement=True, primary_key=True)
    image = Column(String, nullable=False)
    name = Column(String(100), nullable=True)
    amount = Column(Float, nullable=False)
    is_active = Column(Boolean, nullable=False)
    is_deleted = Column(Boolean, nullable=False, default=False)
    pay = Column(Boolean, nullable=False, default=True)
    min_amount = Column(Integer, nullable=False)
    min_probability = Column(Float, nullable=False)
    max_probability = Column(Float, nullable=False)
    first_amount = Column(Float, nullable=False)
    amount_percent = Column(Float, nullable=False)
    created_at = Column(DateTime, nullable=False, default=datetime.now())
    timer = Column(Integer, nullable=True, autoincrement=False)
    transactions = relationship("Association", back_populates="jackpot")

    def __init__(self, image: str, name: str, amount: float, is_active: bool, is_deleted: bool, pay: bool,
                 min_amount: float, min_probability: float, max_probability: float, first_amount: float,
                 amount_percent: float, timer: int):
        self.image = image
        self.name = name
        self.amount = amount
        self.is_active = is_active
        self.is_deleted = is_deleted
        self.pay = pay
        self.min_amount = min_amount
        self.min_probability = min_probability
        self.max_probability = max_probability
        self.first_amount = first_amount
        self.amount_percent = amount_percent
        self.timer = timer

    @property
    def end_time(self):
        return timedelta(days=self.timer) + self.created_at if self.timer else None

    @classmethod
    def get_jackpot_list(cls, db):
        result = db.query(cls).filter(cls.is_deleted == False, cls.is_active == True).all()
        return result

    @classmethod
    def get_jackpot_by_id(cls, db, jackpot_id):
        result = db.query(cls).filter(cls.id == jackpot_id).one()
        return result

    @classmethod
    def get_user_jackpot_list(cls, db, player_id):
        result = db.query(cls) \
            .filter(cls.is_deleted == False, cls.is_active == True) \
            .filter(OutComeTransactionModel.player_id == player_id) \
            .all()
        return result

    @classmethod
    def get_not_shown_won_jackpots_by_user(cls, db, player_id: int) -> List['JackpotModel']:
        result = db.query(cls) \
            .select_from(cls) \
            .join(Association) \
            .filter(cls.is_deleted == True,
                    cls.pay == True,
                    Association.is_shown == False,
                    Association.win_jackpot == True,
                    OutComeTransactionModel.player_id == player_id) \
            .join(OutComeTransactionModel) \
            .all()

        return result

    @classmethod
    def get_list_of_jackpots_in_the_game(cls, db, player_id):
        result = db.query(cls) \
            .filter(cls.is_deleted == False, cls.is_active == True, cls.amount >= cls.min_amount) \
            .filter(OutComeTransactionModel.player_id == player_id) \
            .all()
        return result

    @classmethod
    def get_jackpot_users(cls, db, jackpot_id):
        result = db.query(OutComeTransactionModel.player_id).filter(jackpot_id == jackpot_id).distinct().all()
        return result
