from datetime import datetime as dt

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from .base import BaseModel
from .user import UserModel


class XPGSessionModel(BaseModel):

    __tablename__ = 'xpg_session'

    id = Column(Integer, autoincrement=True, primary_key=True)
    token = Column(String(500))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="xpg_session", uselist=False,
                        foreign_keys=[user_id])
    created_at = Column(DateTime, default=dt.now)
    is_registered = Column(Boolean, default=False)

    @classmethod
    def get_by_session(cls, db, user_token) -> 'XPGSessionModel' or None:
        try:
            return db.query(cls).filter_by(token=user_token).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_user(cls, db, user_id) -> 'XPGSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None
