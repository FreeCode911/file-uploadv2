from sqlalchemy import Column, Integer, String

from betronic_core.db.models.base import BaseModel


class AdsModel(BaseModel):

    __tablename__ = "ads"

    id = Column(Integer, autoincrement=True, primary_key=True)
    html = Column(String)
    priority = Column(Integer, default=0)

    @classmethod
    def get_by_priority(cls, db):
        return db.query(cls).order_by(cls.priority.desc()).all()
