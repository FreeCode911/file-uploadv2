from logging import getLogger

import datetime
import uuid
import base64
from sqlalchemy import Column, String, Integer, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from .base import BaseModel
from .email_auth import EmailAuthModel
from sqlalchemy.orm.exc import NoResultFound

logger = getLogger(__name__)

KEY_EXPIRY_DAYS = 3


class RestorePasswordRequest(BaseModel):
    SALT = "4#g0Y/Qvd)Cy?()*\W_s??fp"

    __tablename__ = "restore_password_request"

    id = Column(Integer, primary_key=True)

    email_auth_email = Column(ForeignKey("email_auth.email"), nullable=True)
    email_auth = relationship(EmailAuthModel)

    verification_key = Column(String(64))
    verification_expiry = Column(DateTime)

    @classmethod
    def get_by_verification_code(cls, db, code):
        try:
            return db.query(cls).filter_by(verification_key=code).one()
        except NoResultFound:
            return None

    @classmethod
    def disable_all_previous_by_email(cls, db, email):
        db.query(cls).filter(cls.email_auth_email == email).update({
            cls.verification_key:
            None
        })
        db.commit()

    @classmethod
    def generate_verification_key(cls):
        return uuid.uuid4().hex

    @property
    def is_verified(self):
        return not self.verification_key

    def clear_verification_key(self):
        self.verification_key = None

    def is_verification_key_expired(self):
        if not self.verification_expiry:
            return True
        return self.verification_expiry < datetime.datetime.utcnow()

    def is_verification_key_valid(self, key):
        return self.verification_key and self.verification_key == key

    def set_verification_key(self):
        self.verification_key = RestorePasswordRequest.generate_verification_key(
        )
        self.verification_expiry = datetime.datetime.utcnow(
        ) + datetime.timedelta(days=KEY_EXPIRY_DAYS)

    @staticmethod
    def decode_verification_key(code):
        s = base64.b64decode(code).decode('utf-8')
        parts = s.rsplit('_', 1)
        return parts[0], parts[1]  # email, key

    @staticmethod
    def _encode_verification_key(email, key):
        s = '%s_%s' % (email, key)
        return base64.b64encode(s.encode('utf-8')).decode("utf-8")

    def get_encoded_verification_key(self):
        return self._encode_verification_key(self.email_auth.email,
                                             self.verification_key)
