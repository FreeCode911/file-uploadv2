from sqlalchemy import Column, String, ForeignKey, Integer, Numeric
from sqlalchemy.orm import relationship

from betronic_core.db.models.base import BaseModel


class CashierDataModel(BaseModel):
    __tablename__ = 'cashier_data'

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"))
    user = relationship(
        'UserModel',
        uselist=False,
        back_populates='cashier_data',
        foreign_keys=[user_id])
    max_balance = Column(Numeric(10, 2, asdecimal=False), default=0)
    max_withdrawal = Column(Numeric(10, 2, asdecimal=False), default=0)
