from sqlalchemy import Column, String, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.ext.declarative import declared_attr
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.user import UserModel
from betronic_core.constants import Social
from .base import BaseModel


class BaseSocialMixin(object):
    external_id = Column(String(), primary_key=True)

    @declared_attr
    def user_id(cls):
        return Column(ForeignKey("user.id"))

    @declared_attr
    def user(cls):
        return relationship(UserModel, uselist=False)

    @classmethod
    def get_by_external_id(cls, db, external_id) -> 'BaseSocialMixin':
        try:
            return db.query(cls).filter_by(external_id=str(external_id)).one()
        except NoResultFound:
            return None


class GoogleAuthModel(BaseSocialMixin, BaseModel):
    __tablename__ = "google_auth"


class VkAuthModel(BaseSocialMixin, BaseModel):
    __tablename__ = 'vk_auth'


class OdnoklassnikiAuthModel(BaseSocialMixin, BaseModel):
    __tablename__ = 'odnoklassniki_auth'


class FacebookAuthModel(BaseSocialMixin, BaseModel):
    __tablename__ = 'facebook_auth'


SOCIAL_CLASSES = {
    Social.METHOD_GOOGLE: GoogleAuthModel,
    Social.METHOD_VK: VkAuthModel,
    Social.ODNOKLASSNIKI: OdnoklassnikiAuthModel,
    Social.FACEBOOK: FacebookAuthModel,
}