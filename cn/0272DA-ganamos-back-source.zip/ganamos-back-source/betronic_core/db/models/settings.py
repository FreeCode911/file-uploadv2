from datetime import datetime
from xmlrpc.client import DateTime

from sqlalchemy import Column, Integer, String, Boolean, select, update
from sqlalchemy.dialects.postgresql import JSONB
from betronic_core.db.models.base import BaseModel
from betronic_core.db.async_database import session
from sqlalchemy.ext.asyncio import AsyncSession


class SettingsModel(BaseModel):
    __tablename__ = "settings"

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String)
    data = Column(JSONB, nullable=True)

    @classmethod
    async def async_get_setting_by_name(cls, name: str, connection: AsyncSession = None):
        connection = connection or session()

        query = select(cls).where(cls.name == name)
        result_raw = await connection.execute(query)

        return result_raw.scalars().first()

    @classmethod
    def get_by_name(cls, db, name: str):
        return db.query(cls).filter(cls.name == name).first()
