from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy import Column, Integer, String
from .base import BaseModel


class Creative(BaseModel):
    __tablename__ = 'creative'

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String, nullable=False)
    parent = Column(Integer, nullable=False)
    link = Column(String, default=None)

    @classmethod
    def get_folder(cls, db, parent):
        try:
            return db.query(cls).filter_by(parent=parent).all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_id(cls, db, id):
        try:
            return db.query(cls).filter_by(id=id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_parent(cls, db, parent):
        try:
            return db.query(cls).filter_by(parent=parent).all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_ids(cls, db, ids):
        return db.query(cls).filter(cls.id.in_(ids)).all()

    def _update(self, db, fields):
        db.query(self.__class__).filter_by(id=self.id).update(fields)
