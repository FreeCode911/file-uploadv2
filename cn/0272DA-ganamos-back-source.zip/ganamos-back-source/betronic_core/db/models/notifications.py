from sqlalchemy import Column, Integer, \
    ForeignKey, Boolean, or_, \
    String

from sqlalchemy.orm import relationship
from .base import BaseModel


class Notification(BaseModel):
    __tablename__ = "notifications"

    id = Column(Integer, autoincrement=True, primary_key=True)
    from_user_id = Column(ForeignKey("users.id"), nullable=True)

    from_user = relationship(
        "UserModel", backref='notifications', foreign_keys=[from_user_id])

    text = Column(String)
    is_closed = Column(Boolean, default=False)

    @classmethod
    def get_by_user_active(cls, db, user):
        return db.query(cls).filter((cls.from_user == user) & or_(
            (cls.is_closed != True) | (cls.is_closed == None))).all()

    def __str__(self):
        return self.text


class NotificationUser(BaseModel):
    __tablename__ = "notifications_users"

    user_id = Column(ForeignKey("users.id"), nullable=False, primary_key=True)
    user = relationship(
        "UserModel", backref='notifications_user', foreign_keys=[user_id])

    notification_id = Column(
        ForeignKey("notifications.id"), nullable=False, primary_key=True)
    notification = relationship(
        "Notification",
        backref='users_notification',
        foreign_keys=[notification_id])
