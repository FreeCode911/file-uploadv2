from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from typing import List

from .base import BaseModel
from .user import UserModel


class MascotSessionModel(BaseModel):

    __tablename__ = "mascot_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    session = Column(String(100))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="mascot_session", uselist=False,
                        foreign_keys=[user_id])
    create_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_all(cls, db) -> List['MascotSessionModel']:
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id) -> 'MascotSessionModel' or None:
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_session(cls, db, session) -> 'MascotSessionModel' or None:
        try:
            return db.query(cls).filter_by(session=session).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user(cls, db, user_id) -> 'MascotSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None
