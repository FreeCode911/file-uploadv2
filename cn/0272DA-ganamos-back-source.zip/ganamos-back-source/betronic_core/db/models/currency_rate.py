from decimal import Decimal

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.exc import NoResultFound

from .base import BaseModel
from sqlalchemy import Integer, Column, String, Numeric, select
from logging import getLogger

from ..async_database import session

logger = getLogger(__name__)


class CurrencyRateModel(BaseModel):

    __tablename__ = "currency_rate"

    id = Column(Integer, autoincrement=True, primary_key=True)
    from_currency = Column(String(5))
    to_currency = Column(String(5))
    rate = Column(Numeric(12, 6, asdecimal=False))

    @classmethod
    def convert(cls, db, amount, currency, new_currency, allow_negative=False):
        try:
            if currency == new_currency:
                return amount
            if amount == 0:
                return amount
            if not allow_negative:
                if not cls._check_decimal(amount):
                    return None
            return cls._calc_currency(db, amount, currency, new_currency)
        except Exception as e:
            logger.error(
                'CurrencyRateModel: calc: Unexpected error! {}'.format(e))

    @classmethod
    def _calc_currency(cls, db, amount, currency, new_currency):
        currency_rate = db.query(cls).filter_by(
            from_currency=currency, to_currency=new_currency).first()
        if not currency_rate:
            return None
        rate = float(currency_rate.rate)
        return float(amount) * rate

    @staticmethod
    def _check_decimal(amount):
        try:
            if amount <= 0:
                logger.warning('CurrencyRateModel: calc: Incorrect amount: {}'.
                               format(amount))
                return False
            else:
                return True
        except Exception as e:
            logger.warning(
                'CurrencyRateModel: calc: Incorrect amount! e:{}'.format(e))
            return False

    @classmethod
    def get_currency_rate(cls, db, currency, new_currency):
        currency_rate = db.query(cls).filter_by(
            from_currency=currency, to_currency=new_currency).first()
        return currency_rate

    @classmethod
    async def async_convert(cls, amount, currency, new_currency, allow_negative=False):
        try:
            if currency == new_currency:
                return amount
            if amount == 0:
                return amount
            if not allow_negative:
                if not cls._check_decimal(amount):
                    return None
            return await cls._async_calc_currency(amount, currency, new_currency)
        except Exception as e:
            logger.error(
                'CurrencyRateModel: calc: Unexpected error! {}'.format(e))

    @classmethod
    async def _async_calc_currency(cls, amount, currency, new_currency, connection: AsyncSession = None,):

        connection = connection or session()

        query = select(cls).filter_by(
            from_currency=currency, to_currency=new_currency)

        result_raw = await connection.execute(query)
        currency_rate = result_raw.fetchone()[0]

        if not currency_rate:
            return None
        rate = float(currency_rate.rate)
        return float(amount) * rate