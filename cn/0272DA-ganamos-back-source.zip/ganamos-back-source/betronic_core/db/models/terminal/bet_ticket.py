from typing import Optional

from sqlalchemy import Column, Integer, ForeignKey, Boolean, String, Index
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.base import BaseModel, TimestampMixin, UpdateMixin
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel
from util.crypto import pin_from_int


class BetTicketModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "bet_ticket_model"

    __table_args__ = (
        Index("bet_ticket_model_bet_id_ix", "bet_id"),
    )
    id = Column(Integer, autoincrement=True, primary_key=True)

    bet_id = Column(ForeignKey("betroute_local_bet.id"))
    bet = relationship(BetrouteLocalBetModel, backref='bet_ticket',
                       foreign_keys=[bet_id])

    is_closed = Column(Boolean, default=False)

    pin = Column(String)

    def __init__(self):
        super().__init__()
        self.pin = pin_from_int(10, 14, start_char='0')

    @classmethod
    def get_by_pin(cls, db,  pin: str) -> Optional['BetTicketModel']:
        try:
            return db.query(cls).filter_by(pin=pin).one()
        except NoResultFound:
            return None

    def serialize_with_bet(self):
        win_amount = 0 if not self.bet.transfer_win \
            else self.bet.transfer_win.value

        return_amount = 0 if not self.bet.transfer_return \
            else self.bet.transfer_return.value

        return {
            **self.auto_dict_by_fields(['id', 'is_closed', 'pin']),
            **{'bet': self.bet.auto_dict_by_fields(['id', 'status', 'amount',
                                                    'betcode', 'created_at',
                                                    'details',
                                                    'converted_status'])},
            "win_amount": win_amount,
            "return_amount": return_amount
        }
