from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.city import City


class CashBox(BaseModel):
    __tablename__ = "cashbox"

    id = Column(Integer, autoincrement=True, primary_key=True)
    address = Column(String(350), default="")

    city_id = Column(ForeignKey("city.id"), nullable=True)
    city = relationship("City", foreign_keys=[city_id])
