from betronic_core.db.models.base import BaseModel, TimestampMixin, UpdateMixin
from betronic_core.db.models.money_transfer import MoneyTransferModel
from sqlalchemy import Column, Integer, String, Index, ForeignKey, Sequence
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound
from util.crypto import pin_from_int


class CreditTicketModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "credit_ticket"
    __table_args__ = (
        Index("credit_ticket_transfer_out_id_ix", "transfer_out_id"),
        Index("credit_ticket_transfer_in_id_ix", "transfer_in_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)

    transfer_out_id = Column(ForeignKey("transfer.id"))
    transfer_out = relationship(
        MoneyTransferModel,
        backref='ticket_transfer_out',
        foreign_keys=[transfer_out_id])

    transfer_in_id = Column(ForeignKey("transfer.id"))
    transfer_in = relationship(
        MoneyTransferModel,
        backref='ticket_transfer_in',
        foreign_keys=[transfer_in_id])

    pin = Column(String(12), index=True)

    @classmethod
    def get_by_name(cls, db, name):
        try:
            return db.query(cls).filter_by(id_name=name).one()
        except NoResultFound:
            return None

    @staticmethod
    def get_next_id(db):
        return db.execute(Sequence('credit_ticket_id_seq'))

    @staticmethod
    def generate_pin(number):
        return pin_from_int(number, l=8, start_char='1')

    @classmethod
    def get_by_pin(cls, db, pin):
        try:
            return db.query(cls).filter_by(pin=pin).one()
        except NoResultFound:
            return None
