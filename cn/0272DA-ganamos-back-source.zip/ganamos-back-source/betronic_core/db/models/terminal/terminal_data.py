from sqlalchemy import Column, Integer, String, ForeignKey, Numeric
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.base import BaseModel


class TerminalData(BaseModel):

    __tablename__ = "terminal_data"

    def __init__(self, user: 'UserModel'=None) -> 'TerminalData':
        super(TerminalData, self).__init__()
        if user:
            self.user = user

    id = Column(Integer, autoincrement=True, primary_key=True)
    min_bet_amount = Column(Numeric(10, 2, asdecimal=False), default=10)

    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(
        "UserModel", back_populates="terminal_data", foreign_keys=[user_id])

    @classmethod
    def get_by_user_id(cls, db, user_id):
        try:
            return db.query(cls).filter(cls.user_id == user_id).first()
        except NoResultFound:
            return None
