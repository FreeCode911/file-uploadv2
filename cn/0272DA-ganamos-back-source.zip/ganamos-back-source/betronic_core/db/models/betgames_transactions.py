from sqlalchemy import (
    Column, Integer, ForeignKey, String, DateTime, 
    Numeric, BigInteger, Index
)
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.base import BaseModel
from betronic_core.constants import TransferTypes
from betronic_core.db.models.betgames_session import BetGamesSessionModel


class BetgamesTransactionModel(BaseModel):
    __tablename__ = "betgames_transactions"
    __table_args__ = (
        Index("betgames_transactions_local_transaction_id_ix", "local_transaction_id"),
    )

    PAYIN = TransferTypes.TYPE_BETGAMES_PAYIN
    PAYOUT = TransferTypes.TYPE_BETGAMES_PAYIN

    TYPES = {
        PAYIN: TransferTypes.TYPES[PAYIN],
        PAYOUT: TransferTypes.TYPES[PAYOUT]
    }

    id = Column(Integer, autoincrement=True, primary_key=True)

    user_id = Column(ForeignKey('user.id'), nullable=True)
    user = relationship(
        'UserModel',
        backref='betgames_transaction_user', foreign_keys=[user_id])

    session_id = Column(ForeignKey('betgames_session.id'), nullable=True)
    session = relationship(
        BetGamesSessionModel,
        backref='betgames_transaction_session', foreign_keys=[session_id]
    )

    local_transaction_id = Column(ForeignKey('transfer.id'), nullable=True)
    local_transaction = relationship(
        'MoneyTransferModel',
        backref='betgames_transaction_local',
        foreign_keys=[local_transaction_id]
    )

    type = Column(Integer)

    remote_transaction_id = Column(BigInteger, index=True)
    remote_bet_id = Column(BigInteger, index=True)

    amount = Column(Numeric(10, 2))
    currency = Column(String(5))

    bet = Column(String)
    bet_time = Column(DateTime)
    game_id = Column(Integer)

    @classmethod
    def get_by_remote_transaction_id(cls, db, remote_t_id: int):
        try:
            return db.query(cls).filter(cls.remote_transaction_id == remote_t_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_bet_id(cls, db, remote_bet_id: int):
        try:
            return db.query(cls).filter(cls.remote_bet_id == remote_bet_id).all()
        except NoResultFound:
            return None
