from datetime import datetime

from sqlalchemy import func
from sqlalchemy import Column, Integer, ForeignKey, DateTime, Boolean
from sqlalchemy.orm import relationship, Session

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel


class BonusBalanceBurnModel(BaseModel):
    __tablename__ = "bonus_balance_burn"

    id = Column(Integer, primary_key=True)

    user_id = Column(Integer, ForeignKey(UserModel.id), nullable=False)
    bonus_transfer_id = Column(Integer, ForeignKey(BonusTransferModel.id), nullable=True, unique=True)
    is_active = Column(Boolean, default=True, nullable=False, index=True)

    user = relationship(UserModel, foreign_keys=[user_id])
    bonus_transfer = relationship(BonusTransferModel, foreign_keys=[bonus_transfer_id])

    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    closed_at = Column(DateTime, nullable=True, index=True)
    expire_at = Column(DateTime, nullable=False, index=True)

    @classmethod
    def get_all_active_order_by_date(cls, db: Session):
        return db.query(cls).order_by(cls.is_active == False).order_by(cls.created_at).all()

    @classmethod
    def get_inactive_burns_sum_from_date(cls, db: Session, user_id: int, date_from: datetime):
        query = db.query(
            func.sum(cls.bonus_amount)
        ).filter(
            cls.user_id == user_id,
            cls.closed_at > date_from,
            cls.is_active == False
        )

        return query.scalar() or 0
