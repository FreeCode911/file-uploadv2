from datetime import datetime
from typing import List, Union

from sqlalchemy import Column, Integer, Numeric, String, DateTime, ForeignKey, SmallInteger
from sqlalchemy.orm import relationship, aliased
from sqlalchemy.sql import Subquery

from .base import BaseModel
from .email_auth import EmailAuthModel


class AgentPaymentStatisticModel(BaseModel):
    __tablename__ = "agent_payment_statistic"

    id = Column(Integer, autoincrement=True, primary_key=True)
    type = Column(SmallInteger)
    amount = Column(Numeric(15, 2, asdecimal=False), nullable=False)
    count = Column(Integer, nullable=False)
    currency = Column(String(5))
    from_user_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    from_user = relationship(
        'UserModel',
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[from_user_id]
    )
    to_user_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    to_user = relationship(
        'UserModel',
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[to_user_id]
    )
    created_at = Column(DateTime, default=datetime.utcnow)

    @classmethod
    def get_transfers_by_date_type_currency_subq(
            cls,
            db,
            date_from: Union[datetime, str],
            date_to: Union[datetime, str],
            transfer_types: List[int] = None,
            currency: str = None,
            with_username: bool = False,
            with_real_username: bool = False
    ):
        query = cls._prepare_query(
            db=db,
            with_username=with_username,
            with_real_username=with_real_username
        )

        if date_from:
            query = query.filter(cls.created_at >= date_from)
        if date_to:
            query = query.filter(cls.created_at <= date_to)
        if transfer_types:
            query = query.filter(cls.type.in_(tuple(transfer_types)))
        if currency:
            query = query.filter(cls.currency == currency)

        return query.subquery()

    @classmethod
    def _prepare_query(
            cls,
            db,
            with_username: bool = False,
            with_real_username: bool = False
    ):
        query = db.query(cls).select_from(cls)
        query = cls.apply_usernames_to_query(query, cls, with_username, with_real_username)

        return query

    @staticmethod
    def apply_usernames_to_query(main_query, selectable_model, with_username: bool, with_real_username: bool):
        query = main_query

        if with_username:
            username_from_user_aliased = aliased(EmailAuthModel)
            username_to_user_aliased = aliased(EmailAuthModel)

            from_user_id_field = (selectable_model.c.from_user_id
                                  if type(selectable_model) == Subquery else selectable_model.from_user_id)
            to_user_id_field = (selectable_model.c.to_user_id
                                if type(selectable_model) == Subquery
                                else selectable_model.to_user_id)

            query = query.add_columns(
                username_from_user_aliased.email.label('from_user_username'),
                username_to_user_aliased.email.label('to_user_username')
            )

            query = query.join(
                username_from_user_aliased,
                username_from_user_aliased.user_id == from_user_id_field,
                isouter=True
            )
            query = query.join(
                username_to_user_aliased,
                username_to_user_aliased.user_id == to_user_id_field,
                isouter=True
            )

        if with_real_username:
            username_real_from_user_aliased = aliased(EmailAuthModel)
            username_real_to_user_aliased = aliased(EmailAuthModel)

            real_from_user_id_field = (selectable_model.c.real_from_user_id
                                       if type(selectable_model) == Subquery else selectable_model.real_from_user_id)
            real_to_user_id_field = (selectable_model.c.real_to_user_id
                                     if type(selectable_model) == Subquery else selectable_model.real_to_user_id)

            query = query.add_columns(
                username_real_from_user_aliased.email.label('real_from_user_username'),
                username_real_to_user_aliased.email.label('real_to_user_username')
            )

            query = query.join(
                username_real_from_user_aliased,
                username_real_from_user_aliased.user_id == real_from_user_id_field,
                isouter=True
            )
            query = query.join(
                username_real_to_user_aliased,
                username_real_to_user_aliased.user_id == real_to_user_id_field,
                isouter=True
            )

        return query