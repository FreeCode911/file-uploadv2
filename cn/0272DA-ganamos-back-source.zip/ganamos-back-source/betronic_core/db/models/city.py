from sqlalchemy import Column, Integer, String

from .base import BaseModel


class City(BaseModel):

    __tablename__ = "city"

    def __init__(self, name: str):
        super(City, self).__init__()
        if name:
            self.name = name

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String(350), default="")
