from .base import BaseModel, TimestampMixin
from sqlalchemy import (
    Integer, Column, ForeignKey, 
    String, Boolean, Numeric, DateTime,
    Index,
)


class BetContentDataModel(BaseModel, TimestampMixin):

    __tablename__ = "bet_content_data"
    __table_args__ = (
        Index("bet_content_data_local_bet_id_ix", "local_bet_id"),
    )
    id = Column(Integer, autoincrement=True, primary_key=True)
    local_bet_id = Column(Integer, ForeignKey('betroute_local_bet.id'))

    lines_id = Column(Integer, default=0)
    count_results = Column(Integer, default=0)
    outcome = Column(Integer, default=0)
    tournament_name = Column(String, default='')
    is_bonus = Column(Boolean, default='')
    coef_orig = Column(Numeric(10, 2), default='')
    coef = Column(Numeric(10, 2), default='')
    bet_name = Column(String, default='')
    result = Column(String, default='')
    sport_id = Column(Integer, default='')
    is_live = Column(Boolean, default='')
    event_date = Column(DateTime(timezone=True))
    site_bet_id = Column(String, default='')
    teams = Column(String, default='')
    main_result = Column(String, default='')
    is_express = Column(Boolean, default='')
