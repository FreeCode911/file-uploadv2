from datetime import datetime
from random import choices
from string import ascii_uppercase
from string import digits

from sqlalchemy import Column, String, Integer, Boolean, DateTime, ForeignKey, Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship, backref
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.sql import and_, or_
from sqlalchemy.sql import expression
from tornado.options import options

from .base import BaseModel
from .bonus_transfer import BonusTransferModel
from .money_transfer import MoneyTransferModel
from .user import UserModel


class PromoCodeModel(BaseModel):
    __tablename__ = "promo_code"

    TYPE_NORMAL = '0'
    TYPE_PERCENT = '1'
    TYPE_STOBONUS = '2'
    TYPE_SPORT_CASHBACK = '3'
    TYPE_PRAGMATIC_FREESPINS = '4'

    TYPES = {
        TYPE_SPORT_CASHBACK: 'Cashback for sport',
        TYPE_PRAGMATIC_FREESPINS: 'Pragmatic Freespins'
    }
    PROMO_TYPE = [TYPE_NORMAL, TYPE_PERCENT, TYPE_STOBONUS]

    id = Column(Integer, autoincrement=True, primary_key=True)
    code = Column(String(256), nullable=False, unique=True)
    code_type = Column(String(), nullable=False, default=TYPE_NORMAL,
                       server_default=TYPE_NORMAL)
    amount = Column(Integer, nullable=False)
    available_to = Column(DateTime)
    is_bonus = Column(Boolean, nullable=False,
                      server_default=expression.true(), default=False)
    single_activation = Column(Boolean, nullable=False,
                               server_default=expression.false(), default=False)
    partner_id = Column(ForeignKey(UserModel.id), nullable=True, unique=True)
    partner = relationship(UserModel, backref=backref('partner_id'))
    is_banned = Column(Boolean, default=False, nullable=True)
    additional_data = Column(JSONB, nullable=True)

    @classmethod
    def get_by_code(cls, db, code):
        return db.query(cls).filter(cls.code == code).first()

    @classmethod
    def get_by_partner_id(cls, db, partner_id):
        return db.query(cls).filter(cls.partner_id == partner_id).first()

    @classmethod
    def new_partner_promo_code(cls, user_id=None, amount=0, code_type=TYPE_NORMAL):
        partner_promo_code = cls(
            code=cls.generate_code(),
            code_type=code_type,
            amount=amount,
            partner_id=user_id
        )
        return partner_promo_code

    @classmethod
    def is_actual(cls, db, code):
        promo_code = db.query(cls).filter(cls.code == code).first()
        if promo_code.available_to < datetime.today():
            return False
        return True

    @classmethod
    def remove_all(cls, db):
        try:
            [db.delete(x) for x in db.query(cls).filter(cls.code != options.STOBONUS_DEFAULT_PROMOCODE)]
        except NoResultFound:
            pass
        return None

    @staticmethod
    def generate_code():
        code = ''.join(choices(ascii_uppercase, k=4)).join(choices(digits, k=2))
        return code


class PromoCodeActivationModel(BaseModel):
    __tablename__ = "promo_codes_activation"
    __table_args__ = (
        Index("promo_codes_activation_transfer_id_ix", "transfer_id"),
        Index("promo_codes_activation_bonus_transfer_id_ix", "bonus_transfer_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey(UserModel.id), nullable=True)
    user = relationship(UserModel, backref=backref('promo_bonus_activation'))
    promo_code_id = Column(ForeignKey(PromoCodeModel.id), nullable=True)
    promo_code = relationship(
        PromoCodeModel, backref=backref('promo_code_activation'))

    transfer_id = Column(ForeignKey(MoneyTransferModel.id), nullable=True)
    transfer = relationship(
        MoneyTransferModel, backref=backref('promo_real_activation'))

    bonus_transfer_id = Column(ForeignKey(BonusTransferModel.id),
                               nullable=True)
    bonus_transfer = relationship(
        BonusTransferModel,  backref=backref('promo_bonus_activation'))

    is_banned = Column(Boolean, nullable=True, default=False)
    is_hidden = Column(Boolean, nullable=True, default=False)
    is_closed = Column(Boolean, nullable=True, default=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=True)

    additional_data = Column(JSONB, nullable=True)
    note = Column(String(), nullable=True)

    @classmethod
    def get_by_user_and_promo_code(cls, db, user_id, promo_code_id):
        return db.query(cls).filter(
            and_(cls.user_id == user_id, cls.promo_code_id ==
                 promo_code_id)).first()

    @classmethod
    def get_by_user_id(cls, db, user_id: int):
        promo_code = db.query(cls).filter(cls.user_id == user_id).first()
        return promo_code

    @classmethod
    def get_by_user_and_code(cls, db, user_id: int, code: str):
        promo_code = db.query(cls, PromoCodeModel.code)\
            .join(PromoCodeModel)\
            .filter(cls.user_id == user_id)\
            .filter(PromoCodeModel.code == code)\
            .scalar()

        return promo_code

    @classmethod
    def get_all_user_activations(cls, db, user_id: int):
        result = db.query(cls).filter(cls.user_id == user_id).all()
        return result

    @classmethod
    def get_stobonus_by_user_id(cls, db, user_id: int):
        result = db.query(cls, PromoCodeModel.code_type) \
            .join(PromoCodeModel) \
            .filter(cls.user_id == user_id) \
            .filter(PromoCodeModel.code_type == PromoCodeModel.TYPE_STOBONUS) \
            .first()
        return result[0] if result else None

    @classmethod
    def get_promocode_history_by_user(cls, db, user_id: int):
        return db\
            .query(PromoCodeActivationModel) \
            .filter(PromoCodeActivationModel.user_id == user_id) \
            .filter(PromoCodeActivationModel.is_hidden != True) \
            .all()

    @classmethod
    def get_by_promo_code(cls, db, promo_code_id):
        return db.query(cls).filter(cls.promo_code_id == promo_code_id).first()

    @classmethod
    def get_all_by_user_for_date(cls, db, user_id, date):
        query = db.query(cls, MoneyTransferModel.created_at,
                         MoneyTransferModel.created_at) \
            .outerjoin(
                MoneyTransferModel, cls.transfer_id == MoneyTransferModel.id)\
            .outerjoin(MoneyTransferModel,
                       cls.transfer_bonus_id == MoneyTransferModel.id) \
            .filter(cls.user_id == user_id,
                    or_(MoneyTransferModel.created_at > date,
                        MoneyTransferModel.created_at > date))
        return query.all()

    def get_stobonus_coefs(self):
        return self.additional_data.get('STOBONUS_FIRST_PAYMENT_MULTIPLIER'), \
               self.additional_data.get('STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER')

    def get_stobonus_min_coef(self):
        return self.additional_data.get('SETOBONUS_MIN_BET_COEF')

    def set_stobonus_coefs(self,
                           first_payment_coef=None,
                           target_bet_coef=None,
                           min_bet_coef=None):
        self.additional_data['STOBONUS_FIRST_PAYMENT_MULTIPLIER'] = \
            first_payment_coef or options.STOBONUS_FIRST_PAYMENT_MULTIPLIER
        self.additional_data['STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER'] = \
            target_bet_coef or options.STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER
        self.additional_data['SETOBONUS_MIN_BET_COEF'] = \
            min_bet_coef or options.SETOBONUS_MIN_BET_COEF

    def _get_type_0_amount(self):
        return str(self.promo_code.amount) + ' ' + options.PROMOCODE_CURRENCY

    def _get_type_1_amount(self):
        return str(self.promo_code.amount) + ' %'

    def _get_type_2_amount(self):
        fp_coef, tb_coef = self.get_stobonus_coefs()
        min_bet_coef = self.get_stobonus_min_coef()

        return 'x' + str(fp_coef) + ' Депозит / x' + str(tb_coef) + \
               ' Отыгрыш / x' + str(min_bet_coef) + ' Мин. коеф.'

    def get_amount(self):
        if not self.promo_code_id:
            return '?'

        get_function = getattr(
            self, '_get_type_' + self.promo_code.code_type + '_amount')
        return get_function()

    def _get_filled_0_amount(self):
        return str(self.transfer.value) + ' ' + self.transfer.currency

    def _get_filled_1_amount(self):
        db = Session.object_session(self)
        amount = MoneyTransferModel.get_full_bonus_amount(db, self.user_id)

        return str(amount) + ' ' + self.user.currency

    def _get_filled_2_amount(self):
        if not self.transfer_id:
            return '0 ' + self.user.currency
        return str(self.transfer.value) + ' ' + self.user.currency

    def get_already_filled(self):
        if not self.promo_code_id:
            return '?'

        get_function = getattr(self, '_get_filled_' +
                               self.promo_code.code_type + '_amount')
        return get_function()
