from betronic_core.db.models.base import BaseModel
from sqlalchemy import Column, String, Boolean, Integer


class CategoryModel(BaseModel):
    __tablename__ = 'category'

    id = Column(Integer, unique=True, primary_key=True)
    name = Column(String)
    active = Column(Boolean, default=True)
