import string
from datetime import datetime
from typing import List, Optional, Tuple, Union
from decimal import Decimal

from sqlalchemy import Column, Integer, String, DateTime, Boolean, \
    BigInteger, Numeric, or_, ForeignKey, update, select
from sqlalchemy.orm import relationship, aliased, Session, Mapped
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy_utils import LtreeType, Ltree
from sqlalchemy import Index, func
from sqlalchemy.sql import expression
from sqlalchemy.ext.asyncio import AsyncSession
from tornado.options import options
from betronic_core.db.models.terminal.terminal_data import TerminalData
from betronic_core.constants import PartnerTypePayment
from betronic_core.db.async_database import session
from .base import BaseModel
from .additional_data import AdditionalData
from .terminal.cashbox import CashBox
from .betroute_registration import BetrouteRegistrationModel
from .email_auth import EmailAuthModel
from betronic_core.db.models.cashier_data import CashierDataModel
from sqlalchemy import and_


class UserModel(BaseModel):
    __tablename__ = "user"
    __table_args__ = (
        Index('ix_nodes_path', "structure_path", postgresql_using="gist"),
    )

    ORGANIZATION_ID = -1
    PAYMENTS_ID = -2
    WITHDRAWAL_ID = -3
    TICKET_USER_ID = -4
    BILL_ACCEPTOR_ID = -6
    MARKETING_OWNER_ID = -7
    REVENUE_BALANCE_ID = -8

    USER = '0'
    CASHIER = '1'
    ADMIN = '2'
    SUPER_ADMIN = '3'
    LIMITED_OWNER = '4'
    OWNER = '5'
    PARTNER_AGENT = '6'
    TECHSUPPORT = '7'

    # Role for service-to-service communication with Bets service.
    BACKEND = 10

    USER_TYPES = {"USER": '0', "TERMINAL": '1', "CARD": '2'}

    ROLES = {USER: 'Пользователь', CASHIER: 'Кассир',
             ADMIN: 'Администратор', SUPER_ADMIN: 'Супер-Администратор',
             LIMITED_OWNER: 'Ограниченный владелец',
             OWNER: 'Владелец', PARTNER_AGENT: 'Агент'}

    ADMIN_ROLES = {
        SUPER_ADMIN: 'Cупер-Администратор',
        ADMIN: 'Администратор',
    }

    ROLES_FOR_MINI_ADMIN_URLS = {
        'player': CASHIER,
        'cashier': ADMIN
    }

    ROLES_FOR_BLUE_ADMIN_REGISTRATION = {
        USER: 'Пользователь',
        PARTNER_AGENT: 'Агент'
    }

    EXCLUDE_USER_IDS_FOR_INTERACTION = [REVENUE_BALANCE_ID]

    id = Column(Integer, autoincrement=True, primary_key=True)
    first_name = Column(String(60))
    middle_name = Column(String)
    last_name = Column(String(60))
    nickname = Column(String(60), unique=True)
    role = Column(
        String(1), default=USER, server_default=USER)
    type = Column(
        String(10),
        default=USER_TYPES['USER'],
        server_default=USER_TYPES['USER']
    )
    parent_cashier_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    parent_admin_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    parent_suadmin_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)

    parent_agent_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    parent_agent = relationship(
        'UserModel',
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[parent_agent_id]
    )

    structure_path = Column(LtreeType, nullable=True)  # TODO Add descendants relationship
    structure_is_banned = Column(Boolean, default=False, nullable=False)

    p_cashier = relationship('UserModel', remote_side='UserModel.id', uselist=False,
                             foreign_keys=[parent_cashier_id])

    p_admin = relationship('UserModel', remote_side='UserModel.id', uselist=False,
                           foreign_keys=[parent_admin_id])

    p_suadmin = relationship('UserModel', remote_side='UserModel.id', uselist=False,
                             foreign_keys=[parent_suadmin_id])

    is_visible = Column(Boolean(), default=True, nullable=False,
                        server_default=expression.true())

    is_withdrawal_access = Column(Boolean, default=True, server_default=expression.true(), nullable=False)
    is_deposit_access = Column(Boolean, default=True, server_default=expression.true(), nullable=False)

    first_visit = Column(DateTime, default=datetime.utcnow, index=True)
    last_visit = Column(DateTime)

    email_auth: Mapped[EmailAuthModel] = relationship(
        EmailAuthModel, uselist=False, back_populates="user", lazy='select')
    additional_data: Mapped[AdditionalData] = relationship(
        AdditionalData,
        uselist=False,
        back_populates="user",
        cascade="save-update, merge, expunge", lazy='select')

    betroute_registration: Mapped[BetrouteRegistrationModel] = relationship(
        BetrouteRegistrationModel,
        uselist=False,
        back_populates="user",
        cascade="save-update, merge, expunge", lazy='select')

    terminal_data: Mapped[TerminalData] = relationship(
        TerminalData,
        uselist=False,
        back_populates="user",
        cascade="save-update, merge, expunge", lazy='select')

    cashbox_id = Column(Integer, ForeignKey('cashbox.id'))
    cashbox: Mapped[CashBox] = relationship(CashBox)

    cashier_data: Mapped[CashierDataModel] = relationship(
        CashierDataModel,
        uselist=False,
        back_populates='user',
        cascade='save-update, merge, expunge', lazy='select')

    currency = Column(String(5), nullable=False)
    original_currency = Column(String)
    access_ip = Column(String(50))
    lang = Column(String(10), default='ru-ru')

    is_banned = Column(Boolean, default=False, nullable=True)
    balance = Column(Numeric(15, 2, asdecimal=False), default=0)
    bonus_balance = Column(Numeric(10, 2, asdecimal=False), default=0)

    note = Column(String(2000), nullable=True)

    forgot_password_key = Column(String(50))
    forgot_password_key_expiry = Column(BigInteger)

    preferred_language = Column(String(10), nullable=True)

    referral_id = Column(Integer, ForeignKey('user.id'), nullable=True)
    referral = relationship(
        'UserModel', uselist=False,
        remote_side=[id],
        foreign_keys=[referral_id])

    is_partner = Column(Boolean, default=False)

    type_partner_payment = Column(Integer, default=PartnerTypePayment.BET)

    last_change_type_partner_payment = Column(DateTime)

    partner_pay_bet = Column(
        Numeric(10, 2, asdecimal=False), default=options.PARTNER_PAYMENT_BET)
    partner_pay_top_up = Column(
        Numeric(10, 2, asdecimal=False), default=options.PARTNER_PAYMENT_TOP_UP)
    partner_pay_traffic = Column(
        Numeric(10, 2, asdecimal=False), default=options.PARTNER_PAYMENT_TRAFFIC)
    partner_pay_registration = Column(
        Numeric(10, 2, asdecimal=False), default=options.PARTNER_PAYMENT_REGISTRATION)
    partner_balance = Column(Numeric(10, 2, asdecimal=False), default=0)

    promo_code = Column(String())

    changed_password = Column(Boolean, default=True, nullable=False, server_default=expression.true())
    can_create_only_player = Column(
        Boolean, default=False, server_default=expression.false()
    )

    sub_users_mapper = {
        SUPER_ADMIN: ADMIN,
        ADMIN: CASHIER,
        CASHIER: USER
    }

    parent_id_mapper = {
        SUPER_ADMIN: parent_suadmin_id,
        ADMIN: parent_admin_id,
        CASHIER: parent_cashier_id
    }

    @property
    def serialize(self):
        return {
            'id': self.id,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'username': self.nickname,
            'email': self.additional_data.email or '',
            'role': self.role,
            'balance': self.balance,
            'bonus_balance': self.bonus_balance,
            'currency': self.currency,
            'parent_agent_id': self.parent_agent_id,
            'structure_path': self.structure_path.path,
            'structure_is_banned': self.structure_is_banned,
            'note': self.note,
            'is_banned': self.is_banned,
            'is_visible': self.is_visible,
            'is_withdrawal_access': self.is_withdrawal_access,
            'is_deposit_access': self.is_deposit_access,
            'first_visit': self.first_visit.strftime('%Y-%m-%d %H:%M:%S') if self.first_visit else "",
            'last_visit': self.last_visit.strftime('%Y-%m-%d %H:%M:%S') if self.last_visit else "",
            'updated_at': self.additional_data.updated_at.strftime('%Y-%m-%d %H:%M:%S')
            if self.additional_data.updated_at else "",
            'can_create_only_player': self.can_create_only_player
        }

    @property
    def referrals(self) -> List['UserModel']:
        return self.user_referrals

    @property
    def is_active(self):
        return False if self.email_auth.verification_key else True

    @property
    def is_admin(self):
        return True if self.role == self.ADMIN else False

    @property
    def is_user(self):
        return self.type == self.USER_TYPES['USER']

    @property
    def get_currency(self) -> str:
        return str(self.original_currency or self.currency)

    @classmethod
    def get_referrals_by_user_id(cls, db, user_id: int, begin=datetime.min,
                                 end=datetime.max) -> Optional[List['UserModel']]:
        try:
            if not begin:
                begin = datetime.min
            if not end:
                end = datetime.max
            return db.query(cls) \
                .filter(cls.referral_id == user_id) \
                .filter(cls.first_visit > begin) \
                .filter(cls.first_visit < end) \
                .all()
        except NoResultFound:
            return None

    @classmethod
    def get_specific_columns_by_id(cls, db, user_id, *args):
        return db.query(*args).filter(cls.id == user_id).first()

    @classmethod
    def get_by_id(cls, db, user_id: int) -> 'UserModel' or None:
        try:
            return db.query(cls).filter_by(id=user_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_ids(cls, db, user_ids) -> 'UserModel' or None:
        try:
            return db.query(cls).filter(cls.id.in_(user_ids)).all()
        except NoResultFound:
            return None

    @classmethod
    def get_by_id_with_lock(cls, db, user_id) -> 'UserModel' or None:
        row = db.query(cls).with_for_update().filter(cls.id == user_id).first()
        db.refresh(row) if row else None
        return row

    @classmethod
    def get_by_login_with_lock(cls, db, login: str) -> 'UserModel' or None:
        row = (
            db.query(cls)
            .join(EmailAuthModel)
            .with_for_update(of=cls)
            .filter(EmailAuthModel.email == login).first()
        )
        return row
    
    @classmethod
    def get_partner_by_id(cls, db, partner_id: int) -> 'UserModel' or None:
        try:
            return db.query(cls).filter(cls.id == partner_id).filter(cls.is_partner).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_email(cls, db, email) -> 'UserModel' or None:
        try:
            return db.query(cls).join(EmailAuthModel).filter(
                EmailAuthModel.email == email).first()
        except NoResultFound:
            return None

    @classmethod
    def get_by_phone(cls, db, phone) -> 'UserModel' or None:
        try:
            return db.query(cls).join(EmailAuthModel).filter(
                EmailAuthModel.email == str(phone)).first()
        except NoResultFound:
            return None

    @classmethod
    def get_all_partners(cls, db) -> List['UserModel']:
        return db.query(cls).filter(cls.is_partner == True).all()

    @classmethod
    def get_partners_by_payment(cls, db, payment_type) -> List['UserModel']:
        return db.query(cls).filter(
            cls.type_partner_payment == payment_type,
            cls.is_partner == True).all()

    def get_full_name(self) -> str:
        return '%s %s %s' % (self.last_name, self.first_name, self.middle_name)

    def get_personal_data(self) -> AdditionalData:
        return self.additional_data

    @classmethod
    def remove_all_users(cls, db) -> None:
        [db.delete(item) for item in db.query(cls).filter(cls.id > 0).all()]

    @classmethod
    def get_binding_users(cls, db, id, role, count=False):
        user_list = None
        if role == UserModel.CASHIER:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.parent_cashier_id == id)
        elif role == UserModel.ADMIN:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.parent_admin_id == id)
        elif role == UserModel.SUPER_ADMIN:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.parent_suadmin_id == id)
        if user_list:
            if count:
                user_list = user_list.count()
            else:
                user_list = user_list.all()
        return user_list

    @classmethod
    def get_binding_users_by_role(cls, db, id, role, count=False):
        user_list = None
        if role == UserModel.CASHIER:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.role == UserModel.USER,
                        cls.parent_cashier_id == id)
        elif role == UserModel.ADMIN:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.role == UserModel.CASHIER,
                        cls.parent_admin_id == id)
        elif role == UserModel.SUPER_ADMIN:
            user_list = db.query(cls) \
                .filter(cls.is_banned != True,
                        cls.role == UserModel.ADMIN,
                        cls.parent_suadmin_id == id)
        if user_list:
            if count:
                user_list = user_list.count()
            else:
                user_list = user_list.all()
        return user_list

    @classmethod
    def get_users_by_cashier_id(cls, db, cashier_id):
        user_list = db.query(cls) \
            .filter(and_(cls.parent_cashier_id == cashier_id,
                         cls.role == UserModel.USER))
        if user_list:
            quantity = user_list.count()
            users = user_list.all()
            return users, quantity

    @classmethod
    def get_cashiers_by_admin_id(cls, db, admin_id):
        cashier_list = db.query(cls) \
            .filter(and_(cls.parent_admin_id == admin_id,
                         cls.role == UserModel.CASHIER))
        if cashier_list:
            quantity = cashier_list.count()
            cashiers = cashier_list.all()
            return cashiers, quantity

    @classmethod
    def get_admins_by_admin_id(cls, db, admin_id):
        admin_list = db.query(cls) \
            .filter(and_(cls.parent_suadmin_id == admin_id,
                         cls.role == UserModel.ADMIN))
        if admin_list:
            quantity = admin_list.count()
            admins = admin_list.all()
            return admins, quantity

    @classmethod
    def get_descendants(cls, db, admin_id, admin_role, with_username=False):
        if not with_username:
            q = db.query(UserModel.id)
        else:
            q = db.query(UserModel.id.label("user_id"), EmailAuthModel.email.label("username")) \
                .join(EmailAuthModel, EmailAuthModel.user_id == UserModel.id)
        descendants_list = []
        if admin_role == UserModel.OWNER:
            descendants_list = q.filter(cls.role == UserModel.SUPER_ADMIN).all()
        if admin_role == UserModel.ADMIN:
            descendants_list = q.filter(and_(cls.parent_admin_id == admin_id,
                                             cls.role == UserModel.CASHIER)).all()
        elif admin_role == UserModel.CASHIER:
            descendants_list = q.filter(and_(cls.parent_cashier_id == admin_id,
                                             cls.role == UserModel.USER)).all()
        elif admin_role == UserModel.SUPER_ADMIN:
            descendants_list = q.filter(and_(cls.parent_suadmin_id == admin_id,
                                             cls.role == UserModel.ADMIN)).all()
        descendants = []
        if with_username:
            for item in descendants_list:
                element = {"user_id": item.user_id, "username": item.username}
                descendants.append(element)
        else:
            descendants = [item.id for item in descendants_list]
        return descendants

    @classmethod
    def get_by_nickname(cls, db, nickname: str) -> 'UserModel' or None:
        try:
            return db.query(cls).filter_by(nickname=nickname).one()
        except NoResultFound:
            return None

    @classmethod
    def check_role_by_id(cls, db, user_id: int, role: str):
        user = cls.get_by_id(db, user_id)
        if user.role == role:
            return True
        else:
            return False

    @classmethod
    async def async_get_general_data(
            cls,
            user_id: int,
            with_lock: bool = False,
            connection: AsyncSession = None,
    ) -> Optional['UserModel']:
        """
        use "with_lock" and "connection" for transaction
        """
        connection = connection or session()

        query = select(cls).where(cls.id == user_id)
        if with_lock:
            query = query.with_for_update()

        result_raw = await connection.execute(query)

        return result_raw.fetchone()[0]

    @classmethod
    async def async_get_users_general_data(
            cls,
            user_ids: List[int],
            with_lock: bool = False,
            connection: AsyncSession = None,
    ) -> Optional[List['UserModel']]:
        """
        use "with_lock" and "connection" for transaction
        """

        connection = connection or session()

        query = select(cls).where(cls.id.in_(user_ids))
        if with_lock:
            query = query.with_for_update()

        result_raw = await connection.execute(query)

        return result_raw.all()

    @classmethod
    async def async_update_balance(cls, user_id: int, balance: Decimal, connection: AsyncSession = None):
        """
        use "connection" for transaction
        """

        connection = connection or session()

        statement = (
            update(cls).
            where(cls.id == user_id).
            values(balance=balance).
            returning(cls.id, cls.balance, cls.bonus_balance, cls.currency, cls.is_banned)
        )
        result_raw = await connection.execute(statement)

        return result_raw.fetchone()

    @classmethod
    async def async_update_bonus_balance(cls, user_id: int, balance: Decimal, connection: AsyncSession = None):
        """
        use "connection" for transaction
        """

        connection = connection if connection else session()

        statement = (
            update(cls).
            where(cls.id == user_id).
            values(bonus_balance=balance).
            returning(cls.id, cls.balance, cls.bonus_balance, cls.currency, cls.is_banned)
        )
        result_raw = await connection.execute(statement)

        return result_raw.fetchone()

    @classmethod
    def get_descendants_for_tree(cls, db, admin_id: int, admin_role: str):
        query = db.query(UserModel.id.label("user_id"),
                         EmailAuthModel.email.label("username"),
                         UserModel.balance.label("balance"),
                         UserModel.role.label("role"),
                         UserModel.is_banned.label("is_banned")) \
            .join(EmailAuthModel, EmailAuthModel.user_id == UserModel.id)

        descendants_list = cls.get_descendants_list_by_roles(query, admin_id, admin_role)
        return descendants_list

    @classmethod
    def get_descendants_list_by_roles(cls, query, admin_id: int, admin_role: str):
        if admin_role in [UserModel.LIMITED_OWNER, UserModel.OWNER]:
            descendants_list = query.filter(cls.role == UserModel.SUPER_ADMIN).all()
        elif admin_role in cls.parent_id_mapper.keys():
            sub_user_role = cls.sub_users_mapper[admin_role]
            parent_id = cls.parent_id_mapper[admin_role]
            descendants_list = query.filter(
                and_(parent_id == admin_id, cls.role == sub_user_role)).all()
        else:
            descendants_list = []
        return descendants_list

    @classmethod
    def get_count_of_user_struct(cls,
                                 db,
                                 admin_id: int,
                                 admin_role: str,
                                 strategy: str):
        if admin_role not in cls.parent_id_mapper.keys():
            return 0

        if strategy == "sub_users":
            sub_user_role = cls.sub_users_mapper[admin_role]
            parent_id = cls.parent_id_mapper[admin_role]
        elif strategy == "players":
            sub_user_role = UserModel.USER
            parent_id = cls.parent_id_mapper[admin_role]
        else:
            return 0

        count = db.query(cls.id).filter(
            and_(parent_id == admin_id, cls.role == sub_user_role)).count()
        return count

    @classmethod
    def get_descendant_by_ltree_path_subq(
            cls, db,
            ltree_path: Ltree,
            source_entity_id: int,
            is_direct_structure: bool = False,
            target_role: str = None,
            username: str = None,
            is_source: bool = None
    ):
        query = db.query(
            cls.id,
        )

        if is_direct_structure:
            query = query.filter(
                cls.parent_agent_id == source_entity_id,
            )
        else:
            query = query.filter(
                cls.structure_path.descendant_of(ltree_path),
            )

        if not is_source:
            query = query.filter(cls.id != source_entity_id)

        if username:
            query = query.filter(cls.nickname.like(f"%{username.lower()}%"))

        if target_role is not None:
            query = query.filter(cls.role == target_role)

        return query

    @classmethod
    def get_list_users_by_entity_user_subq(
            cls,
            db: Session,
            entity_user: "UserModel",
            is_direct_structure: bool = False,
            target_role: str = None,
            username: str = None,
            is_like_username: bool = True,
    ):
        if entity_user is None:
            main_agents = UserModel.get_main_agents(db)
            agents_ids = [x.id for x in main_agents]

            if is_direct_structure:
                users_subq = UserModel.get_list_by_parent_agent_id_subq(
                    db=db,
                    parent_agent_id=agents_ids,
                    target_role=target_role,
                    username=username,
                    is_like_username=is_like_username,
                )
            else:
                users_subq = UserModel.get_list_subq(
                    db=db,
                    role=target_role,
                    username=username,
                    is_like_username=is_like_username,
                )
        else:
            if is_direct_structure:
                users_subq = cls.get_list_by_parent_agent_id_subq(
                    db=db,
                    parent_agent_id=entity_user.id,
                    target_role=target_role,
                    username=username,
                    is_like_username=is_like_username,
                )
            else:
                is_source = True if username and username.lower() == entity_user.email_auth.email else False
                users_subq = cls.get_descendant_list_by_ltree_path_subq(
                    db=db,
                    ltree_path=entity_user.structure_path,
                    source_entity_id=entity_user.id,
                    target_role=target_role,
                    username=username,
                    is_like_username=is_like_username,
                    is_source=is_source
                )

        return users_subq

    @classmethod
    def update_structure(
            cls, db,
            source_entity_id: int,
            new_path: Ltree,
            old_path: Ltree
    ):
        query = db.query(cls).filter(
            cls.structure_path.descendant_of(old_path),
            cls.id != source_entity_id
        ).update({
            cls.structure_path: new_path.path + func.subpath(
                cls.structure_path,
                func.nlevel(old_path.path)
            )
        }, synchronize_session=False)

        return query

    @classmethod
    def get_descendant_list_by_ltree_path_subq(
            cls, db,
            ltree_path: Ltree,
            source_entity_id: int,
            max_ltree_level: int = None,
            target_role: str = None,
            username: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            is_source: bool = None,
            is_like_username: bool = True
    ):
        descendant_entities = aliased(cls)
        level = expression.label(
            'level',
            func.nlevel(cls.structure_path) - func.nlevel(ltree_path.path)
        )
        child_count = func.count(
            descendant_entities.id
        ).label('child_count')

        query = db.query(
            cls.id,
            cls.parent_agent_id,
            cls.nickname,
            cls.structure_path,
            cls.is_banned,
            level,
            child_count,
        )

        if target_role:
            query = query.join(
                descendant_entities,
                and_(
                    descendant_entities.parent_agent_id == cls.id,
                    descendant_entities.role == target_role
                ),
                isouter=True
            )
        else:
            query = query.join(
                descendant_entities,
                descendant_entities.parent_agent_id == cls.id,
                isouter=True
            )

        query = query.filter(
            cls.structure_path.descendant_of(ltree_path)
        )

        if not is_source:
            query = query.filter(cls.id != source_entity_id)

        if max_ltree_level is not None:
            query = query.filter(level <= max_ltree_level)

        if target_role is not None:
            query = query.filter(cls.role == target_role)

        if is_visible is not None:
            query = query.filter(cls.is_visible == is_visible)

        if is_banned is not None:
            query = query.filter(cls.is_banned == is_banned)

        if username and is_like_username:
            query = query.filter(cls.nickname.like(f"%{username.lower()}%"))
        elif username and not is_like_username:
            query = query.filter(cls.nickname == username.lower())

        query = query.group_by(
            cls.id,
            cls.parent_agent_id,
            cls.nickname
        )

        return query.subquery()

    @classmethod
    def get_descendant_list_by_ltree_path(
            cls, db,
            ltree_path: Ltree,
            source_entity_id: int,
            max_ltree_level: int = None,
            target_role: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            username: str = None,
            is_like_username: bool = True
    ):
        return db.query(
            cls.get_descendant_list_by_ltree_path_subq(
                db=db,
                ltree_path=ltree_path,
                source_entity_id=source_entity_id,
                max_ltree_level=max_ltree_level,
                target_role=target_role,
                is_visible=is_visible,
                is_banned=is_banned,
                username=username,
                is_like_username=is_like_username
            )
        ).all()

    @classmethod
    def get_paginated_descendant_list_by_ltree_path(
            cls,
            db,
            ltree_path: Ltree,
            source_entity_id: int,
            max_ltree_level: int = None,
            target_role: str = None,
            skip: int = None,
            limit: int = None
    ):
        query = db.query(
            cls.get_descendant_list_by_ltree_path_subq(
                db=db,
                ltree_path=ltree_path,
                source_entity_id=source_entity_id,
                target_role=target_role,
            )
        )
        count = query.count()

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)
        return query.all(), count

    @classmethod
    def get_list_by_parent_agent_id_subq(
            cls, db,
            parent_agent_id: Union[int, List[int]],
            username: str = None,
            target_role: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            date_from: datetime = None,
            date_to: datetime = None,
            is_descending_order_id: bool = False,
            limit: int = None,
            is_like_username: bool = True,
    ):
        if isinstance(parent_agent_id, list):
            query = db.query(cls).filter(
                cls.parent_agent_id.in_(parent_agent_id)
            )
        else:
            query = db.query(cls).filter(
                cls.parent_agent_id == parent_agent_id
            )

        if username and is_like_username:
            query = query.filter(cls.nickname.like(f"%{username.lower()}%"))
        elif username and not is_like_username:
            query = query.filter(cls.nickname == username.lower())

        if target_role:
            query = query.filter(cls.role == target_role)

        if is_visible is not None:
            query = query.filter(cls.is_visible == is_visible)

        if is_banned is not None:
            query = query.filter(cls.is_banned == is_banned)

        if date_from and date_to:
            query = query.filter(cls.first_visit.between(date_from, date_to))

        if is_descending_order_id:
            query = query.order_by(cls.id.desc())

        if limit is not None:
            query = query.limit(limit)

        return query.subquery()

    @classmethod
    def get_list_by_structure_path_subq(
            cls, db,
            structure_path: Ltree,
            username: str = None,
            target_role: str = None,
            is_visible: bool = None,
            is_direct_structure: bool = None,
            is_banned: bool = None,
            date_from: datetime = None,
            date_to: datetime = None,
            parent_agent_id: int = None
    ):
        query = db.query(cls).filter(
            cls.structure_path != structure_path,
            cls.structure_path.descendant_of(structure_path)
        )
        if is_direct_structure:
            query = query.filter(cls.parent_agent_id == parent_agent_id)
        if username:
            query = query.filter(cls.nickname.like(f"%{username.lower()}%"))
        if target_role:
            query = query.filter(cls.role == target_role)
        if is_visible is not None:
            query = query.filter(cls.is_visible == is_visible)
        if is_banned is not None:
            query = query.filter(cls.is_banned == is_banned)
        if date_from and date_to:
            query = query.filter(cls.first_visit.between(date_from, date_to))

        return query.subquery()

    @classmethod
    def get_list_with_parent_by_parent_agent_id(
            cls, db,
            parent_agent: "UserModel",
            username: str = None,
            role: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            skip: int = None,
            limit: int = None,
            order_by: str = None,
            date_from: datetime = None,
            date_to: datetime = None
    ) -> Tuple[List["UserModel"], int, float]:
        users_subq = cls.get_list_by_parent_agent_id_subq(
            db=db,
            parent_agent_id=parent_agent.id,
            username=username,
            target_role=role,
            is_banned=is_banned,
            is_visible=is_visible,
            date_from=date_from,
            date_to=date_to
        )

        agent_alias = aliased(UserModel)

        query = db.query(
            users_subq,
            agent_alias.id.label('agent_id'),
            agent_alias.nickname.label('agent_username'),
            agent_alias.balance.label('agent_balance'),
        ).select_from(
            users_subq
        ).join(
            agent_alias,
            agent_alias.id == users_subq.c.parent_agent_id,
            isouter=True
        )

        count = query.count()
        if role:
            balance_subq = cls.get_list_by_structure_path_subq(
                db=db,
                structure_path=parent_agent.structure_path,
                username=username,
                target_role=role,
                is_direct_structure=False,
                is_banned=is_banned,
                is_visible=is_visible,
                date_from=date_from,
                date_to=date_to,
                parent_agent_id=parent_agent.id
            )
            sum_balances = db.query(func.sum(balance_subq.c.balance).label("total_balance"))
        else:
            sum_balances = db.query(func.sum(users_subq.c.balance).label("total_balance"))

        if not order_by:
            query = query.order_by(users_subq.c.id.desc())
        else:
            column_name = order_by.removeprefix('-').removeprefix('+').replace(' ', '')
            if order_by.startswith("-"):
                query = query.order_by(users_subq.c[column_name].desc())
            else:
                query = query.order_by(users_subq.c[column_name].asc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        query_result = query.all()

        return query_result, count, sum_balances.scalar()

    @classmethod
    def get_list_with_parent_by_structure_path(
            cls, db,
            structure_path: Ltree,
            username: str = None,
            role: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            is_direct_structure: bool = None,
            skip: int = None,
            limit: int = None,
            order_by: str = None,
            date_from: datetime = None,
            date_to: datetime = None,
            parent_agent_id: int = None,
    ) -> Tuple[List["UserModel"], int, float]:
        users_subq = cls.get_list_by_structure_path_subq(
            db=db,
            structure_path=structure_path,
            username=username,
            target_role=role,
            is_direct_structure=is_direct_structure,
            is_banned=is_banned,
            is_visible=is_visible,
            date_from=date_from,
            date_to=date_to,
            parent_agent_id=parent_agent_id
        )

        agent_alias = aliased(UserModel)

        query = db.query(
            users_subq,
            agent_alias.id.label('agent_id'),
            agent_alias.nickname.label('agent_username'),
            agent_alias.balance.label('agent_balance'),
        ).select_from(
            users_subq
        ).join(
            agent_alias,
            agent_alias.id == users_subq.c.parent_agent_id,
            isouter=True
        )

        count = query.count()
        sum_balances = db.query(func.sum(users_subq.c.balance).label("total_balance"))

        if not order_by:
            query = query.order_by(users_subq.c.id.desc())
        else:
            column_name = order_by.removeprefix('-').removeprefix('+').replace(' ', '')
            if order_by.startswith("-"):
                query = query.order_by(users_subq.c[column_name].desc())
            else:
                query = query.order_by(users_subq.c[column_name].asc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        query_result = query.all()

        return query_result, count, sum_balances.scalar()

    @classmethod
    def get_list_by_parent_agent_id(
            cls, db,
            parent_agent_id: int,
            username: str = None,
            role: str = None,
            is_visible: bool = None,
            is_banned: bool = None,
            skip: int = None,
            limit: int = None
    ) -> Tuple[List["UserModel"], int]:

        users_subq = cls.get_list_by_parent_agent_id_subq(
            db=db,
            parent_agent_id=parent_agent_id,
            username=username,
            target_role=role,
            is_banned=is_banned,
            is_visible=is_visible
        )

        query = db.query(users_subq)

        count = query.count()

        query = query.order_by(users_subq.c.id.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        query_result = query.all()

        return query_result, count

    @classmethod
    def get_ancestor_list_by_ltree_path_subq(
            cls, db,
            ltree_path: Ltree
    ):
        query = db.query(cls).filter(
            cls.structure_path.ancestor_of(
                ltree_path
            )
        )

        return query.subquery()

    @classmethod
    def get_ancestor_list_by_ltree_path(
            cls,
            db,
            ltree_path: Ltree
    ):
        return db.query(
            cls.get_ancestor_list_by_ltree_path_subq(
                db=db,
                ltree_path=ltree_path
            )
        ).all()

    @classmethod
    def get_banned_substructure_user_ids_by_ltree_path_subq(
            cls, db,
            source_entity_id: int,
            ltree_path: Ltree
    ):
        descendant_entities = aliased(cls)

        query = db.query(
            descendant_entities
        ).select_from(
            cls
        ).join(
            descendant_entities,
            and_(
                descendant_entities.structure_path.descendant_of(cls.structure_path),
                descendant_entities.id != cls.id
            )
        ).filter(
            cls.structure_is_banned == True,
            cls.structure_path.descendant_of(ltree_path),
            cls.id != source_entity_id
        ).subquery()

        return query

    @classmethod
    def get_banned_substructure_user_ids_by_ltree_path(
            cls, db,
            source_entity_id: int,
            ltree_path: Ltree
    ):
        return db.query(
            cls.get_banned_substructure_user_ids_by_ltree_path_subq(
                db=db,
                source_entity_id=source_entity_id,
                ltree_path=ltree_path
            )
        ).all()

    @classmethod
    def set_ban_status_structure_by_ltree_path(
            cls, db,
            source_entity_id: int,
            ltree_path: Ltree,
            ban_status: bool
    ):
        if ban_status is False:
            excluded_users_subq = cls.get_banned_substructure_user_ids_by_ltree_path_subq(
                db=db,
                source_entity_id=source_entity_id,
                ltree_path=ltree_path
            )
            and_statement = and_(
                    cls.structure_path.descendant_of(ltree_path),
                    ~cls.id.in_(
                        db.query(excluded_users_subq.c.id)
                    ),
                    cls.id != source_entity_id
                )
        else:
            and_statement = and_(
                cls.structure_path.descendant_of(ltree_path),
                cls.id != source_entity_id
            )

        statement = (
            update(cls).
            where(and_statement).
            values(is_banned=ban_status).
            execution_options(synchronize_session=False).
            returning(cls.id)
        )

        banned_ids = db.execute(statement).fetchall()

        return banned_ids

    @classmethod
    def delete_structure_by_ltree_path(
            cls,
            db,
            source_entity_id: int,
            ltree_path: Ltree,
    ):
        and_statement = and_(
                cls.structure_path.descendant_of(ltree_path),
                cls.id != source_entity_id
            )
        statement = (
            update(cls).
            where(and_statement).
            values(is_banned=True, is_visible=False).
            returning(cls.id)
        )
        deleted_ids = db.execute(statement).fetchall()
        deleted_ids = [x.id for x in deleted_ids]
        email_auth_update = (
            update(EmailAuthModel).
            where(EmailAuthModel.user_id.in_(deleted_ids)).
            values(email="deleted_" + EmailAuthModel.email + '_' + expression.cast(EmailAuthModel.user_id, String)))
        db.execute(email_auth_update)
        return deleted_ids

    def delete_user(self, db):
        self.is_banned = True
        self.is_visible = False
        self.email_auth.email = "deleted_" + self.email_auth.email + "_" + str(self.id)
        db.add(self)
        db.commit()

    def set_ban_user(self, db: Session, is_banned: bool):
        self.is_banned = is_banned
        db.add(self)
        db.commit()

    @classmethod
    def get_main_agents(cls, db: Session):
        return db.query(cls)\
            .filter(cls.role == cls.PARTNER_AGENT)\
            .filter(cls.parent_agent == None)\
            .filter(cls.is_banned == False)\
            .filter(cls.is_visible == True)\
            .all()

    @classmethod
    def get_list_subq(
            cls,
            db: Session,
            role: str = None,
            username: str = None,
            is_like_username: bool = True,
    ):
        users_subq = db.query(cls)\
            .filter(cls.is_banned == False)\
            .filter(cls.is_visible == True)

        if role:
            users_subq = users_subq.filter(cls.role == role)

        if username and is_like_username:
            users_subq = users_subq.filter(cls.nickname.like(f"%{username.lower()}%"))
        elif username and not is_like_username:
            users_subq = users_subq.filter(cls.nickname == username.lower())

        users_subq = users_subq.order_by(cls.id.desc()).subquery()
        return users_subq

    @classmethod
    def get_list_with_parent(cls, db: Session, role: str, skip: int, limit: int, username: str = None):

        agent_alias = aliased(UserModel)

        users_subq = cls.get_list_subq(db, role, username)

        query = db.query(
            users_subq,
            agent_alias.nickname.label('agent_username'),
        ).select_from(
            users_subq
        ).join(
            agent_alias,
            agent_alias.id == users_subq.c.parent_agent_id,
            isouter=True
        )

        count = query.count()
        query = query.offset(skip).limit(limit)
        return query.all(), count

    @classmethod
    def get_by_partial_nickname(cls, db, nickname, source_user):
        try:
            result = db.query(cls).filter(
                cls.nickname == nickname,
                cls.structure_path.descendant_of(source_user.structure_path)
            ).first()
        except NoResultFound:
            result = None

        if not result:
            try:
                result = db.query(cls).filter(
                    cls.nickname.like(f"%{nickname}%"),
                    cls.structure_path.descendant_of(source_user.structure_path)
                ).first()
            except NoResultFound:
                result = None

        return result

    @classmethod
    async def async_can_user_place_bet(
            cls,
            user_id: int,
            with_lock: bool = False,
            connection: AsyncSession = None
    ):
        connection = connection or session()

        query = select(cls.changed_password).where(
            cls.id == user_id
        )
        if with_lock:
            query = query.with_for_update()

        result_raw = await connection.execute(query)

        return result_raw.fetchone()[0]

    @classmethod
    def get_total_count(cls, db) -> int:
        return db.query(func.count(UserModel.id)).scalar()
