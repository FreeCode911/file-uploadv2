from logging import getLogger

from sqlalchemy import (
    Column, Integer, String,
    Boolean,
    ForeignKey,
    Numeric,
    SmallInteger,
    Index,
    and_,
    select
)
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import relationship, backref
from tornado.options import options

from .base import BaseModel, TimestampMixin, UpdateMixin
from .money_transfer import MoneyTransferModel
from .user import UserModel

logger = getLogger(__name__)


class WithdrawalModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "withdrawal"
    __table_args__ = (
        Index("withdrawal_transfer_cancel_id_ix", "transfer_cancel_id"),
        Index("withdrawal_transfer_id_ix", "transfer_id"),
    )

    CREATED = 0
    PROCESSING = 1
    DONE = 2
    CANCELED = 4

    STATUSES = {
        CREATED: options.WITHDRAWAL_STATUS_NAMES.get('CREATED'),
        PROCESSING: options.WITHDRAWAL_STATUS_NAMES.get('PROCESSING'),
        DONE: options.WITHDRAWAL_STATUS_NAMES.get('DONE'),
        CANCELED: options.WITHDRAWAL_STATUS_NAMES.get('CANCELED'),
    }

    END_STATUSES = (DONE, CANCELED)

    id = Column(Integer, autoincrement=True, primary_key=True)

    purse = Column(String(100))
    payment_mode = Column(String(100))
    amount = Column(Numeric(15, 2, asdecimal=False))
    status = Column(SmallInteger, default=CREATED)
    currency = Column(String(100))
    is_closed = Column(Boolean, default=False)

    transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer = relationship(
        MoneyTransferModel,
        uselist=False,
        backref=backref('withdrawal', uselist=False),
        foreign_keys=[transfer_id])

    transfer_cancel_id = Column(ForeignKey("transfer.id"), nullable=True)
    transfer_cancel = relationship(
        MoneyTransferModel,
        uselist=False,
        backref=backref('withdrawal_cancel', uselist=False),
        foreign_keys=[transfer_cancel_id])

    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref='withdrawals', lazy='select', foreign_keys=[user_id])
    cashier_id = Column(ForeignKey("user.id"), nullable=True)

    @classmethod
    def get_all(cls, db):
        return db.query(cls).all()

    def get_status(self):
        if not self.status:
            return None
        try:
            return self.statuses[self.status]
        except KeyError as e:
            logger.warning("WithdrawalModel: status " "doesn't exist: %s", e)
            return None

    @classmethod
    def get_by_id(cls, db, id) -> 'WithdrawalModel':
        return super(WithdrawalModel, cls).get_by_id(db, id)

    @classmethod
    def get_withdrawals(cls, db, user_id, begin, end):
        q = db.query(cls).filter(cls.user_id == user_id)
        if begin:
            q = q.filter(and_(cls.created_at >= begin))
        if end:
            q = q.filter(and_(cls.created_at <= end))

        return q.all()

    @classmethod
    async def async_get_by_transaction_id(cls, transaction_id: str, connection: AsyncSession, with_lock: bool = False):
        select_q = select(cls).where(cls.external_id == transaction_id)
        if with_lock:
            select_q = select_q.with_for_update()

        result = await connection.execute(select_q)

        return result.scalar()

    @classmethod
    def get_withdrawals_by_user_id(cls, db, user_id, begin, end, statuses):
        q = db.query(cls).filter(cls.user_id == user_id)

        if statuses:
            q = q.filter(cls.status.in_(statuses))
        if begin:
            q = q.filter(and_(cls.created_at >= begin))
        if end:
            q = q.filter(and_(cls.created_at <= end))
        return q.all()