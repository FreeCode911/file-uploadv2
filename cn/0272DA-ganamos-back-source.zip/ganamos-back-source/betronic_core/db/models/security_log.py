
from datetime import datetime

from sqlalchemy import Column, Integer, ForeignKey, String, DateTime
from sqlalchemy.dialects.postgresql import JSONB

from .base import BaseModel


class SecurityLogModel(BaseModel):
    __tablename__ = "security_log"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    ip_address = Column(String(50), nullable=True, index=True)
    request_from = Column(String(120), nullable=True)
    operation = Column(String(50), nullable=True)
    request_body = Column(JSONB, nullable=True)
    note = Column(String(2000))
    created_at = Column(DateTime, default=datetime.utcnow)

    def __init__(self, user_id=None, ip_address=None, request_from=None, operation=None, request_body=None, note=None):
        self.user_id = user_id
        self.ip_address = ip_address
        self.request_from = request_from
        self.operation = operation
        self.request_body = request_body
        self.note = note