from tornado.options import options

from betronic_core.db.models.base import BaseModel, TimestampMixin, UpdateMixin
from sqlalchemy import Column, Integer, String, Text, UniqueConstraint, \
    Boolean, true
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy import true


class FlatPageModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "flatpage"

    LANGUAGE = options['LANGUAGES']
    LANGUAGES_FOR_ADMIN = options['LANGUAGES_FOR_ADMIN']

    def __init__(self, name="", id_name="", text="", lang="ru", priority=0,
                 is_active=True):
        super(FlatPageModel, self).__init__()
        self.name = name
        self.id_name = id_name
        self.text = text
        self.priority = priority
        self.is_active = is_active
        try:
            self.lang = int(lang)
        except:
            self.lang = self.LANGUAGE[lang]

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String(40), nullable=True)
    priority = Column(Integer, default=0)
    is_active = Column(Boolean, default=True, nullable=False,
                       server_default=true())
    id_name = Column(String(40), nullable=True)
    lang = Column(Integer, nullable=True, default=LANGUAGE['es'])
    text = Column(Text)

    __table_args__ = (UniqueConstraint(
        'id_name', 'lang', name='_flat_page_lang'), )

    @classmethod
    def get_by_name(cls, db, name) -> 'FlatPageModel':
        try:
            return db.query(cls).filter_by(id_name=name).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_name_by_lang(cls, db, name, lang) -> 'FlatPageModel':
        try:
            return db.query(cls).filter_by(id_name=name).filter_by(
                lang=cls.LANGUAGE[lang]).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_lang(cls, db, lang) -> list('FlatPageModel'):
        try:
            return db.query(cls).filter_by(lang=cls.LANGUAGE[lang]).\
                filter(cls.is_active == True).\
                order_by(cls.priority.desc()).all()
        except NoResultFound:
            return None
