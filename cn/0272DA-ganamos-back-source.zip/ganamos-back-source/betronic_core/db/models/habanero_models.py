from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Index, SmallInteger
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from .base import BaseModel
from .user import UserModel


class HabaneroTokenModel(BaseModel):
    __tablename__ = 'habanero_token'

    id = Column(Integer, autoincrement=True, primary_key=True)
    token = Column(String(500))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="habanero_token", uselist=False,
                        foreign_keys=[user_id])
    created_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_by_token(cls, db, token) -> 'HabaneroTokenModel' or None:
        try:
            return db.query(cls).filter_by(token=token).one()
        except NoResultFound:
            return None

    @classmethod
    def get_by_user_id(cls, db, user_id) -> 'HabaneroTokenModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None


class HabaneroTransactionsModel(BaseModel):
    __tablename__ = 'habanero_transactions'
    __table_args__ = (
        Index("habanero_transactions_transfer_id_ix", "transfer_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    habanero_transaction_id = Column(String(), nullable=False, unique=True)
    token = Column(String(), nullable=False)
    game_instance_id = Column(String(), nullable=False)
    transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    user_id = Column(ForeignKey("user.id"), nullable=True)
    game_state_mode = Column(SmallInteger)
    created_at = Column(DateTime, default=datetime.now())

    transfer: Mapped['MoneyTransferModel'] = relationship(
        "MoneyTransferModel",
        backref='habanero_transaction',
        foreign_keys=[transfer_id])
    user: Mapped['UserModel'] = relationship(
        "UserModel",
        backref='habanero_transaction',
        foreign_keys=[user_id])

    @classmethod
    def get_by_habanero_transaction_id(cls, db, transaction_id):
        try:
            return db.query(cls).filter(cls.habanero_transaction_id == transaction_id).one()
        except NoResultFound:
            return None
