from sqlalchemy import Column, Integer, ForeignKey, Index, select, update
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.async_database import session
from .base import BaseModel
from .user import UserModel


class FavoriteSlots(BaseModel):
    __tablename__ = "favorite_slots"

    __table_args__ = (
        Index('favorite_slots_user_id_idx', "user_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(UserModel, backref="favorite_slots", uselist=False,
                        foreign_keys=[user_id])
    favorite_games = Column(JSONB, nullable=True, default="")

    @classmethod
    async def async_get_favorite_games_by_user_id(cls,
                                                  user_id: int,
                                                  connection: AsyncSession = None):
        connection = connection or session()

        query = select(cls).where(cls.user_id == user_id)
        result_raw = await connection.execute(query)

        return result_raw.scalars().first()

    @classmethod
    async def async_update_user_favorite_games(cls,
                                               user_id: int,
                                               favorite_games: dict,
                                               connection: AsyncSession = None):
        connection = connection or session()

        query = (
            update(cls).
            where(cls.user_id == user_id).
            values(favorite_games=favorite_games).
            returning(cls)
        )
        result_raw = await connection.execute(query)

        return result_raw.fetchone()[0]
