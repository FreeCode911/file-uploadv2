from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy import Column, Integer, Boolean
from sqlalchemy.exc import NoResultFound
from sqlalchemy.sql import expression
from .base import BaseModel


class NotificationModel(BaseModel):
    __tablename__ = "notifications"

    id = Column(Integer, autoincrement=True, primary_key=True)
    notification = Column(JSONB, nullable=True, default={})
    is_closed = Column(Boolean, server_default=expression.false(), default=False)

    @classmethod
    def get_by_id(cls, db, notification_id):
        try:
            return db.query(cls).filter(cls.id == notification_id).one()
        except NoResultFound:
            return None
