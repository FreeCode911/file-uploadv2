from sqlalchemy import Integer, Column, ForeignKey, String
from .base import BaseModel
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from .limit_group import LimitGroupModel


class LimitTourneyModel(BaseModel):

    __tablename__ = "limit_tourney"

    id = Column(Integer, autoincrement=True, primary_key=True)
    name = Column(String)
    tourney_id = Column(String, index=True)
    group_id = Column(ForeignKey("limit_group.id"), nullable=False)
    user = relationship(
        "LimitGroupModel", backref='tourney_ids', foreign_keys=[group_id])

    @classmethod
    def get_by_ids(cls, db, ids):
        return db.query(cls).filter(cls.id.in_(ids)).all()

    @classmethod
    def get_limit(cls, db, ids):
        try:
            q = db.query(func.min(LimitGroupModel.max_limit)).select_from(cls)\
                .join(LimitGroupModel, cls.group_id == LimitGroupModel.id)\
                .filter(cls.tourney_id.in_(ids))
            q = q.one()[0]
        except Exception as e:
            q = None
        return q
