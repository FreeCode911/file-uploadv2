from datetime import datetime
from typing import List, Union, Optional
from sqlalchemy import Column, Integer, Numeric, String, DateTime, ForeignKey, Boolean, Index, func, and_
from sqlalchemy.engine import Row
from sqlalchemy.sql import expression
from sqlalchemy.orm import relationship
from .base import BaseModel
from .email_auth import EmailAuthModel
from .user import UserModel


class UserProviderStatisticModel(BaseModel):
    __tablename__ = "user_provider_statistic"
    __table_args__ = (
        Index('ix_user_statistic_created_at_provider_currency_is_bonus',
              'created_at', 'provider', 'currency', 'is_bonus'),
        Index('ix_user_statistic_created_at_user_id',
              'created_at', 'user_id'),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)

    currency = Column(String(5))
    provider = Column(String(60), nullable=False)

    bet_count = Column(Integer, nullable=False)
    win_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    win_count = Column(Integer, nullable=False, server_default='0')
    bet_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)

    is_bonus = Column(Boolean, server_default=expression.false(), default=False)

    user_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    user = relationship(
        'UserModel',
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[user_id]
    )

    created_at = Column(DateTime, default=datetime.utcnow)

    @classmethod
    def get_by_user_id_and_date(
            cls,
            db,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None,
            providers: List[str] = None,
            need_grouping_by_provider: bool = True
    ):
        query = db.query(
            UserModel.id.label('user_id'),
            cls.provider.label('provider') if need_grouping_by_provider else None,
            func.coalesce(func.sum(cls.bet_count), 0).label('bet_count'),
            func.coalesce(func.sum(cls.win_sum), 0).label('win_sum'),
            func.coalesce(func.sum(cls.bet_sum), 0).label('bet_sum'),
        ).select_from(
            UserModel
        ).join(
            cls,
            and_(
                cls.created_at >= date_from,
                cls.created_at <= date_to,
                UserModel.id == cls.user_id
            ),
            isouter=True
        )

        if isinstance(user_id, list):
            query = query.filter(UserModel.id.in_(user_id))
        else:
            query = query.filter(
                UserModel.id == user_id
            )

        if providers:
            query = query.filter(
                cls.provider.in_(providers)
            )

        if need_grouping_by_provider:
            query = query.group_by(UserModel.id, cls.provider)
        else:
            query = query.group_by(UserModel.id)

        return query.all()

    @classmethod
    def get_users_ranked_by_netwin(
            cls,
            db,
            user: UserModel,
            date_from: Optional[datetime],
            date_to: Optional[datetime],
    ) -> list[Row]:
        if user.parent_agent_id:
            structure_path = user.parent_agent.structure_path
        else:
            structure_path = None

        subquery = db.query(
            cls.user_id,
            func.sum(cls.bet_count).label('bet_count'),
            func.sum(cls.win_count).label('win_count'),
            func.sum(cls.win_sum).label('win_sum'),
            func.sum(cls.bet_sum).label('bet_sum'),
            func.sum(cls.bet_sum - cls.win_sum).label('profit'),
        ).join(
            UserModel,
            UserModel.id == cls.user_id
        ).where(
            cls.created_at >= date_from,
            cls.created_at <= date_to,
            UserModel.structure_path != structure_path,
            UserModel.structure_path.descendant_of(user.structure_path),
            UserModel.role == UserModel.USER,
            UserModel.is_visible.is_(True),
            UserModel.is_banned.is_(False)
        ).group_by(cls.user_id).order_by(func.sum(cls.bet_sum - cls.win_sum).desc()).limit(10).subquery()

        query = db.query(
            subquery.c.user_id,
            EmailAuthModel.email,
            subquery.c.bet_count,
            subquery.c.win_count,
            subquery.c.win_sum,
            subquery.c.bet_sum,
            subquery.c.profit,
        ).join(
            EmailAuthModel,
            subquery.c.user_id == EmailAuthModel.user_id
        )

        return query.all()

