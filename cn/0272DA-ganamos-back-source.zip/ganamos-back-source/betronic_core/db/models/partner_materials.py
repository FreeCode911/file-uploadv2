from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.category import CategoryModel
from sqlalchemy import Column, String, DateTime, Boolean, Integer, ForeignKey
from datetime import datetime as dt


class PartnerMaterialsModel(BaseModel):
    __tablename__ = 'partner_materials'

    id = Column(Integer, unique=True, primary_key=True)
    name = Column(String)

    preview = Column(String, unique=True)
    filename = Column(String, unique=True)

    created_at = Column(DateTime, default=dt.now())
    is_active = Column(Boolean, default=True)
    description = Column(String)

    category_id = Column('category_id', Integer,
                         ForeignKey('category.id'), nullable=True, index=True)
