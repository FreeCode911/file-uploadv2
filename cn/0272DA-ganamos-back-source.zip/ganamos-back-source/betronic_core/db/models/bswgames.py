from typing import Collection

from sqlalchemy import Column, Integer, String, ForeignKey, Index
from sqlalchemy.orm import relationship, Session

from betronic_core.db.models.base import BaseModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel


class BswGamesBetModel(BaseModel):

    __tablename__ = "bsw_bet"
    __table_args__ = (
        Index('bsw_bet_prize_transfer_id_key', "prize_transfer_id", ),
        Index('bsw_bet_bet_transfer_id_key', "bet_transfer_id"),
    )

    id = Column(Integer, primary_key=True)
    external_id = Column(String(40), nullable=False, unique=True)

    user_id = Column(Integer, ForeignKey(UserModel.id), nullable=False)
    status = Column(Integer, nullable=False, default=0)

    bet_transfer_id = Column(Integer, ForeignKey(MoneyTransferModel.id), nullable=False, unique=True)
    prize_transfer_id = Column(Integer, ForeignKey(MoneyTransferModel.id), unique=True)

    user = relationship(UserModel)
    bet_transfer = relationship(MoneyTransferModel, foreign_keys=[bet_transfer_id])
    prize_transfer = relationship(MoneyTransferModel, foreign_keys=[prize_transfer_id])

    @classmethod
    def get_by_external_ids_with_lock(cls, ids: Collection[str], db: Session) -> Collection['BswGamesBetModel']:
        return db.query(cls).with_for_update().filter(cls.external_id.in_(ids))
