from datetime import datetime
from typing import List

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, SmallInteger, Index
from sqlalchemy import func
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from betronic_core.constants import TransferTypes
from betronic_core.db.models.money_transfer import MoneyTransferModel
from .base import BaseModel
from .user import UserModel


class PragmaticPlaySessionModel(BaseModel):

    __tablename__ = "pragmatic_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    session = Column(String(100), index=True)
    user_id = Column(ForeignKey("user.id"), index=True)
    user = relationship(UserModel, backref="pragmatic_session", uselist=False,
                        foreign_keys=[user_id])
    create_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_all(cls, db) -> List['PragmaticPlaySessionModel'] or None:
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, session_id: int) -> 'PragmaticPlaySessionModel' or None:
        try:
            return db.query(cls).filter_by(id=session_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_session(cls, db, session: str) -> 'PragmaticPlaySessionModel' or None:
        try:
            return db.query(cls).filter_by(session=session).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user(cls, db, user_id: int) -> 'PragmaticPlaySessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None


class PragmaticTransactionsModel(BaseModel):
    __tablename__ = 'pragmatic_transactions'
    __table_args__ = (
        Index("pragmatic_round_game_ids", "game_id", "round_id"),
        Index("pragmatic_transactions_transfer_id_ix", "transfer_id")
    )
    #  Descriptions for types
    BET = TransferTypes.TYPE_PRAGMATIC_SLOTS_BET
    RESULT = TransferTypes.TYPE_PRAGMATIC_SLOTS_RESULT
    REFUND = TransferTypes.TYPE_PRAGMATIC_SLOTS_REFUND

    id = Column(Integer, autoincrement=True, primary_key=True)
    type = Column(SmallInteger)
    game_id = Column(String(), nullable=True)
    round_id = Column(String(), nullable=True)
    bonus_code = Column(String(), nullable=True)
    provider_transaction_id = Column(String(), index=True)
    transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    created_at = Column(DateTime, default=datetime.now())

    transfer: Mapped['MoneyTransferModel'] = relationship(
        "MoneyTransferModel",
        backref='pragmatic_transaction',
        foreign_keys=[transfer_id])

    @classmethod
    def get_by_external_id(cls, db, provider_id: str):
        return db.query(cls).filter(cls.provider_transaction_id == provider_id).first()

    @classmethod
    def get_free_round_sum(cls, db, user_id: int, bonus_code: str):
        query = db.query(cls.type, func.sum(MoneyTransferModel.value).label('sum_amount')) \
            .join(MoneyTransferModel, MoneyTransferModel.id == cls.transfer_id) \
            .filter(cls.type == TransferTypes.TYPE_PRAGMATIC_SLOTS_RESULT) \
            .filter(MoneyTransferModel.to_user_id == user_id) \
            .filter(cls.bonus_code == bonus_code) \
            .group_by(cls.type)
        result = query.first()
        if result:
            return result.sum_amount
