from typing import List
from datetime import datetime

from sqlalchemy import Column, Integer, ForeignKey, Numeric, \
    SmallInteger, String, func
from sqlalchemy.orm import relationship

from betronic_core.db.models.base import BaseModel, TimestampMixin
from betronic_core.constants import PartnerTypePayment, \
    PartnerStatusMoneyTransfer, PartnerTypeMoneyTransfer
from betronic_core.db.models.user import UserModel


class PartnerMoneyTransfer(BaseModel, TimestampMixin):
    __tablename__ = "partner_money_transfer"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"), nullable=False, index=True)
    user = relationship(
        UserModel,
        backref='partner_transfers',
        foreign_keys=[user_id]
    )
    value = Column(Numeric(10, 2, asdecimal=False))
    currency = Column(String(5))
    type = Column(SmallInteger, default=PartnerTypeMoneyTransfer.TYPE_CREDIT)
    type_credit = Column(SmallInteger, default=PartnerTypePayment.BET)
    status = Column(SmallInteger, default=PartnerStatusMoneyTransfer.DONE)
    method = Column(String(100))

    def __init__(self, value: float, currency: str, user: UserModel = None,
                 type: int = PartnerTypeMoneyTransfer.TYPE_CREDIT,
                 status: int = PartnerStatusMoneyTransfer.DONE,
                 type_credit: int = PartnerTypePayment.BET):
        self.value = value
        self.currency = currency
        self.user = user
        self.type = type
        self.status = status
        self.type_credit = type_credit

    @classmethod
    def get_summary_balance_by_user(cls, db, user_id: int) -> float:
        sum_query = db.query(func.sum(cls.value)).filter(
            cls.user_id == user_id,
            cls.type == PartnerTypeMoneyTransfer.TYPE_CREDIT
        ).one()[0] or float(0.0)

        ex_query = db.query(func.sum(cls.value)).filter(
            cls.user_id == user_id,
            cls.type == PartnerTypeMoneyTransfer.TYPE_WITHDRAWAL
        ).one()[0] or float(0.0)

        balance = sum_query - ex_query

        return balance or float(0)

    @classmethod
    def get_withdrawal_by_user_id(
            cls, db, user_id: int) -> List['PartnerMoneyTransfer']:
        return db.query(cls).filter(cls.user_id == user_id).all()

    @classmethod
    def get_summary_credit_by_user_id(
            cls, db, user_id: int, begin=datetime.min, end=datetime.max) -> List['PartnerMoneyTransfer']:
        if not begin:
            begin = datetime.min
        if not end:
            end = datetime.max
        q = db.query(func.sum(cls.value)
                     .filter(cls.user_id == user_id)
                     .filter(cls.created_at > begin)
                     .filter(cls.created_at < end)
                     .filter(cls.type == PartnerTypeMoneyTransfer.TYPE_CREDIT)).scalar()
        if q:
            return q
        else:
            return 0
