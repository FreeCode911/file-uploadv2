from sqlalchemy import Column, Integer, Boolean, String
from ujson import encode, decode

from ..base import BaseModel, TimestampMixin


class EmailNotification(BaseModel, TimestampMixin):
    __tablename__ = "notification_email"

    id = Column(Integer, autoincrement=True, primary_key=True)
    email = Column(String)
    template_name = Column(String)
    context = Column(String)
    is_closed = Column(Boolean, nullable=False, default=False)
    attempt = Column(Integer, default=0)
    lang = Column(String(10))

    @classmethod
    def get_open_emails(cls, db):
        return db.query(cls).filter(cls.is_closed != True).all()

    @classmethod
    def get_by_email(cls, db, email) -> 'EmailNotification':
        return db.query(cls).filter(cls.email == email).one()

    def set_context(self, context: dict):
        self.context = encode(context)

    def get_context(self):
        return decode(self.context)
