from sqlalchemy import Column, Integer, String, ForeignKey, DateTime, func, Index
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound

from .base import BaseModel


class AdditionalData(BaseModel):

    __tablename__ = "additional_data"

    def __init__(self, user: 'UserModel'=None):
        super(AdditionalData, self).__init__()
        if user:
            self.user = user

    __table_args__ = (
        Index('additional_data_user_id_idx', "user_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)

    email = Column(String(50), default="")
    card = Column(String(50), default="")
    number_document = Column(String(15), default="")
    address = Column(String(350), default="")
    phone = Column(String(20), default="")
    gender = Column(String(20), default="")
    birth_date = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, server_default=None, default=None, nullable=True, onupdate=func.now())
    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(
        "UserModel", back_populates="additional_data", foreign_keys=[user_id])

    @classmethod
    def get_by_user_id(cls, db, user_id):
        try:
            return db.query(cls).filter(cls.user_id == user_id).first()
        except NoResultFound:
            return None

    @classmethod
    def get_by_user_phone(cls, db, phone: str):
        try:
            return db.query(cls).filter(cls.phone == phone).first()
        except NoResultFound:
            return None

    @classmethod
    def check_user_phone(cls, db, phone):
        try:
            return db.query(cls).filter(cls.phone == phone).first()
        except NoResultFound:
            return None