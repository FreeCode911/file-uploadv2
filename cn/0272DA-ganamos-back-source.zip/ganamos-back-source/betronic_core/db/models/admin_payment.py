from datetime import datetime
from typing import List
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Index
from sqlalchemy import and_
from sqlalchemy.orm import Session, relationship
from .base import BaseModel


class AdminPaymentRequestModel(BaseModel):
    __tablename__ = 'admin_payment_request'

    CREATED = 0
    PAID = 1
    CANCELED = 2

    STATUSES = {
        CREATED: 'Создан',
        PAID: 'Выплачен',
        CANCELED: 'Отменен'
    }

    __table_args__ = (
        Index('ix_created_at_status',
              'created_at', 'status'),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)

    from_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    to_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    requisite_id = Column(ForeignKey("admin_payment_requisite.id"), nullable=False, index=True)
    amount = Column(Integer, nullable=True)
    img_url = Column(String, nullable=True)
    comment = Column(String, nullable=True)

    status = Column(Integer, default=CREATED, nullable=False, index=True)

    from_account = relationship("UserModel", remote_side='UserModel.id',
                                uselist=False, foreign_keys=[from_user_id])
    to_account = relationship("UserModel", remote_side='UserModel.id',
                              uselist=False, foreign_keys=[to_user_id])
    requisite = relationship("AdminPaymentRequisiteModel",
                             remote_side='AdminPaymentRequisiteModel.id',
                             uselist=False, foreign_keys=[requisite_id])

    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    def __init__(self, from_user_id: int, to_user_id: int, requisite_id: int, amount: float, img_url: str):
        self.from_user_id = from_user_id
        self.to_user_id = to_user_id
        self.requisite_id = requisite_id
        self.amount = amount
        self.img_url = img_url

    def __str__(self):
        return str(self.id)


class AdminPaymentRequisiteModel(BaseModel):
    __tablename__ = 'admin_payment_requisite'

    id = Column(Integer, autoincrement=True, primary_key=True)

    user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    payment_system = Column(String(100), nullable=True)
    payment_requisite = Column(String, nullable=True)
    is_deleted = Column(Boolean, default=False, nullable=False)

    account = relationship("UserModel", remote_side='UserModel.id', uselist=False,
                           foreign_keys=[user_id])

    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    def __init__(self, user_id: int, payment_system: str, payment_requisite: str):
        self.user_id = user_id
        self.payment_system = payment_system
        self.payment_requisite = payment_requisite

    def __str__(self):
        return str(self.id)

    @classmethod
    def get_active_by_user_id(cls, db: Session, user_id: int) -> List['AdminPaymentRequisiteModel']:
        return db.query(cls)\
            .filter(and_(cls.user_id == user_id,
                         cls.is_deleted == False)).all()
