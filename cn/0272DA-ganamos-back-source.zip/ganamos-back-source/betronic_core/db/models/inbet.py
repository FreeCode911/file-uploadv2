from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, Float, ForeignKey, Index
from sqlalchemy.orm import relationship, backref
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from typing import List

from .base import BaseModel
from .user import UserModel
from .money_transfer import MoneyTransferModel


class InbetSessionModel(BaseModel):

    __tablename__ = "inbet_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    session = Column(String(100))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="inbet_session", uselist=False,
                        foreign_keys=[user_id])
    create_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_all(cls, db) -> List['InbetSessionModel']:
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id) -> 'InbetSessionModel' or None:
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_session(cls, db, session) -> 'InbetSessionModel' or None:
        try:
            return db.query(cls).filter_by(session=session).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user(cls, db, user_id) -> 'InbetSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None


class InbetTransactionModel(BaseModel):
    __tablename__ = "inbet_transaction"
    __table_args__ = (
        Index("inbet_transaction_plus_transaction_id_ix", "plus_transaction_id"),
        Index("inbet_transaction_minus_transaction_id_ix", "minus_transaction_id"),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)
    trx = Column(String(100))
    plus = Column(Float)
    minus = Column(Float)
    created = Column(DateTime, default=datetime.utcnow)
    user_id = Column(ForeignKey("user.id"))
    user = relationship(
        UserModel,
        backref=backref("inbet_transaction"),
        uselist=False,
        foreign_keys=[user_id])
    plus_transaction_id = Column(ForeignKey("transfer.id"))
    minus_transaction_id = Column(ForeignKey("transfer.id"))
    plus_transaction = relationship(
        MoneyTransferModel,
        backref=backref("inbet_transaction_plus"),
        uselist=False,
        foreign_keys=[plus_transaction_id])
    minus_transaction = relationship(
        MoneyTransferModel,
        backref=backref("inbet_transaction_minus"),
        uselist=False,
        foreign_keys=[minus_transaction_id])
    game = Column(String)
    game_id = Column(String)
    game_uuid = Column(String)

    @classmethod
    def get_all(cls, db):
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id):
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_trx(cls, db, trx):
        try:
            return db.query(cls).filter_by(trx=trx).all()
        except (NoResultFound, ):
            return None
