from betronic_core.db.models.base import BaseModel
from sqlalchemy import Column, Integer, ForeignKey, String, DateTime, Boolean
from sqlalchemy.orm import relationship
from datetime import datetime as dt
from sqlalchemy.orm.exc import NoResultFound, MultipleResultsFound
from secrets import token_hex
from betronic_core.db.models.user import UserModel
from logging import getLogger

logger = getLogger(__name__)

class BetGamesSessionModel(BaseModel):

    __tablename__ = "betgames_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey('user.id'), nullable=True, index=True)
    user = relationship(
        'UserModel', backref='betgames_session', foreign_keys=[user_id]
    )
    token = Column(String(100), index=True)
    created_at = Column(DateTime, default=dt.now())
    is_active = Column(Boolean, default=True)
    timestamp = Column(String, default=str(int(dt.now().timestamp())))

    @classmethod
    def get_by_token(cls, db, token: str):
        try:
            result = db.query(cls).filter(cls.token == token).one()
        except NoResultFound:
            result = None

        return result

    @classmethod
    def refresh_or_get_new_session(cls, db, user_id,
                                   token_bytes: int = 45) -> str:
        try:
            session = db.query(cls).filter(cls.user_id == user_id).one()
            session.token = token_hex(token_bytes)
            session.timestamp = str(int(dt.now().timestamp()))
            session.is_active = True
            session.created_at = dt.now()
        except NoResultFound:
            session = cls()
            session.token = token_hex(token_bytes)
            session.is_active = True
            session.user = UserModel.get_by_id(db, user_id)
        db.add(session)
        db.commit()
        return session.token

    @classmethod
    def get_by_user_id(cls, db, user_id):
        query = db.query(cls).filter(user_id == user_id).all()
        return query

    @classmethod
    def deactivate_session(cls, db, user_id):
        sessions = cls.get_by_user_id(db, user_id)
        for session in sessions:
            session.is_active = False
            db.add(session)
        db.commit()
