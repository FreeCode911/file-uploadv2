from sqlalchemy import Column, Integer, String
from betronic_core.db.models.base import BaseModel


class EzugiTransferModel(BaseModel):
    __tablename__ = "ezugi_transfers"

    id = Column(Integer, primary_key=True)
    transfer_id = Column(Integer)  # MoneyTransferModel.id
    type = Column(String(8))  # "credit", "debit", "rollback"
    uid = Column(Integer)  # user_id
