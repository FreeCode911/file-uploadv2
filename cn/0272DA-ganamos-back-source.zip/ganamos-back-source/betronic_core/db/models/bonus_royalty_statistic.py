from sqlalchemy import Column, Integer, Numeric, String, DateTime
from sqlalchemy import func

from datetime import datetime, date

from .base import BaseModel


class BonusRoyaltyStatisticModel(BaseModel):
    __tablename__ = "bonus_royalty_statistic"
    id = Column(Integer, autoincrement=True, primary_key=True)
    provider = Column(String(60), nullable=False)
    bet_count = Column(Integer, nullable=False)
    bet_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    win_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    total = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    currency = Column(String(5))
    revenue_share_local_currency = Column(Numeric(20, 2, asdecimal=True), nullable=False, server_default=str(0))
    revenue_share_usd = Column(Numeric(20, 2, asdecimal=True), nullable=False, server_default=str(0))
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    @classmethod
    def get_rev_share_by_date_grouped_by_partner(cls, db, start_date: date, end_date: date):
        return (db.query(func.sum(cls.revenue_share_usd), cls.provider).
                filter(cls.created_at.between(start_date, end_date)).
                group_by(cls.provider).all())
