from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from typing import List

from .base import BaseModel
from .user import UserModel


class OutComeBetSessionModel(BaseModel):

    __tablename__ = "outcome_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    session = Column(String(100))
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="outcome_session", uselist=False,
                        foreign_keys=[user_id])
    create_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_all(cls, db) -> List['OutComeBetSessionModel']:
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id) -> 'OutComeBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_session(cls, db, session) -> 'OutComeBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(session=session).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user(cls, db, user_id) -> 'OutComeBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None
