from tornado.options import options
from datetime import datetime, timedelta
from decimal import Decimal

from sqlalchemy import Column, Integer, SmallInteger, String, Numeric, DateTime, ForeignKey, select
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import NoResultFound
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.sql import func
from typing import Union

from betronic_core.db.async_database import session
from betronic_core.constants import TransferTypes

from .base import BaseModel


class BonusTransferTypes:
    TYPE_PROMO_CODE_BONUS = 1
    TYPE_SET_BET = 2
    TYPE_CASHBACK_PAYMENTS = 3
    TYPE_CASHBACK_BET = 4
    TYPE_REGISTRATION_BONUS = 5
    TYPE_ADMIN_REFILL = 6
    TYPE_RETURN_BET = 7
    TYPE_REMOVE_BONUS = 8
    TYPE_ADMIN_DEBIT = 9

    TYPE_BONUS_BURN = 21
    TYPE_BONUS_TO_REAL_MONEY = 999

    BONUS_TYPES = {
        TYPE_PROMO_CODE_BONUS: 'Активация промокода',
        TYPE_SET_BET: 'Поставил ставку',
        TYPE_CASHBACK_PAYMENTS: 'Кэшбек от пополнения средств',
        TYPE_CASHBACK_BET: 'Кэшбек от ставки',
        TYPE_REGISTRATION_BONUS: 'Регистрационный бонус',
        TYPE_ADMIN_REFILL: 'Пополнение администратором',
        TYPE_RETURN_BET: 'Возврат ставки',

        TYPE_REMOVE_BONUS: "Зануление бонусного баланса после пополнения",
        TYPE_BONUS_TO_REAL_MONEY: "Перевод бонусных денег в реальные",
        TYPE_BONUS_BURN: "Сгоревший бонус",

    }

    # BONUS_PAYMENT_TYPES = [TYPE_REFILL]
    BONUS_WITHDRAWAL_TYPES = [TYPE_SET_BET]
    TYPES = TransferTypes.TYPES.copy()
    TYPES.update(BONUS_TYPES)


class BonusTransferModel(BaseModel):
    __tablename__ = "bonus_transfer"
    id = Column(Integer, autoincrement=True, primary_key=True)
    type = Column(SmallInteger)
    from_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    to_user_id = Column(ForeignKey("user.id"), nullable=True, index=True)
    from_account = relationship(
        "UserModel", backref='sent_bonus_transfers', foreign_keys=[from_user_id])
    to_account = relationship(
        "UserModel", backref='received_bonus_transfers',
        foreign_keys=[to_user_id])
    value = Column(Numeric(10, 2, asdecimal=False))
    currency = Column(String(5))
    note = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    additional_data = Column(JSONB, nullable=True, default={})
    transaction_id = Column(String(), index=True, nullable=True)

    def __init__(self, from_user_id: int, to_user_id: int, tr_type: int,
                 value: Union[float, Decimal], note: str = None, transaction_id: str = None) -> 'BonusTransferModel':
        self.from_user_id = from_user_id
        self.to_user_id = to_user_id
        self.type = tr_type
        self.value = value
        self.note = note
        self.transaction_id = transaction_id

    @classmethod
    def get_by_id(cls, db, transfer_id):
        try:
            return db.query(cls).filter_by(id=transfer_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_summary_balance_by_user(cls, db, user_id):
        sum_query = db.query(func.sum(cls.value)).filter(
            cls.to_user_id == user_id, ).one()[0]
        if not sum_query:
            sum_query = float(0.0)
        ex_query = db.query(func.sum(cls.value)).filter(
            cls.from_user_id == user_id).one()[0]
        if not ex_query:
            ex_query = float(0.0)
        balance = sum_query - ex_query
        return balance or Decimal(0)

    @classmethod
    def get_count_bonus_bet_on_month(cls, db, user_id):
        now = datetime.now()
        prev_month = now - timedelta(1 * 365 / 12)
        count = db.query(cls) \
            .filter(cls.from_user_id == user_id,
                    cls.created_at > prev_month,
                    cls.type == BonusTransferTypes.TYPE_SET_BET) \
            .count()
        return count

    @classmethod
    def get_bet_by_note(cls, db, note: str) -> "BonusTransferModel":
        query = db.query(cls).filter(
            cls.type.in_(options.ROYALTY_STATISTIC_BET_TYPES),
            cls.note == note
        )

        return query.first()

    @classmethod
    async def async_get_bet_by_note(cls, connection: AsyncSession, note: Union[str, int]):
        query = (
            select(cls).where(
                cls.type.in_(options.ROYALTY_STATISTIC_BET_TYPES),
                cls.note == note
            )
        )

        raw_result = await connection.execute(query)

        return raw_result.scalar()

    @classmethod
    async def async_create_transfer(
            cls,
            transfer: 'BonusTransferModel',
            connection: AsyncSession = None
    ):
        """
        use "connection" for transaction
        """
        connection = connection if connection else session()
        connection.add(transfer)

        await connection.flush()

        return transfer

    def __str__(self):
        return str(self.id)
    
    @classmethod
    async def async_get_by_transaction_id(cls, connection: AsyncSession, transaction_id: Union[str, int]):
        query = (select(
            cls.id, cls.type, cls.from_user_id,
            cls.to_user_id, cls.value, cls.transaction_id
        ).where(cls.transaction_id == transaction_id))

        raw_result = await connection.execute(query)

        return raw_result.fetchone()
