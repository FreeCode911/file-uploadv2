from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, Boolean, \
    BigInteger, Numeric, or_, and_, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.terminal.terminal_data import TerminalData
from .additional_data import AdditionalData
from .base import BaseModel
from .betroute_registration import BetrouteRegistrationModel
from .email_auth import EmailAuthModel
from .user import UserModel


class FavoritModel(BaseModel):
    __tablename__ = "favorite"

    id = Column(Integer, autoincrement=True, primary_key=True)
    user_id = Column(ForeignKey("user.id"), nullable=True)
    user = relationship(
        "UserModel", backref="owner_favorite", foreign_keys=[user_id])
    data = Column(JSONB)
    is_active = Column(Boolean, default=True)

    @classmethod
    def get_active_favorites_by_user_id(cls, db, user_id: int):
        return db.query(cls).filter(and_(cls.user_id == user_id, \
                                         cls.is_active == True)).all()

    @classmethod
    def get_favorite_by_id(cls, db, id: int) -> 'FavoritModel':
        return db.query(cls).filter(cls.id == id).one()

    @classmethod
    def get_favorite_by_id_and_user(cls, db, id: int, user_id: int):
        return db.query(cls).filter(cls.id == id, cls.user_id == user_id).one()

    @classmethod
    def get_favorite_by_payload(cls, db, data, user_id) -> 'FavoritModel':
        try:
            return db.query(cls).filter(cls.data == data,\
                                        cls.user_id == user_id, cls.is_active == True).one()
        except NoResultFound:
            return None