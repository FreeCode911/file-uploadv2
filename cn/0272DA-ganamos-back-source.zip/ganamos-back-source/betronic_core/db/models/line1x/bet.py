from sqlalchemy import Integer, String, ForeignKey, Column, Numeric, DateTime, Index

from betronic_core.db.models.base import BaseModel, UpdateMixin, TimestampMixin


class Bet1xStatus:
    WAIT = 0
    WIN = 1
    LOSS = 2
    RETURN = 3
    WIN_WIN = 4     # |
    LOSS_LOSS = 5   # |
    WIN_LOSS = 6    # |
    LOSS_WIN = 7    # \ asian bets statuses
    WIN_RET = 8     # / asian bets statuses
    RET_WIN = 9     # |
    LOSS_RET = 10   # |
    RET_LOSS = 11   # |

    STATUS_REPRESENTATION = {
        WAIT: "Ожидание",
        WIN: "Выигрыш",
        LOSS: "Проигрыш",
        RETURN: "Возврат",
        WIN_WIN: "Выигрыш_Выигрыш",
        LOSS_LOSS: "Проигрыш_Проигрыш",
        WIN_LOSS: "Выигрыш_Проигрыш",
        LOSS_WIN: "Проигрыш_Выигрыш",
        WIN_RET: "Выигрыш_Возврат",
        RET_WIN: "Возврат_Выигрыш",
        LOSS_RET: "Проигрыш_Возврат",
        RET_LOSS: "Возврат_Проигрыш",
    }


class BetsLine1xModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "line1x_bet_content"

    __table_args__ = (
        Index('ix_line1x_bet_content_local_coupon_id', "local_coupon_id",),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    remote_bet_code = Column(String(50), nullable=True, index=True)
    local_coupon_id = Column(ForeignKey("line1x_placed_coupon.id"), nullable=False, index=True)
    type = Column(String(15), nullable=False)
    market_name = Column(String, nullable=False)
    bet_name = Column(String, nullable=False, index=True)
    coeff = Column(Numeric(10, 3), nullable=False)
    sport_id = Column(Integer, nullable=False, index=True)
    country_id = Column(Integer, nullable=False, index=True)
    champ_name = Column(String, nullable=False, index=True)
    teams = Column(String, nullable=False, index=True)
    score = Column(String, nullable=True)
    start_date = Column(DateTime)
    status = Column(Integer, default=Bet1xStatus.WAIT)
