from datetime import datetime
from typing import List, Optional, Tuple, Union

from sqlalchemy import Integer, ForeignKey, Column, Numeric, DateTime, Index, desc, and_
from sqlalchemy.orm import relationship, Mapped
from sqlalchemy.orm.exc import NoResultFound

from betronic_core.db.models.base import BaseModel, UpdateMixin, TimestampMixin
from betronic_core.db.models.line1x.bet import BetsLine1xModel
from betronic_core.db.models.money_transfer import MoneyTransferModel


class Coupon1xStatus:
    WAIT = 0
    WIN = 2
    RETURN = 3
    LOSS = 4
    SOLD = 5

    STATUS_REPRESENTATION = {
        WAIT: "Ожидание",
        WIN: "Выигрыш",
        LOSS: "Проигрыш",
        RETURN: "Возврат",
        SOLD: "Продан",
    }

    COUPON_STATUSES_MAP = {
        "win": WIN,
        "lost": LOSS,
        "pending": WAIT,
        "return": RETURN,
        "sold": SOLD,
    }


class PlacedCouponLine1xModel(BaseModel, TimestampMixin, UpdateMixin):
    __tablename__ = "line1x_placed_coupon"

    __table_args__ = (
        Index('ix_line1x_placed_coupon_uid_created_at', "user_id", "created_at"),
        Index('line1x_placed_coupon_win_transfer_id_ix', "win_transfer_id"),
        Index('line1x_placed_coupon_return_transfer_id_ix', "return_transfer_id"),
        Index('line1x_placed_coupon_bet_transfer_id_ix', "bet_transfer_id"),
    )

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(ForeignKey("user.id"), nullable=False)
    remote_coupon_id = Column(Integer, nullable=False)
    amount = Column(Numeric(10, 2, asdecimal=False), nullable=False)
    status = Column(Integer, default=Coupon1xStatus.WAIT)

    bet_transfer_id = Column(ForeignKey("transfer.id"), nullable=False)
    win_transfer_id = Column(ForeignKey("transfer.id"), nullable=True)
    return_transfer_id = Column(ForeignKey("transfer.id"), nullable=True)

    last_result_timestamp = Column(DateTime, nullable=True)  # TimeStamp последнего изменения статуса в расчетке

    user = relationship(
        "UserModel",
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[user_id]
    )

    bet_transfer: Mapped[MoneyTransferModel] = relationship(
        "MoneyTransferModel",
        backref='line1x_bet_place_transfers',
        foreign_keys=[bet_transfer_id])

    win_transfer: Mapped[MoneyTransferModel] = relationship(
        "MoneyTransferModel",
        backref='line1x_bet_win_transfers',
        foreign_keys=[win_transfer_id])

    return_transfer: Mapped[MoneyTransferModel] = relationship(
        "MoneyTransferModel",
        backref='line1x_bet_return_transfers',
        foreign_keys=[return_transfer_id])

    bets_content: Mapped[BetsLine1xModel] = relationship(
        'BetsLine1xModel',
        backref='local_coupon'
    )

    @classmethod
    def get_by_remote_coupon_id(cls, db, coupon_id):
        try:
            return db.query(cls).filter_by(remote_coupon_id=coupon_id).one()
        except NoResultFound:
            return None

    @classmethod
    def get_coupons_history(cls,
                            db,
                            user_id: int,
                            from_date: datetime,
                            to_date: datetime,
                            limit: Optional[int],
                            offset: Optional[int],
                            status: List[str]) -> List['PlacedCouponLine1xModel']:
        query = db.query(cls)

        query = query.filter(cls.user_id == user_id,
                             cls.created_at.between(from_date, to_date),
                             cls.status.in_(status))

        query = query.order_by(desc(cls.created_at))

        if limit is not None and offset is not None:
            query = query.limit(limit).offset(offset)

        result = query.all()

        return result

    @classmethod
    def get_coupons_history_count(cls,
                                  db,
                                  user_id: int,
                                  from_date: datetime,
                                  to_date: datetime,
                                  status: List[str]) -> int:
        query = db.query(cls)

        query = query.filter(cls.user_id == user_id,
                             cls.created_at.between(from_date, to_date),
                             cls.status.in_(status))

        query = query.order_by(desc(cls.created_at))

        count = query.count()

        return count

    @classmethod
    def get_coupon_history(cls,
                           db,
                           user_id: int,
                           coupon_id: str) -> List['PlacedCouponLine1xModel']:
        query = db.query(cls).join(BetsLine1xModel)

        query = query.filter(cls.user_id == user_id,
                             cls.remote_coupon_id == coupon_id)
        return query.all()

    @classmethod
    def get_coupon_history_by_remote_coupon_id(
            cls,
            db,
            coupon_id: str
    ) -> List['PlacedCouponLine1xModel']:
        query = db.query(cls).join(
            BetsLine1xModel,
            BetsLine1xModel.local_coupon_id == cls.id
        ).filter(
            cls.remote_coupon_id == coupon_id
        )

        return query.all()

    @classmethod
    def get_coupon_history_by_user_ids(
            cls,
            db,
            user_ids: Union[List[int]],
            date_from: datetime,
            date_to: datetime,
            statuses: List[str] = [],
            skip: Optional[str] = 0,
            limit: Optional[str] = 20,
            decreasing_by_id: bool = False
    ) -> Tuple[List['PlacedCouponLine1xModel'], int]:
        query = db.query(cls).filter(
            cls.created_at.between(date_from, date_to),
            cls.user_id.in_(user_ids)
        )

        if statuses:
            query = query.filter(cls.status.in_(statuses))

        total_count = query.count()

        if decreasing_by_id:
            query = query.order_by(cls.id.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return query.all(), total_count
