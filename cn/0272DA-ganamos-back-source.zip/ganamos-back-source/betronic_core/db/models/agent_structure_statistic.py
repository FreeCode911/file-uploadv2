from sqlalchemy import Column, Integer, Numeric, String, DateTime, ForeignKey, Boolean, Index, desc, column
from sqlalchemy.orm import relationship
from sqlalchemy.sql import expression
from sqlalchemy import func, and_
from typing import List, Union

from datetime import datetime, timedelta

from .base import BaseModel
from .email_auth import EmailAuthModel
from .user import UserModel


class AgentStructureStatisticModel(BaseModel):
    __tablename__ = "agent_structure_statistic"
    __table_args__ = (
        Index('ix_agent_statistic_created_at_provider_currency_is_bonus',
              'created_at', 'provider', 'currency', 'is_bonus'),
        Index('ix_agent_statistic_created_at_user_id',
              'created_at', 'user_id'),
    )

    id = Column(Integer, autoincrement=True, primary_key=True)

    currency = Column(String(5))
    provider = Column(String(60), nullable=False)

    direct_bet_count = Column(Integer, nullable=False)
    direct_win_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    direct_bet_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)

    structure_bet_count = Column(Integer, nullable=False)
    structure_bet_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)
    structure_win_sum = Column(Numeric(20, 2, asdecimal=True), nullable=False)

    is_bonus = Column(Boolean, server_default=expression.false(), default=False)

    user_id = Column(Integer, ForeignKey("user.id"), nullable=True, index=True)
    user = relationship(
        'UserModel',
        remote_side='UserModel.id',
        uselist=False,
        foreign_keys=[user_id]
    )

    created_at = Column(DateTime, default=datetime.utcnow)

    @classmethod
    def get_by_user_id_and_date(
            cls,
            db,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        query = db.query(
            UserModel.id.label('user_id'),
            cls.provider.label('provider'),
            func.coalesce(func.sum(cls.direct_bet_count), 0).label('direct_bet_count'),
            func.coalesce(func.sum(cls.direct_win_sum), 0).label('direct_win_sum'),
            func.coalesce(func.sum(cls.direct_bet_sum), 0).label('direct_bet_sum'),
            func.coalesce(func.sum(cls.structure_bet_count), 0).label('structure_bet_count'),
            func.coalesce(func.sum(cls.structure_bet_sum), 0).label('structure_bet_sum'),
            func.coalesce(func.sum(cls.structure_win_sum), 0).label('structure_win_sum')
        ).select_from(
            UserModel
        ).join(
            cls,
            and_(
                cls.created_at >= date_from,
                cls.created_at <= date_to,
                UserModel.id == cls.user_id
            ),
            isouter=True
        )

        if isinstance(user_id, list):
            query = query.filter(UserModel.id.in_(user_id))
        else:
            query = query.filter(
                UserModel.id == user_id
            )

        query = query.group_by(UserModel.id, cls.provider)

        return query.all()

    @classmethod
    def get_total_by_user_id_and_date(
            cls,
            db,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        query = db.query(
            UserModel.id.label('user_id'),
            func.coalesce(func.sum(cls.structure_bet_count), 0).label('structure_bet_count'),
            func.coalesce(func.sum(cls.structure_bet_sum), 0).label('structure_bet_sum'),
            func.coalesce(func.sum(cls.structure_win_sum), 0).label('structure_win_sum')
        ).select_from(
            UserModel
        ).join(
            cls,
            and_(
                cls.created_at >= date_from,
                cls.created_at <= date_to,
                UserModel.id == cls.user_id
            ),
            isouter=True
        )

        if isinstance(user_id, list):
            query = query.filter(UserModel.id.in_(user_id))
        else:
            query = query.filter(
                UserModel.id == user_id
            )

        query = query.group_by(UserModel.id)

        return query.all()

    @classmethod
    def get_total_by_user_id_and_grouped_by_date(
            cls,
            db,
            user_id: int,
            date_from: datetime = None,
            date_to: datetime = None
    ):
        date_list = func.generate_series(date_from, date_to, '1 day').alias('day')
        day = column('day')

        query = db.query(
            day.label("date"),
            func.coalesce(func.sum(cls.structure_bet_sum), 0).label('structure_bet_sum'),
            func.coalesce(func.sum(cls.structure_win_sum), 0).label('structure_win_sum')
        ).select_from(
            date_list
        ).outerjoin(
            cls,
            func.date_trunc('day', cls.created_at).between(day, day + timedelta(days=1))
        ).filter(
            cls.user_id == user_id
        ).group_by(
            day
        )
        return query.all()
