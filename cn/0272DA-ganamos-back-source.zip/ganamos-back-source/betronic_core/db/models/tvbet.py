from datetime import datetime

from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from sqlalchemy.orm.exc import MultipleResultsFound, NoResultFound

from typing import List

from .base import BaseModel
from .user import UserModel


class TvBetSessionModel(BaseModel):

    __tablename__ = "tvbet_session"

    id = Column(Integer, autoincrement=True, primary_key=True)
    auth_token = Column(String(100), nullable=True)
    secure_token = Column(String(100), nullable=True)
    user_id = Column(ForeignKey("user.id"))
    user = relationship(UserModel, backref="tvbet_session", uselist=False,
                        foreign_keys=[user_id])
    auth_created_at = Column(DateTime, default=datetime.now())
    secure_created_at = Column(DateTime, default=datetime.now())
    created_at = Column(DateTime, default=datetime.now())

    @classmethod
    def get_all(cls, db) -> List['TvBetSessionModel']:
        return db.query(cls).all()

    @classmethod
    def get_by_id(cls, db, game_id) -> 'TvBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(id=game_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_auth_token(cls, db, auth_token) -> 'TvBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(auth_token=auth_token).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_secure_token(cls, db, secure_token) -> 'TvBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(secure_token=secure_token).one()
        except (NoResultFound, MultipleResultsFound):
            return None

    @classmethod
    def get_by_user_id(cls, db, user_id) -> 'TvBetSessionModel' or None:
        try:
            return db.query(cls).filter_by(user_id=user_id).one()
        except (NoResultFound, MultipleResultsFound):
            return None
