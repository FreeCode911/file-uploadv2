import os

from sqlalchemy import create_engine
from tornado.options import options

from betronic_core.db.documents.agents_settings import agents_settings
from betronic_core.db.documents.bonus_settings import bonus_settings
from betronic_core.db.documents.deposit_level_settings import deposit_level_settings
from betronic_core.db.documents.first_deposit_bonus_settings import first_deposit_bonus_settings
from betronic_core.db.documents.marketing_owner_settings import marketing_owner_settings
from betronic_core.db.documents.password_check_settings import password_check_settings
from betronic_core.db.documents.payment_settings import payment_settings
from betronic_core.db.documents.social_media_settings import social_media_settings
from betronic_core.db.documents.max_user_creating_count_limit import max_user_creating_count_limit


def get_engine(database_config_data: dict = options.DATABASE):
    url = "postgresql://%(user)s:%(password)s@%(host)s:%(port)s/%(name)s" % database_config_data
    echo = True if os.environ.get('db_echo') is not None else False
    return create_engine(
        url,
        pool_size=options.DATABASE_MIN_POOL_SIZE,
        max_overflow=options.DATABASE_MAX_POOL_SIZE,
        echo=echo)


def get_single_connection_engine(database_config_data: dict = options.DATABASE):
    url = "postgresql://%(user)s:%(password)s@%(host)s:%(port)s/%(name)s" % database_config_data
    echo = True if os.environ.get('db_echo') is not None else False
    # Да, здесь прописан size/max как 1/1, хотя название содержит слово single. Но это только для подстраховки.
    return create_engine(url, pool_size=1, max_overflow=1, echo=echo)


DEFAULT_SETTINGS = {
    'PaymentSettings': payment_settings,
    'BonusSettings': bonus_settings,
    'MarketingOwnerSettings': marketing_owner_settings,
    'FirstDepositBonusSettings': first_deposit_bonus_settings,
    'PasswordCheckSettings': password_check_settings,
    'DepositLevelSettings': deposit_level_settings,
    'AgentsSettings': agents_settings,
    'SocialMediaSettings': social_media_settings,
    'MaxUserCreatingCountLimit': max_user_creating_count_limit,
}


def get_settings():
    from .database import DataBase
    try:
        settings = check_settings_exist(DataBase.get())
    except Exception:
        settings = []
    return settings


def check_settings_exist(db):
    from betronic_core.settings_manager.manager import SettingsManager
    settings = []

    for setting_name in options.ALL_SETTINGS:
        setting = SettingsManager(db).get_setting_by_name(setting_name)
        if not setting:
            setting = get_default_setting(setting_name)
            db.add(setting)
            SettingsManager(db).set_setting_to_cache(setting_name, setting.data)
    db.commit()
    return settings


def get_default_setting(setting_name):
    from betronic_core.db.models.settings import SettingsModel
    setting = SettingsModel()
    setting.name = setting_name
    setting.data = DEFAULT_SETTINGS[setting_name]
    return setting
