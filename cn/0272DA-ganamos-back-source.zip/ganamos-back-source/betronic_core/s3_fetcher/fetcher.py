import base64
import os.path

import boto3
from pydantic import BaseModel
import mimetypes

from tornado.options import options
from typing import Union

class EncryptionSchema(BaseModel):
    encryption_key_id: str = ""
    encryption_type: str = "aws:kms"

class S3CloudBucketFetcher:
    CLOUD_ENDPOINT_URL = options.CLOUD_ENDPOINT_URL
    CLOUD_SERVICE_NAME = options.CLOUD_SERVICE_NAME
    CLOUD_REGION_NAME = options.CLOUD_REGION_NAME
    CLOUD_STATIC_BASE_URL = options.CLOUD_STATIC_BASE_URL

    def __init__(
        self,
        access_key: str,
        secret_access_key: str,
        bucket_name: str = None,
        base_folder: str = "media/",
    ):
        self.bucket_name = bucket_name or options.CLOUD_BUCKET_NAME_FOR_MEDIA
        self.base_folder = os.path.join(options.PROJECT_NAME, base_folder)
        self.encryption_schema = EncryptionSchema(
            encryption_key_id=options.CARACAL_KMS_KEY_ID_FOR_ENCRYPT
        )
        self.access_key = access_key
        self.secret_access_key = secret_access_key

    
    def _get_s3_instance(self):
        session = boto3.session.Session()
        return session.client(
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_access_key,
            service_name=self.CLOUD_SERVICE_NAME,
            endpoint_url=self.CLOUD_ENDPOINT_URL,
            region_name=self.CLOUD_REGION_NAME,
        )
    
    @classmethod
    def _get_media_type(cls, filename: str):
        return mimetypes.MimeTypes().guess_type(filename)[0] or 'image/jpg'

    @classmethod
    def _get_filename(cls, name: str, ext: str = None):
        if not ext:
            return name

        return f"{name}.{ext}" if (ext not in name) else name

    def _get_s3_path_key(self, filename: str):
        return os.path.join(self.base_folder, filename)

    def _configure_media_url_path(self, filename: str):
        return os.path.join(self.CLOUD_STATIC_BASE_URL, self.base_folder, filename)

    @staticmethod
    def _get_s3_bucket_content_body(media_bytes: Union[str, bytes]):
        if isinstance(media_bytes, bytes):
            return media_bytes
        return base64.decodebytes(media_bytes.encode("utf-8"))

    def _upload_media_to_s3_bucket(
            self,
            media_bytes: Union[str, bytes],
            media_type: str, media_s3_path_key: str
    ):
        s3_instance = self._get_s3_instance()
        s3_instance.put_object(
            Body=media_bytes,
            Key=media_s3_path_key,
            Bucket=self.bucket_name,
            ContentType=media_type
        )

        return media_s3_path_key

    def _delete_media_to_s3_bucket(
            self,
            media_s3_path_key: str
    ):
        s3_instance = self._get_s3_instance()
        s3_instance.delete_object(
            Bucket=self.bucket_name,
            Key=media_s3_path_key
        )

        return media_s3_path_key

    def upload_media_from_b64_data(
            self,
            b64_data: Union[str, bytes],
            file_ext: str = None,
            file_name: str = None
    ):
        filename = self._get_filename(name=file_name, ext=file_ext)
        media_type = self._get_media_type(filename=filename)
        media_s3_path_key = self._get_s3_path_key(filename=filename)
        media_s3_url_path = self._configure_media_url_path(filename=filename)
        media_content_body = self._get_s3_bucket_content_body(b64_data)

        self._upload_media_to_s3_bucket(
            media_bytes=media_content_body,
            media_type=media_type,
            media_s3_path_key=media_s3_path_key
        )

        return media_s3_url_path

    def delete_media_by(self, media_key: str):
        self.delete_media_by(media_key=media_key)

        return media_key

    def upload_object_from_bytes(
        self,
        media_bytes: Union[str, bytes],
        name: str = None,
        ext: str = None,
        mime_type: str = None,
    ):
        filename = self._get_filename(name=name, ext=ext)
        file_type = mime_type or self._get_media_type(filename=filename)
        file_path = self._get_s3_path_key(filename=filename)

        self._upload_object_to_s3_bucket(
            media_bytes=media_bytes, media_type=file_type, media_path=file_path
        )
        return file_path
    
    def _upload_object_to_s3_bucket(
        self, media_bytes: Union[str, bytes], media_type: str, media_path: str
    ):
        s3_instance = self._get_s3_instance()

        if self.encryption_schema:
            event_system = s3_instance.meta.events
            event_system.register_first(
                "request-created.s3.PutObject", self.add_encryption_headers
            )

        s3_instance.put_object(
            Body=self._get_s3_bucket_content_body(media_bytes),
            Bucket=self.bucket_name,
            ContentType=media_type,
            Key=media_path,
        )

        return media_path
    
    def add_encryption_headers(self, request, **kwargs):
        request.headers[
            "X-Amz-Server-Side-Encryption"
        ] = self.encryption_schema.encryption_type
        request.headers[
            "X-Amz-Server-Side-Encryption-Aws-Kms-Key-Id"
        ] = self.encryption_schema.encryption_key_id