from datetime import datetime as dt
from typing import List

from betronic_core.constants import TransferTypes
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel as U
from betronic_core.db.models.xpg_session import XPGSessionModel
from betronic_core.db.models.xpg_transaction import XPGTransactionModel
from betronic_core.manager import IManager
from betronic_core.money_manager.manager import MoneyManager
from util.error import CustomError
from . import error_codes


class XProGamingManager(IManager):

    @staticmethod
    def validate_request_body(params_list: list, body_of_request: dict) -> list:
        result = []

        try:
            for param in params_list:
                required_param = body_of_request[param]
                if not required_param and not type(required_param) in (str, int, float):
                    raise KeyError
                result.append(required_param)
        except KeyError:
            raise CustomError(error_codes.REQUIRED_FILED_MISSING, "Obligatory Field Missing")

        return result

    def get_transaction_by_unique_params(self, game_id: str, round_id: str, user_id: int,
                                         sequence: int = None, provider_id: int = None,
                                         transfer_types: list = None) -> XPGTransactionModel:
        return XPGTransactionModel.get_by_unique_params(self.db, game_id, round_id, user_id, sequence, provider_id,
                                                        transfer_types)

    def create_xpg_transfer(self, from_user_id: int, to_user_id: int,
                            amount: float, transfer_type: int,
                            game_id: int, round_id: int,
                            sequence_of_transaction: int = None,
                            provider_id=None,
                            provider_transaction_id: str = None,
                            commit=True) -> XPGTransactionModel or (XPGTransactionModel, MoneyTransferModel):
        money_transaction = MoneyManager(self.db).user_move_money(from_user_id,
                                                                  to_user_id,
                                                                  amount,
                                                                  transfer_type,
                                                                  "round_id: %s game_id %s" % (round_id, game_id))
        user_id = from_user_id if from_user_id > 0 else to_user_id
        xpg_transaction = XPGTransactionModel(type=transfer_type,
                                              game_id=game_id,
                                              round_id=round_id,
                                              sequence=sequence_of_transaction,
                                              external_transaction_id=provider_transaction_id,
                                              provider_id=provider_id,
                                              user_id=user_id,
                                              transfer_id=money_transaction.id)

        self.db.add(xpg_transaction)
        if commit:
            self.db.commit()
        else:
            return xpg_transaction, money_transaction
        return xpg_transaction

    def set_cancel_transaction(self, origin_transaction: XPGTransactionModel,
                               cancel_transaction: XPGTransactionModel):
        origin_transaction.cancel_transfer = cancel_transaction.transfer
        self.db.add(origin_transaction)
        self.db.commit()

    def get_or_create_xpg_session(self, user_id: int, session_token: str):
        session = XPGSessionModel.get_by_user(self.db, user_id=user_id)
        if session:
            session.token = session_token
            session.created_at = dt.now()
            self.db.add(session)
            self.db.commit()
            return session

        session = XPGSessionModel()
        session.user_id = user_id
        session.token = session_token
        session.created_at = dt.now()
        self.db.add(session)
        self.db.commit()

        return session

    def check_duplicate_transaction(self, user_id: int, provider_transaction: str) -> XPGTransactionModel:
        return XPGTransactionModel.get_by_provider_transaction_id(self.db, user_id, provider_transaction)

    def create_not_existing_transaction(self,
                                        user_id: int,
                                        game_id: int,
                                        round_id: int,
                                        sequence_of_transaction: int,
                                        provider_id: int,
                                        transaction_id: str) -> XPGTransactionModel:
        """
        Function for creating not existing transaction for future checking and correct response to XPG.
        """
        new_transaction = XPGTransactionModel(user_id=user_id,
                                              type=XPGTransactionModel.XPG_NOT_EXISTING_TRANSACTION,
                                              game_id=game_id,
                                              round_id=round_id,
                                              sequence=sequence_of_transaction,
                                              provider_id=provider_id)
        if transaction_id:
            new_transaction.external_transaction_id = transaction_id
        self.db.add(new_transaction)
        self.db.commit()
        return new_transaction

    def get_transactions_for_cancel(self,
                                    game_id: int,
                                    round_id: int,
                                    logins: List[str]) -> List[XPGTransactionModel] or None:
        return XPGTransactionModel.get_transactions_for_cancel(self.db, game_id, round_id, logins)

    def get_canceled_transactions(self,
                                  game_id: int,
                                  round_id: int) -> List[XPGTransactionModel] or None:
        return XPGTransactionModel.get_canceled_transactions(self.db, game_id, round_id)

    @staticmethod
    def get_transactions_by_type(list_of_transactions: List[XPGTransactionModel], transfer_type):
        return [item for item in list_of_transactions if item.type == transfer_type]

    def cancel_transactions_by_type(self, list_of_transactions: List[XPGTransactionModel],
                                    transfer_type) -> List[XPGTransactionModel]:
        result_transactions = []

        for item in list_of_transactions:
            from_user_id = U.ORGANIZATION_ID if transfer_type == TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT \
                else item.user_id

            to_user_id = item.user_id if transfer_type == TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT \
                else U.ORGANIZATION_ID

            xpg_transaction, money_transaction = self.create_xpg_transfer(from_user_id,
                                                                          to_user_id,
                                                                          item.transfer.value,
                                                                          transfer_type,
                                                                          item.game_id,
                                                                          item.round_id,
                                                                          item.sequence,
                                                                          item.provider_id,
                                                                          item.external_transaction_id,
                                                                          commit=False)
            item.cancel_transfer = money_transaction
            self.db.add(item)
            result_transactions.append(xpg_transaction)
        self.db.commit()
        return result_transactions
