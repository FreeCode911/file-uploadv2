from logging import getLogger

from sqlalchemy.orm.attributes import flag_modified
from tornado.options import options

from betronic_core.constants import TransferTypes as tt
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.promo_code import PromoCodeActivationModel
from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.pragmatic_fetcher.fetcher import PragmaticFetcher, PragmaticServiceResponseStatus
from betronic_core.promocode_manager import errors
from util.error import PragmaticError, InvalidRequestData

logger = getLogger(__name__)


class ITypePromocodeActivator:

    def __init__(self, db, promocode: PromoCodeModel = None,
                 user: UserModel = None):
        self.db = db
        self.user = user
        self.promocode = promocode

    def _activate(self):
        raise NotImplementedError

    def _deactivate(self):
        raise NotImplementedError

    def activate(self):
        result: dict = self._activate()
        result = result or {}
        self.set_user_refferal_id()
        self.add_to_promocode_activation_model(**result)

    def deactivate(self):
        self._deactivate()

    def set_user_refferal_id(self):
        if not self.promocode:
            return

        if self.promocode.partner_id:
            logger.info('Add refferal_id {} to user {}'.format(
                self.promocode.partner_id, self.user.id))
            self.user.referral_id = self.promocode.partner_id
            self.db.add(self.user)
            self.db.commit()

    def add_to_promocode_activation_model(self, **kwargs):
        logger.info('Add promocode activation to PromoCodeActivationModel')
        activation = PromoCodeActivationModel()
        activation.user_id = self.user.id
        activation.transfer_id = kwargs.get('transfer_id', None)
        activation.additional_data = {**kwargs}
        activation.promo_code_id = self.promocode.id
        activation.is_closed = kwargs.get('is_closed', True)
        activation.is_hidden = kwargs.get('is_hidden', False)
        self.db.add(activation)
        self.db.commit()
        return activation


class  NormalPromocodeActivator(ITypePromocodeActivator):

    def _activate(self):
        logger.info('Try to activate normal promocode {} for user {}'
                    .format(self.promocode.code, self.user.id))

        money_manager = MoneyManager(self.db)

        converted_amount = CurrencyRateModel.convert(
            self.db, self.promocode.amount, options.PROMOCODE_CURRENCY,
            self.user.currency)

        transfer = money_manager.user_move_money(
            UserModel.ORGANIZATION_ID, self.user.id, converted_amount,
            tt.TYPE_PROMOCODE_BONUS)

        return {'transfer_id': transfer.id}

    def _deactivate(self):
        logger.info('Try to deactivate normal promocode for user {}'
                    .format(self.user.id))
        logger.info('Nothing to do. Normal promocode '
                    'self-deactivated after activate')


class PercentPromocodeActivator(ITypePromocodeActivator):

    def _activate(self):
        logger.info('Try to activate percent promocode {} for user {}'
                    .format(self.promocode.code, self.user.id))
        self.user.promo_code = self.promocode.code
        self.db.add(self.user)
        self.db.commit()

    def _deactivate(self):
        logger.info('Try to deactivate percent promocode for user {}'
                    .format(self.user.id))

        if not self.user.promo_code:
            logger.info('Nothing to do. There is not percent promocode')

        self.user.promo_code = None
        self.db.add(self.user)
        self.db.commit()


class StobonusPromocodeActivator(ITypePromocodeActivator):

    activation_params = {'STOBONUS_FIRST_PAYMENT_MULTIPLIER':
                             options.STOBONUS_FIRST_PAYMENT_MULTIPLIER,
                         'STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER':
                             options.STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER,
                         'SETOBONUS_MIN_BET_COEF':
                             options.SETOBONUS_MIN_BET_COEF}

    def deactivate_all_others(self):
        logger.info('Stobonus promocode activator try to '
                    'deactivate other promocodes')
        NormalPromocodeActivator(self.db, user=self.user).deactivate()
        PercentPromocodeActivator(self.db, user=self.user).deactivate()
        self.deactivate_hidden_default()

    def _activate(self):
        self.deactivate_all_others()

        return self.activation_params

    def _deactivate(self):
        money_manager = MoneyManager(self.db)
        transfer = money_manager.user_move_money(
            from_user_id=UserModel.ORGANIZATION_ID, to_user_id=self.user.id,
            value=float(0.0), transfer_type=tt.TYPE_STOBONUS)

        activation = PromoCodeActivationModel\
            .get_stobonus_by_user_id(self.db, self.user.id)

        activation.transfer = transfer
        self.db.add(activation)
        self.db.commit()

    def activate_hidden_default(self, user_id: int):
        self.user = UserModel.get_by_id(self.db, user_id)
        self.promocode = PromoCodeModel.get_by_code(
            self.db, options.STOBONUS_DEFAULT_PROMOCODE)
        self.add_to_promocode_activation_model(
            is_hidden=True, additional_data=self.activation_params)

    def deactivate_hidden_default(self):
        hidden = self.db.query(PromoCodeActivationModel)\
            .filter(PromoCodeActivationModel.is_hidden)\
            .filter(PromoCodeActivationModel.user_id == self.user.id)\
            .scalar()

        if hidden:
            self.db.delete(hidden)
            self.db.commit()


class SportCashbackPromocodeActivator(ITypePromocodeActivator):
    def _activate(self):
        logger.info(f'Try to activate sport cashback promocode {self.promocode.code} for user {self.user.id}')
        return {"is_closed": False}

    def _deactivate(self):
        logger.info('Try to deactivate sport cashback promocode for user {}'.format(self.user.id))
        logger.info('Nothing to do. Sport cashback promocode self-deactivated after activate')


class PragmaticFreespinsPromocodeActivator(ITypePromocodeActivator):
    def _activate(self):

        try:
            remote_result = PragmaticFetcher.patch_update_pragmatic_freespins(self.promocode, self.user)
        except PragmaticError as remote_err:

            logger.error(
                f"Error when trying activate freespins promocode: {remote_err.status_code, remote_err.error_message}"
            )
            if remote_err.status_code == PragmaticServiceResponseStatus.FREESPINS_OBJ_ALREADY_ACTIVATED:
                raise InvalidRequestData(
                    errors.SINGLE_ACTIVATED_PROMOCODE_HAVE_BEEN_ACTIVATED,
                    f"Promocode: {self.promocode.code} is already activated."

                )
            elif remote_err.status_code == PragmaticServiceResponseStatus.REMOTE_SERVER_ERROR:
                raise InvalidRequestData(errors.REMOTE_SYSTEM_ERROR, f"Remote system error: {remote_err.error_message}")
            elif remote_err.status_code == PragmaticServiceResponseStatus.FREESPINS_OBJ_NOT_FOUND:
                raise InvalidRequestData(errors.PROMOCODE_NOT_FOUND, "Promocode is not found.")
            elif remote_err.status_code == PragmaticServiceResponseStatus.INVALID_SESSION_TOKEN:
                raise InvalidRequestData(errors.USER_IS_NOT_PRAGMATIC_PLAYER, "Player hasn't played pragmatic yet.")
            else:
                raise InvalidRequestData(errors.PROMOCODE_IS_BANNED_BY_ADMIN, "Unknown error")
        else:
            self.promocode.additional_data["activation_result"] = remote_result
            flag_modified(self.promocode, "additional_data")
            self.db.add(self.promocode)
            return {}
    def _deactivate(self):
        logger.info('Try to deactivate pragmatic freespins promocode for user {}'.format(self.user.id))
        logger.info("Nothing to do. Pragmatic freespins can't be deactivated after activation.")
