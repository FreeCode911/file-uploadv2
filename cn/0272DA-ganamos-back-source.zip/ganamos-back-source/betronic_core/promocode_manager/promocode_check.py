from datetime import datetime

from betronic_core.checks_chains import ChecksChain, CheckHandler
from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.promocode_manager import errors as er
from util.error import InvalidRequestData


class ITypePromocodeCheckHandler(CheckHandler):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.code = kwargs.get('code')

    def check_promocode_exist(self):
        promocode = PromoCodeModel.get_by_code(self.db, self.code)

        if not promocode:
            raise InvalidRequestData(er.PROMOCODE_NOT_FOUND,
                                     'Промокод не найден')

    def check_promocode_hasnt_been_expired(self):
        promocode: PromoCodeModel = PromoCodeModel.get_by_code(self.db,
                                                               self.code)
        if promocode.available_to and \
                promocode.available_to < datetime.now():
            raise InvalidRequestData(er.PROMOCODE_EXPIRED,
                                     'Срок действия промокода окончен')


class NormalPromocodeCheckHandler(ITypePromocodeCheckHandler):
    pass


class PercentPromocodeCheckHandler(ITypePromocodeCheckHandler):
    pass


class StobonusPromocodeHandler(ITypePromocodeCheckHandler):
    pass


class SportCashbackPromocodeHandler(ITypePromocodeCheckHandler):
    pass

class PragmaticFreespinsPromocodeHandler(ITypePromocodeCheckHandler):
    pass


class PromocodeChecker(ChecksChain):

    HANDLERS = {
        PromoCodeModel.TYPE_NORMAL: NormalPromocodeCheckHandler,
        PromoCodeModel.TYPE_PERCENT: PercentPromocodeCheckHandler,
        PromoCodeModel.TYPE_STOBONUS: StobonusPromocodeHandler,
        PromoCodeModel.TYPE_SPORT_CASHBACK: SportCashbackPromocodeHandler,
        PromoCodeModel.TYPE_PRAGMATIC_FREESPINS: PragmaticFreespinsPromocodeHandler
    }

    def __init__(self, *args, **kwargs):

        super().__init__(*args, **kwargs)

        code: str = kwargs.get('code', None)

        promocode = PromoCodeModel.get_by_code(self.db, code)

        if not promocode:
            raise InvalidRequestData(er.PROMOCODE_NOT_FOUND,
                                     'Промокод {} не найден'.format(code))

        self.set_handler(promocode.code_type, code=code)


