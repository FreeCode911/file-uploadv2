from betronic_core.manager import IManager
from betronic_core.db.models.promo_code import PromoCodeModel, \
    PromoCodeActivationModel
from betronic_core.promocode_manager.promocode_check import \
    PromocodeChecker
from tornado.options import options
from betronic_core.promocode_manager.apply_promocode_checker import \
    CheckPromocodeApplyToUser
from betronic_core.promocode_manager.promocode_activator import \
    PromocodeActivator
from betronic_core.promocode_manager.activators import \
    StobonusPromocodeActivator
from betronic_core.constants import TransferTypes as tt
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel
from betronic_core.db.models.payments import \
    MoneyTransferModel as MoneyTransfer
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.db.models.user import UserModel


class PromocodeManager(IManager):

    def check_promocode(self, code: str):
        PromocodeChecker(db=self.db, code=code).do_checks()

    def check_promocode_apply_to_user(self, code: str, user_id: int):
        CheckPromocodeApplyToUser(
            db=self.db, code=code, user_id=user_id).do_checks()

    def activate_promocode(self, code: str, user_id: int):
        PromocodeActivator(self.db, code, user_id).activate()

    def hide_stobonus_promocode(self, user_id: int):
        StobonusPromocodeActivator(self.db).activate_hidden_default(user_id)

    def create_stobonus_promocode(self, code: str = None,
                                  partner_id: int = None):

        code = code or PromoCodeModel.generate_code()

        additional_data = {'STOBONUS_FIRST_PAYMENT_MULTIPLIER':
                               options.STOBONUS_FIRST_PAYMENT_MULTIPLIER,
                           'STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER':
                               options.STOBONUS_TARGET_BET_AMOUNT_MULTIPLIER}

        promocode = PromoCodeModel(code=code, partner_id=partner_id,
                                   code_type=PromoCodeModel.TYPE_STOBONUS,
                                   amount=0, additional_data=additional_data)
        self.db.add(promocode)
        self.db.commit()

        return promocode

    def get_promocode_history(self, user_id: int):

        result = []

        history = PromoCodeActivationModel\
            .get_promocode_history_by_user(self.db, user_id)

        if not history:
            return result

        for activation in history:

            transfer_fill = activation.transfer.value if \
                activation.transfer_id else None

            result.append({
                'code': activation.promo_code.code,
                'type_int': activation.promo_code.code_type,
                'type_text':
                    PromoCodeModel.TYPES[activation.promo_code.code_type],
                'transfer_fill': transfer_fill,
            })

        return result

    def get_stobonus_info(self, user_id: int):
        activation: PromoCodeActivationModel = PromoCodeActivationModel\
            .get_stobonus_by_user_id(self.db, user_id)

        first_payment_coef, target_bet_coef = activation.get_stobonus_coefs()
        min_bet_coef = activation.get_stobonus_min_coef()

        currentBetAmount: float = \
            BetrouteLocalBetModel.get_user_current_bet_amount(
                self.db, user_id, min_bet_coef, activation.created_at)

        bet_end_date = BetrouteLocalBetModel\
            .get_first_date_after_stobonus_activation(self.db, activation)

        first_payment_amount = MoneyTransfer.get_first_payment_value(
            self.db, user_id, activation.created_at, bet_end_date)

        personalBonusAmount = first_payment_amount * first_payment_coef

        targetBetAmount: float = first_payment_amount * target_bet_coef

        progress: float = currentBetAmount / targetBetAmount * 100 if\
            targetBetAmount else 0

        progress = int(progress) if progress <= 100 else 100

        hasWithdrawals = len(
            WithdrawalModel.get_withdrawals(self.db, user_id,
                                            begin=activation.created_at)) > 0

        return {
            'personalBonusAmount': personalBonusAmount,
            'currentBetAmount': currentBetAmount,
            'targetBetAmount': targetBetAmount,
            'progress': progress,
            'isBannedByAdmin': activation.is_banned,
            'hasWithdrawals': hasWithdrawals,
            'firstPaymentCoef': first_payment_coef,
            'targetBetCoef': target_bet_coef,
            'minBetCoef': min_bet_coef
        }

    def fill_stobonus(self, user_id: int, amount: float):
        activation: PromoCodeActivationModel = PromoCodeActivationModel \
            .get_stobonus_by_user_id(self.db, user_id)

        bonus_transfer = MoneyManager(self.db).user_move_money(
            from_user_id=UserModel.ORGANIZATION_ID,
            to_user_id=activation.user_id,
            transfer_type=tt.TYPE_STOBONUS,
            value=amount)

        activation.transfer = bonus_transfer
        self.db.add(activation)
        self.db.commit()
