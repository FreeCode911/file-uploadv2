from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.user import UserModel
from betronic_core.promocode_manager import errors as er
from betronic_core.promocode_manager.activators import \
    NormalPromocodeActivator, PercentPromocodeActivator, \
    StobonusPromocodeActivator, SportCashbackPromocodeActivator, PragmaticFreespinsPromocodeActivator
from util.error import InvalidRequestData


class PromocodeActivator:

    TYPE_ACTIVATORS = {
        PromoCodeModel.TYPE_NORMAL: NormalPromocodeActivator,
        PromoCodeModel.TYPE_PERCENT: PercentPromocodeActivator,
        PromoCodeModel.TYPE_STOBONUS: StobonusPromocodeActivator,
        PromoCodeModel.TYPE_SPORT_CASHBACK: SportCashbackPromocodeActivator,
        PromoCodeModel.TYPE_PRAGMATIC_FREESPINS: PragmaticFreespinsPromocodeActivator
    }

    def __init__(self, db, code: str = None, user_id: int = None):
        self.db = db

        if code:
            self.promocode: PromoCodeModel = PromoCodeModel\
                .get_by_code(self.db, code)
        if user_id:
            self.user: UserModel = UserModel.get_by_id(self.db, user_id)

        self.set_activator(promocode_type=self.promocode.code_type)

    def set_activator(self, promocode_type):
        try:
            self.activator = self.TYPE_ACTIVATORS[promocode_type]
        except KeyError or AttributeError:
            raise InvalidRequestData(
                er.UNKNOWN_PROMOCODE_TYPE, 'Неизвестный тип промокода')

    def activate(self):
        self.activator(self.db, self.promocode, self.user).activate()

    def deactivate_all(self):
        for Activator in self.TYPE_ACTIVATORS:
            Activator(self.db, user=self.user).deactivate()
