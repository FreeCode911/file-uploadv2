from betronic_core.checks_chains import ChecksChain, CheckHandler
from betronic_core.constants import TransferTypes as tt
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.promo_code import PromoCodeModel, \
    PromoCodeActivationModel
from betronic_core.db.models.user import UserModel
from betronic_core.promocode_manager import errors as er
from util.error import InvalidRequestData


class ITypeCheckHandler(CheckHandler):
    def __init__(self, *a, **kw):
        super().__init__(*a, **kw)

        self.code = kw.get('code')
        self.user_id = kw.get('user_id')

        self.promocode: PromoCodeModel = PromoCodeModel\
            .get_by_code(self.db, self.code)

    def check_user_havent_activated_this_promocode(self):
        if PromoCodeActivationModel.get_by_user_and_code(
                self.db, self.user_id, self.code):
            raise InvalidRequestData(
                er.USER_ALREADY_ACTIVATE_THIS_PROMOCODE,
                'Пользователь {} уже активировал промокод {}'.format(
                    self.user_id, self.code))

    def check_single_activation_promocode_havnt_been_activated(self):

        if not self.promocode.single_activation:
            return

        if PromoCodeActivationModel\
                .get_by_promo_code(self.db, self.promocode.id):
            raise InvalidRequestData(
                er.SINGLE_ACTIVATED_PROMOCODE_HAVE_BEEN_ACTIVATED,
                'Одноразовый промокод {} уже был активирован'.format(
                    self.promocode.code))

    def check_user_referral_is_promocode_partner(self):

        user = UserModel.get_by_id(self.db, self.user_id)

        if not user.referral_id:
            return

        if not self.promocode.partner_id:
            return

        if user.referral_id != self.promocode.partner_id:
            raise InvalidRequestData(
                er.REFERRAL_TRY_TO_APPLY_PROMOCODE_OF_ANOTHER_PARTNER,
                'User с id: {user.id} и referral_id: {user.referral_id} '
                'пытается активировать промокод {code} другого партнера'
                .format(user=user, code=self.code))

    def check_partner_doesnt_apply_promocode_to_himself(self):
        if self.user_id == self.promocode.partner_id:
            raise InvalidRequestData(
                er.PARTNER_CANT_APPLY_PROMOCODE_TO_HIMSELF,
                'Партнер {} пытается активировать собственный промокод {}'
                .format(self.user_id, self.code))

    def check_promocode_is_not_banned_for_user(self):
        if self.promocode.is_banned:
            raise InvalidRequestData(er.PROMOCODE_IS_BANNED_BY_ADMIN,
                                     'Промокод забанен админом')


class NormalCheckHandler(ITypeCheckHandler):
    pass


class PercentCheckHandler(ITypeCheckHandler):
    def check_user_hasnt_percent_promocode(self):
        user: UserModel = UserModel.get_by_id(self.db, self.user_id)

        if user.promo_code:
            raise InvalidRequestData(
                er.USER_ALREADY_ACTIVATE_PERCENT_PROMOCODE,
                'Пользователь уже активировал промокод {}'.format(self.code))


class StobonusCheckHandler(ITypeCheckHandler):
    def check_user_havent_activated_this_promocode(self):
        history: [PromoCodeActivationModel] = PromoCodeActivationModel\
            .get_all_user_activations(self.db, self.user_id)

        if not history:
            return

        for activation in history:
            if activation.promo_code.code_type == PromoCodeModel.TYPE_STOBONUS\
                    and not activation.is_hidden:
                raise InvalidRequestData(
                    er.USER_ALREADY_ACTIVATE_STOBONUS_PROMOCODE,
                    'Пользователь {} уже активировал такой промокод'
                    .format(self.user_id))

    def check_user_rejected_stobonus_program(self):
        activation: PromoCodeActivationModel = PromoCodeActivationModel\
            .get_by_user_and_code(self.db, self.user_id, self.code)

        if not activation:
            return

        if activation.is_hidden:
            raise InvalidRequestData(
                er.USER_REJECT_STOBONUS_EARLIER,
                'Пользователь {} ранее отказался от участия в +X%'
                    .format(self.user_id))

    def check_user_already_has_this_bonus(self):
        bonus_transfer = self.db.query(MoneyTransferModel)\
            .filter(MoneyTransferModel.to_user_id == self.user_id)\
            .filter(MoneyTransferModel.type == tt.TYPE_STOBONUS).first()

        if bonus_transfer:
            raise InvalidRequestData(
                er.STOBONUS_HAS_BEEN_FILLED_EARLIER,
                'Пользователь {} уже получал этот бонус'
                    .format(self.user_id))

class SportCashbackPromocodeChecker(ITypeCheckHandler):
    pass

class PragmaticFreespinsPromocodeChecker(ITypeCheckHandler):
    pass

class CheckPromocodeApplyToUser(ChecksChain):

    HANDLERS = {
        PromoCodeModel.TYPE_NORMAL: NormalCheckHandler,
        PromoCodeModel.TYPE_PERCENT: PercentCheckHandler,
        PromoCodeModel.TYPE_STOBONUS: StobonusCheckHandler,
        PromoCodeModel.TYPE_SPORT_CASHBACK: SportCashbackPromocodeChecker,
        PromoCodeModel.TYPE_PRAGMATIC_FREESPINS: PragmaticFreespinsPromocodeChecker
    }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        code: str = kwargs.get('code', '')
        user_id: int = kwargs.get('user_id')

        self.promocode: PromoCodeModel = PromoCodeModel \
            .get_by_code(self.db, code)

        self.set_handler(self.promocode.code_type, code=code, user_id=user_id)
