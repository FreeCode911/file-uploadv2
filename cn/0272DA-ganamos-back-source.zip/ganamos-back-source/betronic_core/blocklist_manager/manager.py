from logging import getLogger
from typing import Optional

from betronic_core.db.models.permission_details import PermissionDetailsModel
from betronic_core.manager import IManager
from util.redis import SyncRedisWrapperLocal, RedisBaseTypes, AsyncRedisWrapperLocal
from util.validators import validate_decode
from json import loads, dumps
from tornado.options import options
from util.error import CustomError
from .error_codes import GLOBALLY_BLOCKED

logger = getLogger(__name__)


class BlocklistManager(IManager):
    FULL_LOCK_STATE_KEY = "FULL_LOCK_AGENTS"
    GLOBAL_CATEGORY_KEY = "CATEGORY_BLOCKLIST"
    GLOBAL_PROVIDER_KEY = "PROVIDER_BLOCKLIST"

    @classmethod
    def get_blocklist_from_redis(cls, agent_id) -> list:
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(f"{agent_id}_blocklist")
        if value:
            return loads(validate_decode(value))
        return list()

    @classmethod
    async def async_get_blocklist_from_redis(cls, agent_id) -> list:
        value = await AsyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(f"{agent_id}_blocklist")
        if value:
            return loads(validate_decode(value))
        return list()

    @classmethod
    def set_blocklist_to_redis(cls, agent_id, value):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(f"{agent_id}_blocklist", dumps(value))
        return value

    @classmethod
    def check_user_for_blocked_providers(cls, user_db):
        blocklist_user = cls.get_blocklist_from_redis(user_db.id)
        blocklist_agent = cls.get_blocklist_from_redis(user_db.parent_agent_id)
        set_agent = set(blocklist_agent) if blocklist_agent else set()
        set_user = set(blocklist_user) if blocklist_user else set()
        return list(set_user.union(set_agent))

    @classmethod
    def add_user_to_lock_data(cls, subusers_id, category):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(cls.FULL_LOCK_STATE_KEY)
        if value:
            value = loads(validate_decode(value))
        if not value:
            value = {category: subusers_id}
        else:
            if category in value:
                value[category] = list(set(value[category] + subusers_id))
            else:
                value[category] = subusers_id
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(cls.FULL_LOCK_STATE_KEY, dumps(value))
        return value

    @classmethod
    def remove_user_from_lock_data(cls, subusers_id, category):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(cls.FULL_LOCK_STATE_KEY)
        if value:
            value = loads(validate_decode(value))
        if not value:
            value = dict()
        if category in value:
            value[category] = list(set(value[category]) - set(subusers_id))
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(cls.FULL_LOCK_STATE_KEY, dumps(value))
        return value

    def upsert_full_lock_data(self, ids, category, is_full_branch):
        permissions = PermissionDetailsModel.get_by_user_ids(self.db, ids)
        user_permission_details = {detail.user_id: detail for detail in permissions}

        updates = list()
        inserts = list()
        for user_id in ids:
            if user_id in user_permission_details:
                permission_detail = user_permission_details[user_id]
                categories = list(set(permission_detail.categories + [category])) \
                    if is_full_branch else list(set(permission_detail.categories) - {category})
                user_item = {
                    "categories": categories,
                    "is_full_branch": is_full_branch,
                    "id": user_id
                }
                updates.append(user_item)
            else:
                categories = {category} if is_full_branch else []
                user_item = {
                    "user_id": user_id,
                    "categories": categories,
                    "is_full_branch": is_full_branch
                }
                inserts.append(user_item)
    
        if updates:
            PermissionDetailsModel.batch_update(self.db, updates)
        if inserts:
            PermissionDetailsModel.batch_insert(self.db, inserts)

    def upsert_provider_lock_data(self, ids, providers, action):
        user_permission_details = PermissionDetailsModel.get_by_user_ids(self.db, ids)
        updates = list()
        for permission_detail in user_permission_details:
            new_providers = list(set(permission_detail.providers + providers)) \
                if action == 'add' else list(set(permission_detail.providers) - set(providers))
            item = {
                "providers": new_providers,
                "id": permission_detail.user_id
            }
            updates.append(item)
        PermissionDetailsModel.batch_update(self.db, updates)

    @classmethod
    def get_user_lock_data(cls, user_id):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(cls.FULL_LOCK_STATE_KEY)
        output = []
        if value:
            value = loads(validate_decode(value))
            for category, users in value.items():
                if user_id in users:
                    output.append(category)
        return output

    @classmethod
    async def async_check_user_for_blocked_providers(cls, user_id, parent_agent_id):
        blocklist_user = await cls.async_get_blocklist_from_redis(user_id)
        blocklist_agent = await cls.async_get_blocklist_from_redis(parent_agent_id)
        blocklist_global = await cls.async_get_global_blocklist()
        set_agent = set(blocklist_agent) if blocklist_agent else set()
        set_user = set(blocklist_user) if blocklist_user else set()
        return list(set_user.union(set_agent).union(blocklist_global))

    @classmethod
    def add_providers_to_blocklist(cls, agent_id, providers_to_block):
        blocklist = cls.get_blocklist_from_redis(agent_id)
        for provider in providers_to_block:
            if provider not in blocklist:
                blocklist.append(provider)
        cls.set_blocklist_to_redis(agent_id, blocklist)
        return blocklist

    @classmethod
    def remove_providers_from_blocklist(cls, agent_id, providers_to_unblock):
        blocklist = cls.get_blocklist_from_redis(agent_id)
        for provider in providers_to_unblock:
            if provider in blocklist:
                blocklist.remove(provider)
        cls.set_blocklist_to_redis(agent_id, blocklist)
        return blocklist

    @classmethod
    def remove_global_block_category(cls, category: str):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_CATEGORY_KEY
        )
        if value:
            value = set(loads(value))
            if category not in value:
                return
            value.remove(category)
        else:
            value = []
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(
            cls.GLOBAL_CATEGORY_KEY, dumps(list(value))
        )

    @classmethod
    def add_global_block_category(cls, category: str):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_CATEGORY_KEY
        )
        value = validate_decode(value)
        if value:
            value = set(loads(value))
            value = value.union([category])
        else:
            value = set([category])
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(
            cls.GLOBAL_CATEGORY_KEY, dumps(list(value))
        )

    @classmethod
    def remove_global_block_provider(cls, provider: str):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_PROVIDER_KEY
        )
        if value:
            value = set(loads(value))
            if provider not in value:
                return
            value.remove(provider)
        else:
            value = []
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(
            cls.GLOBAL_PROVIDER_KEY, dumps(list(value))
        )

    @classmethod
    def add_global_block_provider(cls, provider: str):
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_PROVIDER_KEY
        )
        if value:
            value = set(loads(value))
            value = value.union([provider])
        else:
            value = set([provider])
        SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).set(
            cls.GLOBAL_PROVIDER_KEY, dumps(list(value))
        )

    @classmethod
    async def async_get_global_blocklist(cls) -> set:
        value = await AsyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_PROVIDER_KEY
        )
        if value:
            return set(loads(value))
        return set()
    
    @classmethod
    async def async_get_global_category_blocklist(cls) -> set:
        value = await AsyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_CATEGORY_KEY
        )
        if value:
            return set(loads(value))
        return set()

    @staticmethod
    def is_full_category(category: str, providers: list[str])-> bool:
        category_data = options.PROVIDERS.get(category, [])
        return len(category_data) == len(providers)

    @classmethod
    async def async_get_user_block_category(cls, user_id: str) -> set:
        value = await AsyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.FULL_LOCK_STATE_KEY
        )
        output = set()
        if value:
            value = loads(validate_decode(value))
            for category, users in value.items():
                if user_id in users:
                    output.add(category)
        return output
    
    @classmethod
    def get_global_providers_block(cls)-> set:
        value = SyncRedisWrapperLocal(RedisBaseTypes.BLOCKLISTS).get(
            cls.GLOBAL_PROVIDER_KEY
        )
        if not value:
            return set()
        return set(loads(value))

    @classmethod
    def check_providers_globally_blocked(cls, providers: list[str])-> None:
        value = cls.get_global_providers_block()
        blocked_providers = value.intersection(set(providers))
        if blocked_providers:
            raise CustomError(GLOBALLY_BLOCKED, f"Globally blocked providers: {', '.join(blocked_providers)}")

    def get_permission_detail(self, user_id: int)-> Optional[PermissionDetailsModel]:
        return PermissionDetailsModel.get_by_id(self.db, user_id)