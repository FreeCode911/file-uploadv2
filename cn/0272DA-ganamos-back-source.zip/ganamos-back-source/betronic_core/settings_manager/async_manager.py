from logging import getLogger
from typing import Optional

from pydantic import create_model
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.models.settings import SettingsModel

logger = getLogger(__name__)


class AsyncSettingsManager:
    @classmethod
    async def get_setting_by_name(
            cls,
            name: str,
            connection: AsyncSession = None
    ) -> Optional[create_model]:
        return await SettingsModel.async_get_setting_by_name(
            name=name,
            connection=connection
        )
