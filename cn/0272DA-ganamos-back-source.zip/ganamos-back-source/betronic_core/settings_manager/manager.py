import json

from tornado.options import options

from betronic_core.manager import IManager
from betronic_core.db.models.settings import SettingsModel
from util.redis import SyncRedisWrapperLocal, RedisBaseTypes

from logging import getLogger
logger = getLogger(__name__)


class SettingsManager(IManager):
    def get_setting_by_name(self, setting_name: str):
        setting = SyncRedisWrapperLocal(
            db=RedisBaseTypes.SITE_SETTINGS,
            connection_data=options.REDIS
        ).get(setting_name)

        if not setting:
            setting = SettingsModel.get_by_name(self.db, setting_name)
            if setting:
                SyncRedisWrapperLocal(
                    db=RedisBaseTypes.SITE_SETTINGS,
                    connection_data=options.REDIS
                ).set(setting_name, json.dumps(setting.data))

                return setting.data
            else:
                return None

        return json.loads(setting)

    @staticmethod
    def set_setting_to_cache(setting_name, data):
        setting = SyncRedisWrapperLocal(
            db=RedisBaseTypes.SITE_SETTINGS,
            connection_data=options.REDIS
        ).get(setting_name)

        if not setting:
            SyncRedisWrapperLocal(
                db=RedisBaseTypes.SITE_SETTINGS,
                connection_data=options.REDIS
            ).set(setting_name, json.dumps(data))
