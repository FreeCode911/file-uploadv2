from tornado.options import options
from typing import List
from betronic_core.structure_manager.manager import  AgentStructureStatisticModel, UserProviderStatisticModel


def prepare_result_agent_statistic_by_query_result(
            provider_statistics: List[AgentStructureStatisticModel],
            is_direct_only: bool
    ):
    providers_statistic = {
        provider_name: {
            'bet_count': 0,
            'bet_amount': 0,
            'win_amount': 0,
            'income_amount': 0,
        } for provider_name in options.ROYALTY_STATISTIC_TRANSFER_TYPES
    }

    providers_statistic_query_result = {
        provider_statistic.provider: {
            'bet_count': (
                provider_statistic.direct_bet_count if is_direct_only else
                provider_statistic.structure_bet_count
            ),
            'bet_amount': (
                provider_statistic.direct_bet_sum if is_direct_only else
                provider_statistic.structure_bet_sum
            ),
            'win_amount': (
                provider_statistic.direct_win_sum if is_direct_only else
                provider_statistic.structure_win_sum
            ),
        } for provider_statistic in provider_statistics
    }

    for provider_name, statistic in providers_statistic_query_result.items():
        providers_statistic[provider_name] = {
            'bet_count': statistic.get('bet_count', 0),
            'bet_amount': statistic.get('bet_amount', 0),
            'win_amount': statistic.get('win_amount', 0),
            'income_amount': statistic.get('bet_amount', 0) - statistic.get('win_amount', 0)
        }
    total_bet_count = sum([provider_result['bet_count'] for provider_result in providers_statistic.values()])
    total_bet = sum([provider_result['bet_amount'] for provider_result in providers_statistic.values()])
    total_won = sum([provider_result['win_amount'] for provider_result in providers_statistic.values()])

    result = {
        'providers': providers_statistic,
        'detail': {
            'total_bet_count': total_bet_count,
            'total_bet': total_bet,
            'total_won': total_won,
            'total_income': total_bet - total_won,
        }
    }

    return result


def prepare_result_user_statistic_by_query_result(
    provider_statistics: List[UserProviderStatisticModel]
):
    providers_statistic = {
        provider_name: {
            'bet_count': 0,
            'bet_amount': 0,
            'win_amount': 0,
            'income_amount': 0,
        } for provider_name in options.ROYALTY_STATISTIC_TRANSFER_TYPES
    }

    providers_statistic_query_result = {
        provider_statistic.provider: {
            'bet_count': provider_statistic.bet_count,
            'bet_amount': provider_statistic.bet_sum,
            'win_amount': provider_statistic.win_sum
        } for provider_statistic in provider_statistics
    }

    for provider_name, statistic in providers_statistic_query_result.items():
        providers_statistic[provider_name] = {
            'bet_count': statistic.get('bet_count', 0),
            'bet_amount': statistic.get('bet_amount', 0),
            'win_amount': statistic.get('win_amount', 0),
            'income_amount': statistic.get('bet_amount', 0) - statistic.get('win_amount', 0)
        }
    total_bet_count = sum([provider_result['bet_count'] for provider_result in providers_statistic.values()])
    total_bet = sum([provider_result['bet_amount'] for provider_result in providers_statistic.values()])
    total_won = sum([provider_result['win_amount'] for provider_result in providers_statistic.values()])

    result = {
        'providers': providers_statistic,
        'detail': {
            'total_bet_count': total_bet_count,
            'total_bet': total_bet,
            'total_won': total_won,
            'total_income': total_bet - total_won,
        }
    }

    return result


def prepare_result_agent_total_statistic_by_query_result(
        user_statistic,
        structure_statistic,
        structure_statistic_by_date,
        ranked_statistic,
        is_user_ranking,
        active_users,
        total_deposits
):
    ranked_agents = []
    ranked_players = []
    if not is_user_ranking:
        ranked_agents = [
            {
                "user_id": rank.user_id,
                "username": rank.username,
                "netwin": rank.direct_netwin_sum}
            for rank in ranked_statistic]
    else:
        ranked_players = [
            {
                "user_id": rank['user_id'],
                "rank": rank['number'],
                "username": rank['username'],
                "bets_count": rank['bets_count'],
                "wins_count": rank['wins_count'],
                "wins_sum": rank['wins_sum'],
                "bets_sum": rank['bets_sum'],
                "netwin": rank['profit']}
            for rank in ranked_statistic]

    result = {
        "bet_count": structure_statistic.structure_bet_count,
        "total_bets": structure_statistic.structure_bet_sum,
        "total_win": structure_statistic.structure_win_sum,
        "total_netwin":  structure_statistic.structure_bet_sum - structure_statistic.structure_win_sum,
        "netwin_by_dates": [
            {
                "date": str(stat_date.date),
                "netwin": stat_date.structure_bet_sum - stat_date.structure_win_sum
            }
            for stat_date in structure_statistic_by_date],
        "total_user_balance": user_statistic[0],
        "total_agent_balance": user_statistic[1],
        "users_count": user_statistic[2],
        "active_users_count": active_users,
        "total_deposits": total_deposits,
        "ranked_agents": ranked_agents,
        "ranked_players": ranked_players
    }

    return result