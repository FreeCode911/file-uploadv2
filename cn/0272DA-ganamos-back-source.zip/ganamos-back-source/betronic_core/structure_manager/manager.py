import json
import logging
from itertools import chain
from typing import Union, Iterable, List
from datetime import datetime, date

from sqlalchemy import select, delete, text
from tornado.options import options

from betronic_core.manager import IManager
from betronic_core.owner_page_manager.copy_helper import bulk_copy
from betronic_core.db.database import DataBase
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.user_provider_statistic import UserProviderStatisticModel
from betronic_core.db.models.agent_structure_statistic import AgentStructureStatisticModel

from util.decorator import error_logging_decorator
from util.redis import SyncRedisWrapperLocal, RedisBaseTypes
from .sql_queries import *
from ..db.models.commission_percents import CommissionBalances

logger = logging.getLogger(__name__)


class StructureStatisticBotManager(IManager):
    @staticmethod
    def _insert_user_provider_statistic_data(calculated_data):
        eng = DataBase.get_engine()
        bulk_copy(eng, UserProviderStatisticModel.__table__, calculated_data)

    @staticmethod
    def _insert_agent_structure_statistic_data(calculated_data):
        eng = DataBase.get_engine()
        bulk_copy(eng, AgentStructureStatisticModel.__table__, calculated_data)

    @staticmethod
    def _insert_agent_commission_data(calculated_data):
        eng = DataBase.get_engine()
        bulk_copy(eng, CommissionBalances.__table__, calculated_data)

    @classmethod
    def _prepare_user_provider_statistic_data_to_insert(
            cls,
            sql_data,
            provider: str,
            currency: str,
            is_bonus: bool,
            created_at_time: str
    ):
        insert_data = []
        for row in sql_data:
            if row["bet_total"] > 0 or row["win_total"] > 0:
                insert_data.append(
                    {
                        "provider": provider,
                        "currency": currency,
                        "bet_count": row["bet_count"],
                        "bet_sum": row["bet_total"],
                        "win_sum": row["win_total"],
                        "user_id": row['user_id'],
                        "is_bonus": is_bonus,
                        "created_at": created_at_time,
                    }
                )

        return insert_data

    @classmethod
    def _prepare_agent_structure_statistic_data_to_insert(
            cls,
            sql_data,
            provider: str,
            currency: str,
            is_bonus: bool,
            created_at_time: str,
    ):
        insert_data = []
        for row in sql_data:
            if row["structure_bet_sum"] > 0 or row["structure_win_sum"] > 0:
                insert_data.append(
                    {
                        "provider": provider,
                        "currency": currency,
                        "direct_bet_count": row["direct_bet_count"],
                        "direct_win_sum": row["direct_win_sum"],
                        "direct_bet_sum": row["direct_bet_sum"],
                        "structure_bet_count": row["structure_bet_count"],
                        "structure_bet_sum": row["structure_bet_sum"],
                        "structure_win_sum": row["structure_win_sum"],
                        "user_id": row['agent_id'],
                        "is_bonus": is_bonus,
                        "created_at": created_at_time,
                    }
                )

        return insert_data

    @classmethod
    def _prepare_agent_commissions_data_to_insert(
            cls,
            sql_data,
            created_at,
            is_manual_mode=False
    ):
        insert_data = []
        for row in sql_data:
            insert_data.append(
                {
                    "commission_percent": row['commission_percent'],
                    "commission_amount": row['commission_amount'],
                    "netwin": row['total'],
                    "created_at": created_at if not is_manual_mode else row['created_at'],
                    "to_user_id": row['to_user_id']
                }
            )

        return insert_data

    def _calculate_user_provider_bonus_statistic_by_currency(
            self,
            currency: str,
            provider: str,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            place_bet_transfers: Iterable[int],
            win_bet_transfers: Iterable[int],
            count_bet_transfers: int
    ):
        logger.info(f'start calculate user bonus transfer statistic '
                    f'for {provider} from {start_date} to {end_date} '
                    f'with currency {currency}.')

        bonus_transfer_data = self.db.execute(
            text(CALCULATE_USER_BONUS_TRANSFER_STATISTIC),
            {
                "date_from": start_date,
                "date_to": end_date,
                "transfer_bet_types": tuple(place_bet_transfers),
                "transfer_win_types": tuple(win_bet_transfers),
                "transfer_count_type": count_bet_transfers,
                "transfer_currency": currency
            }
        ).fetchall()

        bonus_insert_data = self._prepare_user_provider_statistic_data_to_insert(
            provider=provider,
            sql_data=bonus_transfer_data,
            created_at_time=end_date,
            currency=currency,
            is_bonus=True
        )

        if bonus_insert_data:
            self._insert_user_provider_statistic_data(bonus_insert_data)

    def _calculate_user_provider_real_statistic_by_currency(
            self,
            currency: str,
            provider: str,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            place_bet_transfers: Iterable[int],
            win_bet_transfers: Iterable[int],
            count_bet_transfers: int
    ):
        logger.info(f'start calculate user real transfer statistic '
                    f'for {provider} from {start_date} to {end_date} '
                    f'with currency {currency}.')

        real_transfer_data = self.db.execute(
            text(CALCULATE_USER_REAL_TRANSFER_STATISTIC),
            {
                "date_from": start_date,
                "date_to": end_date,
                "transfer_bet_types": tuple(place_bet_transfers),
                "transfer_win_types": tuple(win_bet_transfers),
                "transfer_count_type": count_bet_transfers,
                "transfer_currency": currency
            }
        ).fetchall()

        real_insert_data = self._prepare_user_provider_statistic_data_to_insert(
            provider=provider,
            sql_data=real_transfer_data,
            created_at_time=end_date,
            currency=currency,
            is_bonus=False
        )
        if real_insert_data:
            self._insert_user_provider_statistic_data(real_insert_data)

    def _calculate_user_provider_real_statistic_by_currency_without_iteration(
            self,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            provider_types: dict[dict],
    ):
        logger.info(f'start calculate user real transfer statistic '
                    f'for providers {provider_types.keys()} from {start_date} to {end_date}')

        cte_statement = self._prepate_cte_for_transfer_structure_statistic(provider_types)
        real_transfer_data = self.db.execute(
            text(cte_statement + CALCULATE_USER_REAL_TRANSFER_STATISTIC_WITHOUT_ITERATION),
            {
                "date_from": start_date,
                "date_to": end_date
            }
        ).mappings().fetchall()
        real_transfer_data = [dict(data) for data in real_transfer_data]
        if real_transfer_data:
            self._insert_user_provider_statistic_data(real_transfer_data)

    @staticmethod
    def _prepate_cte_for_transfer_structure_statistic(provider_types: dict[dict]) -> str:
        cte_values = """"""
        for provider, types in provider_types.items():
            cte_values += f"""
                ('{provider}', {types['bet_count_transfer']}, ARRAY{types["place_bet"]}, ARRAY{types["win_bet"]}),"""
        cte_values = cte_values[:-1]
        cte_statement = f"""
        WITH transfer_types_cte AS (
            SELECT * FROM (
            VALUES
                {cte_values})
            AS a (provider, bet_count_transfer, place_bet, win_bet)            
        )"""
        return cte_statement

    def _calculate_user_provider_real_statistic_by_currency_and_structure_path(
            self,
            currency: str,
            provider: str,
            structure_path: str,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            place_bet_transfers: Iterable[int],
            win_bet_transfers: Iterable[int],
            count_bet_transfers: int
    ):
        logger.info(f'start calculate user real transfer statistic for '
                    f'substructure {structure_path} '
                    f'for {provider} from {start_date} to {end_date} '
                    f'with currency {currency}.')

        self.db.execute(text("SET statement_timeout = 600000;"))

        real_transfer_data = self.db.execute(
            text(CALCULATE_USER_REAL_TRANSFER_STATISTIC_BY_STRUCTURE_PATH),
            {
                "structure_path": structure_path,
                "date_from": start_date,
                "date_to": end_date,
                "transfer_bet_types": tuple(place_bet_transfers),
                "transfer_win_types": tuple(win_bet_transfers),
                "transfer_count_type": count_bet_transfers,
                "transfer_currency": currency
            }
        ).fetchall()

        real_insert_data = self._prepare_user_provider_statistic_data_to_insert(
            provider=provider,
            sql_data=real_transfer_data,
            created_at_time=end_date,
            currency=currency,
            is_bonus=False
        )
        if real_insert_data:
            self._insert_user_provider_statistic_data(real_insert_data)

    def _calculate_structure_statistic_by_currency_and_structure_path(
            self,
            structure_path: str,
            currency: str,
            provider: str,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            is_bonus: bool
    ):
        level_number = len(structure_path.split('.'))

        self.db.execute(text("SET statement_timeout = 600000;"))

        max_structure_level = self.db.execute(
            text(GET_USER_MAX_STRUCTURE_LEVEL_BY_STRUCTURE_PATH),
            {
                "structure_path": structure_path
            }
        ).scalar() or 0

        if max_structure_level < 1:
            logger.info(
                f'User max structure data is '
                f'less then 1. Result: {max_structure_level}.'
                f'Breaking...'
            )
            return

        for level_n in range(max_structure_level, level_number - 1, -1):
            logger.info(f"Start. Calculate agent structure level {level_n} "
                        f"for provider {provider} from {start_date} to {end_date} "
                        f"with currency {currency}.")

            self.db.execute(text("SET statement_timeout = 600000;"))

            agents_data = self.db.execute(
                text(GET_AGENT_STRUCTURE_STATISTIC_BY_STRUCTURE_PATH),
                {
                    "structure_path": structure_path,
                    "level_n": level_n,
                    "provider": provider,
                    "currency": currency,
                    "start_date": start_date,
                    "end_date": end_date,
                    "is_bonus": is_bonus
                }
            ).fetchall()

            insert_data = (
                self._prepare_agent_structure_statistic_data_to_insert(
                    provider=provider,
                    sql_data=agents_data,
                    created_at_time=end_date,
                    currency=currency,
                    is_bonus=is_bonus
                )
            )

            if insert_data:
                self._insert_agent_structure_statistic_data(insert_data)

    def _calculate_structure_statistic_by_currency(
            self,
            currency: str,
            provider: str,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date],
            is_bonus: bool
    ):
        max_structure_level = self.db.execute(
            text(GET_USER_MAX_STRUCTURE_LEVEL)
        ).scalar() or 0

        if max_structure_level < 1:
            logger.info(
                f'User max structure data is '
                f'less then 1. Result: {max_structure_level}.'
                f'Breaking...')
            return

        for level_n in range(max_structure_level, 0, -1):
            logger.info(f"Start. Calculate agent structure level {level_n} "
                        f"for provider {provider} from {start_date} to {end_date} "
                        f"with currency {currency}.")

            agents_data = self.db.execute(
                text(GET_AGENT_STRUCTURE_STATISTIC),
                {
                    "level_n": level_n,
                    "provider": provider,
                    "currency": currency,
                    "start_date": start_date,
                    "end_date": end_date,
                    "is_bonus": is_bonus
                }
            ).fetchall()

            insert_data = (
                self._prepare_agent_structure_statistic_data_to_insert(
                    provider=provider,
                    sql_data=agents_data,
                    created_at_time=end_date,
                    currency=currency,
                    is_bonus=is_bonus
                )
            )

            if insert_data:
                self._insert_agent_structure_statistic_data(insert_data)

    def calculate_structure_statistic(self, start_date, end_date, is_manual=False):
        self.check_already_calculated_structure_statistic(start_date, is_manual)

        types = options.NEW_ROYALTY_STATISTIC_TRANSFER_TYPES
        for provider, transfers_types in types.items():
            get_real_currencies = self.db.execute(
                text(GET_TRANSFER_CURRENCIES),
                {
                    "types": tuple(transfers_types["place_bet"] + transfers_types["win_bet"]),
                    "start_date": start_date,
                    "end_date": end_date,
                }
            ).fetchall()

            # get_bonus_currencies = self.db.execute(
            #     GET_TRANSFER_CURRENCIES,
            #     {
            #         "types": tuple(transfers_types["place_bet"] + transfers_types["win_bet"]),
            #         "start_date": start_date,
            #         "end_date": end_date,
            #     }
            # ).fetchall()

            for row in get_real_currencies:
                currency = row["currency"]

                self._calculate_user_provider_real_statistic_by_currency(
                    currency=currency,
                    provider=provider,
                    start_date=start_date,
                    end_date=end_date,
                    place_bet_transfers=tuple(transfers_types["place_bet"]),
                    win_bet_transfers=tuple(transfers_types["win_bet"]),
                    count_bet_transfers=transfers_types["bet_count_transfer"]
                )
                self._calculate_structure_statistic_by_currency(
                    currency=currency,
                    provider=provider,
                    start_date=start_date,
                    end_date=end_date,
                    is_bonus=False
                )

    def _calculate_structure_statistic_by_currency_without_iteration(
            self,
            start_date: Union[str, datetime, date],
            end_date: Union[str, datetime, date]
    ):

        agents_data = self.db.execute(
            text(GET_AGENT_STRUCTURE_STATISTIC_WITHOUT_ITERATION),
            {
                "start_date": start_date,
                "end_date": end_date
            }
        ).mappings().fetchall()

        agents_data = [dict(data) for data in agents_data]
        if agents_data:
            self._insert_agent_structure_statistic_data(agents_data)

    def calculate_structure_statistic_without_iteration(self, start_date, end_date, is_manual=False):
        self.check_already_calculated_structure_statistic(start_date, is_manual)

        self._calculate_user_provider_real_statistic_by_currency_without_iteration(
            start_date=start_date,
            end_date=end_date,
            provider_types=options.NEW_ROYALTY_STATISTIC_TRANSFER_TYPES
        )
        self._calculate_structure_statistic_by_currency_without_iteration(
            start_date=start_date,
            end_date=end_date
        )

    def calculate_structure_statistic_for_structure_path(
            self,
            start_date: str,
            end_date: str,
            structure_path: str,
            royalty_transfer_types: dict = options.NEW_ROYALTY_STATISTIC_TRANSFER_TYPES
    ):
        for provider, transfers_types in royalty_transfer_types.items():
            get_real_currencies = self.db.execute(
                text(GET_TRANSFER_CURRENCIES),
                {
                    "types": tuple(transfers_types["place_bet"] + transfers_types["win_bet"]),
                    "start_date": start_date,
                    "end_date": end_date,
                }
            ).fetchall()

            for row in get_real_currencies:
                currency = row["currency"]
                self._calculate_user_provider_real_statistic_by_currency_and_structure_path(
                    structure_path=structure_path,
                    currency=currency,
                    provider=provider,
                    start_date=start_date,
                    end_date=end_date,
                    place_bet_transfers=tuple(transfers_types["place_bet"]),
                    win_bet_transfers=tuple(transfers_types["win_bet"]),
                    count_bet_transfers=transfers_types["bet_count_transfer"]
                )

                self._calculate_structure_statistic_by_currency_and_structure_path(
                    structure_path=structure_path,
                    currency=currency,
                    provider=provider,
                    start_date=start_date,
                    end_date=end_date,
                    is_bonus=False
                )

    def check_already_calculated_structure_statistic(self, start_date, is_manual_mode=False):
        result = self.db.execute(
            select(1).select_from(
                AgentStructureStatisticModel
            ).where(
                AgentStructureStatisticModel.created_at > start_date
            )
        )
        if not is_manual_mode and result.scalars().first():
            self.db.execute(
                delete(AgentStructureStatisticModel).where(AgentStructureStatisticModel.created_at > start_date)
            )
            self.db.execute(
                delete(UserProviderStatisticModel).where(UserProviderStatisticModel.created_at > start_date)
            )
            self.db.commit()

    def calculate_agents_commissions(self, start_date, end_date, is_manual_mode=False):
        commission_percent_data = self.db.execute(text(GET_COMMISSION_PERCENTS)).mappings().fetchall()
        commission_agents = []
        for row in commission_percent_data:
            if row['to_user_id']:
                commission_agents.append(row['to_user_id'])

        query = GET_AGENT_COMMISSIONS if not is_manual_mode else GET_AGENT_COMMISSIONS_MANUAL_MODE

        commission_balance_data = self.db.execute(
            text(query),
            {
                "start_date": start_date,
                "end_date": end_date,
                "agents_id": tuple(commission_agents)
            }
        ).mappings().fetchall()

        insert_data = self._prepare_agent_commissions_data_to_insert(sql_data=commission_balance_data,
                                                                     created_at=end_date,
                                                                     is_manual_mode=is_manual_mode)

        if insert_data:
            self._insert_agent_commission_data(insert_data)

    def calculate_agents_commissions_by_from_to_user_id(
            self, start_date, end_date, to_user_id: int
    ):
        commission_balance_data = self.db.execute(
            text(GET_AGENT_COMMISSIONS_FOR_USER),
            {
                "start_date": start_date,
                "end_date": end_date,
                "to_user_id": to_user_id
            }
        )

        insert_data = self._prepare_agent_commissions_data_to_insert(
            sql_data=commission_balance_data,
            created_at=end_date,
            is_manual_mode=True
        )
        if insert_data:
            self._insert_agent_commission_data(insert_data)

    def check_already_calculated_structure_statistic_remove_later(self, start_date, end_date):
        result = self.db.execute(
            select(1).select_from(
                AgentStructureStatisticModel
            ).where(
                AgentStructureStatisticModel.created_at.between(start_date, end_date)
            )
        ).scalars().first()
        return result

    @error_logging_decorator
    def recalc_structure_statistic_for_agent_ids(
            self,
            start_date: str,
            end_date: str,
            agent_ids: List[int],
            royalty_transfer_types: dict = options.NEW_ROYALTY_STATISTIC_TRANSFER_TYPES
    ):
        for agent_id in agent_ids:
            logger.info(f"[StructureStatisticBotManager] start recalculate "
                        f"structure statistic for agent with ID {agent_id} "
                        f"from {start_date} to {end_date}")

            agent_db: UserModel = UserModel.get_by_id(self.db, agent_id)
            if not agent_db:
                logger.warning(f"[StructureStatisticBotManager] "
                               f"agent with ID {agent_id} not found")
                continue

            if agent_db.role != UserModel.PARTNER_AGENT:
                logger.warning(f"[StructureStatisticBotManager] "
                               f"agent with ID {agent_id} must have an agent role")
                continue

            logger.info(f"[StructureStatisticBotManager] start deleting "
                        f"agent structure statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.db.execute(
                delete(AgentStructureStatisticModel)
                .where(
                    AgentStructureStatisticModel.user_id.in_(
                        select(UserModel.id)
                        .where(
                            UserModel.role == UserModel.PARTNER_AGENT,
                            UserModel.structure_path.descendant_of(agent_db.structure_path)
                        ).subquery()
                    ),
                    AgentStructureStatisticModel.created_at >= start_date,
                    AgentStructureStatisticModel.created_at <= end_date
                ).execution_options(synchronize_session=False)
            )

            logger.info(f"[StructureStatisticBotManager] start deleting "
                        f"user provider statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.db.execute(
                delete(UserProviderStatisticModel)
                .where(
                    UserProviderStatisticModel.user_id.in_(
                        select(UserModel.id)
                        .where(
                            UserModel.role == UserModel.USER,
                            UserModel.structure_path.descendant_of(agent_db.structure_path)
                        ).subquery()
                    ),
                    UserProviderStatisticModel.created_at >= start_date,
                    UserProviderStatisticModel.created_at <= end_date
                ).execution_options(synchronize_session=False)
            )

            self.db.commit()

            # TODO do delete and recalc commission

            logger.info(f"[StructureStatisticBotManager] start calculating "
                        f"structure statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.calculate_structure_statistic_for_structure_path(
                start_date=start_date,
                end_date=end_date,
                structure_path=str(agent_db.structure_path),
                royalty_transfer_types=royalty_transfer_types
            )

    @error_logging_decorator
    def recalc_script_structure_statistic_for_agent_ids(
            self,
            start_date: str,
            end_date: str,
            agent_ids: List[int],
            provider: str,
            royalty_transfer_types: dict = options.NEW_ROYALTY_STATISTIC_TRANSFER_TYPES,
    ):
        for agent_id in agent_ids:
            logger.info(f"[StructureStatisticBotManager] start recalculate "
                        f"structure statistic for agent with ID {agent_id} "
                        f"from {start_date} to {end_date}")

            agent_db: UserModel = UserModel.get_by_id(self.db, agent_id)
            if not agent_db:
                logger.warning(f"[StructureStatisticBotManager] "
                               f"agent with ID {agent_id} not found")
                continue

            if agent_db.role != UserModel.PARTNER_AGENT:
                logger.warning(f"[StructureStatisticBotManager] "
                               f"agent with ID {agent_id} must have an agent role")
                continue

            logger.info(f"[StructureStatisticBotManager] start deleting "
                        f"agent structure statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.db.execute(
                delete(AgentStructureStatisticModel)
                .where(
                    AgentStructureStatisticModel.created_at >= start_date,
                    AgentStructureStatisticModel.created_at <= end_date,
                    AgentStructureStatisticModel.provider == provider
                ).execution_options(synchronize_session=False)
            )

            logger.info(f"[StructureStatisticBotManager] start deleting "
                        f"user provider statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.db.execute(
                delete(UserProviderStatisticModel)
                .where(
                    UserProviderStatisticModel.provider == provider,
                    UserProviderStatisticModel.created_at >= start_date,
                    UserProviderStatisticModel.created_at <= end_date
                ).execution_options(synchronize_session=False)
            )

            self.db.commit()

            # TODO do delete and recalc commission

            logger.info(f"[StructureStatisticBotManager] start calculating "
                        f"structure statistic for agent with ID "
                        f"{agent_id} from {start_date} to {end_date}")

            self.calculate_structure_statistic_for_structure_path(
                start_date=start_date,
                end_date=end_date,
                structure_path=str(agent_db.structure_path),
                royalty_transfer_types=royalty_transfer_types
            )

            self.db.commit()

    def reset_agent_ranking(self, old_ranking):
        for row in old_ranking:
            old_ranking[row]["rank_points"] = 0.0

        return old_ranking

    def calc_classify_agent_ranking(self, redis_ranking, start_date, end_date):
        ranking = self.db.execute(text(GET_AGENTS_NETWIN_FOR_RANKING),
                                  {"start_date": start_date, "end_date": end_date}).fetchall()
        if len(ranking) > 0:
            for row in ranking:
                if redis_ranking.get(str(row[1]), None):
                    rank_points = redis_ranking[str(row[1])]["rank_points"] + (float(row[0]) * options.AGENT_RANKS_POINT[row[3]]) \
                        if row[0] > 0 else 0
                    redis_ranking[str(row[1])]["rank_points"] = round(rank_points, 2)
                else:
                    rank_points = (
                                float(row[0]) * options.AGENT_RANKS_POINT[row[3]]) \
                        if row[0] > 0 else 0
                    redis_ranking[str(row[1])] = {
                        "id": row[1],
                        "username": row[2],
                        "rank_points": round(rank_points, 2),
                        "rank": None
                    }

            redis_ranking = {
                agent_id: agent_rank_points for agent_id, agent_rank_points
                in sorted(redis_ranking.items(), key=lambda item: item[1]['rank_points'], reverse=True)
            }

            percentage = 100 / len(redis_ranking.items())
            percent_step = 0
            for k, v in redis_ranking.items():
                percent_step += percentage
                rank = next((rank for range_, rank in options.AGENT_RANKS_RANGE.items() if int(percent_step) in range_),
                            None)
                redis_ranking[k]["rank"] = rank

        return redis_ranking


class StructureStatisticManager(IManager):
    def get_provider_statistic_for_agent_by_id(
            self,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        result = AgentStructureStatisticModel\
            .get_by_user_id_and_date(
                db=self.db,
                user_id=user_id,
                date_from=date_from,
                date_to=date_to
            )

        return result
    
    def get_provider_statistic_for_user_by_id(
            self,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        result = UserProviderStatisticModel\
            .get_by_user_id_and_date(
                db=self.db,
                user_id=user_id,
                date_from=date_from,
                date_to=date_to
            )

        return result

    def get_total_statistic(
            self,
            user_ids: list,
            date_from: datetime = None,
            date_to: datetime = None,
            providers: List[str] = None,
    ):

        bet_count = 0
        bet_total = 0
        win_total = 0

        if providers:
            providers = [options.PROVIDER_MAPPER[provider] for provider in providers]

        result = UserProviderStatisticModel \
            .get_by_user_id_and_date(
                db=self.db,
                user_id=user_ids,
                date_from=date_from,
                date_to=date_to,
                providers=providers,
                need_grouping_by_provider=False
            )

        for row in result:
            bet_count += row.bet_count
            bet_total += row.bet_sum
            win_total += row.win_sum

        return bet_count, bet_total, win_total

    def get_total_statistic_for_agent_by_id(
            self,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        result = AgentStructureStatisticModel\
            .get_total_by_user_id_and_date(
                db=self.db,
                user_id=user_id,
                date_from=date_from,
                date_to=date_to
            )

        return result

    def get_total_statistic_for_agent_by_id_grouped_by_date(
            self,
            user_id: Union[int, List[int]],
            date_from: datetime = None,
            date_to: datetime = None
    ):
        result = AgentStructureStatisticModel\
            .get_total_by_user_id_and_grouped_by_date(
                db=self.db,
                user_id=user_id,
                date_from=date_from,
                date_to=date_to
            )

        return result

    def get_agents_ranked_by_netwin(
            self,
            user_db: UserModel,
            date_from: datetime = None,
            date_to: datetime = None
    ):
        query = self.db.execute(text(GET_RANKING_AGENTS), {
            "structure_path": str(user_db.structure_path),
            "user_id": user_db.id,
            "start_date": date_from,
            "end_date": date_to
        })

        return query.all()

    def get_active_users_count(
            self,
            user_db: UserModel,
            date_from: datetime = None,
            date_to: datetime = None
    ):
        query = self.db.execute(text(GET_ACTIVE_USERS_COUNT), {
            "structure_path": str(user_db.structure_path),
            "user_id": user_db.id,
            "start_date": date_from,
            "end_date": date_to
        })

        return query.scalar()
