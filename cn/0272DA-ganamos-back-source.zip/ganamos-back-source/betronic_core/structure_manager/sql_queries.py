CALCULATE_USER_REAL_TRANSFER_STATISTIC = """
SELECT subq.id AS user_id,
               subq.win_total AS win_total,
               subq.bet_total AS bet_total,
               subq.bet_count AS bet_count
        FROM (
                 SELECT users.id,
                        sum(coalesce(transfer_win_total.value, 0)) AS win_total,
                        sum(coalesce(transfer_bet_total.value, 0)) AS bet_total,
                        sum(coalesce(transfer_bet_count.value, 0)) as bet_count
                 FROM "user" users
                 LEFT JOIN (
                    SELECT t.to_user_id as id, sum(t.value) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type IN :transfer_win_types
                        AND t.currency = :transfer_currency
                        AND to_user_id > 0
                    GROUP BY t.to_user_id
                 ) transfer_win_total on (transfer_win_total.id = users.id)
                 LEFT JOIN (
                    SELECT t.from_user_id as id, sum(t.value) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type IN :transfer_bet_types
                        AND t.currency = :transfer_currency
                        AND t.from_user_id > 0
                    GROUP BY t.from_user_id
                 ) transfer_bet_total on (transfer_bet_total.id = users.id)
                 LEFT JOIN (
                    SELECT t.from_user_id as id, count(t.id) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type = :transfer_count_type
                        AND t.currency = :transfer_currency
                        AND t.from_user_id > 0
                    GROUP BY t.from_user_id
                 ) transfer_bet_count on (transfer_bet_count.id = users.id)
                 WHERE users.id > 0 and users.role = '0'
                 GROUP BY users.id
             ) subq;
"""


CALCULATE_USER_REAL_TRANSFER_STATISTIC_WITHOUT_ITERATION = f"""

SELECT totals.currency,
       totals.provider,
       totals.user_id,
       sum(coalesce(totals.win_sum, 0))::numeric(20, 2) AS win_sum,
       sum(coalesce(totals.win_count, 0))::integer      AS win_count,
       sum(coalesce(totals.bet_sum, 0))::numeric(20, 2) AS bet_sum,
       sum(coalesce(totals.bet_count, 0))::integer      as bet_count,
       :date_to ::timestamp          as created_at,
       'false'::boolean                                 as is_bonus
FROM "user" users

         JOIN (SELECT t.currency,
                      tt.provider,
                      0            AS bet_count,
                      SUM(value)   AS win_sum,
                      count(*)     AS win_count,
                      0            AS bet_sum,
                      t.to_user_id as user_id

               FROM "transfer" t
                        JOIN transfer_types_cte tt ON t.type = ANY (tt.win_bet)
               WHERE t.created_at > :date_from
                 AND t.created_at <= :date_to
                 AND t.to_user_id > 0
               GROUP BY t.currency, tt.provider, t.to_user_id
               UNION ALL

               SELECT t.currency,
                      tt.provider,
                      0              AS bet_count,
                      0              AS win_sum,
                      0              AS win_count,
                      SUM(value)     AS bet_sum,
                      t.from_user_id as user_id

               FROM "transfer" t
                        JOIN transfer_types_cte tt ON t.type = ANY (tt.place_bet)
               WHERE t.created_at > :date_from
                 AND t.created_at <= :date_to
                 AND t.from_user_id > 0
               GROUP BY t.currency, tt.provider, t.from_user_id
               UNION ALL

               SELECT t.currency,
                      tt.provider,
                      count(*)       AS bet_count,
                      0              AS win_sum,
                      0              AS win_count,
                      0              AS bet_sum,
                      t.from_user_id as user_id

               FROM "transfer" t
                        JOIN transfer_types_cte tt ON t.type = tt.bet_count_transfer
               WHERE t.created_at > :date_from
                 AND t.created_at <= :date_to
                 AND t.from_user_id > 0
               GROUP BY t.currency, tt.provider, t.from_user_id) totals ON users.id = totals.user_id
WHERE users.id > 0
  and users.role = '0'
GROUP BY totals.currency, totals.provider, totals.user_id
ORDER BY 1, 2, 3;
"""

CALCULATE_USER_REAL_TRANSFER_STATISTIC_BY_STRUCTURE_PATH = """
SELECT subq.id AS user_id,
               subq.win_total AS win_total,
               subq.bet_total AS bet_total,
               subq.bet_count AS bet_count
        FROM (
                 SELECT users.id,
                        sum(coalesce(transfer_win_total.value, 0)) AS win_total,
                        sum(coalesce(transfer_bet_total.value, 0)) AS bet_total,
                        sum(coalesce(transfer_bet_count.value, 0)) as bet_count
                 FROM "user" users
                 LEFT JOIN (
                    SELECT t.to_user_id as id, sum(t.value) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type IN :transfer_win_types
                        AND t.currency = :transfer_currency
                        AND to_user_id > 0
                    GROUP BY t.to_user_id
                 ) transfer_win_total on (transfer_win_total.id = users.id)
                 LEFT JOIN (
                    SELECT t.from_user_id as id, sum(t.value) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type IN :transfer_bet_types
                        AND t.currency = :transfer_currency
                        AND t.from_user_id > 0
                    GROUP BY t.from_user_id
                 ) transfer_bet_total on (transfer_bet_total.id = users.id)
                 LEFT JOIN (
                    SELECT t.from_user_id as id, count(t.id) AS value
                    FROM "transfer" t WHERE
                        t.created_at > :date_from AND t.created_at <= :date_to
                        AND t.type = :transfer_count_type
                        AND t.currency = :transfer_currency
                        AND t.from_user_id > 0
                    GROUP BY t.from_user_id
                 ) transfer_bet_count on (transfer_bet_count.id = users.id)
                 WHERE users.structure_path <@ :structure_path and users.role = '0'
                 GROUP BY users.id
             ) subq;
"""

CALCULATE_USER_BONUS_TRANSFER_STATISTIC = """
SELECT subq.id AS user_id, 
       subq.win_total AS win_total, 
       subq.bet_total AS bet_total, 
       subq.bet_count AS bet_count
FROM (
         SELECT users.id,
            	sum(coalesce(transfer_win_total.value, 0)) AS win_total, 
            	sum(coalesce(transfer_bet_total.value, 0)) AS bet_total, 
            	sum(coalesce(transfer_bet_count.value, 0)) as bet_count
         FROM "user" users
         LEFT JOIN (
            SELECT u.id, sum(t.value) AS value
            FROM "user" u LEFT JOIN "bonus_transfer" t on (
                u.id = t.to_user_id
                AND t.created_at > :date_from
			    AND t.created_at <= :date_to
                AND t.type IN :transfer_win_types
                AND t.currency = :transfer_currency
            )
            WHERE u.id > 0
            GROUP BY u.id
         ) transfer_win_total on (transfer_win_total.id = users.id)
         LEFT JOIN (
            SELECT u.id, sum(t.value) AS value
            FROM "user" u LEFT JOIN "bonus_transfer" t on (
                u.id = t.from_user_id
                AND t.created_at > :date_from
			    AND t.created_at <= :date_to
                AND t.type IN :transfer_bet_types
                AND t.currency = :transfer_currency
            )
            WHERE u.id > 0
            GROUP BY u.id
         ) transfer_bet_total on (transfer_bet_total.id = users.id)
         LEFT JOIN (
            SELECT u.id, count(t.id) AS value
            FROM "user" u LEFT JOIN "bonus_transfer" t on (
                u.id = t.from_user_id
                AND t.created_at > :date_from 
			    AND t.created_at <= :date_to
                AND t.type = :transfer_count_type
                AND t.currency = :transfer_currency
            )
            WHERE u.id > 0
            GROUP BY u.id
         ) transfer_bet_count on (transfer_bet_count.id = users.id)
         WHERE users.id > 0 and users.role = '0'
         GROUP BY users.id
     ) subq;
"""

GET_TRANSFER_CURRENCIES = """
SELECT currency from public.transfer as t
WHERE t.type in :types
AND created_at > :start_date
AND created_at <= :end_date
GROUP BY currency
"""

GET_BONUS_TRANSFER_CURRENCIES = """
SELECT currency from public.bonus_transfer as t
WHERE t.type in :types
AND created_at > :start_date
AND created_at <= :end_date
GROUP BY currency
"""

GET_USER_MAX_STRUCTURE_LEVEL = """
SELECT COALESCE(MAX(nlevel(u.structure_path)), 0) as max_level 
FROM public.user u
"""

GET_USER_MAX_STRUCTURE_LEVEL_BY_STRUCTURE_PATH = """
SELECT COALESCE(MAX(nlevel(u.structure_path)), 0) as max_level 
FROM public.user u
WHERE u.structure_path <@ :structure_path
"""

GET_AGENT_STRUCTURE_STATISTIC = """
SELECT subq.agent_id,
	   subq.direct_bet_count as direct_bet_count,
	   subq.direct_win_sum as direct_win_sum,
	   subq.direct_bet_sum as direct_bet_sum,
	   subq.structure_bet_count as structure_bet_count,
	   subq.structure_bet_sum as structure_bet_sum,
	   subq.structure_win_sum as structure_win_sum
FROM (
		SELECT users.id as agent_id,
		       sum(coalesce(user_direct_statistic.bet_count, 0)) as direct_bet_count,
		       sum(coalesce(user_direct_statistic.win_sum, 0)) as direct_win_sum,
		       sum(coalesce(user_direct_statistic.bet_sum, 0)) as direct_bet_sum,
		       sum(coalesce(agent_structure_statistic.bet_count, 0) + coalesce(user_direct_statistic.bet_count, 0)) as structure_bet_count,
		       sum(coalesce(agent_structure_statistic.bet_sum, 0) + coalesce(user_direct_statistic.bet_sum, 0)) as structure_bet_sum,
		       sum(coalesce(agent_structure_statistic.win_sum, 0) + coalesce(user_direct_statistic.win_sum, 0)) as structure_win_sum
		FROM "user" users
		LEFT JOIN (
			SELECT u.parent_agent_id as parent_agent_id,
			       coalesce(sum(ups.bet_count), 0) AS bet_count,
			       coalesce(sum(ups.win_sum), 0) AS win_sum,
			       coalesce(sum(ups.bet_sum), 0) AS bet_sum
			FROM "user" u LEFT JOIN user_provider_statistic ups on (
			    ups.user_id = u.id
			    AND ups.created_at > :start_date 
			    AND ups.created_at <= :end_date
	            AND ups.provider = :provider
	            AND ups.currency = :currency
	            AND ups.is_bonus = :is_bonus
			)
			WHERE u.id > 0
			  AND u.role = '0'
	        GROUP BY u.parent_agent_id
		) user_direct_statistic on users.id = user_direct_statistic.parent_agent_id
		LEFT JOIN (
			SELECT u.parent_agent_id as parent_agent_id,
			       coalesce(sum(ast.structure_bet_count), 0) AS bet_count,
			       coalesce(sum(ast.structure_bet_sum), 0) AS bet_sum,
			       coalesce(sum(ast.structure_win_sum), 0) AS win_sum
			FROM "user" u LEFT JOIN agent_structure_statistic ast on (
			    ast.user_id = u.id
			    AND ast.created_at > :start_date 
			    AND ast.created_at <= :end_date
                AND ast.provider = :provider
                AND ast.currency = :currency
                AND ast.is_bonus = :is_bonus
			)
			WHERE u.id > 0
			  AND u.role = '6'
	        GROUP BY u.parent_agent_id
		) agent_structure_statistic on users.id = agent_structure_statistic.parent_agent_id
		WHERE users.role = '6' and nlevel(users.structure_path) = :level_n
		GROUP BY users.id
	) subq;
"""

GET_AGENT_STRUCTURE_STATISTIC_BY_STRUCTURE_PATH = """
SELECT subq.agent_id,
	   subq.direct_bet_count as direct_bet_count,
	   subq.direct_win_sum as direct_win_sum,
	   subq.direct_bet_sum as direct_bet_sum,
	   subq.structure_bet_count as structure_bet_count,
	   subq.structure_bet_sum as structure_bet_sum,
	   subq.structure_win_sum as structure_win_sum
FROM (
		SELECT users.id as agent_id,
		       sum(coalesce(user_direct_statistic.bet_count, 0)) as direct_bet_count,
		       sum(coalesce(user_direct_statistic.win_sum, 0)) as direct_win_sum,
		       sum(coalesce(user_direct_statistic.bet_sum, 0)) as direct_bet_sum,
		       sum(coalesce(agent_structure_statistic.bet_count, 0) + coalesce(user_direct_statistic.bet_count, 0)) as structure_bet_count,
		       sum(coalesce(agent_structure_statistic.bet_sum, 0) + coalesce(user_direct_statistic.bet_sum, 0)) as structure_bet_sum,
		       sum(coalesce(agent_structure_statistic.win_sum, 0) + coalesce(user_direct_statistic.win_sum, 0)) as structure_win_sum
		FROM "user" users
		LEFT JOIN (
			SELECT u.parent_agent_id as parent_agent_id,
			       coalesce(sum(ups.bet_count), 0) AS bet_count,
			       coalesce(sum(ups.win_sum), 0) AS win_sum,
			       coalesce(sum(ups.bet_sum), 0) AS bet_sum
			FROM "user" u LEFT JOIN user_provider_statistic ups on (
			    ups.user_id = u.id
			    AND ups.created_at > :start_date 
			    AND ups.created_at <= :end_date
	            AND ups.provider = :provider
	            AND ups.currency = :currency
	            AND ups.is_bonus = :is_bonus
			)
			WHERE u.id > 0
			  AND u.role = '0'
	        GROUP BY u.parent_agent_id
		) user_direct_statistic on users.id = user_direct_statistic.parent_agent_id
		LEFT JOIN (
			SELECT u.parent_agent_id as parent_agent_id,
			       coalesce(sum(ast.structure_bet_count), 0) AS bet_count,
			       coalesce(sum(ast.structure_bet_sum), 0) AS bet_sum,
			       coalesce(sum(ast.structure_win_sum), 0) AS win_sum
			FROM "user" u LEFT JOIN agent_structure_statistic ast on (
			    ast.user_id = u.id
			    AND ast.created_at > :start_date 
			    AND ast.created_at <= :end_date
                AND ast.provider = :provider
                AND ast.currency = :currency
                AND ast.is_bonus = :is_bonus
			)
			WHERE u.id > 0
			  AND u.role = '6'
	        GROUP BY u.parent_agent_id
		) agent_structure_statistic on users.id = agent_structure_statistic.parent_agent_id
		WHERE users.structure_path <@ :structure_path and nlevel(users.structure_path) = :level_n and users.role = '6'
		GROUP BY users.id
	) subq;
"""

GET_COMMISSION_PERCENTS = """
SELECT * FROM commission_percents
"""

GET_AGENT_COMMISSIONS = """
SELECT t.total * t.percent * 0.01 as commission_amount,
       t.total as total,
       t.percent as commission_percent,
       t.to_user_id as to_user_id
FROM (
    SELECT cp.commission_percent as percent,
           ass.total as total,
           cp.to_user_id as to_user_id
    FROM commission_percents as cp
    JOIN (
        SELECT sum(structure_bet_sum - structure_win_sum) as total,
               user_id as agent_id
        FROM agent_structure_statistic
        WHERE created_at between :start_date and :end_date
          AND user_id in :agents_id
        GROUP BY user_id
    ) as ass on cp.to_user_id = ass.agent_id
     ) as t;
"""


GET_AGENT_COMMISSIONS_MANUAL_MODE = """
SELECT t.total * t.percent * 0.01 as commission_amount,
       t.total as total,
       t.percent as commission_percent,
       t.to_user_id as to_user_id,
       t.created_at as created_at
FROM (
    SELECT cp.commission_percent as percent,
           ass.total as total,
           cp.to_user_id as to_user_id,
           ass.created_at as created_at
    FROM commission_percents as cp
    JOIN (
        SELECT sum(structure_bet_sum - structure_win_sum) as total,
               user_id as agent_id,
               created_at as created_at
        FROM agent_structure_statistic
        WHERE created_at between :start_date and :end_date
          AND user_id in :agents_id
        GROUP BY user_id, created_at
    ) as ass on cp.to_user_id = ass.agent_id
     ) as t;
"""


GET_AGENT_COMMISSIONS_FOR_USER = """
SELECT t.total * t.percent * 0.01 as commission_amount,
       t.total as total,
       t.percent as commission_percent,
       t.to_user_id as to_user_id,
       t.created_at as created_at
FROM (
    SELECT cp.commission_percent as percent,
           ass.total as total,
           cp.to_user_id as to_user_id,
           ass.created_at as created_at
    FROM commission_percents as cp
    JOIN (
        SELECT sum(structure_bet_sum - structure_win_sum) as total,
               user_id as agent_id,
               created_at as created_at
        FROM agent_structure_statistic
        WHERE created_at between :start_date and :end_date
          AND user_id = :to_user_id
        GROUP BY user_id, created_at
    ) as ass on cp.to_user_id = ass.agent_id
     ) as t;
"""

GET_AGENT_STRUCTURE_STATISTIC_WITHOUT_ITERATION = """
select ups.currency,
       ups.provider,
       coalesce(sum(ups.bet_count) filter (where users.structure_path ~ ('*.' || agents.id || '.*{1}')::lquery),
                0)                             as direct_bet_count,
       coalesce(sum(ups.win_sum) filter (where users.structure_path ~ ('*.' || agents.id || '.*{1}')::lquery),
                0)::numeric(20, 2)             as direct_win_sum,
       coalesce(sum(ups.bet_sum) filter (where users.structure_path ~ ('*.' || agents.id || '.*{1}')::lquery),
                0)::numeric(20, 2)             as direct_bet_sum,
       sum(ups.bet_count)                      as structure_bet_count,
       sum(ups.bet_sum)                        as structure_bet_sum,
       sum(ups.win_sum)                        as structure_win_sum,
       agents.id                               as user_id,
       :end_date as created_at,
       ups.is_bonus

from "user" agents
         join "user" users on
    agents.id = any (((string_to_array(ltree2text(users.structure_path), '.'))::int[]))
-- users.structure_path ~ ('*.' || agents.id || '.*')::lquery
         join user_provider_statistic ups on ups.user_id = users.id

where agents.role = '6'
  and agents.id > 0
  and ups.created_at > :start_date
  and ups.created_at <= :end_date
group by agents.id, ups.currency, ups.provider, ups.is_bonus
order by user_id, currency, provider;

"""

GET_AGENTS_NETWIN_FOR_RANKING = """
SELECT SUM(ass.structure_bet_sum) - SUM(ass.structure_win_sum) as netwin,
       ass.user_id as uid,
       u.nickname as username,
       u.currency as currency
FROM agent_structure_statistic as ass
JOIN "user" u ON ass.user_id = u.id
WHERE ass.created_at > :start_date
  AND ass.created_at < :end_date
GROUP BY uid, username, u.currency
ORDER BY netwin DESC;
"""

GET_ACTIVE_USERS_COUNT = """
SELECT count(*)
        FROM "user"
        WHERE ("user".structure_path <@ :structure_path) AND "user".id != :user_id AND "user".role = '0'
        and exists (
            select from user_provider_statistic
            where user_provider_statistic.user_id = "user".id
                and user_provider_statistic.created_at >= :start_date AND user_provider_statistic.created_at <= :end_date
        )
"""

GET_RANKING_AGENTS = """
SELECT
    st.agent_structure_statistic_user_id as user_id,
    email_auth.email AS username,
    st.direct_netwin_sum
FROM (
    SELECT
        agent_structure_statistic.user_id AS agent_structure_statistic_user_id,
        coalesce(sum(agent_structure_statistic.structure_bet_sum), 0) - coalesce(sum(agent_structure_statistic.structure_win_sum), 0) AS direct_netwin_sum
    FROM
        agent_structure_statistic
    WHERE
        agent_structure_statistic.user_id IN (
            SELECT
                "user".id AS id
            FROM
                "user"
            WHERE ("user".structure_path <@ :structure_path)
            AND "user".id != :user_id
            AND "user".role = '6')
        AND agent_structure_statistic.created_at BETWEEN :start_date AND :end_date
    GROUP BY
        agent_structure_statistic.user_id
    ORDER BY
        direct_netwin_sum DESC
    LIMIT 10
    ) st
    JOIN email_auth ON st.agent_structure_statistic_user_id = email_auth.user_id
ORDER BY
    st.direct_netwin_sum DESC;
"""
