def serialize_payment_request_by_admin_view(instance):
    return {
        "id": instance.id, # noqa
        "date": instance.created_at.strftime("%Y-%m-%d %H:%M:%S"), # noqa
        "amount": instance.amount, # noqa
        "status": instance.status, # noqa
        "comment": instance.comment or '', # noqa
        "payment_system": instance.payment_system, # noqa
        "payment_requisite": instance.payment_requisite, # noqa
        "img_url": instance.img_url # noqa
    }


def serialize_payment_request_by_user_view(instance):
    return {
        "id": instance.id, # noqa
        "date": instance.created_at.strftime("%Y-%m-%d %H:%M:%S"), # noqa
        "amount": instance.amount, # noqa
        "status": instance.status, # noqa
        "comment": instance.comment or '', # noqa
        "payment_system": instance.payment_system, # noqa
        "payment_requisite": instance.payment_requisite, # noqa
    }
