from logging import getLogger
from typing import List, Tuple
from sqlalchemy import or_

from . import error_codes
from util.error import InvalidRequestData
from betronic_core.manager import IManager
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.db.models.money_transfer import TransferTypes as TT
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.admin_payment import AdminPaymentRequisiteModel, \
    AdminPaymentRequestModel


logger = getLogger(__name__)


class AdminPaymentManager(IManager):
    def get_active_payment_requisites_by_user_id(self, user_id: int) -> List[AdminPaymentRequisiteModel]:
        return AdminPaymentRequisiteModel.get_active_by_user_id(self.db, user_id)

    def get_payment_request_by_id(self, request_id: int):
        request_db = AdminPaymentRequestModel.get_by_id(self.db, request_id)
        if not request_db:
            raise InvalidRequestData(error_codes.INCORRECT_ADMIN_PAYMENT_REQUEST_ID,
                                     f'Requisite with id {request_id} not found')

        return request_db

    def get_payment_requisite_by_id(self, requisite_id: int):
        requisite_db = AdminPaymentRequisiteModel.get_by_id(self.db, requisite_id)
        if not requisite_db:
            raise InvalidRequestData(error_codes.INCORRECT_ADMIN_PAYMENT_REQUISITE_ID,
                                     f'Requisite with id {requisite_id} not found')

        return requisite_db

    def check_can_close_request_by_admin(self, request_id: int, admin_id: int, amount: float, status: int):
        request_db = self.get_payment_request_by_id(request_id=request_id)
        if admin_id != request_db.from_user_id:
            raise Exception('Permission denied')

        if status != AdminPaymentRequestModel.CANCELED:
            user = UserModel.get_by_id(db=self.db, user_id=admin_id)
            if amount > user.balance:
                raise InvalidRequestData(error_codes.INSUFFICIENT_BALANCE, "Balance less than payment request amount.")

    def close_payment_request(self, request_id: int, amount: float, status: int, comment: str):
        logger.info(f'Close payment {request_id} with '
                    f'amount: {amount}, status: {status}, comment: {comment}')

        request_db = self.get_payment_request_by_id(request_id=request_id)
        if request_db.status != AdminPaymentRequestModel.CREATED:
            raise Exception('Payment request already processed')
        if status not in [AdminPaymentRequestModel.PAID, AdminPaymentRequestModel.CANCELED]:
            raise Exception('Invalid status type')
        if amount < 0:
            raise Exception(f'Amount {amount} is not valid')

        request_db.amount = 0.0 if status == AdminPaymentRequestModel.CANCELED else amount
        request_db.status = status
        request_db.comment = comment

        self.db.add(request_db)
        self.db.commit()

        if status != AdminPaymentRequestModel.CANCELED:
            logger.info(f'Move user money from {request_db.from_user_id} to '
                        f'{request_db.to_user_id} with amount {request_db.amount}')
            MoneyManager(self.db).user_move_money(
                from_user_id=request_db.from_user_id,
                to_user_id=request_db.to_user_id,
                value=request_db.amount,
                transfer_type=TT.TYPE_ADMIN_TO_USER
            )

        return request_db

    def create_payment_request(self, from_user_id: int, to_user_id: int, requisite_id: int,
                               amount: float, img_url: str):
        logger.info(f'Start create payment request with from_user_id:{from_user_id}, to_user_id:{to_user_id}, '
                    f'requisite_id:{requisite_id}, amount:{amount}, img_url: {img_url}')
        model = AdminPaymentRequestModel(
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            requisite_id=requisite_id,
            amount=amount,
            img_url=img_url
        )
        self.db.add(model)
        self.db.commit()

        return model

    def create_payment_requisite(self, user_id: int, payment_system: str, payment_requisite: str):
        logger.info(f'Start create payment requisite with user_id:{user_id}, '
                    f'payment_system:{payment_system}, payment_requisite: {payment_requisite}')
        model = AdminPaymentRequisiteModel(
            user_id,
            payment_system,
            payment_requisite
        )
        self.db.add(model)
        self.db.commit()

        return model

    def delete_payment_requisite(self, requisite_id: int):
        logger.info(f'Start delete payment requisite with id:{requisite_id}')
        requisite_db = self.get_payment_requisite_by_id(requisite_id)
        requisite_db.is_deleted = True
        self.db.add(requisite_db)
        self.db.commit()

        return requisite_db

    def get_user_payment_request_history(self, user_id: int,
                                         date_from: str = None,
                                         date_to: str = None,
                                         statuses: list or tuple = None,
                                         skip: int = None,
                                         limit: int = None,
                                         reverse: bool = False)\
            -> Tuple[List['AdminPaymentRequestModel'], int]:
        request = AdminPaymentRequestModel
        requisite = AdminPaymentRequisiteModel

        query = self.db\
            .query(*request.__table__.columns,
                   requisite.payment_system.label("payment_system"),
                   requisite.payment_requisite.label("payment_requisite")) \
            .join(requisite,
                  requisite.id == request.requisite_id, isouter=True)\
            .filter(or_(request.from_user_id == user_id,
                        request.to_user_id == user_id))

        if date_from and date_to:
            query = query.filter(request.created_at.between(date_from, date_to))
        if statuses:
            query = query.filter(request.status.in_(tuple(statuses)))

        total_items = query.count()

        if reverse:
            query = query.order_by(request.created_at.desc())
        else:
            query = query.order_by(request.created_at)

        if (skip and limit) is not None:
            query = query.offset(skip).limit(limit)

        items = query.all()

        return items, total_items
