from betronic_core.adapter import AdapterBase


class ConvertPaymentRequestByAdminAdapter(AdapterBase):
    def convert(self):
        return {
            "id": self.instance.id, # noqa
            "date": self.instance.created_at.strftime("%Y-%m-%d %H:%M:%S"), # noqa
            "amount": self.instance.amount, # noqa
            "status": self.instance.status, # noqa
            "comment": self.instance.comment or '', # noqa
            "payment_system": self.instance.payment_system, # noqa
            "payment_requisite": self.instance.payment_requisite, # noqa
            "img_url": self.instance.img_url # noqa
        }


class ConvertPaymentRequestByUserAdapter(AdapterBase):
    def convert(self):
        return {
            "id": self.instance.id, # noqa
            "date": self.instance.created_at.strftime("%Y-%m-%d %H:%M:%S"), # noqa
            "amount": self.instance.amount, # noqa
            "status": self.instance.status, # noqa
            "comment": self.instance.comment or '', # noqa
            "payment_system": self.instance.payment_system, # noqa
            "payment_requisite": self.instance.payment_requisite, # noqa
        }
