from logging import getLogger
from betronic_core.manager import IManager
from betronic_core.db.models.outcome_transactions import JackpotModel, Association, OutComeTransactionModel
from random import uniform, choices
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.constants import TransferTypes
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.manager import UserManager

logger = getLogger(__name__)


class JackpotManager(IManager):
    def top_up_the_jackpots(self, amount, outcome_transaction):
        jackpots = JackpotModel.get_jackpot_list(self.db)
        result_associates = []
        for jackpot in jackpots:
            attachments = amount * jackpot.amount_percent
            jackpot.amount += attachments
            result_associates.append(Association(outcome_transaction_id=outcome_transaction.id,
                                                 attachments=attachments,
                                                 win_jackpot=False,
                                                 is_shown=False,
                                                 jackpot_id=jackpot.id))
        if result_associates:
            self.db.add_all(result_associates)
            self.db.commit()

    def get_jackpot_list(self):
        jackpots = JackpotModel.get_jackpot_list(self.db)
        return jackpots

    def get_user_jackpot_list(self, player_id):
        jackpots = JackpotModel.get_user_jackpot_list(self.db, player_id)
        return jackpots

    def get_list_of_jackpots_in_the_game(self, player_id):
        jackpots = JackpotModel.get_list_of_jackpots_in_the_game(self.db, player_id)
        return jackpots

    def get_not_shown_won_jackpots_by_user(self, player_id):
        jackpots = JackpotModel.get_not_shown_won_jackpots_by_user(self.db, player_id)
        return jackpots

    def try_your_luck(self, attachments, outcome_transaction, jackpot):
        jackpot_user_probability = self.get_jackpot_user_probability(attachments, jackpot)
        probability = jackpot_user_probability * self.get_probability_of_getting_a_jackpot(jackpot)
        luck = uniform(0, 1)
        if luck < probability and jackpot.pay:
            association = Association(outcome_transaction_id=outcome_transaction.id,
                                      attachments=0,
                                      win_jackpot=True,
                                      is_shown=False,
                                      jackpot_id=jackpot.id)
            self.reset_jackpot(jackpot)
            self.db.add(association)
            self.db.commit()
            return True

        elif luck < jackpot_user_probability and not jackpot.pay:
            self.reset_jackpot(jackpot)
            self.db.commit()
            return False

    def get_probability_of_getting_a_jackpot(self, jackpot):
        probability = jackpot.min_probability * jackpot.amount / jackpot.min_amount
        probability = jackpot.max_probability if probability > jackpot.max_probability else probability
        return probability

    def get_jackpot_user_probability(self, attachments, jackpot):
        try:
            probability = attachments / (jackpot.amount - jackpot.first_amount)
            return probability
        except (ZeroDivisionError, TypeError):
            return 0

    def reset_jackpot(self, jackpot):
        model = JackpotModel(jackpot.image, jackpot.name, jackpot.first_amount, jackpot.is_active, False, jackpot.pay,
                             jackpot.min_amount, jackpot.min_probability, jackpot.max_probability, jackpot.first_amount,
                             jackpot.amount_percent, jackpot.timer)
        jackpot.is_deleted = True

        self.db.add(model)
        self.db.commit()

    def calculate_jackpot(self, jackpot_id):
        users = JackpotModel.get_jackpot_users(self.db, jackpot_id)
        jackpot = JackpotModel.get_jackpot_by_id(self.db, jackpot_id)
        user_manager = UserManager(self.db)
        probabilities = list()
        for user in users:
            attachments = OutComeTransactionModel.get_jackpot_attachments_by_user(self.db, user, jackpot)[0]
            probabilities.append(self.get_jackpot_user_probability(attachments, jackpot))
        winner = choices(users, probabilities)[0]
        money_manager = MoneyManager(self.db)
        to_user = user_manager.get_user_by_id(winner)
        transfer = money_manager.user_move_money(UserModel.ORGANIZATION_ID,
                                                 to_user.id,
                                                 jackpot.amount,
                                                 TransferTypes.TYPE_OUTCOMEBET_PRIZE)
        self.db.add(transfer)
        self.db.commit()

        self.reset_jackpot(jackpot)

    def update_is_shown(self, jackpot_id):
        association = Association.get_record_by_jackpot_id(self.db, jackpot_id)
        if association:
            association.is_shown = True
            self.db.commit()
            return True
        return False
