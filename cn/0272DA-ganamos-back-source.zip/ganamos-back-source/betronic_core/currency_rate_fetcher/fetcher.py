from logging import getLogger
from requests import get
from tornado.httpclient import HTTPError
from tornado.options import options

from betronic_core.cache_manager.manager import CacheManager

logger = getLogger(__name__)


class CurrencyRateFetcher:
    @classmethod
    def get_currency_rate(cls, from_currency, to_currency):
        pair = f'{from_currency}{to_currency}'
        rate = CacheManager.get_currency_rate(pair)
        if not rate:
            response = cls._fetch(from_currency, to_currency)
            rate = float(response['result'][pair])
            CacheManager.set_currency_rate(pair, rate)
        return float(rate)

    @classmethod
    def _fetch(cls, from_currency, to_currency):
        payload = f'?from_currency={from_currency}&to_currency={to_currency}&real=True'
        try:
            response = get(
                options.CURRENCY_RATE_API + payload
            )
            response_body = response.json()
        except HTTPError:
            logger.warning('error when sending request to currency rate service')

        return response_body
