from betronic_core.constants import TransferTypes

# Slots bets statuses: 1-win, 2-bet, 3-refund
class SlotBetStatusTypes:
    WIN = "1"
    BET = "2"
    RETURN = "3"


transfer_direction_by_bet_type = {
    SlotBetStatusTypes.WIN: "to",
    SlotBetStatusTypes.BET: "from",
    SlotBetStatusTypes.RETURN: "to"
}

STATUSES = {
    SlotBetStatusTypes.WIN: [
        TransferTypes.TYPE_OUTCOMEBET_PRIZE, TransferTypes.TYPE_FIABLE_WIN,
        TransferTypes.TYPE_TVBET_PRISE, TransferTypes.TYPE_TVBET_JACKPOT,
        TransferTypes.TYPE_TVBET_PRISE, TransferTypes.TYPE_TVBET_JACKPOT,
        TransferTypes.TYPE_EVO_PROXY_CREDIT, TransferTypes.TYPE_SOFT_SLOTS_CREDIT,
        TransferTypes.TYPE_EVOPLAY_WIN, TransferTypes.TYPE_BSW_PRIZE,
        TransferTypes.TYPE_INBET_PRIZE, TransferTypes.TYPE_SLOTEGRATOR_WIN,
        TransferTypes.TYPE_FLG_WIN, TransferTypes.TYPE_RUBIPLAY_CREDIT,
        TransferTypes.TYPE_XPG_CREDIT, TransferTypes.TYPE_CASIMI_WIN,
        TransferTypes.TYPE_CASIMI_BONUS, TransferTypes.TYPE_CASIMI_JACKPOT,
        TransferTypes.TYPE_GR_WIN, TransferTypes.TYPE_DIGITAIN_WIN,
        TransferTypes.TYPE_UNIVERSALRACE_WIN, TransferTypes.TYPE_PRAGMATIC_SLOTS_RESULT,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_PROMO,TransferTypes.TYPE_PRAGMATIC_SLOTS_BONUS_WIN,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_JACKPOT, TransferTypes.TYPE_PRAGMATIC_SLOTS_FRB,
        TransferTypes.TYPE_PRAGMATIC_LC_RESULT, TransferTypes.TYPE_PRAGMATIC_LC_PROMO,
        TransferTypes.TYPE_PRAGMATIC_LC_BONUS_WIN, TransferTypes.TYPE_PRAGMATIC_LC_JACKPOT,
        TransferTypes.TYPE_PRAGMATIC_LC_FRB, TransferTypes.TYPE_PRAGMATIC_BJ_RESULT,
        TransferTypes.TYPE_PRAGMATIC_BJ_PROMO, TransferTypes.TYPE_PRAGMATIC_BJ_BONUS_WIN,
        TransferTypes.TYPE_PRAGMATIC_BJ_JACKPOT, TransferTypes.TYPE_PRAGMATIC_BJ_FRB,
        TransferTypes.TYPE_EZUGI_WIN, TransferTypes.TYPE_EVOLUTION_EZUGI_WIN,
        TransferTypes.TYPE_POPOKGAMING_PROMO_WIN, TransferTypes.TYPE_POPOKGAMING_TOURNAMENT_WIN,
        TransferTypes.TYPE_POPOKGAMING_WIN, TransferTypes.TYPE_REDRAKE_CREDIT,
    ],
    SlotBetStatusTypes.BET: [
        TransferTypes.TYPE_OUTCOMEBET_BET, TransferTypes.TYPE_TVBET_BET,
        TransferTypes.TYPE_FIABLE_BET, TransferTypes.TYPE_EVO_PROXY_DEBIT,
        TransferTypes.TYPE_EVOPLAY_BET, TransferTypes.TYPE_BSW_BET,
        TransferTypes.TYPE_INBET_BET, TransferTypes.TYPE_SOFT_SLOTS_DEBIT,
        TransferTypes.TYPE_SLOTEGRATOR_BET, TransferTypes.TYPE_FLG_BET,
        TransferTypes.TYPE_RUBIPLAY_DEBIT, TransferTypes.TYPE_XPG_DEBIT,
        TransferTypes.TYPE_CASIMI_BET, TransferTypes.TYPE_GR_BET,
        TransferTypes.TYPE_DIGITAIN_BET, TransferTypes.TYPE_UNIVERSALRACE_BET,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_BET, TransferTypes.TYPE_PRAGMATIC_LC_BET,
        TransferTypes.TYPE_PRAGMATIC_BJ_BET, TransferTypes.TYPE_EZUGI_BET,
        TransferTypes.TYPE_EVOLUTION_EZUGI_BET, TransferTypes.TYPE_POPOKGAMING_BET,
        TransferTypes.TYPE_REDRAKE_DEBIT,
    ],
    SlotBetStatusTypes.RETURN: [
        TransferTypes.TYPE_TVBET_ROLLBACK, TransferTypes.TYPE_EVO_PROXY_CANCEL_CREDIT,
        TransferTypes.TYPE_EVO_PROXY_CANCEL_DEBIT, TransferTypes.TYPE_EVOPLAY_REFUND,
        TransferTypes.TYPE_SOFT_SLOTS_CANCEL_DEBIT,
        TransferTypes.TYPE_SOFT_SLOTS_CANCEL_CREDIT, TransferTypes.TYPE_SLOTEGRATOR_REFUND,
        TransferTypes.TYPE_SLOTEGRATOR_ROLLBACK_OUTCOME,
        TransferTypes.TYPE_SLOTEGRATOR_ROLLBACK_INCOME,
        TransferTypes.TYPE_FLG_REFUND, TransferTypes.TYPE_RUBIPLAY_CANCEL_DEBIT,
        TransferTypes.TYPE_XPG_CANCEL_ROUND_CREDIT, TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT,
        TransferTypes.TYPE_XPG_REFUND, TransferTypes.TYPE_GR_ROLLBACK,
        TransferTypes.TYPE_DIGITAIN_ROLLBACK_BET,
        TransferTypes.TYPE_DIGITAIN_ROLLBACK_WIN, TransferTypes.TYPE_UNIVERSALRACE_RETURN_BET,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_REFUND, TransferTypes.TYPE_PRAGMATIC_LC_REFUND,
        TransferTypes.TYPE_PRAGMATIC_BJ_REFUND, TransferTypes.TYPE_EZUGI_ROLLBACK,
        TransferTypes.TYPE_POPOKGAMING_ROLLBACK_BET, TransferTypes.TYPE_EVOLUTION_EZUGI_ROLLBACK,
        TransferTypes.TYPE_REDRAKE_CANCEL_CREDIT, TransferTypes.TYPE_REDRAKE_CANCEL_DEBIT,
    ]
}
PROVIDERS = {
    "PRAGMATIC-SLOTS": [
        TransferTypes.TYPE_PRAGMATIC_SLOTS_PROMO, TransferTypes.TYPE_PRAGMATIC_SLOTS_BONUS_WIN,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_JACKPOT, TransferTypes.TYPE_PRAGMATIC_SLOTS_REFUND,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_BET, TransferTypes.TYPE_PRAGMATIC_SLOTS_FRB,
        TransferTypes.TYPE_PRAGMATIC_SLOTS_RESULT,
    ],
    "PRAGMATIC-LIVE-CASINO": [
        TransferTypes.TYPE_PRAGMATIC_LC_PROMO, TransferTypes.TYPE_PRAGMATIC_LC_BONUS_WIN,
        TransferTypes.TYPE_PRAGMATIC_LC_JACKPOT, TransferTypes.TYPE_PRAGMATIC_LC_REFUND,
        TransferTypes.TYPE_PRAGMATIC_LC_BET, TransferTypes.TYPE_PRAGMATIC_LC_FRB,
        TransferTypes.TYPE_PRAGMATIC_LC_RESULT,
    ],
    "PRAGMATIC-BJ": [
        TransferTypes.TYPE_PRAGMATIC_BJ_PROMO, TransferTypes.TYPE_PRAGMATIC_BJ_BONUS_WIN,
        TransferTypes.TYPE_PRAGMATIC_BJ_JACKPOT, TransferTypes.TYPE_PRAGMATIC_BJ_REFUND,
        TransferTypes.TYPE_PRAGMATIC_BJ_BET, TransferTypes.TYPE_PRAGMATIC_BJ_FRB,
        TransferTypes.TYPE_PRAGMATIC_BJ_RESULT,
    ],
    "OUTCOMEBET": [TransferTypes.TYPE_OUTCOMEBET_BET, TransferTypes.TYPE_OUTCOMEBET_PRIZE],
    "EVOPLAY": [TransferTypes.TYPE_EVOPLAY_REFUND, TransferTypes.TYPE_EVOPLAY_WIN, TransferTypes.TYPE_EVOPLAY_BET],
    "TVBET": [TransferTypes.TYPE_TVBET_ROLLBACK, TransferTypes.TYPE_TVBET_JACKPOT, TransferTypes.TYPE_TVBET_BET,
              TransferTypes.TYPE_TVBET_PRISE],
    "FIABLE": [TransferTypes.TYPE_FIABLE_BET, TransferTypes.TYPE_FIABLE_WIN],
    "BSW": [TransferTypes.TYPE_BSW_BET, TransferTypes.TYPE_BSW_PRIZE],
    "INBET": [TransferTypes.TYPE_INBET_BET, TransferTypes.TYPE_INBET_PRIZE],
    "SOFTGAMING-SLOTS": [TransferTypes.TYPE_SOFT_SLOTS_DEBIT, TransferTypes.TYPE_SOFT_SLOTS_CREDIT,
                         TransferTypes.TYPE_SOFT_SLOTS_CANCEL_CREDIT, TransferTypes.TYPE_SOFT_SLOTS_CANCEL_DEBIT],
    "SLOTEGRATOR": [TransferTypes.TYPE_SLOTEGRATOR_WIN, TransferTypes.TYPE_SLOTEGRATOR_BET,
                    TransferTypes.TYPE_SLOTEGRATOR_REFUND, TransferTypes.TYPE_SLOTEGRATOR_ROLLBACK_INCOME,
                    TransferTypes.TYPE_SLOTEGRATOR_ROLLBACK_OUTCOME],
    "FLG": [TransferTypes.TYPE_FLG_BET, TransferTypes.TYPE_FLG_WIN, TransferTypes.TYPE_FLG_REFUND],
    "RUBYPLAY": [TransferTypes.TYPE_RUBIPLAY_DEBIT, TransferTypes.TYPE_RUBIPLAY_CREDIT,
                 TransferTypes.TYPE_RUBIPLAY_CANCEL_DEBIT],
    "XPG": [TransferTypes.TYPE_XPG_DEBIT, TransferTypes.TYPE_XPG_CREDIT, TransferTypes.TYPE_XPG_REFUND,
            TransferTypes.TYPE_XPG_CANCEL_ROUND_CREDIT, TransferTypes.TYPE_XPG_CANCEL_ROUND_DEBIT],
    "CASIMI": [TransferTypes.TYPE_CASIMI_BONUS, TransferTypes.TYPE_CASIMI_JACKPOT,
               TransferTypes.TYPE_CASIMI_WIN, TransferTypes.TYPE_CASIMI_BET],
    "GOLDENRACE": [TransferTypes.TYPE_GR_ROLLBACK, TransferTypes.TYPE_GR_WIN, TransferTypes.TYPE_GR_BET],
    "DIGITAIN": [TransferTypes.TYPE_DIGITAIN_BET, TransferTypes.TYPE_DIGITAIN_WIN,
                 TransferTypes.TYPE_DIGITAIN_ROLLBACK_WIN, TransferTypes.TYPE_DIGITAIN_ROLLBACK_BET],
    "EVOLUTION_ORIGINAL": [TransferTypes.TYPE_EVOLUTION_ORIGINAL_DEBIT, TransferTypes.TYPE_EVOLUTION_ORIGINAL_CREDIT,
                 TransferTypes.TYPE_EVOLUTION_ORIGINAL_CANCEL_DEBIT, TransferTypes.TYPE_EVOLUTION_ORIGINAL_PROMO_PAYOUT],
    "UNIVERSALRACE": [TransferTypes.TYPE_UNIVERSALRACE_BET, TransferTypes.TYPE_UNIVERSALRACE_WIN,
                      TransferTypes.TYPE_UNIVERSALRACE_RETURN_BET],
    "EZUGI": [TransferTypes.TYPE_EZUGI_WIN, TransferTypes.TYPE_EZUGI_BET, TransferTypes.TYPE_EZUGI_ROLLBACK],
    "EVOLUTION_EZUGI": [TransferTypes.TYPE_EVOLUTION_EZUGI_WIN, TransferTypes.TYPE_EVOLUTION_EZUGI_BET,
                        TransferTypes.TYPE_EVOLUTION_EZUGI_ROLLBACK],
    "POPOKGAMING": [TransferTypes.TYPE_POPOKGAMING_BET, TransferTypes.TYPE_POPOKGAMING_WIN,
                    TransferTypes.TYPE_POPOKGAMING_TOURNAMENT_WIN, TransferTypes.TYPE_POPOKGAMING_PROMO_WIN,
                    TransferTypes.TYPE_POPOKGAMING_ROLLBACK_BET],
    "REDRAKE": [TransferTypes.TYPE_REDRAKE_DEBIT, TransferTypes.TYPE_REDRAKE_CREDIT,
                TransferTypes.TYPE_REDRAKE_CANCEL_DEBIT, TransferTypes.TYPE_REDRAKE_CANCEL_CREDIT],
}

PROVIDERS_TYPES = {
    "slots": ["PRAGMATIC-SLOTS", "OUTCOMEBET", "EVOPLAY",
              "SLOTEGRATOR", "SOFTGAMING-SLOTS", "BSW", "INBET",
              "FLG", "RUBYPLAY", "CASIMI", "FIABLE", "EVOLUTION_EZUGI", "POPOKGAMING", "REDRAKE"],
    "live-casino": ["TVBET", "XPG", "EVOLUTION_ORIGINAL", "PRAGMATIC-LIVE-CASINO", "EZUGI"],
    "virtual-games": ["GOLDENRACE", "UNIVERSALRACE", "PRAGMATIC-BJ"],
    "sport": ["DIGITAIN"],
    "all": ["PRAGMATIC-SLOTS", "OUTCOMEBET", "FIABLE", "EVOPLAY",
            "SLOTEGRATOR", "SOFTGAMING-SLOTS", "BSW", "INBET",
            "TVBET", "FLG", "RUBYPLAY", "XPG", "CASIMI", "GOLDENRACE",
            "PRAGMATIC-LIVE-CASINO", "PRAGMATIC-BJ", "EZUGI", "EVOLUTION_EZUGI", "POPOKGAMING",
            "REDRAKE"]
}
