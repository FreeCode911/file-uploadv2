import datetime
from decimal import Decimal, ROUND_HALF_UP
from itertools import chain
from logging import getLogger
from typing import Optional, List, Union, Tuple

from sqlalchemy import and_, or_, func, union_all, literal
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.sql import case, text
from sqlalchemy_utils import Ltree
from tornado.options import options
from betronic_core.bonus_burner_manager.manager import BonusBurnerManager
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.constants import TransferTypes, PartnerTypePayment, \
    PartnerTypeMoneyTransfer, PartnerStatusMoneyTransfer, UserTypePaymentTransfer
from betronic_core.db.models.betgames_transactions import \
    BetgamesTransactionModel
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel, BetStatus
from betronic_core.db.models.bonus_transfer import BonusTransferModel, \
    BonusTransferTypes as BONUS_TRANSFER_TYPES
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from betronic_core.db.models.payments import PaymentTransactionModel
from betronic_core.db.models.promo_code import PromoCodeModel
from betronic_core.db.models.terminal.credit_ticket import CreditTicketModel
from betronic_core.db.models.user import UserModel
from betronic_core.error import InvalidRequestData, ProgrammingError
from betronic_core.manager import IManager
from betronic_core.money_manager import PROVIDERS, STATUSES, PROVIDERS_TYPES, transfer_direction_by_bet_type
from util.error import InvalidRequestData, ProgrammingError
from util.validators import as_decimal
from . import error_codes
from .dto.partner_min_withdrawal import PartnerMinWithdrawalDTO
from ..currency_rate_fetcher.fetcher import CurrencyRateFetcher
from betronic_core.settings_manager.manager import SettingsManager

logger = getLogger(__name__)


class MoneyManager(IManager):
    accuracy = Decimal("1.00")

    def calculation_partner_balance_by_user_id(self, user_id: int) -> float:
        try:
            return PartnerMoneyTransfer.get_summary_balance_by_user(self.db, user_id)
        except Exception as e:
            logger.warning("Can't get u:{} balance e:{}".format(user_id, e))
            raise ProgrammingError(e)

    def user_partner_calc_balance(self, user: UserModel) -> UserModel:
        user.partner_balance = float(self.calculation_partner_balance_by_user_id(user.id))
        return user

    def get_user_from_list(self, items, user_id) -> UserModel:
        for item in items:
            if item.id == user_id:
                return item

    def _get_user_move_money_win_limit(
            self,
            user_amount: Union[float, Decimal],
            transfer_type: int,
            to_user_id: int,
    ) -> Tuple[Union[float, Decimal], Union[float, Decimal, None]]:

        if options.USER_MAX_WIN_STATE is False:
            return user_amount, None

        if transfer_type not in TransferTypes.WIN_TYPES_FOR_MAX_AMOUNT:
            return user_amount, None

        user = UserModel.get_by_id_with_lock(self.db, to_user_id)
        payment_settings = CacheManager.get_payment_settings(currency=user.currency)

        system_max = as_decimal(payment_settings.get('max_win_amount', options.DEFAULT_SYSTEM_MAX_WINNING_AMOUNT))
        organization_amount = as_decimal(user_amount) - as_decimal(system_max)
        if organization_amount <= 0:
            return user_amount, None

        user_amount = system_max
        return user_amount, organization_amount

    def _transfer_overflow_amount_to_organisation(
            self,
            full_value: Union[Decimal, float],
            win_limit_amount: Union[Decimal, float],
            balance_limit_amount: Union[Decimal, float],
            original_transfer: MoneyTransferModel,
            commit: bool = True
    ) -> None:

        original_transfer_type = original_transfer.type
        original_note = original_transfer.note
        user_value = original_transfer.value
        original_transfer_id = original_transfer.id

        user_id = original_transfer.to_user_id
        currency = original_transfer.currency

        if win_limit_amount:
            overflow_win_transfer, _ = self._user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=win_limit_amount,
                additional_data={
                    'transfer_user_id': user_id,
                    'user_value': float(user_value),
                    'full_value': float(full_value),
                    'original_note': original_note
                },
                transfer_type=original_transfer_type,
                note=f"Win overflow",
                currency=currency,
                commit=commit
            )
            logger.info(
                f"Win overflow limit for user {user_id}:"
                f"full value: {full_value}, "
                f"user value: {user_value}, "
                f"original transfer_id: {original_transfer_id}, "
                f"original tranfer_type: {original_transfer_type}, "
                f"original note: {original_note}"
            )

        if balance_limit_amount:
            balance_limit_transfer, _ = self._user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=balance_limit_amount,
                additional_data={
                    'transfer_user_id': user_id,
                    'user_value': float(user_value),
                    'full_value': float(full_value),
                    'original_note': original_note
                },
                transfer_type=original_transfer_type,
                note=f'Balance overflow',
                currency=currency,
                commit=commit
            )
            logger.info(
                f"Balance overflow limit for user {user_id}:"
                f"full value: {full_value}, "
                f"user value: {user_value}, "
                f"original note: {original_note}, "
                f"original transfer_type: {original_transfer_type}, "
                f"original transfer_id: {original_transfer_id}"
            )

        if commit:
            self.db.commit()

    def user_move_money(self, from_user_id: int, to_user_id: int, value: float or Decimal,
                        transfer_type: int = TransferTypes.TYPE_REFILL,
                        note: str = None, additional_data: dict = None, real_from_user_id: int = None,
                        real_to_user_id: int = None, description: str = None,
                        transaction_id: str = None, currency: str = None,
                        commit: bool = True) -> MoneyTransferModel:

        user_amount, win_limit_amount = \
            self._get_user_move_money_win_limit(
                user_amount=value,
                transfer_type=transfer_type,
                to_user_id=to_user_id
            )

        transfer, balance_limit_amount = \
            self._user_move_money(
                from_user_id=from_user_id,
                to_user_id=to_user_id,
                value=user_amount,
                transfer_type=transfer_type,
                note=note,
                additional_data=additional_data,
                real_from_user_id=real_from_user_id,
                real_to_user_id=real_to_user_id,
                description=description,
                transaction_id=transaction_id,
                currency=currency,
                commit=commit
            )

        if win_limit_amount or balance_limit_amount:
            self._transfer_overflow_amount_to_organisation(
                full_value=value,
                win_limit_amount=win_limit_amount,
                balance_limit_amount=balance_limit_amount,
                original_transfer=transfer,
                commit=commit
            )

        return transfer

    def _user_move_money(self, from_user_id: int, to_user_id: int, value: float or Decimal,
                         transfer_type: int = TransferTypes.TYPE_REFILL,
                         note: str = None, additional_data: dict = None, real_from_user_id: int = None,
                         real_to_user_id: int = None, description: str = None,
                         transaction_id: str = None, currency: str = None,
                         commit: bool = True) -> Tuple[MoneyTransferModel, Union[float, int]]:
        real_from_user_id = real_from_user_id or from_user_id
        real_to_user_id = real_to_user_id or to_user_id
        transfer = MoneyTransferModel(
            type=transfer_type,
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            real_from_user_id=real_from_user_id,
            real_to_user_id=real_to_user_id,
            value=value, note=note,
            description=description,
            transaction_id=transaction_id
        )
        from_user = to_user = None
        balance_from_user_after = balance_to_user_after = 0
        balance_from_user_before = balance_to_user_before = "0"
        amount_to_organization = 0
        real_value = 0

        U = UserModel
        if from_user_id > 0 and to_user_id > 0:
            users = self.db.query(U).filter(
                U.id.in_([from_user_id, to_user_id])).with_for_update(of=U).all()
            from_user = self.get_user_from_list(users, from_user_id)
            to_user = self.get_user_from_list(users, to_user_id)
        else:
            if from_user_id > 0:
                from_user = self.db.query(U).filter(
                    U.id == from_user_id).with_for_update(of=U).first()
                transfer.currency = from_user.currency
            if to_user_id > 0:
                to_user = self.db.query(U).filter(
                    U.id == to_user_id).with_for_update(of=U).first()
        if to_user:
            transfer.currency = to_user.currency
            self.db.refresh(to_user)

            balance_to_user_before = str(to_user.balance)
            balance_to_user_after = Decimal(str(to_user.balance)) + Decimal(str(value))

            payment_settings = CacheManager.get_payment_settings(currency=to_user.currency)
            max_balance_amount = as_decimal(
                payment_settings.get('max_balance_amount', options.DEFAULT_MAX_BALANCE_AMOUNT)
            )

            if to_user.role is UserModel.USER and balance_to_user_after > max_balance_amount:
                real_value = value
                new_value = as_decimal(max_balance_amount) - as_decimal(to_user.balance)
                transfer.value = new_value
                amount_to_organization = balance_to_user_after - Decimal(str(max_balance_amount))
                balance_to_user_after = Decimal(str(max_balance_amount))

            self.db.query(U).filter(U.id == to_user.id).update(
                {U.balance: balance_to_user_after},
                synchronize_session='fetch')

            CacheManager.set_user_data_to_cache(to_user)

        if from_user:
            self.db.refresh(from_user)
            balance_from_user_before = str(from_user.balance)
            balance_from_user_after = Decimal(str(from_user.balance)) - Decimal(str(value))
            self.db.query(U).filter(U.id == from_user.id).update(
                {U.balance: balance_from_user_after},
                synchronize_session='fetch')
            CacheManager.set_user_data_to_cache(from_user)

        transfer.additional_data = {
            'balance_before_from_user': balance_from_user_before,
            'balance_before_to_user': balance_to_user_before,
            'balance_after_from_user': str(balance_from_user_after),
            'balance_after_to_user': str(balance_to_user_after),
            'real_value': str(Decimal(real_value).quantize(self.accuracy, ROUND_HALF_UP))
        }

        if currency:
            transfer.currency = currency

        if additional_data:
            transfer.additional_data.update(additional_data)

        self.db.add(transfer)

        if commit:
            self.db.commit()

        return transfer, amount_to_organization

    def user_is_first_deposit(self, user_id):
        if MoneyTransferModel.count_transactions_for_deposit_bonus(self.db, user_id) <= 1:
            return True
        else:
            return False

    def write_off_bonus(self, user: UserModel, transfer: MoneyTransferModel):
        if user.bonus_balance > 0:
            self.move_marketing_money(
                user_id=transfer.from_user_id,
                value=user.bonus_balance,
                transfer_type=BONUS_TRANSFER_TYPES.TYPE_REMOVE_BONUS,
                note=f"Withdrawal transfer id: {transfer.id}",
                is_bonus=True,
                is_outcome=True
            )

    def process_first_deposit_bonus(self, transfer: MoneyTransferModel):
        settings_manager = SettingsManager(self.db)
        setting: dict = settings_manager.get_setting_by_name('FirstDepositBonusSettings')

        bonus_is_active = bool(
            setting.get('bonus_is_active', False)
        )

        if bonus_is_active:
            bonus_percent = round(
                float(setting['bonus_system_cashback_percent']), 2)
            max_first_deposit_bonus = round(
                float(setting['max_first_deposit_bonus'][transfer.currency]), 2)
            days_to_use_the_bonus_balance = int(
                setting['days_to_use_the_bonus_balance'])

            if self.user_is_first_deposit(transfer.to_user_id):
                cashback_amount = Decimal(str(transfer.value)) * Decimal(str(bonus_percent))

                if cashback_amount > max_first_deposit_bonus:
                    cashback_amount = max_first_deposit_bonus

                if cashback_amount:
                    bonus_transfer = self.move_marketing_money(
                        user_id=transfer.to_user_id,
                        value=cashback_amount,
                        transfer_type=TransferTypes.TYPE_BONUS_FOR_FIRST_DEPOSIT,
                        note=f"First deposit bonus by tr_id: {transfer.id}",
                        is_outcome=False,
                        is_bonus=True
                    )
                    bonus_expire_at = bonus_transfer.created_at + \
                                      datetime.timedelta(days=days_to_use_the_bonus_balance)

                    BonusBurnerManager(self.db).create_bonus_burn_date(
                        user=transfer.real_to_user,
                        bonus_transfer=bonus_transfer,
                        expire_at=bonus_expire_at
                    )

                logger.info(f"The bonus for the first deposit has been successfully "
                            f"credited for user {transfer.to_user_id} and is equal to "
                            f"{cashback_amount}")

            else:
                logger.info(f"User {transfer.to_user_id} has already received a first deposit bonus")

        return True

    def move_betgames_money(self, transfer_type: int, user_id: int,
                            value_cents, currency: str,
                            remote_transaction_id: int,
                            remote_bet_id: int, **kwargs) -> int:

        if transfer_type == TransferTypes.TYPE_BETGAMES_PAYOUT:
            from_user_id = UserModel.ORGANIZATION_ID
            to_user_id = user_id
        else:
            from_user_id = user_id
            to_user_id = UserModel.ORGANIZATION_ID

        value = Decimal(int(value_cents) / 100)
        currency = currency.upper()  # Why attr currency? It always should be user's currency

        local_transfer = MoneyTransferModel(type=transfer_type, from_user_id=from_user_id, to_user_id=to_user_id,
                                            real_from_user_id=from_user_id, real_to_user_id=to_user_id,
                                            value=value, note="betgames", currency=currency)
        from_user = to_user = None
        U = UserModel
        if from_user_id > 0:
            from_user = self.db.query(U).filter(
                U.id == from_user_id).with_for_update(of=U).first()
        elif to_user_id > 0:
            to_user = self.db.query(U).filter(
                U.id == to_user_id).with_for_update(of=U).first()
        balance_user_after = 0
        if to_user:
            balance_user_after = Decimal(to_user.balance) + value
            self.db.query(U).filter(U.id == to_user.id).update(
                {U.balance: balance_user_after},
                synchronize_session='fetch')
        elif from_user:
            balance_user_after = Decimal(from_user.balance) - value
            self.db.query(U).filter(U.id == from_user.id).update(
                {U.balance: balance_user_after},
                synchronize_session='fetch')
        self.db.add(local_transfer)

        bg_transaction = BetgamesTransactionModel()
        bg_transaction.remote_transaction_id = remote_transaction_id
        bg_transaction.user_id = user_id
        bg_transaction.amount = value
        bg_transaction.type = transfer_type
        bg_transaction.currency = currency
        bg_transaction.remote_bet_id = remote_bet_id
        bg_transaction.local_transaction = local_transfer

        self.db.add(bg_transaction)
        self.db.commit()

        balance_after = int(balance_user_after * 100)
        return balance_after

    def move_bonus_money(self, from_user_id, to_user_id, value,
                         transfer_type=BONUS_TRANSFER_TYPES.TYPE_SET_BET, note=None,
                         transaction_id: str = None, is_commit: bool = True):
        U = UserModel
        from_user = to_user = None
        transfer = BonusTransferModel(from_user_id, to_user_id, transfer_type,
                                      value, note, transaction_id)

        if to_user_id > 0 and from_user_id > 0:
            users = self.db.query(U).filter(
                U.id.in_([from_user_id, to_user_id])).with_for_update(of=U).all()
            from_user = self.get_user_from_list(users, from_user_id)
            to_user = self.get_user_from_list(users, to_user_id)
        else:
            if from_user_id > 0:
                from_user = self.db.query(U).filter(
                    U.id == from_user_id).with_for_update(of=U).first()
                transfer.currency = from_user.currency
            if to_user_id > 0:
                to_user = self.db.query(U).filter(
                    U.id == to_user_id).with_for_update(of=U).first()
                transfer.currency = to_user.currency
        if to_user:
            self.db.refresh(to_user)
            self.change_bonus_balance_with_lock(to_user.id, value)

        if from_user:
            self.db.refresh(from_user)
            self.change_bonus_balance_with_lock(from_user.id, -value)

        self.db.add(transfer)
        if is_commit:
            self.db.commit()
        return transfer

    @staticmethod
    def _prepare_transfer_source_account_to_service_account(
            transfer: MoneyTransferModel,
            source_user: UserModel,
            source_user_id: int,
            target_user_id: int,
            is_outcome: bool
    ):
        if source_user and source_user_id > 0:
            if is_outcome:
                transfer.from_user_id = target_user_id
                transfer.to_user_id = source_user_id
                transfer.type = TransferTypes.SERVICE_ACCOUNT_TRANSFER_TYPES_BY_ROLE[
                    UserTypePaymentTransfer.TYPE_WITHDRAWAL][source_user.role]
            else:
                transfer.from_user_id = source_user_id
                transfer.to_user_id = target_user_id
                transfer.type = TransferTypes.SERVICE_ACCOUNT_TRANSFER_TYPES_BY_ROLE[
                    UserTypePaymentTransfer.TYPE_DEPOSIT][source_user.role]
        else:
            if is_outcome:
                transfer.from_user_id = target_user_id
                transfer.to_user_id = UserModel.ORGANIZATION_ID
                transfer.type = TransferTypes.TYPE_SERVICE_ACCOUNT_TO_OWNER
            else:
                transfer.from_user_id = UserModel.ORGANIZATION_ID
                transfer.to_user_id = target_user_id
                transfer.type = TransferTypes.TYPE_OWNER_TO_SERVICE_ACCOUNT

        return transfer

    def _move_money_to_service_user(
        self,
        source_user_id: int,
        target_user_id: int,
        amount: float,
        note: str = '',
        is_outcome: bool = False,
        additional_data: dict = None,
        transfer_type: str = None,
    ):
        U = UserModel
        source_user = target_user = None
        balance_source_after = balance_service_after = 0
        balance_source_before = balance_service_before = "0"
        transfer_value = round(Decimal(str(amount)), 2)

        transfer = MoneyTransferModel(
            value=amount,
            note=note
        )

        if source_user_id > 0:
            source_user = self.db.query(U).filter(U.id == source_user_id) \
                .with_for_update(of=U).first()

        if target_user_id < 0:
            target_user = self.db.query(U).filter(U.id == target_user_id) \
                .with_for_update(of=U).first()

        transfer = self._prepare_transfer_source_account_to_service_account(
            transfer=transfer,
            source_user=source_user,
            source_user_id=source_user_id,
            target_user_id=target_user_id,
            is_outcome=is_outcome
        )
        if transfer_type:
            transfer.type = transfer_type

        if source_user:
            self.db.refresh(source_user)
            balance_source_before = round(Decimal(str(source_user.balance)), 2)
            balance_source_after = balance_source_before + transfer_value \
                if is_outcome else balance_source_before - transfer_value

            self.db.query(U).filter(U.id == source_user_id).update(
                {U.balance: balance_source_after},
                synchronize_session='fetch')

        if target_user:
            self.db.refresh(target_user)
            balance_service_before = round(Decimal(str(target_user.balance)), 2)
            balance_service_after = balance_service_before - transfer_value \
                if is_outcome else balance_service_before + transfer_value

            self.db.query(U).filter(U.id == target_user_id).update(
                {U.balance: balance_service_after},
                synchronize_session='fetch')

        if is_outcome:
            transfer.additional_data = {
                'balance_before_from_user': str(balance_service_before),
                'balance_before_to_user': str(balance_source_before),
                'balance_after_from_user': str(balance_service_after),
                'balance_after_to_user': str(balance_source_after)}
        else:
            transfer.additional_data = {
                'balance_before_from_user': str(balance_source_before),
                'balance_before_to_user': str(balance_service_before),
                'balance_after_from_user': str(balance_source_after),
                'balance_after_to_user': str(balance_service_after)
            }
        if additional_data:
            transfer.additional_data.update(additional_data)
        self.db.add(transfer)
        self.db.commit()

        return transfer

    def move_marketing_money(self,
                             user_id,
                             value,
                             transfer_type,
                             note: str = None,
                             transaction_id: str = None,
                             is_bonus: bool = False,
                             is_outcome: bool = False,
                             is_commit: bool = True):
        U = UserModel
        from_user_id = U.ORGANIZATION_ID
        to_user_id = user_id
        balance_marketing_owner_before = "0"
        balance_marketing_owner_after = "0"
        transfer_value = round(Decimal(str(value)), 2)

        marketing_owner = self.db.query(U).filter(U.id == U.MARKETING_OWNER_ID) \
            .with_for_update(of=U).first()

        if marketing_owner:
            from_user_id = U.MARKETING_OWNER_ID

            self.db.refresh(marketing_owner)
            balance_marketing_owner_before = round(Decimal(str(marketing_owner.balance)), 2)
            user = self.db.query(U).filter(U.id == user_id).with_for_update(of=U).first()

            if is_bonus:
                user_balance_before = round(Decimal(str(user.bonus_balance)), 2)
                max_bonus_balance = options.MAX_BONUS_BALANCE_AMOUNT_BY_CURRENCY.get(user.currency, 0.0)
                if not is_outcome and (user_balance_before + transfer_value) > max_bonus_balance:
                    transfer_value = round(Decimal(max_bonus_balance), 2) - user_balance_before
            else:
                user_balance_before = round(Decimal(str(user.balance)), 2)

            if is_outcome:
                if user_balance_before < transfer_value:
                    transfer_value = user_balance_before
                balance_marketing_owner_after = balance_marketing_owner_before + transfer_value
            else:
                if balance_marketing_owner_before < transfer_value:
                    note = note + f" Marketing account is empty. The sum was {transfer_value}"
                    transfer_value = balance_marketing_owner_before
                balance_marketing_owner_after = balance_marketing_owner_before - transfer_value

            self.db.query(U).filter(U.id == U.MARKETING_OWNER_ID).update(
                {U.balance: balance_marketing_owner_after},
                synchronize_session='fetch')

        additional_data = {
            'original_value': str(transfer_value),
            'real_value': str(value)
        }

        if is_outcome:
            from_user_id, to_user_id = to_user_id, from_user_id
            additional_data.update({
                'balance_before_to_user': str(balance_marketing_owner_before),
                'balance_after_to_user': str(balance_marketing_owner_after)
            })
        else:
            additional_data.update({
                'balance_before_from_user': str(balance_marketing_owner_before),
                'balance_after_from_user': str(balance_marketing_owner_after)
            })

        if is_bonus:
            transfer = self.move_bonus_money(
                from_user_id=from_user_id,
                to_user_id=to_user_id,
                value=transfer_value,
                transfer_type=transfer_type,
                note=note,
                transaction_id=transaction_id
            )
        else:
            transfer = self.user_move_money(
                from_user_id=from_user_id,
                to_user_id=to_user_id,
                value=transfer_value,
                transfer_type=transfer_type,
                note=note,
                transaction_id=transaction_id
            )

        transfer.additional_data.update(additional_data)
        flag_modified(transfer, 'additional_data')
        self.db.add(transfer)

        if is_commit:
            self.db.commit()

        return transfer

    def check_for_allow_service_money_transfer(
        self,
        source_user_id: int,
        target_user_id: int,
        amount: float,
        is_outcome: bool = False
    ):
        U = UserModel
        if not is_outcome and source_user_id > 0:
            source_user = self.db.query(U).filter(U.id == source_user_id) \
                .with_for_update(of=U).first()
            if source_user and source_user.balance < amount:
                raise Exception(f'Balance user {source_user_id} is insufficient')
        elif is_outcome and target_user_id != UserModel.REVENUE_BALANCE_ID:
            source_user = U.get_specific_columns_by_id(self.db, source_user_id, U.id, U.role)
            if source_user.role == UserModel.LIMITED_OWNER and target_user_id == UserModel.MARKETING_OWNER_ID:
                raise Exception(f'Limited owner can not withdraw from marketing owner')
            target_user = self.db.query(U).filter(U.id == target_user_id) \
                .with_for_update(of=U).first()
            if target_user and target_user.balance < amount:
                raise Exception(f'Balance service account {target_user_id} is insufficient')

        return

    def move_money_to_service_user(
        self,
        source_user_id: int,
        service_account_id: int,
        amount: float,
        note: str = '',
        is_outcome: bool = False,
        additional_data: dict = None,
        transfer_type: str = None,
        allow_negative_balance: bool = False
    ):
        if allow_negative_balance is False:
            self.check_for_allow_service_money_transfer(
                source_user_id=source_user_id,
                target_user_id=service_account_id,
                amount=amount,
                is_outcome=is_outcome
            )

        self._move_money_to_service_user(
            source_user_id=source_user_id,
            target_user_id=service_account_id,
            amount=amount,
            note=note,
            is_outcome=is_outcome,
            additional_data=additional_data,
            transfer_type=transfer_type
        )

    def partner_move_money(
            self, user_id: int, value: float,
            type: int = PartnerTypeMoneyTransfer.TYPE_CREDIT,
            status: int = PartnerStatusMoneyTransfer.DONE,
            type_payment=PartnerTypePayment.BET) -> MoneyTransferModel:
        user = UserModel.get_by_id(self.db, user_id)
        currency = user.currency
        transfer = PartnerMoneyTransfer(value, currency, user, type, status,
                                        type_payment)
        self.db.add(transfer)
        self.db.commit()
        self.user_move_money(UserModel.ORGANIZATION_ID, user.id, value,
                             transfer_type=TransferTypes.TYPE_PARTNER_WITHDRAWAL,
                             note=f"Partner move money")
        # self.update_balance_by_user(user)
        self.db.add(user)
        self.db.commit()

        return transfer

    def get_user_balance_by_user_id(self, user_id: int) -> float:
        return float(UserModel.get_by_id(self.db, user_id).balance)

    def get_user_bonus_balance_by_user_id(self, user_id: int) -> float:
        balance = UserModel.get_by_id(self.db, user_id).bonus_balance
        amount = float(balance) if balance else 0
        return amount

    def calculation_bonus_balance_by_user_id(self, user_id: int) -> float:
        try:
            return BonusTransferModel.get_summary_balance_by_user(self.db, user_id)
        except Exception as e:
            logger.warning("Can't get u:{} balance e:{}".format(user_id, e))
            raise ProgrammingError(e)

    def get_user_partner_balance_by_user_id(self, user_id: int) -> float:
        return float(UserModel.get_by_id(self.db, user_id).partner_balance)

    def move_convert_money(self, user_id, amount):
        transfer = self.user_move_money(UserModel.ORGANIZATION_ID, user_id,
                                        amount, TransferTypes.TYPE_CONVERT_USER)
        return transfer

    # def update_balance_by_user(self, user: UserModel) -> UserModel:
    #     """Takes user model"""
    #     user.balance = self.calculation_balance_by_user_id(user.id)
    #     user.bonus_balance = self.calculation_bonus_balance_by_user_id(user.id)
    #     self.db.add(user)
    #     self.db.commit()
    #     return user

    def get_user_currency_by_user_id(self, user_id: int) -> str:
        try:
            return UserModel.get_by_id(self.db, user_id).currency
        except Exception as e:
            logger.warning("Can't get u:{} currency e:{}".format(user_id, e))
            raise ProgrammingError(e)

    def check_balance(self, user_id: int, real_amount: float = 0,
                      bonus_amount: float = 0):
        real_amount = Decimal(real_amount).quantize(self.accuracy, ROUND_HALF_UP)
        user = self.db.query(UserModel.balance, UserModel.bonus_balance).filter_by(id=user_id).first()
        real_balance = Decimal(user.balance).quantize(self.accuracy, ROUND_HALF_UP)
        bonus_balance = Decimal(self.calculation_bonus_balance_by_user_id(user_id)). \
            quantize(self.accuracy, ROUND_HALF_UP)
        bonus_amount = Decimal(bonus_amount).quantize(self.accuracy, ROUND_HALF_UP)
        if user.bonus_balance != bonus_balance:
            self.db.query(UserModel).filter(UserModel.id == user_id).update({"bonus_balance": bonus_balance},
                                                                            synchronize_session="fetch")
            self.db.commit()
        if (real_amount > real_balance) or (bonus_amount > bonus_balance):
            raise InvalidRequestData(
                error_codes.INSUFFICIENT_BALANCE,
                f"Insufficient funds! Balance:{real_balance}, amount: {real_amount}; "
                f"Bonus_balance: {bonus_balance}, bonus_amount: {bonus_amount}")
        return True

    # def check_balance(self, user_id: int, real_amount: float = 0,
    #                   bonus_amount: float = 0):
    #     real_amount = Decimal(real_amount).quantize(self.accuracy, ROUND_HALF_UP)
    #     bonus_amount = Decimal(bonus_amount)
    #     user = UserModel.get_by_id(self.db, user_id)
    #     real_balance = Decimal(self.calculation_balance_by_user_id(user_id)).\
    #         quantize(self.accuracy, ROUND_HALF_UP)
    #     bonus_balance = Decimal(self.calculation_bonus_balance_by_user_id(user_id)).\
    #         quantize(self.accuracy, ROUND_HALF_UP)
    #     if user.balance != real_balance or user.bonus_balance != bonus_balance:
    #         user.balance = real_balance
    #         user.bonus_balance = bonus_balance
    #         self.db.add(user)
    #         self.db.commit()
    #     if not real_amount <= real_balance and bonus_amount <= bonus_balance:
    #         raise InvalidRequestData(
    #             error_codes.INSUFFICIENT_BALANCE,
    #             "Insufficient balance you have only %s" % real_balance)
    #     return True

    def check_bonus_balance(self, user_id: int, bonus_amount=0):
        bonus_amount = float(bonus_amount)
        user = UserModel.get_by_id(self.db, user_id)
        bonus_balance = self.calculation_bonus_balance_by_user_id(user_id)
        if user.balance != bonus_balance:
            user.bonus_balance = bonus_balance
            self.db.add(user)
            self.db.commit()
        if not bonus_amount <= bonus_balance:
            raise InvalidRequestData(
                error_codes.INSUFFICIENT_BALANCE,
                "Insufficient Bonus balance you have only %s" % bonus_balance)
        return True

    def check_balance_withdrawal(self, user: UserModel, amount: float):
        self.check_balance(user.id, amount)
        withdrawal_minimum = options.MIN_WITHDRAWAL.get(user.currency, 0)
        if amount < withdrawal_minimum:
            raise InvalidRequestData(
                error_codes.WITHDRAWAL_AMOUNT_MIN,
                "Amount less than the minimum %s %s" % (amount, user.currency))

    def out_money_to_ticket(
            self, user: UserModel, value: float) -> MoneyTransferModel:
        self.check_balance(user.id, value)
        return self.user_move_money(user.id, UserModel.TICKET_USER_ID, value,
                                    TransferTypes.TYPE_TICKET_OUT)

    def top_up_balance(self, payment: PaymentTransactionModel) -> PaymentTransactionModel:
        note = "Refill from %s" % payment.payment_mode
        transfer = self.user_move_money(
            UserModel.ORGANIZATION_ID, payment.user_id,
            payment.user_amount, TransferTypes.TYPE_FREEKASSA_TRANSFER, note=note)
        # TODO Move this bonus to other place
        if payment.user.promo_code:
            percent = (PromoCodeModel.get_by_code(
                self.db, payment.user.promo_code).amount / 100)
            promo_transfer = self.user_move_money(
                UserModel.ORGANIZATION_ID, payment.user_id,
                float(payment.user_amount) * float(percent),
                TransferTypes.TYPE_PROMOCODE_BONUS,
                note=note)
            self.db.add(promo_transfer)
        payment.transfer = transfer
        self.db.add(transfer)
        self.db.add(payment)
        self.db.commit()
        return payment

    def fill_money_from_ticket(
            self, user: UserModel,
            ticket: CreditTicketModel) -> MoneyTransferModel:
        transfer = self.user_move_money(
            UserModel.TICKET_USER_ID, user.id, ticket.transfer_in.value,
            TransferTypes.TYPE_TICKET_IN)
        ticket.transfer_out = transfer
        self.db.add(ticket)
        self.db.commit()
        return transfer

    def top_up_balance_from_bill(
            self, user: UserModel, amount: float) -> MoneyTransferModel:
        return self.user_move_money(UserModel.ORGANIZATION_ID, user.id, amount,
                                    TransferTypes.BILL_PAYMENT)

    def take_money_for_bet(
            self, user_id: int, amount: float, note: str = None) -> MoneyTransferModel:
        self.check_balance(user_id, amount)
        return self.user_move_money(user_id, UserModel.ORGANIZATION_ID, amount,
                                    TransferTypes.SET_BET_BETSSTORE, note=note)

    def take_bonus_money_for_bet(self, user_id, amount):
        self.check_bonus_balance(user_id, amount)
        return self.move_bonus_money(user_id, UserModel.ORGANIZATION_ID, amount,
                                     BONUS_TRANSFER_TYPES.TYPE_SET_BET)

    def pay_win_bet(self, bet: BetrouteLocalBetModel,
                    amount_out) -> MoneyTransferModel:
        transfer = None
        amount = Decimal("0")
        if bet.transfer_return and bet.transfer_return.value:
            amount -= Decimal(str(bet.transfer_return.value))
            bet.transfer_return.value = 0
        if not bet.transfer_win:
            transfer = self.user_move_money(
                UserModel.ORGANIZATION_ID, bet.from_user_id, amount_out,
                TransferTypes.WIN_BET_BETSSTORE, f"Bet: {bet.betcode}")
            bet.transfer_win = transfer
        else:
            amount += Decimal(str(amount_out)) - Decimal(str(bet.transfer_win.value))
            bet.transfer_win.value = amount_out
        if amount:
            self.change_balance_with_lock(user_id=bet.from_user_id, value=float(amount))
        self.db.add(bet)
        self.db.commit()
        return transfer

    def loss_bet(self, bet: BetrouteLocalBetModel) -> BetrouteLocalBetModel:
        amount = Decimal("0")
        change = False
        if bet.transfer_return and bet.transfer_return.value:
            amount -= Decimal(str(bet.transfer_return.value))
            bet.transfer_return.value = 0
            change = True
        if bet.transfer_win and bet.transfer_win.value:
            amount -= Decimal(str(bet.transfer_win.value))
            bet.transfer_win.value = 0
            change = True
        if change:
            self.db.add(bet)
        if amount:
            self.change_balance_with_lock(user_id=bet.from_user_id, value=float(amount))
        if change or amount:
            self.db.commit()
        return bet

    def return_bet(self, bet: BetrouteLocalBetModel, user: UserModel = None) -> MoneyTransferModel:
        change = transfer = None
        if not bet.transfer_return:
            user_id = user.id if user else bet.from_user_id
            transfer = self.user_move_money(
                UserModel.ORGANIZATION_ID, bet.from_user_id, bet.transfer.value,
                TransferTypes.RETURN_BET_BETSSTORE,
                f"Bet: {bet.betcode}"
            )
            if bet.bonus_transfer:
                bonus_transfer = self.move_bonus_money(
                    UserModel.ORGANIZATION_ID,
                    user_id,
                    bet.bonus_transfer.value,
                    BONUS_TRANSFER_TYPES.TYPE_RETURN_BET)
                bet.bonus_transfer_return = bonus_transfer
            bet.transfer_return = transfer
            change = True

        if bet.transfer_win and bet.transfer_win.value:
            self.change_balance_with_lock(user_id=bet.from_user_id, value=-bet.transfer_win.value)
            bet.transfer_win.value = 0
            change = True
        if change:
            self.db.add(bet)
            self.db.commit()
        return transfer

    def sell_bet(self, bet: BetrouteLocalBetModel, amount_out, user_id):
        logger.info(f"User {user_id} is selling bet: {bet}, with amount {amount_out}")
        transfer = None
        if not bet.transfer_win:
            transfer = self.user_move_money(
                UserModel.ORGANIZATION_ID, bet.from_user_id, amount_out,
                TransferTypes.SELL_BET_BETSTORE, f"Bet: {bet.betcode}")
            bet.status = BetStatus.CASH_OUT
            bet.transfer_win = transfer
        else:
            value = Decimal(str(amount_out)) - Decimal(str(bet.transfer_win.value))
            if value:
                self.change_balance_with_lock(user_id=bet.from_user_id, value=value)
            bet.transfer_win.value = amount_out
        self.db.add(bet)
        self.db.commit()
        return transfer

    def withdrawal_transfer(self, user_id: int, amount: float) -> MoneyTransferModel:
        transfer = self.user_move_money(user_id, UserModel.ORGANIZATION_ID,
                                        amount, TransferTypes.TYPE_WITHDRAWAL)
        return transfer

    def withdrawal_transfer_cancel(self, user_id: int, amount: float) -> MoneyTransferModel:
        transfer = self.user_move_money(UserModel.ORGANIZATION_ID, user_id,
                                        amount, TransferTypes.TYPE_CANCEL_WITHDRAWAL)
        return transfer

    def promo_code_transfer(self, amount: float, user: UserModel) -> MoneyTransferModel:
        transfer = self.user_move_money(UserModel.ORGANIZATION_ID, user.id,
                                        amount, TransferTypes.TYPE_PROMOCODE_BONUS)
        return transfer

    def promo_code_bonus_transfer(self, amount: float, user: UserModel) -> BonusTransferModel:

        transfer = self.move_bonus_money(UserModel.ORGANIZATION_ID, user.id, amount,
                                         BONUS_TRANSFER_TYPES.TYPE_PROMO_CODE_BONUS)
        return transfer

    def payment_cash_back(self, payment: PaymentTransactionModel):
        setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
        bonus_amount = float(payment.payment_amount) * float(setting['cashback_payment'])
        bonus_transfer = self.move_bonus_money(
            UserModel.ORGANIZATION_ID,
            payment.user_id,
            bonus_amount,
            BONUS_TRANSFER_TYPES.TYPE_CASHBACK_PAYMENTS)
        self.db.add(bonus_transfer)
        self.db.commit()
        return bonus_transfer

    def bet_cash_back(self, bet: BetrouteLocalBetModel):
        setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
        bonus_amount = float(bet.transfer.value) * float(setting['cashback_bet'])
        bonus_transfer = self.move_bonus_money(
            UserModel.ORGANIZATION_ID,
            bet.from_user_id,
            bonus_amount,
            BONUS_TRANSFER_TYPES.TYPE_CASHBACK_BET)
        self.db.add(bonus_transfer)
        self.db.commit()
        return bonus_transfer

    def registration_bonus(self, user_id: int, bonus_amount: float):
        bonus_transfer = self.move_bonus_money(
            UserModel.ORGANIZATION_ID,
            user_id,
            bonus_amount,
            BONUS_TRANSFER_TYPES.TYPE_REGISTRATION_BONUS)
        self.db.add(bonus_transfer)
        self.db.commit()
        return bonus_transfer

    def partner_get_min_withdrawal(self, user: UserModel) -> PartnerMinWithdrawalDTO:
        currency = user.currency or user.original_currency
        amount = CurrencyRateModel.convert(
            self.db, options.PARTNER_MIN_WITHDRAWAL,
            options.PARTNER_CURRENCY, currency)

        result = PartnerMinWithdrawalDTO(amount, currency)

        return result

    def partner_take_money(
            self, partner: UserModel, amount: float,
            partner_payment: int = PartnerTypePayment.BET) -> \
            PartnerMoneyTransfer or None:

        # TODO: Raise exception about amount less zero
        if amount <= 0:
            return None

        result = self.partner_move_money(
            partner.id, amount, PartnerTypeMoneyTransfer.TYPE_CREDIT,
            PartnerStatusMoneyTransfer.DONE, partner_payment)

        return result

    def get_summary_top_up_transfer(self, user_id: int) -> MoneyTransferModel:
        return MoneyTransferModel.get_sum_payments(self.db, user_id)

    def partner_take_registration_money(
            self, partner: UserModel) -> PartnerMoneyTransfer or None:
        result = None
        if partner.type_partner_payment == PartnerTypePayment.REGISTRATION:
            currency = partner.get_currency
            amount = CurrencyRateModel.convert(
                self.db, partner.partner_pay_registration,
                options.PARTNER_CURRENCY, currency)
            result = self.partner_take_money(
                partner, amount, PartnerTypePayment.REGISTRATION)

        return result

    def partner_take_click_money(self, partner: UserModel) -> Optional[PartnerMoneyTransfer]:
        if partner.type_partner_payment == PartnerTypePayment.CLICK_LINKS:
            currency = partner.get_currency
            amount = CurrencyRateModel.convert(self.db, partner.partner_pay_traffic,
                                               options.PARTNER_CURRENCY, currency)
            result = self.partner_take_money(partner, amount, PartnerTypePayment.CLICK_LINKS)

            return result

    def partner_take_topup_money(self, partner: UserModel) -> Optional[PartnerMoneyTransfer]:
        if partner.type_partner_payment == PartnerTypePayment.MONEY_UP:
            currency = partner.get_currency
            amount = CurrencyRateModel.convert(
                self.db, partner.partner_pay_top_up,
                options.PARTNER_CURRENCY, currency)
            result = self.partner_take_money(
                partner, amount, PartnerTypePayment.MONEY_UP)

            return result

    def partner_take_bet_money(self, partner: UserModel) -> Optional[PartnerMoneyTransfer]:
        if partner.type_partner_payment == PartnerTypePayment.BET:
            currency = partner.get_currency
            amount = CurrencyRateModel.convert(self.db, partner.partner_pay_bet,
                                               options.PARTNER_CURRENCY, currency)
            result = self.partner_take_money(partner, amount, PartnerTypePayment.BET)
            return result

    def first_payment_cashback(
            self, payment: PaymentTransactionModel) -> MoneyTransferModel:

        if PaymentTransactionModel.count_closed_payments(self.db,
                                                         payment.user_id) <= 1:
            setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
            coef = setting['first_payment_cashback']

            value = float(payment.transfer.value) * float(coef)

            transfer = self.user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=payment.user_id, value=value,
                note='Payment cashback', additional_data={
                    'payment_id': payment.id
                }
            )

            return transfer

    def move_promo_code_percent_money(self, from_user_id: int, to_user_id: int, promo_code: PromoCodeModel,
                                      transfer=MoneyTransferModel, additional_data: dict = None):
        percent = promo_code.amount
        code = promo_code.code
        if promo_code.is_actual(self.db, code):
            logger.info("Creating bonus transfer with promocode %s", code)
            bonus_transfer = self.user_move_money(from_user_id, to_user_id,
                                                  value=float(transfer.value * percent / 100),
                                                  transfer_type=TransferTypes.TYPE_PROMOCODE_BONUS,
                                                  additional_data=additional_data)
            self.db.add(transfer)
            self.db.commit()
            return bonus_transfer

    def move_money_CASHIER_to_USER(self, cashier: UserModel, user: UserModel,
                                   amount: float, note: str, is_outcome: bool):
        transfer = self.move_money_with_currency_rate(
            source_user_id=cashier.id,
            target_user_id=user.id,
            amount=amount,
            note=note,
            transfer_type=TransferTypes.TYPE_USER_TO_CASHIER
            if is_outcome else TransferTypes.TYPE_CASHIER_TO_USER,
            is_outcome=is_outcome,
            check_balances=True
        )
        return transfer

    def change_balance_with_lock(self, user_id: int, value: float or Decimal):
        """If value > 0 balance will be increased by value. If value < 0 balance will be decreased"""

        user = UserModel.get_by_id_with_lock(self.db, user_id)
        if user:
            new_balance = Decimal(str(user.balance)) + Decimal(str(value))
            self.db.query(UserModel).filter(UserModel.id == user_id).update(
                {UserModel.balance: new_balance},
                synchronize_session='fetch')
            CacheManager.set_user_data_to_cache(user)
            return new_balance
        return None

    def change_bonus_balance_with_lock(self, user_id: int, value: float):
        """If value > 0 balance will be increased by value. If value < 0 balance will be decreased"""

        user = self.db.query(UserModel).filter(
            UserModel.id == user_id).with_for_update(of=UserModel).first()
        if user:
            new_balance = Decimal(str(user.bonus_balance)) + Decimal(str(value))
            logger.info(f"Change bonus balance with lock operation."
                        f"U: {user_id} From: {user.bonus_balance} To: {new_balance}")
            self.db.query(UserModel).filter(UserModel.id == user_id).update(
                {UserModel.bonus_balance: new_balance},
                synchronize_session='fetch')
            CacheManager.set_user_data_to_cache(user)
            return new_balance
        return None

    def multi_user_move_money(self, transfers: list, skip_locked: bool = False):
        """
        skip_locked = True Only when Organization one of from_user or to_user !!!
        transfers = [
                        {"from_user_id": user_id,
                        "to_user_id": -1,
                        "value": 100,
                        "transfer_type": TransferTypes.TYPE_ROULETTE_BET,
                        "real_from_user_id": user_id,
                        "real_to_user_id": -1,
                        "note": 'My note'}
                        , {...}, {...}, ...
            ]
        """

        args = {"from_user_id",  # - Обязательные аргументы
                "to_user_id",
                "value",
                "transfer_type"}
        ids_balances = dict()
        good_transfers = []
        for transfer in transfers:
            if not (args - set(transfer.keys())):
                good_transfers.append(transfer)
                from_user_id = transfer["from_user_id"]
                if from_user_id > 0:
                    if from_user_id not in ids_balances.keys():
                        ids_balances[from_user_id] = Decimal("0")
                    ids_balances[from_user_id] -= Decimal(str(transfer["value"]))
                to_user_id = transfer["to_user_id"]
                if to_user_id > 0:
                    if to_user_id not in ids_balances.keys():
                        ids_balances[to_user_id] = Decimal("0")
                    ids_balances[to_user_id] += Decimal(str(transfer["value"]))
        U = UserModel
        users = self.db.query(U).filter(
            U.id.in_(ids_balances.keys())).with_for_update(of=U, skip_locked=skip_locked).all()
        if users:
            new_balances = dict()
            old_balances = dict()
            ids_currencies = dict()
            for user in users:
                old_balances[user.id] = str(user.balance)
                new_balances[user.id] = Decimal(old_balances[user.id]) + ids_balances[user.id]
                ids_currencies[user.id] = user.currency
            answer = self.db.query(U).filter(U.id.in_(new_balances)).update(
                {U.balance: case(new_balances, value=U.id)},
                synchronize_session=False)
            if answer:
                self.db.commit()
            logger.info(f"{len(new_balances.keys())} balances should be updated, Realy updated = {answer}")

            transfers = []
            for transfer in good_transfers:
                to_user_id = transfer.get("to_user_id")
                from_user_id = transfer.get("from_user_id")
                if (to_user_id <= 0 or to_user_id in new_balances.keys()) and (
                        from_user_id <= 0 or from_user_id in new_balances.keys()):
                    real_from_user_id = transfer.get("real_from_user_id") or from_user_id
                    real_to_user_id = transfer.get("real_to_user_id") or to_user_id
                    currency = ids_currencies.get(to_user_id) or ids_currencies.get(from_user_id)
                    transfer = MoneyTransferModel(type=transfer["transfer_type"], from_user_id=from_user_id,
                                                  to_user_id=to_user_id,
                                                  real_from_user_id=real_from_user_id, real_to_user_id=real_to_user_id,
                                                  value=transfer["value"], note=transfer.get("note"), currency=currency)
                    transfer.additional_data = {
                        'balance_before_from_user': old_balances.get(from_user_id, "0"),
                        'balance_before_to_user': old_balances.get(to_user_id, "0"),
                        'balance_after_from_user': str(new_balances.get(from_user_id, 0)),
                        'balance_after_to_user': str(new_balances.get(to_user_id, 0))
                    }
                    transfers.append(transfer)
            if transfers:
                self.db.bulk_save_objects(transfers)
                self.db.commit()
            return new_balances
        return None

    def get_sum_of_deposits_by_admin_id_role_date(self, admin_id, role, from_date, to_date):
        query_by_date = self.db.query(MoneyTransferModel).filter(and_(MoneyTransferModel.created_at >= from_date,
                                                                      MoneyTransferModel.created_at <= to_date))
        query_by_admin_id = query_by_date.filter(or_(MoneyTransferModel.from_user_id == admin_id,
                                                     MoneyTransferModel.to_user_id == admin_id))
        credits_sum = 0
        debits_sum = 0
        if role == UserModel.CASHIER:
            credits_and_debits = query_by_admin_id.filter(
                or_(MoneyTransferModel.type == TransferTypes.TYPE_CASHIER_TO_USER,
                    MoneyTransferModel.type == TransferTypes.TYPE_USER_TO_CASHIER)).all()
            for transfer in credits_and_debits:
                if transfer.type == TransferTypes.TYPE_CASHIER_TO_USER:
                    credits_sum += transfer.value
                else:
                    debits_sum += transfer.value
        else:
            credits_and_debits = query_by_admin_id.filter(
                or_(MoneyTransferModel.type == TransferTypes.TYPE_ADMIN_TO_CASHIER,
                    MoneyTransferModel.type == TransferTypes.TYPE_CASHIER_TO_ADMIN)).all()
            for transfer in credits_and_debits:
                if transfer.type == TransferTypes.TYPE_ADMIN_TO_CASHIER:
                    credits_sum += transfer.value
                else:
                    debits_sum += transfer.value

        return credits_sum, debits_sum, credits_sum - debits_sum

    def get_cashier_sum_of_deposits_by_id_and_date(self, id, from_date, to_date):
        query_by_date = self.db.query(MoneyTransferModel).filter(and_(MoneyTransferModel.created_at >= from_date,
                                                                      MoneyTransferModel.created_at <= to_date))
        query_by_admin_id = query_by_date.filter(or_(MoneyTransferModel.from_user_id == id,
                                                     MoneyTransferModel.to_user_id == id))
        credits_sum = 0
        debits_sum = 0
        credits_and_debits = query_by_admin_id.filter(
            or_(MoneyTransferModel.type == TransferTypes.TYPE_CASHIER_TO_ADMIN,
                MoneyTransferModel.type == TransferTypes.TYPE_ADMIN_TO_CASHIER)).all()
        for transfer in credits_and_debits:
            if transfer.type == TransferTypes.TYPE_ADMIN_TO_CASHIER:
                credits_sum += transfer.value
            else:
                debits_sum += transfer.value

        return credits_sum, debits_sum, credits_sum - debits_sum

    def get_user_sum_of_deposits_by_id_and_date(self, id, from_date, to_date):
        query_by_date = self.db.query(MoneyTransferModel).filter(and_(MoneyTransferModel.created_at >= from_date,
                                                                      MoneyTransferModel.created_at <= to_date))
        query_by_admin_id = query_by_date.filter(or_(MoneyTransferModel.from_user_id == id,
                                                     MoneyTransferModel.to_user_id == id))
        credits_sum = 0
        debits_sum = 0
        credits_and_debits = query_by_admin_id.filter(
            or_(MoneyTransferModel.type == TransferTypes.TYPE_CASHIER_TO_USER,
                MoneyTransferModel.type == TransferTypes.TYPE_USER_TO_CASHIER)).all()
        for transfer in credits_and_debits:
            if transfer.type == TransferTypes.TYPE_CASHIER_TO_USER:
                credits_sum += transfer.value
            else:
                debits_sum += transfer.value

        return credits_sum, debits_sum, credits_sum - debits_sum

    def get_transfers_by_date_and_type(
            self,
            date_from: Union[datetime.datetime, str],
            date_to: Union[datetime.datetime, str],
            transfer_types: List[int],
            descendants: List[int],
            currency: str = None,
            skip: int = None,
            limit: int = None,
            with_username: bool = False
    ) -> Tuple[List[MoneyTransferModel], int]:
        transfers_subq = MoneyTransferModel.get_transfers_by_date_type_currency_subq(
            db=self.db,
            date_from=date_from,
            date_to=date_to,
            transfer_types=transfer_types,
            currency=currency,
            with_username=with_username
        )

        query = self.db.query(transfers_subq).filter(
            or_(
                transfers_subq.c.from_user_id.in_(descendants),
                transfers_subq.c.to_user_id.in_(descendants)
            )
        )

        total_count = query.count()

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return query.all(), total_count

    def get_transfers_by_date_and_type_for_single_user(
            self,
            user_db: UserModel,
            admin_id: int,
            date_from: Union[datetime.datetime, str],
            date_to: Union[datetime.datetime, str],
            transfer_types: List[int],
            currency: str = None,
            skip: int = None,
            limit: int = None,
            with_username: bool = False,
            decreasing_by_id: bool = False,
            only_user_transfers: bool = False,
            only_personal_higher_transfers: bool = False,
            is_deposit: bool = False,
            is_withdrawal: bool = False,
    ) -> Tuple[List[MoneyTransferModel], int, int, int]:
        transfers_subq = MoneyTransferModel.get_transfers_by_date_type_currency_subq(
            db=self.db,
            date_from=date_from,
            date_to=date_to,
            transfer_types=transfer_types,
            currency=currency,
            with_username=with_username
        )
        if user_db.id != admin_id:
            query = self.db.query(transfers_subq).filter(
                or_(and_(transfers_subq.c.from_user_id == admin_id,
                         transfers_subq.c.to_user_id == user_db.id),
                    and_(transfers_subq.c.from_user_id == user_db.id,
                         transfers_subq.c.to_user_id == admin_id))
            )
            withdrawals_sum = self.db.query(func.sum(transfers_subq.c.value)).filter(
                transfers_subq.c.from_user_id == user_db.id,
                transfers_subq.c.to_user_id == admin_id
            ).scalar()

            deposits_sum = self.db.query(func.sum(transfers_subq.c.value)).filter(
                transfers_subq.c.from_user_id == admin_id,
                transfers_subq.c.to_user_id == user_db.id
            ).scalar()
        else:
            if only_user_transfers:
                if is_deposit:
                    filter_param = transfers_subq.c.from_user_id == admin_id
                if is_withdrawal:
                    filter_param = transfers_subq.c.to_user_id == admin_id
                if is_deposit == is_withdrawal:
                    filter_param = or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )
                query = self.db.query(transfers_subq).filter(
                    filter_param,
                    or_(
                        transfers_subq.c.from_user_id.notin_(user_db.structure_path.path.split('.')),
                        transfers_subq.c.to_user_id.notin_(user_db.structure_path.path.split('.'))
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.to_user_id == admin_id
                ).scalar()
                deposits_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.from_user_id == admin_id
                ).scalar()

            if only_personal_higher_transfers:
                if is_deposit:
                    filter_param = transfers_subq.c.to_user_id == admin_id
                if is_withdrawal:
                    filter_param = transfers_subq.c.from_user_id == admin_id
                if is_deposit == is_withdrawal:
                    filter_param = or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )

                # Вынес то что было в фильтрах from_user_id и to_user_id
                user_ids = user_db.structure_path.path.split('.')[:-1]

                # Берём айдишники лмитированного овнера и кассира. Овнера (бога) не берём, трансферы его идут с id=-1
                # Techsupport не может пополнять/списывать
                lct_ids = self.db.query(UserModel.id).filter(
                    UserModel.role.in_([UserModel.LIMITED_OWNER,
                                        UserModel.CASHIER])
                ).all()

                # Добовление адйишников лимитированного овнера, кассиров и овнера (ORGANIZATION)
                user_ids += [id[0] for id in lct_ids]
                user_ids.append(UserModel.ORGANIZATION_ID)


                query = self.db.query(transfers_subq).filter(
                    filter_param,
                    or_(
                        transfers_subq.c.from_user_id.in_(user_ids),
                        transfers_subq.c.to_user_id.in_(user_ids)
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.from_user_id == admin_id
                ).scalar()
                deposits_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.to_user_id == admin_id
                ).scalar()

            if only_user_transfers == only_personal_higher_transfers:
                query = self.db.query(transfers_subq).filter(
                    or_(
                        transfers_subq.c.from_user_id == admin_id,
                        transfers_subq.c.to_user_id == admin_id
                    )
                )
                query_subq = query.subquery()
                withdrawals_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.type.in_(TransferTypes.WITHDRAWAL_TYPES)
                ).scalar()

                deposits_sum = self.db.query(func.sum(query_subq.c.value)).filter(
                    query_subq.c.type.notin_(TransferTypes.WITHDRAWAL_TYPES)
                ).scalar()

        total_count = query.count()

        if decreasing_by_id:
            query = query.order_by(transfers_subq.c.id.desc())

        if skip is not None and limit is not None:
            query = query.offset(skip).limit(limit)

        return (query.all(), total_count, withdrawals_sum if withdrawals_sum else 0,
                deposits_sum if deposits_sum else 0)

    def get_total_by_cashier_id_and_date(self, cashier_id, from_date, to_date):
        query_by_date = self.db.query(MoneyTransferModel).filter(and_(MoneyTransferModel.created_at >= from_date,
                                                                      MoneyTransferModel.created_at <= to_date))
        query_by_admin_id = query_by_date.filter(or_(MoneyTransferModel.from_user_id == cashier_id,
                                                     MoneyTransferModel.to_user_id == cashier_id))
        credits_sum = 0
        debits_sum = 0

        credits_and_debits = query_by_admin_id.filter(
            or_(MoneyTransferModel.type == TransferTypes.TYPE_CASHIER_TO_USER,
                MoneyTransferModel.type == TransferTypes.TYPE_USER_TO_CASHIER)).all()
        for transfer in credits_and_debits:
            if transfer.type == TransferTypes.TYPE_CASHIER_TO_USER:
                credits_sum += transfer.value
            else:
                debits_sum += transfer.value

        return credits_sum, debits_sum, credits_sum - debits_sum

    @staticmethod
    def get_slot_types_by_provider_and_game_type(
            providers: List[str] = None,
            game_types: List[str] = None,
            statuses: List[str] = None
    ):
        slots_types = []
        if game_types:
            providers_by_type = []
            for game_type_ in game_types:
                providers_by_type.extend(PROVIDERS_TYPES[game_type_])

            if providers:
                providers = set(providers_by_type) & set(providers)
            else:
                providers = providers_by_type

        if providers:
            for provider in providers:
                slots_types.extend(PROVIDERS[provider])

        if statuses:
            filtered_slots = []
            for status in statuses:
                available_types_for_status = set(STATUSES[str(status)])
                if slots_types:
                    required_types_slots = set(slots_types).intersection(available_types_for_status)
                else:
                    required_types_slots = available_types_for_status

                filtered_slots.extend(list(required_types_slots))

            slots_types = filtered_slots

        return slots_types

    def get_users_slots_bet_history(
            self,
            source_entity: UserModel,
            from_date: datetime,
            to_date: datetime,
            username: str = None,
            providers: List[str] = None,
            statuses: List[str] = None,
            game_types: List[str] = None,
            skip: int = None,
            limit: int = None,
            is_like_username: bool = True,
    ) -> Tuple[list[MoneyTransferModel], int, list[int]]:
        slot_types = self.get_slot_types_by_provider_and_game_type(
            providers=providers,
            statuses=statuses,
            game_types=game_types
        )

        users_subq = UserModel.get_list_users_by_entity_user_subq(
            db=self.db,
            entity_user=source_entity,
            username=username,
            is_like_username=is_like_username,
            is_direct_structure=False
        )
        user_ids = list(chain(*self.db.query(users_subq.c.id).all()))

        transfers_directions = [transfer_direction_by_bet_type[status] for status in statuses]
        transfers_direction = (transfers_directions[0]
                                if transfers_directions.count(transfers_directions[0]) == len(transfers_directions)
                                else None)
        bets_list, count = MoneyTransferModel.get_users_slots_bet_history(
            db=self.db,
            user_ids=user_ids,
            slots_types=slot_types,
            from_date=from_date,
            to_date=to_date,
            decreasing_by_id=True,
            transfers_direction=transfers_direction,
            skip=skip,
            limit=limit
        )

        return bets_list, count, user_ids

    def get_user_slots_bet_history(
            self, user_id, from_date, to_date,
            providers: List[str], statuses: List[str], types: List[str] = None,
            skip=None, limit=None
    ) -> Tuple[list, int]:
        slot_types = self.get_slot_types_by_provider_and_game_type(
            providers=providers,
            statuses=statuses,
            game_types=types
        )

        if slot_types:
            bets_list, count = MoneyTransferModel.get_user_slots_bet_history(
                self.db,
                user_id=user_id,
                from_date=from_date,
                to_date=to_date,
                slots_types=slot_types,
                skip=skip,
                limit=limit
            )
        else:
            bets_list, count = [], 0

        return bets_list, count

    def check_habanero_transfer(self, note):
        return MoneyTransferModel.get_transfer_by_note(self.db, note)

    def first_deposit_bonus_cashback(self, user: UserModel, amount: float or Decimal):
        is_first_deposit = MoneyTransferModel.check_payment_user(self.db, user.id)
        if not is_first_deposit:
            setting = SettingsManager(self.db).get_setting_by_name("BonusSettings")
            coeff_for_bonus = setting["first_deposit_bonus_cashback"]
            bonus_amount = amount * coeff_for_bonus
            self.move_bonus_money(UserModel.ORGANIZATION_ID, user.id, bonus_amount,
                                  BONUS_TRANSFER_TYPES.TYPE_CASHBACK_PAYMENTS)

    def get_total_by_role_id_and_date(self, descendants: List[dict], admin_role: str,
                                      from_date: str, to_date: str) -> List[dict]:
        """
        Select all transfers of sub_users of admin and make sum of values by type transaction (credit, withdrawal)
        @param descendants:
        @param admin_role:
        @param from_date:
        @param to_date:
        @return:
        """
        for descendant in descendants:
            if descendant.get("total") is None:
                descendant.update({
                    "credits_sum": Decimal("0"),
                    "debits_sum": Decimal("0"),
                    "total": Decimal("0")
                })
        admins_id = [descendant['user_id'] for descendant in descendants]

        result_credit_q = MoneyTransferModel.get_query_total_credit_by_ids_role(self.db, admins_id, admin_role,
                                                                                from_date, to_date)
        result_debit_q = MoneyTransferModel.get_query_total_debit_by_ids_role(self.db, admins_id, admin_role,
                                                                              from_date, to_date)

        result_credits = result_credit_q.all()
        result_debits = result_debit_q.all()

        descendants_data = {}
        for credit in result_credits:
            descendants_data[credit.admin_id] = {
                "credits_sum": Decimal(credit.sum),
                "debits_sum": Decimal('0')
            }

        for debit in result_debits:
            if debit.admin_id not in descendants_data:
                descendants_data[debit.admin_id] = {
                    "credits_sum": Decimal('0'),
                    "debits_sum": Decimal(debit.sum)
                }
            else:
                descendants_data[debit.admin_id]["debits_sum"] = Decimal(debit.sum)

            debits_sum = Decimal(descendants_data[debit.admin_id]["debits_sum"])
            credits_sum = Decimal(descendants_data[debit.admin_id]["credits_sum"])
            descendants_data[debit.admin_id]["total"] = credits_sum - debits_sum

        [item.update(user_id=item["user_id"], **descendants_data[item["user_id"]]) for item in descendants
         if item["user_id"] in descendants_data]
        return descendants

    def get_total_by_agent_ids_and_date(
            self,
            entity_user: UserModel,
            target_role: str,
            date_from: Union[datetime.datetime, str],
            date_to: Union[datetime.datetime, str],
            username: str = None,
            is_direct_structure: bool = False,
            is_higher_transaction_only: bool = False,
            is_withdrawal_transfers: bool = True,
            is_deposit_transfers: bool = True,
            is_bonus_deposits: bool = False
    ):
        deposit_types = self.get_structure_transfer_types(
            is_deposit_transfers=is_deposit_transfers,
            role=target_role,
            is_bonus_deposits=is_bonus_deposits
        )
        withdrawal_types = self.get_structure_transfer_types(
            is_withdrawal_transfers=is_withdrawal_transfers,
            role=target_role
        )

        users_subq = UserModel.get_descendant_by_ltree_path_subq(
            db=self.db,
            is_direct_structure=is_direct_structure,
            ltree_path=entity_user.structure_path,
            source_entity_id=entity_user.id,
            target_role=target_role,
            username=username
        )

        if deposit_types:
            result_deposits = MoneyTransferModel.get_query_structure_total_by_entity_user(
                db=self.db,
                users_subq=users_subq,
                date_from=date_from,
                date_to=date_to,
                transfer_types=deposit_types,
                is_higher_transaction_only=is_higher_transaction_only,
                transfer_direction='to').first()

            deposits_sum = result_deposits.sum
        else:
            deposits_sum = 0

        if withdrawal_types:
            result_withdraws = MoneyTransferModel.get_query_structure_total_by_entity_user(
                db=self.db,
                users_subq=users_subq,
                date_from=date_from,
                date_to=date_to,
                transfer_types=withdrawal_types,
                is_higher_transaction_only=is_higher_transaction_only,
                transfer_direction='from').first()

            withdrawals_sum = result_withdraws.sum
        else:
            withdrawals_sum = 0

        result = {
            "deposits_sum": deposits_sum,
            "withdrawals_sum": withdrawals_sum
        }

        return result

    def bonus_money_to_real_money(self, user_id, transaction_type, amount):

        # REMOVE BONUS MONEY
        bonus_money_transfer = self.move_bonus_money(user_id, UserModel.ORGANIZATION_ID, amount, transaction_type)

        # ADD REAL MONEY
        money_transfer = self.user_move_money(UserModel.ORGANIZATION_ID, user_id, amount, transaction_type)

        return bonus_money_transfer, money_transfer

    @staticmethod
    def _prepare_transfer_source_to_target_account(
            transfer: MoneyTransferModel,
            source_user_id: int,
            target_user_id: int,
            is_outcome: bool
    ):
        if is_outcome:
            transfer.from_user_id = target_user_id
            transfer.to_user_id = source_user_id
        else:
            transfer.from_user_id = source_user_id
            transfer.to_user_id = target_user_id

        return transfer

    @staticmethod
    def check_for_allow_money_transfer(
            source_user: UserModel,
            target_user: UserModel,
            source_user_amount: Union[float, Decimal],
            target_user_amount: Union[float, Decimal],
            is_outcome: bool,
            allow_negative: bool = False
    ):
        if is_outcome:
            if target_user and target_user.balance < target_user_amount and not allow_negative:
                raise Exception(f'Balance user {target_user.id} is insufficient')
        else:
            if source_user and source_user.balance < source_user_amount and not allow_negative:
                raise Exception(f'Balance user {source_user.id} is insufficient')

        return True

    def move_money_with_currency_rate(
            self,
            source_user_id: int,
            target_user_id: int,
            amount: float,
            transfer_type: int,
            is_outcome: bool,
            note: str = '',
            is_commit: bool = True,
            allow_negative: bool = False,
            check_balances: bool = True
    ):
        source_user_amount = round(Decimal(str(amount)), 2)
        target_user_amount = round(Decimal(str(amount)), 2)
        source_user = target_user = None

        if source_user_id > 0:
            source_user = self.db.query(UserModel).filter(UserModel.id == source_user_id) \
                .with_for_update(of=UserModel).first()

        if target_user_id > 0:
            target_user = self.db.query(UserModel).filter(UserModel.id == target_user_id) \
                .with_for_update(of=UserModel).first()

        if (source_user and target_user) and source_user.currency != target_user.currency:
            source_user_amount = CurrencyRateModel.convert(
                self.db,
                amount=amount,
                currency=target_user.currency,
                new_currency=source_user.currency
            )

            note = note or (
                f'{"receive" if is_outcome else "write off"} '
                f'{round(source_user_amount, 2)} {source_user.currency} '
                f'from {source_user.id} ID'
            )

        if check_balances:
            self.check_for_allow_money_transfer(
                source_user=source_user,
                target_user=target_user,
                source_user_amount=source_user_amount,
                target_user_amount=target_user_amount,
                is_outcome=is_outcome,
                allow_negative=allow_negative
            )

        transfer = self._move_money_with_user_amount_values(
            source_user=source_user,
            target_user=target_user,
            source_user_amount=source_user_amount,
            target_user_amount=target_user_amount,
            amount=amount,
            transfer_type=transfer_type,
            is_outcome=is_outcome,
            note=note,
            is_commit=is_commit
        )

        return transfer

    def _move_money_with_user_amount_values(
            self,
            source_user: UserModel,
            target_user: UserModel,
            source_user_amount: Union[float, Decimal],
            target_user_amount: Union[float, Decimal],
            amount: float,
            transfer_type: int,
            is_outcome: bool,
            note: str = '',
            is_commit: bool = True
    ):
        U = UserModel
        source_user_amount = round(Decimal(str(source_user_amount)), 2)
        target_user_amount = round(Decimal(str(target_user_amount)), 2)
        balance_source_user_after = balance_target_user_after = 0
        balance_source_user_before = balance_target_user_before = "0"

        transfer = MoneyTransferModel(
            value=amount,
            type=transfer_type,
            note=note
        )

        transfer = self._prepare_transfer_source_to_target_account(
            transfer=transfer,
            source_user_id=source_user.id,
            target_user_id=target_user.id,
            is_outcome=is_outcome
        )

        if source_user:
            self.db.refresh(source_user)
            balance_source_user_before = round(Decimal(str(source_user.balance)), 2)
            balance_source_user_after = balance_source_user_before + Decimal(str(source_user_amount)) \
                if is_outcome else balance_source_user_before - Decimal(str(source_user_amount))

            self.db.query(U).filter(U.id == source_user.id).update(
                {U.balance: balance_source_user_after},
                synchronize_session='fetch')
            CacheManager.set_user_data_to_cache(source_user)

        if target_user:
            self.db.refresh(target_user)
            balance_target_user_before = round(Decimal(str(target_user.balance)), 2)
            balance_target_user_after = balance_target_user_before - Decimal(str(target_user_amount)) \
                if is_outcome else balance_target_user_before + Decimal(str(target_user_amount))

            self.db.query(U).filter(U.id == target_user.id).update(
                {U.balance: balance_target_user_after},
                synchronize_session='fetch')
            CacheManager.set_user_data_to_cache(target_user)

        transfer.note = note

        if is_outcome:
            transfer.additional_data = {
                'balance_before_from_user': str(balance_target_user_before),
                'balance_before_to_user': str(balance_source_user_before),
                'balance_after_from_user': str(balance_target_user_after),
                'balance_after_to_user': str(balance_source_user_after),
            }

        else:
            transfer.additional_data = {
                'balance_before_from_user': str(balance_source_user_before),
                'balance_before_to_user': str(balance_target_user_before),
                'balance_after_from_user': str(balance_source_user_after),
                'balance_after_to_user': str(balance_target_user_after),
            }

        self.db.add(transfer)

        if is_commit:
            self.db.commit()

        return transfer

    def move_money_LIMITED_OWNER_TO_USER(self, limited_owner: UserModel, user: UserModel,
                                         amount: float, note: str, is_outcome):
        transfer = self.move_money_with_currency_rate(
            source_user_id=limited_owner.id,
            target_user_id=user.id,
            amount=amount,
            note=note,
            transfer_type=TransferTypes.TYPE_USER_TO_LIMITED_OWNER
            if is_outcome else TransferTypes.TYPE_LIMITED_OWNER_TO_USER,
            is_outcome=is_outcome,
            check_balances=True
        )
        return transfer

    def get_bonus_cashback_for_today(self, user_id: int) -> Union[Decimal, float]:
        now_date = datetime.datetime.now()
        # UTC date but for Tunisia 00:00
        start_of_day = datetime.datetime(
            year=now_date.year, month=now_date.month,
            day=now_date.day - 1, hour=23, minute=00
        )
        bonus_cashback_for_today = self.db.query(func.sum(BonusTransferModel.value)).filter(
            BonusTransferModel.to_user_id == user_id,
            BonusTransferModel.type == BONUS_TRANSFER_TYPES.TYPE_CASHBACK_PAYMENTS,
            BonusTransferModel.created_at.between(start_of_day, now_date)
        ).scalar() or 0
        return Decimal(str(bonus_cashback_for_today))

    def move_bonus_deposit_cashback(self, transfer: MoneyTransferModel):
        bonus_percent = options.DEPOSIT_BONUS_PERCENT
        max_bonus_cashback_by_day = Decimal(str(options.MAX_BONUS_CASHBACK_BY_DAY.
                                                get(transfer.currency, options.DEFAULT_MAX_BONUS_CASHBACK_BY_DAY)))
        cashback_amount = Decimal(str(transfer.value)) * Decimal(str(bonus_percent))
        bonus_amount_for_current_day = self.get_bonus_cashback_for_today(transfer.to_user_id)

        if bonus_amount_for_current_day >= max_bonus_cashback_by_day:
            return
        elif cashback_amount + bonus_amount_for_current_day >= max_bonus_cashback_by_day:
            cashback_amount = max_bonus_cashback_by_day - bonus_amount_for_current_day

        self.move_bonus_money(
            UserModel.ORGANIZATION_ID, transfer.to_user_id,
            cashback_amount, BONUS_TRANSFER_TYPES.TYPE_CASHBACK_PAYMENTS,
            note=f"Deposit cashback by tr_id: {transfer.id}"
        )

    def check_for_availability_real_money(
            self,
            user_id: int,
            amount: float,
            with_lock: bool = True
    ):
        user: UserModel = UserModel.get_by_id_with_lock(db=self.db, user_id=user_id) if with_lock else\
                          UserModel.get_by_id(db=self.db, user_id=user_id)
        if not user:
            raise InvalidRequestData(
                error_codes.USER_DOES_NOT_EXIST,
                f'User with ID {user_id} not found'
            )

        if round(user.balance, 2) < round(amount, 2):
            raise InvalidRequestData(
                error_codes.INSUFFICIENT_BALANCE,
                'Balance is insufficient'
            )

        return

    @staticmethod
    def get_structure_transfer_types(
            is_withdrawal_transfers: bool = False,
            is_deposit_transfers: bool = False,
            role: str = None,
            is_bonus_deposits: bool = False
    ):
        transfer_types = []
        if is_withdrawal_transfers:
            if role == UserModel.PARTNER_AGENT:
                transfer_types += TransferTypes.AGENT_WITHDRAWAL_TYPES
            elif role == UserModel.USER:
                transfer_types += TransferTypes.USER_WITHDRAWAL_TYPES
            else:
                transfer_types += TransferTypes.WITHDRAWAL_TYPES

        if is_deposit_transfers:
            if role == UserModel.PARTNER_AGENT:
                transfer_types += TransferTypes.AGENT_DEPOSIT_TYPES
            elif role == UserModel.USER:
                transfer_types += TransferTypes.USER_DEPOSIT_TYPES
            else:
                transfer_types += TransferTypes.PAYMENT_TYPES

        if is_bonus_deposits:
            transfer_types += [TransferTypes.TYPE_BONUS_AGENT_TO_USER]

        return transfer_types

    def get_structure_transfers_by_source_user(
            self,
            db,
            source_user: UserModel,
            date_from: datetime,
            date_to: datetime,
            target_role: str = None,
            username: str = None,
            is_direct_structure: bool = False,
            is_higher_transaction_only: bool = False,
            is_withdrawal_transfers: bool = True,
            is_deposit_transfers: bool = True,
            with_username: bool = False,
            with_real_username: bool = False,
            skip: str = 0,
            limit: str = 20,
            is_bonus_deposits: bool = False
    ):
        users_subq = UserModel.get_list_users_by_entity_user_subq(
            db=db,
            entity_user=source_user,
            target_role=target_role,
            username=username,
            is_direct_structure=is_direct_structure,
        )

        user_ids = list(chain(*db.query(users_subq.c.id).all()))
        transfer_types = self.get_structure_transfer_types(
            is_withdrawal_transfers=is_withdrawal_transfers,
            is_deposit_transfers=is_deposit_transfers,
            is_bonus_deposits=is_bonus_deposits,
            role=target_role
        )

        if transfer_types and user_ids:
            transfers, total_count = MoneyTransferModel.get_structure_transfers_by_user_ids(
                db=db,
                user_ids=user_ids,
                date_from=date_from,
                date_to=date_to,
                transfer_types=transfer_types,
                is_higher_transaction_only=is_higher_transaction_only,
                with_username=with_username,
                with_real_username=with_real_username,
                skip=skip,
                limit=limit,
                decreasing_by_id=True
            )
        else:
            transfers, total_count = [], 0

        return transfers, total_count

    def get_revenue_topups_sum(self, start_date: datetime.date, end_date: datetime.date) -> Tuple[int, int]:
        transfers_by_date = self.db.query(func.sum(MoneyTransferModel.value)).filter(and_(
            MoneyTransferModel.created_at.between(start_date, end_date)
        ))
        transfers_topup = transfers_by_date.filter(
            MoneyTransferModel.type == TransferTypes.TYPE_REVENUE_TOP_UP).scalar() or 0
        transfers_write_off = transfers_by_date.filter(
            MoneyTransferModel.type == TransferTypes.TYPE_REVENUE_WRITE_OFF).scalar() or 0

        balance_from_previous_month = self.get_balance_from_previous_month(start_date, end_date)

        return transfers_topup - transfers_write_off + balance_from_previous_month, \
            balance_from_previous_month

    def get_revenue_number_of_deposits(self, start_date: datetime.date, end_date: datetime.date):
        transfers_count_by_date = self.db.query(func.count()).filter(and_(
            MoneyTransferModel.created_at.between(start_date, end_date)
        ))
        transfers_count = transfers_count_by_date.filter(
            MoneyTransferModel.type.in_(
                [TransferTypes.TYPE_REVENUE_TOP_UP, TransferTypes.TYPE_REVENUE_WRITE_OFF])).scalar() or 0

        return transfers_count

    def get_balance_from_previous_month(self, start_date: datetime.date, end_date: datetime.date):
        query = self.db.query(MoneyTransferModel.value,
                              MoneyTransferModel.type). \
            filter(and_(MoneyTransferModel.created_at.between(start_date, end_date),
                        MoneyTransferModel.type.in_([TransferTypes.TYPE_REVENUE_INCREMENT,
                                                     TransferTypes.TYPE_REVENUE_DECREMENT]))).first()

        if not query:
            return 0

        if query.type == TransferTypes.TYPE_REVENUE_DECREMENT:
            return -query.value

        return query.value

    def get_currency_rate_or_converted_amount(
          self,
          from_currency: str,
          to_currency: str,
          without_convert: bool = True,
          allow_negative: bool = False,
          amount=None
    ):
        if without_convert:
            return CurrencyRateModel.get_currency_rate(
                db=self.db,
                currency=from_currency,
                new_currency=to_currency
            ).rate
        else:
            return round(Decimal(str(CurrencyRateModel.convert(
                self.db,
                amount=amount,
                currency=from_currency,
                new_currency=to_currency,
                allow_negative=allow_negative)
            )), 2)

    def get_converted_royalty_amount(self,
                                     amount,
                                     from_currency: str,
                                     to_currency: str,
                                     allow_negative: bool = False,
                                     currency_selected: bool = False):
        exclusion_list = options.ROYALTY_CURRENCY_CONVERSION_SEQUENCE

        if currency_selected or from_currency not in exclusion_list:
            return round(Decimal(str(CurrencyRateModel.convert(
                self.db,
                amount=amount,
                currency=from_currency,
                new_currency=to_currency,
                allow_negative=allow_negative)
            )), 2)
        else:
            for currency in exclusion_list[from_currency]:
                if (from_currency in exclusion_list
                        and exclusion_list[from_currency][currency] == "real"):
                    currency_rate = CurrencyRateFetcher.get_currency_rate(
                        from_currency=from_currency,
                        to_currency=currency
                    )
                    amount = round(Decimal(str(float(amount) * currency_rate)), 2)
                else:
                    amount = round(Decimal(str(CurrencyRateModel.convert(
                        self.db,
                        amount=amount,
                        currency=from_currency,
                        new_currency=currency,
                        allow_negative=allow_negative)
                    )), 2)
                from_currency = currency

            return amount

    def get_currency_rate_for_royalty(self,
                                      from_currency: str,
                                      to_currency: str):
        if from_currency in options.CURRENCIES_CONVERSION_WITHOUT_GOOGLE:
            return CurrencyRateModel.get_currency_rate(
                self.db, from_currency, to_currency
            ).rate
        else:
            return CurrencyRateFetcher.get_currency_rate(
                from_currency=from_currency,
                to_currency=to_currency
            )

    def calculate_revenue_share_usd(
        self,
        from_currency: str,
        amount: int
    ) -> float:
        real_rate = self.get_currency_rate_for_royalty(from_currency, "USD")
        value = (
            round(amount * Decimal(real_rate) * options.REVENUE_MARGIN, 2)
        )
        return value

    def process_deposit_bonus(self, transfer: MoneyTransferModel, bonus_amount: float = None, percent_amount: float = None):

        is_percent_bonus_deposit = False

        if percent_amount:
            bonus_amount = transfer.value * percent_amount * 0.01
            is_percent_bonus_deposit = True

        additional_data = {
            "is_percent_bonus_deposit": is_percent_bonus_deposit,
            "percent_amount": percent_amount
        }

        self.user_move_money(
            from_user_id=transfer.from_user_id,
            to_user_id=transfer.to_user_id,
            real_from_user_id=transfer.real_from_user_id,
            real_to_user_id=transfer.real_to_user_id,
            transfer_type=TransferTypes.TYPE_BONUS_AGENT_TO_USER,
            value=bonus_amount,
            note=f"Deposit bonus from transfer: {transfer.id}",
            additional_data=additional_data
        )

    def get_transfer_total_by_date_and_type_by_user_id(
            self,
            date_from: datetime.datetime,
            date_to: datetime.datetime,
            user_id: int,
            outcome_transfer_types: List[int] = [],
            income_transfer_types: List[int] = []
    ):
        income_transfers_query = (
            self.db.query(
                literal("0").label("total_income"),
                func.coalesce(func.sum(MoneyTransferModel.value), 0).label('total_outcome')
            ).filter(
                MoneyTransferModel.type.in_(income_transfer_types),
                MoneyTransferModel.created_at.between(date_from, date_to),
                UserModel.id == user_id
            ).join(
                UserModel,
                UserModel.id == MoneyTransferModel.to_user_id,
                isouter=True
            )
        )

        outcome_transfers_query = (
            self.db.query(
                func.coalesce(func.sum(MoneyTransferModel.value), 0).label('total_income'),
                literal("0").label("total_outcome")
            ).filter(
                MoneyTransferModel.type.in_(outcome_transfer_types),
                MoneyTransferModel.created_at.between(date_from, date_to),
                UserModel.id == user_id
            ).join(
                UserModel,
                UserModel.id == MoneyTransferModel.from_user_id,
                isouter=True
            )
        )

        union_subq = union_all(income_transfers_query, outcome_transfers_query).subquery()

        query = (
            self.db.query(
                func.sum(union_subq.c.total_income).label('total_income'),
                func.sum(union_subq.c.total_outcome).label('total_outcome')
            )
        )

        return self.db.execute(query).first()

    def get_transfer_total_by_date_and_type_by_structure_path(
            self,
            date_from: datetime.datetime,
            date_to: datetime.datetime,
            structure_path: Ltree,
            outcome_transfer_types: List[int] = [],
            income_transfer_types: List[int] = [],
            is_direct_only: bool = False
    ):
        income_transfers_query = (
            self.db.query(
                literal("0").label("total_outcome"),
                func.coalesce(func.sum(MoneyTransferModel.value), 0).label('total_income'))
            .join(
                    UserModel,
                    UserModel.id == MoneyTransferModel.to_user_id,
                    isouter=True
                )
            ).filter(
                MoneyTransferModel.type.in_(income_transfer_types),
                MoneyTransferModel.created_at.between(date_from, date_to),)

        if is_direct_only:
            income_transfers_query = income_transfers_query.filter(
                UserModel.parent_agent_id == str(structure_path).split('.')[-1],
            )
        else:
            income_transfers_query = income_transfers_query.filter(
                UserModel.structure_path.descendant_of(structure_path),
                UserModel.structure_path != structure_path)

        outcome_transfers_query = (
            self.db.query(
                func.coalesce(func.sum(MoneyTransferModel.value), 0).label('total_outcome'),
                literal("0").label("total_income")
            ).filter(
                MoneyTransferModel.type.in_(outcome_transfer_types),
                MoneyTransferModel.created_at.between(date_from, date_to),
                UserModel.structure_path.descendant_of(structure_path),
                UserModel.structure_path != structure_path
            ).join(
                UserModel,
                UserModel.id == MoneyTransferModel.from_user_id,
                isouter=True
            )
        )

        union_subq = union_all(income_transfers_query, outcome_transfers_query).subquery()

        query = (
            self.db.query(
                func.sum(union_subq.c.total_income).label('total_income'),
                func.sum(union_subq.c.total_outcome).label('total_outcome')
            )
        )

        return self.db.execute(query).first()

    def get_bet(self, bet_id: int)-> MoneyTransferModel:
        query = self.db.query(MoneyTransferModel).filter(MoneyTransferModel.id == bet_id).first()
        return query
