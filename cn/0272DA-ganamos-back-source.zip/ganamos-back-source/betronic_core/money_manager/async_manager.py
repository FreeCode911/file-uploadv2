from decimal import Decimal, ROUND_HALF_UP
from logging import getLogger
from time import monotonic
from typing import List, Union, Tuple, Optional

from pydantic import create_model
from sqlalchemy.ext.asyncio.session import AsyncSession
from sqlalchemy.orm.attributes import flag_modified
from tornado.options import options

from betronic_core.cache_manager.manager import AsyncCacheManager
from betronic_core.constants import TransferTypes
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from util.validators import as_decimal
from util.validators import round_value

logger = getLogger(__name__)


class AsyncMoneyManager:
    accuracy = Decimal("1.00")

    @staticmethod
    def get_user_from_list(items: List[create_model], user_id: int) -> create_model:
        for item in items:
            if item.id == user_id:
                return item

    @staticmethod
    async def _get_user_move_money_win_limit(
            user_amount: Union[float, Decimal],
            transfer_type: int,
            payment_settings: dict = None
    ) -> Tuple[Union[float, Decimal], Union[float, Decimal, None]]:
        if options.USER_MAX_WIN_STATE is False:
            return user_amount, None

        if transfer_type not in TransferTypes.WIN_TYPES_FOR_MAX_AMOUNT:
            return user_amount, None

        system_max = as_decimal(payment_settings.get('max_win_amount', options.DEFAULT_SYSTEM_MAX_WINNING_AMOUNT))
        organization_amount = as_decimal(user_amount) - as_decimal(system_max)
        if organization_amount <= 0:
            return user_amount, None

        user_amount = system_max

        return user_amount, organization_amount

    @classmethod
    async def user_move_money(
            cls,
            from_user_id: int,
            to_user_id: int,
            value: float,
            transfer_type: int = TransferTypes.TYPE_REFILL,
            note: str = None,
            transaction_id: str = None,
            additional_data: dict = None,
            real_from_user_id: int = None,
            real_to_user_id: int = None,
            connection: AsyncSession = None,
            to_user: create_model = None,
            from_user: create_model = None,
            description: str = None,
            currency: str = None
    ) -> MoneyTransferModel:
        payment_settings = await AsyncCacheManager.get_payment_settings(currency=currency)

        user_amount, win_limit_amount = (
            await cls._get_user_move_money_win_limit(
                user_amount=value,
                transfer_type=transfer_type,
                payment_settings=payment_settings
            )
        )

        transfer, balance_limit_amount = await cls._user_move_money(
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            value=user_amount,
            transfer_type=transfer_type,
            note=note,
            transaction_id=transaction_id,
            additional_data=additional_data,
            real_from_user_id=real_from_user_id,
            real_to_user_id=real_to_user_id,
            connection=connection,
            to_user=to_user,
            from_user=from_user,
            description=description,
            currency=currency,
            payment_settings=payment_settings
        )

        if balance_limit_amount or win_limit_amount:
            await cls._transfer_overflow_amount_to_organisation(
                full_value=value,
                original_transfer=transfer,
                win_limit_amount=win_limit_amount,
                balance_limit_amount=balance_limit_amount,
                payment_settings=payment_settings
            )

        return transfer

    @classmethod
    async def _transfer_overflow_amount_to_organisation(
            cls,
            full_value: Union[Decimal, float],
            original_transfer: MoneyTransferModel,
            win_limit_amount: Union[Decimal, float] = None,
            balance_limit_amount: Union[Decimal, float] = None,
            connection: AsyncSession = None,
            payment_settings: dict = None
    ):
        original_transfer_type = original_transfer.type
        original_note = original_transfer.note
        user_value = original_transfer.value
        original_transfer_id = original_transfer.id

        user_id = original_transfer.to_user_id
        currency = original_transfer.currency

        if win_limit_amount:
            overflow_win_transfer, _ = await cls._user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=win_limit_amount,
                additional_data={
                    'transfer_id': original_transfer.id,
                    'transfer_user_id': original_transfer.to_user_id,
                    'transfer_value': str(Decimal(original_transfer.value).quantize(cls.accuracy, ROUND_HALF_UP)),
                    'real_value': str(Decimal(full_value).quantize(cls.accuracy, ROUND_HALF_UP))
                },
                transfer_type=original_transfer_type,
                note=f"Win overflow",
                currency=currency,
                connection=connection,
                payment_settings=payment_settings
            )
            logger.info(
                f"Win overflow limit for user {user_id}:"
                f"full value: {full_value}, "
                f"user value: {user_value}, "
                f"original transfer_id: {original_transfer_id}, "
                f"original tranfer_type: {original_transfer_type}, "
                f"original note: {original_note}"
            )

        if balance_limit_amount:
            balance_limit_transfer, _ = await cls._user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=balance_limit_amount,
                additional_data={
                    'transfer_id': original_transfer.id,
                    'transfer_user_id': original_transfer.to_user_id,
                    'transfer_value': str(Decimal(original_transfer.value).quantize(cls.accuracy, ROUND_HALF_UP)),
                    'real_value': str(Decimal(full_value).quantize(cls.accuracy, ROUND_HALF_UP))
                },
                transfer_type=original_transfer_type,
                note=f'Balance overflow from transfer',
                currency=currency,
                connection=connection,
                payment_settings=payment_settings
            )
            logger.info(
                f"Balance overflow limit for user {user_id}:"
                f"full value: {full_value}, "
                f"user value: {user_value}, "
                f"original note: {original_note}, "
                f"original transfer_type: {original_transfer_type}, "
                f"original transfer_id: {original_transfer_id}"
            )

    @classmethod
    async def _user_move_money(
            cls,
            from_user_id: int,
            to_user_id: int,
            value: float,
            transfer_type: int = TransferTypes.TYPE_REFILL,
            note: str = None,
            transaction_id: str = None,
            additional_data: dict = None,
            real_from_user_id: int = None,
            real_to_user_id: int = None,
            connection: AsyncSession = None,
            to_user: create_model = None,
            from_user: create_model = None,
            description: str = None,
            currency: str = None,
            payment_settings: dict = None
    ) -> Tuple[MoneyTransferModel, Union[Decimal, int, float]]:
        """
        don't forget transaction() on the level above
        use "connection", "to_user", "from_user" for transaction
        """
        real_from_user_id = real_from_user_id or from_user_id
        real_to_user_id = real_to_user_id or to_user_id
        transfer = MoneyTransferModel(
            type=transfer_type,
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            real_from_user_id=real_from_user_id,
            real_to_user_id=real_to_user_id,
            value=value,
            note=note,
            transaction_id=transaction_id,
            additional_data=additional_data,
            description=description
        )

        real_value = 0
        balance_from_user_after = balance_to_user_after = 0
        balance_from_user_before = balance_to_user_before = "0"
        amount_to_organization = 0

        fetch_user_time = 0
        cache_user_time = 0
        update_balance_time = 0

        if from_user_id > 0 and to_user_id > 0 and not from_user and not to_user:
            users = await UserModel.async_get_users_general_data(
                user_ids=[from_user_id, to_user_id],
                with_lock=True,
                connection=connection
            )
            from_user = cls.get_user_from_list(users, from_user_id)
            to_user = cls.get_user_from_list(users, to_user_id)

        else:
            user_get_time = monotonic()
            if from_user_id > 0:
                if not from_user:
                    from_user = await UserModel.async_get_general_data(
                        user_id=from_user_id,
                        with_lock=True,
                        connection=connection
                    )
                transfer.currency = from_user.currency

            if to_user_id > 0 and not to_user:
                to_user = await UserModel.async_get_general_data(
                    user_id=to_user_id,
                    with_lock=True,
                    connection=connection
                )
            fetch_user_time = monotonic() - user_get_time

        if to_user:
            await connection.refresh(to_user)
            transfer.currency = to_user.currency
            balance_to_user_before = str(to_user.balance)
            balance_to_user_after = as_decimal(balance_to_user_before) + as_decimal(value)

            max_balance_amount = as_decimal(
                payment_settings.get('max_balance_amount', options.DEFAULT_MAX_BALANCE_AMOUNT)
            )

            if to_user.role is UserModel.USER and balance_to_user_after > max_balance_amount:
                real_value = value
                new_value = as_decimal(max_balance_amount) - as_decimal(to_user.balance)
                transfer.value = new_value
                amount_to_organization = balance_to_user_after - max_balance_amount
                balance_to_user_after = Decimal(str(max_balance_amount))

            start_update_balance_time = monotonic()
            await UserModel.async_update_balance(
                user_id=to_user.id,
                balance=balance_to_user_after,
                connection=connection
            )
            update_balance_time = monotonic() - start_update_balance_time

            start_user_cache_time = monotonic()
            await AsyncCacheManager.set_user_data_to_cache(to_user)
            cache_user_time = monotonic() - start_user_cache_time

        if from_user:
            await connection.refresh(from_user)
            balance_from_user_before = str(from_user.balance)
            balance_from_user_after = Decimal(str(from_user.balance)) - Decimal(str(value))

            start_update_balance_time = monotonic()
            await UserModel.async_update_balance(user_id=from_user.id, balance=balance_from_user_after,
                                                 connection=connection)
            update_balance_time = monotonic() - start_update_balance_time

            start_user_cache_time = monotonic()
            await AsyncCacheManager.set_user_data_to_cache(from_user)
            cache_user_time = monotonic() - start_user_cache_time

        update_data = {
            'balance_before_from_user': balance_from_user_before,
            'balance_before_to_user': balance_to_user_before,
            'balance_after_from_user': str(balance_from_user_after),
            'balance_after_to_user': str(balance_to_user_after),
            'real_value': str(Decimal(real_value).quantize(cls.accuracy, ROUND_HALF_UP))
        }
        if transfer.additional_data is None:
            transfer.additional_data = update_data
        else:
            transfer.additional_data.update(update_data)

        if currency:
            transfer.currency = currency

        transfer = await MoneyTransferModel.async_create_transfer(
            transfer=transfer,
            connection=connection
        )
        logger.info(f"Fetch: {round_value(fetch_user_time, 6)} | "
                    f"Update: {round_value(update_balance_time, 6)} | "
                    f"Cache: {round_value(cache_user_time, 6)}")

        return transfer, amount_to_organization

    @classmethod
    async def move_marketing_money(
            cls,
            user_id,
            value,
            transfer_type,
            note: str = None,
            transaction_id: str = None,
            is_bonus: bool = False,
            is_outcome: bool = False,
            connection: AsyncSession = None,
    ) -> MoneyTransferModel:
        U = UserModel
        from_user_id = U.ORGANIZATION_ID
        to_user_id = user_id
        balance_marketing_owner_before = "0"
        balance_marketing_owner_after = "0"
        transfer_value = round(Decimal(str(value)), 2)

        marketing_owner = await UserModel.async_get_general_data(
            user_id=U.MARKETING_OWNER_ID,
            with_lock=True,
            connection=connection,
        )

        if marketing_owner:
            from_user_id = U.MARKETING_OWNER_ID

            await connection.refresh(marketing_owner)
            balance_marketing_owner_before = round(as_decimal(marketing_owner.balance), 2)
            user = await UserModel.async_get_general_data(
                user_id=user_id,
                with_lock=True,
                connection=connection,
            )

            if is_bonus:
                user_balance_before = round(as_decimal(user.bonus_balance), 2)
                max_bonus_balance = options.MAX_BONUS_BALANCE_AMOUNT_BY_CURRENCY.get(user.currency, 0.0)
                if not is_outcome and (user_balance_before + transfer_value) > max_bonus_balance:
                    transfer_value = round(Decimal(max_bonus_balance), 2) - user_balance_before
            else:
                user_balance_before = round(Decimal(str(user.balance)), 2)

            if is_outcome:
                if user_balance_before < transfer_value:
                    transfer_value = user_balance_before
                balance_marketing_owner_after = as_decimal(balance_marketing_owner_before) + as_decimal(transfer_value)
            else:
                if balance_marketing_owner_before < transfer_value:
                    note = note + f" Marketing account is empty. The sum was {transfer_value}"
                    transfer_value = balance_marketing_owner_before
                balance_marketing_owner_after = as_decimal(balance_marketing_owner_before) - as_decimal(transfer_value)

            await UserModel.async_update_balance(
                user_id=marketing_owner.id,
                balance=balance_marketing_owner_after,
                connection=connection
            )

        additional_data = {
            'original_value': str(transfer_value),
            'real_value': str(value)
        }

        if is_outcome:
            from_user_id, to_user_id = to_user_id, from_user_id
            additional_data.update({
                'balance_before_to_user': str(balance_marketing_owner_before),
                'balance_after_to_user': str(balance_marketing_owner_after)
            })
        else:
            additional_data.update({
                'balance_before_from_user': str(balance_marketing_owner_before),
                'balance_after_from_user': str(balance_marketing_owner_after)
            })

        if is_bonus:
            transfer = await cls.user_move_bonus_money(
                from_user_id=from_user_id,
                to_user_id=to_user_id,
                value=transfer_value,
                transfer_type=transfer_type,
                note=note,
                transaction_id=transaction_id,
                connection=connection
            )
        else:
            transfer = await cls.user_move_money(
                from_user_id=from_user_id,
                to_user_id=to_user_id,
                value=transfer_value,
                transfer_type=transfer_type,
                note=note,
                transaction_id=transaction_id,
                connection=connection
            )

        transfer.additional_data.update(additional_data)
        flag_modified(transfer, 'additional_data')
        connection.add(transfer)

        return transfer

    @classmethod
    async def user_move_bonus_money(
            cls,
            from_user_id: int,
            to_user_id: int,
            value: float,
            transfer_type: int,
            note: str = None,
            connection: AsyncSession = None,
            to_user: create_model = None,
            from_user: create_model = None,
            transaction_id: str = None
    ) -> BonusTransferModel:
        """
        don't forget transaction() on the level above
        use "connection", "to_user", "from_user" for transaction
        """
        transfer = BonusTransferModel(
            tr_type=transfer_type,
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            value=value,
            note=note,
            transaction_id=transaction_id
        )

        if from_user_id > 0 and to_user_id > 0 and not from_user and not to_user:
            users = await UserModel.async_get_users_general_data(
                user_ids=[from_user_id, to_user_id],
                with_lock=True,
                connection=connection
            )
            from_user = cls.get_user_from_list(users, from_user_id)
            to_user = cls.get_user_from_list(users, to_user_id)

        else:
            if from_user_id > 0:
                if not from_user:
                    from_user = await UserModel.async_get_general_data(
                        user_id=from_user_id,
                        with_lock=True,
                        connection=connection
                    )
                transfer.currency = from_user.currency

            if to_user_id > 0 and not to_user:
                to_user = await UserModel.async_get_general_data(
                    user_id=to_user_id,
                    with_lock=True,
                    connection=connection
                )

        if to_user:
            transfer.currency = to_user.currency
            balance_to_user_after = Decimal(str(to_user.bonus_balance)) + Decimal(str(value))
            await UserModel.async_update_bonus_balance(
                user_id=to_user.id,
                balance=balance_to_user_after,
                connection=connection
            )
            await AsyncCacheManager.set_user_data_to_cache(to_user)

        if from_user:
            balance_from_user_after = Decimal(str(from_user.bonus_balance)) - Decimal(str(value))
            await UserModel.async_update_bonus_balance(
                user_id=from_user.id,
                balance=balance_from_user_after,
                connection=connection
            )
            await AsyncCacheManager.set_user_data_to_cache(from_user)

        bonus_transfer = await BonusTransferModel.async_create_transfer(
            transfer=transfer,
            connection=connection
        )

        return bonus_transfer

    @classmethod
    async def debit_total_money(
            cls, user: UserModel, amount: float,
            transfer_type: int = TransferTypes.TYPE_REFILL,
            note: str = None, transaction_id: str = None, additional_data: dict = None,
            description: str = None, connection: AsyncSession = None
    ) -> Tuple[Optional[MoneyTransferModel], Optional[BonusTransferModel]]:
        real_transfer, bonus_transfer = None, None
        if round(Decimal(str(amount)), 2) > round(Decimal(str(user.balance)), 2):
            bonus_amount = amount - user.balance
            real_amount = user.balance
            if real_amount:
                real_transfer = await cls.user_move_money(
                    from_user_id=user.id, to_user_id=UserModel.ORGANIZATION_ID,
                    value=real_amount, transfer_type=transfer_type,
                    additional_data=additional_data,
                    note=note, transaction_id=transaction_id, description=description,
                    connection=connection
                )
                await cls.check_real_balance_and_lock_bonus(real_transfer)

            bonus_transfer = await cls.user_move_bonus_money(
                from_user_id=user.id, to_user_id=UserModel.ORGANIZATION_ID,
                value=bonus_amount, transfer_type=transfer_type,
                note=note, transaction_id=transaction_id,
                connection=connection
            )

        elif round(Decimal(str(amount)), 2) <= round(Decimal(str(user.balance)), 2):
            real_amount = amount
            real_transfer = await cls.user_move_money(
                from_user_id=user.id, to_user_id=UserModel.ORGANIZATION_ID,
                value=real_amount, transfer_type=transfer_type,
                additional_data=additional_data, note=note,
                transaction_id=transaction_id, description=description,
                connection=connection
            )
            await cls.check_real_balance_and_lock_bonus(real_transfer)

        return real_transfer, bonus_transfer

    @classmethod
    async def credit_total_money(
            cls, user: UserModel, amount: float,
            transfer_type: int = TransferTypes.TYPE_REFILL,
            note: str = None, transaction_id: str = None, additional_data: dict = None,
            description: str = None, real_transaction_id: str = None,
            connection: AsyncSession = None
    ) -> Tuple[Optional[MoneyTransferModel], Optional[BonusTransferModel]]:
        bonus_transfer = await BonusTransferModel.async_get_by_transaction_id_and_user_id(
            connection=connection,
            transaction_id=transaction_id,
            user_id=user.id)
        if bonus_transfer:
            bonus_place_amount = bonus_transfer.value
            if amount > bonus_place_amount:
                amount = amount - bonus_place_amount
                bonus_win_amount = bonus_transfer.value

                real_transfer = await cls.user_move_money(
                    from_user_id=UserModel.ORGANIZATION_ID,
                    to_user_id=user.id,
                    value=amount,
                    transfer_type=transfer_type,
                    note=note,
                    transaction_id=real_transaction_id if real_transaction_id else transaction_id,
                    description=description,
                    connection=connection
                )
                bonus_transfer = await cls.user_move_bonus_money(
                    from_user_id=UserModel.ORGANIZATION_ID,
                    to_user_id=user.id,
                    value=bonus_win_amount,
                    transfer_type=transfer_type,
                    note=note,
                    transaction_id=transaction_id,
                    connection=connection
                )
                return real_transfer, bonus_transfer

            else:
                bonus_transfer = await cls.user_move_bonus_money(
                    from_user_id=UserModel.ORGANIZATION_ID,
                    to_user_id=user.id,
                    value=amount,
                    transfer_type=transfer_type,
                    note=note,
                    transaction_id=transaction_id,
                    connection=connection
                )

                return None, bonus_transfer
        else:
            transfer = await cls.user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=user.id,
                value=amount,
                transfer_type=transfer_type,
                note=note,
                transaction_id=real_transaction_id if real_transaction_id else transaction_id,
                description=description,
                connection=connection
            )

            return transfer, None

    @staticmethod
    async def check_real_balance_and_lock_bonus(transfer: MoneyTransferModel):
        real_balance_after = transfer.additional_data["balance_after_from_user"]
        if float(real_balance_after) <= float(options.MINIMUM_POSSIBLE_REAL_BALANCE):
            await AsyncCacheManager.temporary_lock_bonus_balance(transfer.from_user_id)

    @classmethod
    async def update_transaction_id(
            cls,
            user_id: int,
            original_txn_id: str,
            new_txn_id: str,
            connection: AsyncSession = None
    ):
        await MoneyTransferModel.async_update_transaction_id(
            user_id=user_id,
            original_txn_id=original_txn_id,
            new_txn_id=new_txn_id,
            connection=connection
        )

    @classmethod
    async def extract_total_balance(cls, user: UserModel):
        minimum_possible_real_balance = options.\
            USER_MINIMUM_POSSIBLE_REAL_BALANCE.get(user.currency, 0.0)

        if user.balance > minimum_possible_real_balance:
            return user.balance
        else:
            bonus_balance = 0.0 if await AsyncCacheManager\
                .check_temporary_lock_of_bonus_balance(user.id) else user.bonus_balance

            return bonus_balance
