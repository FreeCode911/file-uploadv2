class PartnerMinWithdrawalDTO:

    __slots__ = ['amount', 'currency']

    def __init__(self, amount, currency):
        self.amount = amount
        self.currency = currency
