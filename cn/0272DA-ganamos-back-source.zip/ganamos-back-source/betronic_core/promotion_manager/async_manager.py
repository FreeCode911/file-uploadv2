from decimal import Decimal
from logging import getLogger
from typing import Union
from sqlalchemy.ext.asyncio.session import AsyncSession

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.async_manager import AsyncMoneyManager

logger = getLogger(__name__)


class AsyncLastDepositPromotionManager:
    @classmethod
    async def process_user_bonus_bet(
            cls,
            user: UserModel,
            amount: Union[Decimal, int, float],
            transfer_type: int,
            transaction_id: str,
            note: str,
            connection: AsyncSession = None
    ) -> BonusTransferModel:
        bonus_transfer: BonusTransferModel = await AsyncMoneyManager\
            .user_move_bonus_money(
                from_user_id=user.id,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=amount,
                transfer_type=transfer_type,
                transaction_id=transaction_id,
                note=note,
                connection=connection
            )

        return bonus_transfer

    @classmethod
    async def process_user_bonus_win(
            cls,
            user: UserModel,
            amount: Union[Decimal, int, float],
            transfer_type: int,
            transaction_id: str,
            note: str,
            connection: AsyncSession = None
    ) -> MoneyTransferModel:
        """
        Process win with rules

        TotalWin = WinAmount - BetAmount
        If TotalWin less than 0, then TotalWin is 0

        Transfer bet search by note
        """
        bonus_transfer_bet: BonusTransferModel = \
            await BonusTransferModel.async_get_bet_by_note(
                connection=connection,
                note=note
            )

        if not bonus_transfer_bet:
            transfer: MoneyTransferModel = await AsyncMoneyManager.user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=user.id,
                value=amount,
                transfer_type=transfer_type,
                note=note,
                transaction_id=transaction_id,
                connection=connection
            )

            return transfer

        bonus_amount_win = round(Decimal(str(amount)), 2)
        bonus_amount_bet = round(Decimal(str(bonus_transfer_bet.value)), 2)

        if bonus_amount_win <= bonus_amount_bet:
            bonus_amount_win = 0
            bonus_to_organization = bonus_amount_bet
        else:
            bonus_amount_win = bonus_amount_win - bonus_amount_bet
            bonus_to_organization = bonus_amount_bet - bonus_amount_win

        if bonus_to_organization:
            await AsyncMoneyManager.user_move_money(
                from_user_id=UserModel.ORGANIZATION_ID,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=bonus_to_organization,
                currency=user.currency,
                transfer_type=transfer_type,
                note=f"{note}. Overflow bonus to organization",
                transaction_id=transaction_id,
                connection=connection
            )

        transfer: MoneyTransferModel = await AsyncMoneyManager.user_move_money(
            from_user_id=UserModel.ORGANIZATION_ID,
            to_user_id=user.id,
            value=bonus_amount_win,
            transfer_type=transfer_type,
            note=note,
            transaction_id=transaction_id,
            connection=connection
        )

        return transfer

