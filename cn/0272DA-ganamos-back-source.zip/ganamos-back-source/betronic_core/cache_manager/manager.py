import ujson
import logging
from typing import List, Optional, Union
from uuid import uuid4
from datetime import datetime
from tornado.options import options

from betronic_core.db.models.user import UserModel
from betronic_core.db.models.notification import NotificationModel
from util.redis import (AsyncRedisWrapperForSecrets, AsyncRedisWrapperLocal,
                        RedisBaseTypes, SecretRedisBaseTypes,
                        SyncRedisWrapperLocal, SyncRedisWrapperSecrets)
from util.validators import validate_decode
from util.error import InvalidRequestData


logger = logging.getLogger(__name__)


class CacheManager:

    LOCKING_MIGRATION_SET_KEY = "set_for_locking_migration"

    @staticmethod
    def get_user_balance_key(user_id: Union[str, int]) -> str:
        return 'user-balance-%s' % user_id

    @classmethod
    def set_user_data_to_cache(cls, user: UserModel):
        data_for_cache = {
            "balance": float(user.balance),
            "bonus_balance": float(user.bonus_balance),
            "currency": user.currency,
            "is_banned": user.is_banned
        }
        if not user.is_banned:
            SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).set(
                cls.get_user_balance_key(user.id),
                ujson.dumps(data_for_cache)
            )
        return data_for_cache

    @staticmethod
    def get_notifications_key() -> str:
        return 'notifications'

    @classmethod
    def set_notification_to_cache(cls, notification: NotificationModel, is_update: bool = False):
        notification_key = cls.get_notifications_key()
        notification_id_str = str(notification.id)

        existing_notes = SyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).get(notification_key)
        existing_notifications = ujson.loads(existing_notes) if existing_notes else {}

        if existing_notifications and 'notifications' in existing_notifications:
            notifications = existing_notifications['notifications']
            if notification_id_str in notifications and not is_update:
                return  # No need to update if notification already exists and it's not an update

            if is_update:
                notifications[notification_id_str] = {
                    key: notification.notification[key] if key in notification.notification else value
                    for key, value in notifications[notification_id_str].items()
                }
            else:
                notifications[notification_id_str] = notification.notification
        else:
            notifications = {notification_id_str: notification.notification}

        data_for_cache = {'notifications': notifications}
        SyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).set(
            notification_key,
            ujson.dumps(data_for_cache)
        )

    @classmethod
    def remove_notification_from_cache(cls, notification_id):
        notification_key = cls.get_notifications_key()
        existing_notifications = SyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).get(notification_key)

        if existing_notifications:
            notifications = ujson.loads(existing_notifications)
            if str(notification_id) in notifications['notifications']:  # Check if notification exists before removing
                notifications['notifications'].pop(str(notification_id))
                SyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).set(
                    notification_key,
                    ujson.dumps(notifications)
                )

    @classmethod
    def set_slides_to_cache(cls, slide_list: list):
        SyncRedisWrapperLocal(
            db=options.REDIS_SLIDE_DB,
            connection_data=options.REDIS_REVOLUTION
        ).set_with_ttl(
            options.SLIDE_CACHING_KEY, ujson.dumps(slide_list), options.SLIDE_CACHING_TTL
        )

    @classmethod
    def reset_slide_cache(cls):
        SyncRedisWrapperLocal(RedisBaseTypes.SLIDES).reset(options.SLIDE_CACHING_KE)

    @classmethod
    def reset_cache_balance(cls, cache_key: str):
        SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).reset(cache_key)

    @classmethod
    def lock_balance_migration_for_user(cls, user_id: int):
        """
        Метод добавляет ID пользователя в множество для блокировки миграции баланса
        """
        redis_connection = SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get_instance()
        redis_connection.sadd(cls.LOCKING_MIGRATION_SET_KEY, user_id)

    @classmethod
    def unlock_balance_migration_for_user(cls, user_id: int):
        """
        Метод удаляет ID пользователя из множества для блокировки миграции баланса.
        """
        redis_connection = SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get_instance()
        redis_connection.srem(cls.LOCKING_MIGRATION_SET_KEY, user_id)

    @staticmethod
    def get_user_cookie_salt_key(user_id):
        return 'cookie_salt_%s' % user_id

    @classmethod
    def get_user_cookie_salt(cls, user_id) -> str:
        key = cls.get_user_cookie_salt_key(user_id)
        value = SyncRedisWrapperLocal(RedisBaseTypes.COOKIE_SALTS).get(key)
        return validate_decode(value)

    @classmethod
    def set_cookie_salt(cls, user_id: int):
        key = cls.get_user_cookie_salt_key(user_id)
        value = uuid4().hex[:16]
        SyncRedisWrapperLocal(RedisBaseTypes.COOKIE_SALTS).set(key, value)

    @classmethod
    def close_all_sessions_by_user_id(cls, user_id: int):
        cache_key = cls.get_user_balance_key(user_id)
        cls.reset_cache_balance(cache_key)
        cls.set_cookie_salt(user_id)

    @classmethod
    def close_all_sessions_by_user_ids(cls, user_ids: List[int]):
        for user_id in user_ids:
            cls.close_all_sessions_by_user_id(user_id=user_id)

    @classmethod
    def get_integration_status(cls, raise_exception=True) -> bool:
        if options.REVENUE_SYSTEM:
            redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
            settings = redis.get(options.REVENUE_STATUS_KEY)
            if settings:
                settings = ujson.loads(settings)
                if settings["emergency_shutdown"]:
                    status = False
                elif settings["bypass_operation"]:
                    status = True
                else:
                    status = settings["integration_status"]
            else:
                cls.set_revenue_status_settings()
                status = True

            if not status and raise_exception:
                raise InvalidRequestData(-1, "Games are not available at the moment")
            return status
        return True

    @classmethod
    def get_revenue_status_settings(cls) -> dict:
        redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        settings = redis.get(options.REVENUE_STATUS_KEY)
        if settings:
            settings = ujson.loads(settings)
            return settings
        else:
            cls.set_revenue_status_settings()
            return options.REVENUE_STATUS_DEFAULT

    @staticmethod
    def set_revenue_status_settings(revenue_settings=None):
        revenue_settings = revenue_settings if revenue_settings else options.REVENUE_STATUS_DEFAULT
        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(options.REVENUE_STATUS_KEY,
                                                           ujson.dumps(revenue_settings))

    @classmethod
    def get_currency_rate(cls, pair):
        currency_rate = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).get(f"currency_rate_{pair}")
        return currency_rate

    @classmethod
    def set_currency_rate(cls, pair, value):
        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set_with_ttl(f"currency_rate_{pair}", value, 600)

    @classmethod
    def get_unplayed_rev_share(cls):
        currency_rates = SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get(f"unplayed_rev_share")
        return currency_rates

    @classmethod
    def set_unplayed_rev_share(cls, unplayed_rev_share: float):
        SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).set_with_ttl(f"unplayed_rev_share", unplayed_rev_share)

    @classmethod
    def lock_alert_for_royalty_recalc(cls) -> None:
        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(options.ROYALTY_RECALC_ALERT_LOCK_KEY, 1)

    @classmethod
    def unlock_alert_for_royalty_recalc(cls) -> None:
        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).reset(options.ROYALTY_RECALC_ALERT_LOCK_KEY)
    
    @classmethod
    def get_lock_alert_for_royalty_recalc(cls) -> bool:
        lock = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).get(options.ROYALTY_RECALC_ALERT_LOCK_KEY)
        return bool(lock)

    @classmethod
    def set_payments_settings(cls, key='payment_settings', currency: str = "USD", data: dict = None):
        payments_settings = data or {
            "max_balance_amount": options.DEFAULT_MAX_BALANCE_AMOUNT,
            "max_win_amount": options.DEFAULT_SYSTEM_MAX_WINNING_AMOUNT
        }

        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(
            key=f"{key}_{currency}",
            value=ujson.dumps(payments_settings)
        )

        return payments_settings

    @classmethod
    def get_payment_settings(cls, key='payment_settings', currency: str = "USD"):
        redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        if not (payments_settings := redis.get(key=f"{key}_{currency}")):
            payments_settings = cls.set_payments_settings()
            return payments_settings

        return ujson.loads(payments_settings)
    
    @classmethod
    def get_owner_collector_last_calc_time(cls, key="owner_reports_last_calc_time"):
        redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        raw_data = redis.get(key)
        if raw_data:
            return datetime.fromisoformat(raw_data.decode('ascii'))
        else:
            return None

    @classmethod
    def set_owner_collector_last_calc_time(cls, last_calc_time: datetime, key="owner_reports_last_calc_time"):
        redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        redis.set(key, last_calc_time.isoformat())

    @classmethod
    def get_owner_collector_manual_mode(cls, key="owner_reports_manual_mode"):
        redis = SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        raw_data = redis.get(key)
        if raw_data:
            return ujson.loads(raw_data)
        else:
            return None
    
    @classmethod
    def set_owner_collector_manual_mode(cls, value: dict, key="owner_reports_manual_mode"):
        SyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(
            key=key,
            value=ujson.dumps(value)
        )

    @classmethod
    def get_from_secrets(cls, key: str) -> Optional[str]:
        key_values = SyncRedisWrapperSecrets(SecretRedisBaseTypes.DEFAULT).get(key)
        return key_values


class AsyncCacheManager:
    @staticmethod
    def get_user_balance_key(user_id: Union[str, int]) -> str:
        return 'user-balance-%s' % user_id

    @staticmethod
    async def get_notifications_key() -> str:
        return 'notifications'

    @staticmethod
    async def get_ranking_key() -> str:
        return 'agent_ranking'

    @classmethod
    async def hide_agent_notification_from_cache(cls, user_id, notification_id):
        notification_key = await cls.get_notifications_key()
        existing_notifications = await AsyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).get(notification_key)

        if existing_notifications:
            notifications_wrapper = ujson.loads(existing_notifications)
            notifications = notifications_wrapper.get('notifications', {})
            notification = notifications.get(notification_id)
            if notification:
                if 'hidden_for_user_ids' not in notification:
                    notification['hidden_for_user_ids'] = []
                notification['hidden_for_user_ids'].append(user_id)
                notifications[notification_id] = notification
        else:
            notifications = {}

        await AsyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).set(
            notification_key,
            ujson.dumps({"notifications": notifications})
        )

    @classmethod
    async def set_user_data_to_cache(cls, user: UserModel):
        data_for_cache = {
            "balance": float(user.balance),
            "bonus_balance": float(user.bonus_balance),
            "currency": user.currency,
            "is_banned": user.is_banned,
        }
        if not user.is_banned:
            await AsyncRedisWrapperLocal(RedisBaseTypes.BALANCES).set(
                cls.get_user_balance_key(user.id),
                ujson.dumps(data_for_cache)
            )

        return data_for_cache

    @classmethod
    async def reset_cache_balance(cls, cache_key: str):
        await AsyncRedisWrapperLocal(RedisBaseTypes.BALANCES).delete(cache_key)

    @staticmethod
    def get_user_cookie_salt_key(user_id):
        return 'cookie_salt_%s' % user_id

    @classmethod
    async def get_user_cookie_salt(cls, user_id) -> str:
        key = cls.get_user_cookie_salt_key(user_id)
        value = await AsyncRedisWrapperLocal(RedisBaseTypes.COOKIE_SALTS).get(key)
        return validate_decode(value)

    @classmethod
    async def set_cookie_salt(cls, user_id: int):
        key = cls.get_user_cookie_salt_key(user_id)
        value = uuid4().hex[:16]
        await AsyncRedisWrapperLocal(RedisBaseTypes.COOKIE_SALTS).set(key, value)

    @classmethod
    async def close_all_sessions_by_user_id(cls, user_id: int):
        cache_key = cls.get_user_balance_key(user_id)
        await cls.reset_cache_balance(cache_key)
        await cls.set_cookie_salt(user_id)

    @classmethod
    async def close_all_sessions_by_user_ids(cls, user_ids: List[int]):
        for user_id in user_ids:
            await cls.close_all_sessions_by_user_id(user_id=user_id)

    @classmethod
    async def get_from_secrets(cls, key: str) -> Optional[str]:
        key_values = await AsyncRedisWrapperForSecrets(SecretRedisBaseTypes.DEFAULT).get(key)
        return key_values

    @classmethod
    async def get_integration_status(cls, raise_exception=True) -> bool:
        if options.REVENUE_SYSTEM:
            redis = AsyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
            settings = await redis.get(options.REVENUE_STATUS_KEY)
            if settings:
                settings = ujson.loads(settings)
                if settings["emergency_shutdown"]:
                    status = False
                elif settings["bypass_operation"]:
                    status = True
                else:
                    status = settings["integration_status"]
            else:
                await cls.set_revenue_status_settings()
                status = True

            if not status and raise_exception:
                raise InvalidRequestData(-1, "Games are not available at the moment")
            return status
        else:
            return True

    @staticmethod
    async def set_revenue_status_settings(revenue_settings=None):
        revenue_settings = revenue_settings if revenue_settings else options.REVENUE_STATUS_DEFAULT
        await AsyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(options.REVENUE_STATUS_KEY,
                                                                  ujson.dumps(revenue_settings))

    @classmethod
    async def check_temporary_lock_of_bonus_balance(cls, user_id: int):
        try:
            temporary_locking_flag = await \
                AsyncRedisWrapperLocal(RedisBaseTypes.LOCKED_BONUS_BALANCES).get(user_id)
        except Exception as exc:
            logger.error(f"REDIS unexpected error: {exc} when tried to check lock for bonus balance of {user_id}")
            temporary_locking_flag = None

        return temporary_locking_flag

    @classmethod
    async def temporary_lock_bonus_balance(cls, user_id: int):
        default_value = "lock"
        default_time_for_lock = options.TEMPORARY_LOCK_BONUS_BALANCE_TIME_BY_SECONDS
        await AsyncRedisWrapperLocal(RedisBaseTypes.LOCKED_BONUS_BALANCES) \
            .set_with_ttl(
            key=str(user_id),
            value=default_value,
            time=default_time_for_lock
        )

    @classmethod
    async def set_payments_settings(cls, key='payment_settings', currency: str = "USD"):
        payments_settings = {
            "max_balance_amount": options.DEFAULT_MAX_BALANCE_AMOUNT,
            "max_win_amount": options.DEFAULT_SYSTEM_MAX_WINNING_AMOUNT
        }

        await AsyncRedisWrapperLocal(RedisBaseTypes.SETTINGS).set(
            key=f"{key}_{currency}",
            value=ujson.dumps(payments_settings)
        )

        return payments_settings

    @classmethod
    async def get_payment_settings(cls, key='payment_settings', currency: str = "USD"):
        redis = AsyncRedisWrapperLocal(RedisBaseTypes.SETTINGS)
        if not (payments_settings := await redis.get(key=f"{key}_{currency}")):
            payments_settings = await cls.set_payments_settings()
            return payments_settings

        return ujson.loads(payments_settings)
