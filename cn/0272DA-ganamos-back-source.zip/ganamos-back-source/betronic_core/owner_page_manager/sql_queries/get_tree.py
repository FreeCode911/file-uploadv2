GET_ALL_SUPER_ADMINS = """
SELECT o_stat.user_id,
       ea.email AS email,
       u.first_name,
       u.middle_name,
       u.last_name,
       u.role,
       sum(o_stat.amount_in)       AS "in",
       sum(o_stat.amount_out)      AS out,
       sum(o_stat.profit)          AS profit,
       sum(o_stat.transfers_count) AS transactions_count
FROM owner_statistic o_stat
         JOIN "user" u ON o_stat.user_id = u.id
         JOIN email_auth ea ON u.id = ea.user_id
WHERE o_stat.date >= :date_from
  AND o_stat.date <= :date_to
  AND o_stat.type = :statistic_type
  AND u.role = '3'
GROUP BY o_stat.user_id, ea.email, u.first_name, u.middle_name, u.last_name, u.role;
"""

GET_ADMINS_BY_SUADMIN = """
SELECT o_stat.user_id,
       ea.email as email,
       u.first_name,
       u.middle_name,
       u.last_name,
       u.role,
       sum(o_stat.amount_in)       as "in",
       sum(o_stat.amount_out)      as out,
       sum(o_stat.profit)          as profit,
       sum(o_stat.transfers_count) as transactions_count
FROM owner_statistic o_stat
         JOIN "user" u on o_stat.user_id = u.id
         JOIN email_auth ea on u.id = ea.user_id
WHERE o_stat.date >= :date_from
  AND o_stat.date <= :date_to
  AND o_stat.type = :statistic_type
  AND u.role = '2'
  AND u.parent_suadmin_id = :suadmin_id
group by o_stat.user_id, ea.email, u.first_name, u.middle_name, u.last_name, u.role;
"""

GET_CASHIERS_BY_ADMIN = """
SELECT o_stat.user_id,
       ea.email as email,
       u.first_name,
       u.middle_name,
       u.last_name,
       u.role,
       sum(o_stat.amount_in)       AS "in",
       sum(o_stat.amount_out)      AS out,
       sum(o_stat.profit)          AS profit,
       sum(o_stat.transfers_count) AS transactions_count
FROM owner_statistic o_stat
         JOIN "user" u on o_stat.user_id = u.id
         JOIN email_auth ea on u.id = ea.user_id
WHERE o_stat.date >= :date_from
  AND o_stat.date <= :date_to
  AND o_stat.type = :statistic_type
  AND u.role = '1'
  AND u.parent_admin_id = :admin_id
GROUP BY o_stat.user_id, ea.email, u.first_name, u.middle_name, u.last_name, u.role;
"""

GET_USERS_BY_CASHIER = """
SELECT o_stat.user_id,
       ea.email as email,
       u.first_name,
       u.middle_name,
       u.last_name,
       u.role,
       sum(o_stat.amount_in)       AS "in",
       sum(o_stat.amount_out)      AS out,
       sum(o_stat.profit)          AS profit,
       sum(o_stat.transfers_count) AS transactions_count
FROM owner_statistic o_stat
         JOIN "user" u on o_stat.user_id = u.id
         JOIN email_auth ea on u.id = ea.user_id
WHERE o_stat.date >= :date_from
  AND o_stat.date <= :date_to
  AND o_stat.type = :statistic_type
  AND u.role = '0'
  AND u.parent_cashier_id = :cashier_id
GROUP BY o_stat.user_id, ea.email, u.first_name, u.middle_name, u.last_name, u.role;
"""
