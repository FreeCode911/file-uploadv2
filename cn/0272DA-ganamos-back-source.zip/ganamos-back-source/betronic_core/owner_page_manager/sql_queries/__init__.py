from .users import *
from .cashiers import *
from .admins import *
from .super_admins import *
from .agentes import *
from .get_tree import *
from betronic_core.db.models.user import UserModel

QUERIES_BY_ROLES_TREE = {
    UserModel.USER: {
        "balance": {
            "in": USERS_BALANCE_IN,
            "out": USERS_BALANCE_OUT
        },
        "higher_balance": {
            "in": USERS_HIGHER_BALANCE_IN,
            "out": USERS_HIGHER_BALANCE_OUT
        },
        "bonus_balance": {
            "in": USERS_BALANCE_IN,
            "out": USERS_BALANCE_OUT
        },
        "bets": {
            "in": USERS_BETS_IN,
            "out": USERS_BETS_OUT
        },
    },
    UserModel.PARTNER_AGENT: {
        "balance": {
            "in": AGENTS_BALANCE_IN,
            "out": AGENTS_BALANCE_OUT
        },
        "higher_balance": {
            "in": AGENTS_HIGHER_BALANCE_IN,
            "out": AGENTS_HIGHER_BALANCE_OUT
        },
        "bonus_balance": {
            "in": AGENTS_BALANCE_IN,
            "out": AGENTS_BALANCE_OUT
        },
        "bets": {
            "in": AGENTS_BETS_IN,
            "out": AGENTS_BETS_OUT
        }
    }
}

QUERIES_BY_ROLES_TRANSFERS = {
    UserModel.USER: {
        "balance": GET_TRANSFERS_BY_UID_BALANCE,
        "bets": GET_TRANSFERS_BY_UID_BETS
    },
    UserModel.PARTNER_AGENT: {
        "balance": GET_TRANSFERS_BY_AGENT_UID_BALANCE,
        "bets": GET_TRANSFERS_BY_AGENT_UID_BETS
    }
}


def get_queries_for_tree(role, statistic_type):
    q_for_role = QUERIES_BY_ROLES_TREE.get(role)
    in_out = q_for_role.get(statistic_type, q_for_role['bets'])
    return in_out.get('in'), in_out.get('out')


def get_queries_for_transfers(role, statistic_type):
    q_for_role = QUERIES_BY_ROLES_TRANSFERS.get(role)
    q = q_for_role.get(statistic_type, q_for_role['bets'])
    return q
