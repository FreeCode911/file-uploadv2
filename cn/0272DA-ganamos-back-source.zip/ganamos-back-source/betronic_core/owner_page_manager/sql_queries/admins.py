ADMINS_BALANCE_IN = """
SELECT subq.id AS user_id, sum(subq.sum_in) AS amount_in, sum(subq.count) AS count
FROM (
         (
             SELECT u.id, 0 AS sum_in, 0 AS count
             FROM "user" u
             WHERE u.role = '2'
               AND u.id > 0
         )
         UNION
         (
             SELECT u.parent_admin_id,
                    sum(t.value) AS sum_in,
                    count(t.id)  AS count
             FROM "user" u
                      LEFT JOIN "transfer" t on u.id = t.to_user_id
             WHERE u.role = '0'
               AND u.id > 0
               AND u.parent_admin_id IS NOT NULL
               AND t.created_at BETWEEN :date_from AND :date_to
               AND t.type IN :transfer_types
             GROUP BY u.parent_admin_id
         )
     ) subq
GROUP BY id
ORDER BY id;
"""

ADMINS_BALANCE_OUT = """
SELECT subq.id AS user_id, sum(subq.sum_out) AS amount_out, sum(subq.count) AS count
FROM (
         (
             SELECT u.id, 0 AS sum_out, 0 AS count
             FROM "user" u
             WHERE u.role = '2'
               AND u.id > 0
         )
         UNION
         (
             SELECT u.parent_admin_id, sum(t.value) AS sum_out, count(t.id) AS count
             FROM "user" u
                      LEFT JOIN "transfer" t ON u.id = t.from_user_id
             WHERE u.role = '0'
               AND u.id > 0
               AND u.parent_admin_id IS NOT NULL
               AND t.created_at BETWEEN :date_from AND :date_to
               AND t.type IN :transfer_types
             GROUP BY u.parent_admin_id
         )
     ) subq
GROUP BY id
ORDER BY id;
"""

ADMINS_BETS_IN = """
SELECT subq.id AS user_id, sum(subq.sum_in) AS amount_in, sum(subq.count) AS count
FROM (
         (
             SELECT u.id, 0 AS sum_in, 0 AS count
             FROM "user" u
             WHERE u.role = '2'
               AND u.id > 0
         )
         UNION
         (
             SELECT u.parent_admin_id,
                    sum(t.value) AS sum_in,
                    count(t.id)  AS count
             FROM "user" u
                      LEFT JOIN "transfer" t on u.id = t.from_user_id
             WHERE u.role = '0'
               AND u.id > 0
               AND u.parent_admin_id IS NOT NULL
               AND t.created_at BETWEEN :date_from AND :date_to
               AND t.type IN :transfer_types
             GROUP BY u.parent_admin_id
         )
     ) subq
GROUP BY id
ORDER BY id;
"""

ADMINS_BETS_OUT = """
SELECT subq.id AS user_id, sum(subq.sum_out) AS amount_out, sum(subq.count) AS count
FROM (
         (
             SELECT u.id, 0 AS sum_out, 0 AS count
             FROM "user" u
             WHERE u.role = '2'
               AND u.id > 0
         )
         UNION
         (
             SELECT u.parent_admin_id, sum(t.value) AS sum_out, count(t.id) AS count
             FROM "user" u
                      LEFT JOIN "transfer" t ON u.id = t.to_user_id
             WHERE u.role = '0'
               AND u.id > 0
               AND u.parent_admin_id IS NOT NULL
               AND t.created_at BETWEEN :date_from AND :date_to
               AND t.type IN :transfer_types
             GROUP BY u.parent_admin_id
         )
     ) subq
GROUP BY id
ORDER BY id;
"""

GET_TRANSFERS_BY_ADMIN_ID_BALANCE = """
SELECT *
FROM (
         (
             SELECT t.id,
                    t.type,
                    t.from_user_id,
                    t.to_user_id,
                    t.value,
                    t.currency,
                    t.note,
                    t.created_at,
                    t.additional_data
             FROM transfer t
                      JOIN "user" u ON u.id = t.from_user_id
             WHERE u.parent_admin_id = :u_id
               AND t.type IN :out_transfer_types
               AND t.created_at >= :date_from
               AND t.created_at < :date_to
         )
         UNION
         (
             SELECT t.id,
                    t.type,
                    t.from_user_id,
                    t.to_user_id,
                    t.value,
                    t.currency,
                    t.note,
                    t.created_at,
                    t.additional_data
             FROM transfer t
                      JOIN "user" u ON u.id = t.to_user_id
             WHERE u.parent_admin_id = :u_id
               AND t.type IN :in_transfer_types
               AND t.created_at >= :date_from
               AND t.created_at < :date_to
         )) subq
ORDER BY subq.id DESC
LIMIT :count_on_page
OFFSET :page_offset;
"""

GET_TRANSFERS_BY_ADMIN_ID_BETS = """
SELECT *
FROM (
         (
             SELECT t.id,
                    t.type,
                    t.from_user_id,
                    t.to_user_id,
                    t.value,
                    t.currency,
                    t.note,
                    t.created_at,
                    t.additional_data
             FROM transfer t
                      JOIN "user" u ON u.id = t.from_user_id
             WHERE u.parent_admin_id = :u_id
               AND t.type IN :in_transfer_types
               AND t.created_at >= :date_from
               AND t.created_at < :date_to
         )
         UNION
         (
             SELECT t.id,
                    t.type,
                    t.from_user_id,
                    t.to_user_id,
                    t.value,
                    t.currency,
                    t.note,
                    t.created_at,
                    t.additional_data
             FROM transfer t
                      JOIN "user" u ON u.id = t.to_user_id
             WHERE u.parent_admin_id = :u_id
               AND t.type IN :out_transfer_types
               AND t.created_at >= :date_from
               AND t.created_at < :date_to
         )) subq
ORDER BY subq.id DESC
LIMIT :count_on_page
OFFSET :page_offset;
"""
