import sqlalchemy
from collections import defaultdict
from copy import deepcopy
from datetime import timedelta, date, datetime
from logging import getLogger
from typing import Union

from sqlalchemy import select, delete, exc, func, text
from tornado.options import options

import betronic_core.owner_page_manager.sql_queries as queries
from betronic_core.constants import TransferTypes as TT
from betronic_core.db.database import DataBase
from betronic_core.db.models.owner_statistic import OwnerStatisticModel, StatisticTypes
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.manager import IManager
from betronic_core.owner_page_manager.copy_helper import bulk_copy_by_chunks

logger = getLogger(__name__)


def interval_generator(date_from: datetime, date_to: datetime, step: timedelta):
    cursor = date_from
    while cursor < date_to:
        start, end = cursor, cursor + step
        if end > date_to:
            end = date_to
        yield start, end

        cursor += step


class OwnerPageManager(IManager):

    def __init__(self, db):
        self.db = db
        self.roles = [UserModel.USER, UserModel.PARTNER_AGENT]

    def calculate_all(self, date_from, date_to, is_manual_mode=False):
        """
        Main method processing all data by time periods,
        statistic types and user roles.
        It calculates and saves everything as needed for
        further querying in admin page.
        :return:
        """

        insert_step = options.OWNER_STATS_INSERT_INTERVAL
        self.check_already_calculated(date_from, is_manual_mode)

        for start_interval, end_interval in interval_generator(date_from, date_to, insert_step):
            for stat_type in StatisticTypes.STATS_NAMES.keys():
                for role in self.roles:
                    logger.info(f"Processing: interval: {start_interval} -> {end_interval}; "
                                f"stat_type: \"{stat_type}\"; role: {role}")
                    q_in, q_out = queries.get_queries_for_tree(role, stat_type)
                    self.calculate_and_save(q_in, q_out, start_interval, end_interval, stat_type)

    def check_already_calculated(self, date_from, is_manual_mode=False):
        result = self.db.execute(
            select(1).select_from(
                OwnerStatisticModel
            ).where(
                OwnerStatisticModel.date >= date_from
            )
        )
        if not is_manual_mode and result.scalars().first():
            self.db.execute(
                delete(OwnerStatisticModel).where(OwnerStatisticModel.date >= date_from)
            )
            self.db.commit()

    @staticmethod
    def get_transfer_types_by_statistic_type(t_type: str) -> dict:
        """
        IN - деньги пришли к заказчику (организации)
        OUT - деньги ушли от заказчика (организации)
        :param t_type: name of provider(sport, live-casino, slots)
        :return: dict of lists with transfer types
        """
        if t_type == 'balance':
            result = {'in': tuple(TT.PAYMENT_TYPES), 'out': tuple(TT.WITHDRAWAL_TYPES)}
        elif t_type == 'higher_balance':
            result = {'in': tuple(TT.PAYMENT_TYPES), 'out': tuple(TT.WITHDRAWAL_TYPES)}
        elif t_type == 'bonus_balance':
            result = {'in': tuple(TT.BONUS_USER_DEPOSIT_TYPES), 'out': tuple()}
        elif t_type == 'sport':
            result = {
                'in': tuple(TT.SPORT_IN_TYPES),
                'out': tuple(TT.SPORT_OUT_TYPES)
            }
        elif t_type == 'slots':
            result = {
                'in': tuple(TT.SLOTS_IN_TYPES),
                'out': tuple(TT.SLOTS_OUT_TYPES)
            }
        elif t_type == 'all':  # sport + slots + live-casino
            result = {
                "in": tuple(TT.SPORT_IN_TYPES + TT.SLOTS_IN_TYPES),
                'out': tuple(TT.SPORT_OUT_TYPES + TT.SLOTS_OUT_TYPES)
            }
        else:
            result = None

        return result

    @staticmethod
    def _convert_to_dict_tree(row_result):
        """
        Method converts SQLAlchemy RowProxy to dict
        :param row_result: list of RowProxy objects
        :return: {user_id: row_data_dict, ...}
        """
        result = dict()
        for r in row_result:
            if isinstance(r, sqlalchemy.Row):
                r = r._mapping

            result[r['user_id']] = {key: r[key] for key in r.keys()}
        return result

    @staticmethod
    def _convert_to_dict_common(row_result):
        """
        Method converts SQLAlchemy RowProxy to dict
        :param row_result: list of RowProxy objects
        :return: {user_id: row_data_dict, ...}
        """
        result = list()
        for r in row_result:
            tmp_row = dict()
            for key in r.keys():
                if isinstance(r[key], datetime):
                    tmp_row[key] = r[key].isoformat()
                else:
                    tmp_row[key] = r[key]
            result.append(tmp_row)
        return result

    @staticmethod
    def _prepare_to_insert(data_in: dict, data_out: dict, date_from: date, stat_type: str):
        """
        Method prepares data to insert: merges data from "in" and "out", adds other static info
        """
        data_in = deepcopy(data_in)
        data_out = deepcopy(data_out)

        result = defaultdict(lambda: {'amount_in': 0, 'amount_out': 0, 'count': 0})

        # Aggregate data from data_in
        for user_id, row in data_in.items():
            result[user_id]['amount_in'] += row.get('amount_in', 0)
            result[user_id]['count'] += row.get('count', 0)

        # Aggregate data from data_out
        for user_id, row in data_out.items():
            result[user_id]['amount_out'] += row.get('amount_out', 0)
            result[user_id]['count'] += row.get('count', 0)

        # Generate result list
        result_list = []
        for user_id, data in result.items():
            result_row = {
                'user_id': user_id,
                'amount_in': data['amount_in'],
                'amount_out': data['amount_out'],
                'date': date_from.isoformat(),
                'type': StatisticTypes.STATS_NAMES[stat_type],
                'profit': data['amount_in'] - data['amount_out'],
                'transfers_count': data['count']
            }
            result_list.append(result_row)

        return result_list

    def calculate_and_save(self, q_in, q_out, date_from, date_to, statistic_type):
        tt = self.get_transfer_types_by_statistic_type(statistic_type)

        result_in = self.calculate_by_interval(q_in, date_from, date_to, tt['in'])
        result_out = self.calculate_by_interval(q_out, date_from, date_to, tt['out'])
        ready_to_insert = self._prepare_to_insert(result_in, result_out, date_from, statistic_type)
        eng = DataBase.get_engine()
        if ready_to_insert:
            bulk_copy_by_chunks(
                engine=eng,
                table=OwnerStatisticModel.__table__,
                values=ready_to_insert,
                chunk_size=options.OWNER_STAT_INSERT_CHUNK_SIZE
            )

    def calculate_by_interval(self, query, date_from, date_to, transfer_types) -> dict:
        # result: user_id -> data
        result = dict()
        if not transfer_types:
            return result

        step_interval = options.OWNER_STATS_CALCULATE_INTERVAL
        for start, end in interval_generator(date_from, date_to, step_interval):
            try_count = 0
            params = {
                "date_from": start,
                "date_to": end,
                "transfer_types": transfer_types
            }
            # result_chunk: list of (user_id, sum, count)
            while True:
                try:
                    timeout = options.OWNER_STATS_RETRY_TIMEOUT.get(try_count, None)
                    if timeout is None:
                        raise Exception("Maximum retry try is reached")
                    self.db.execute(text(f"set statement_timeout={timeout};"))
                    result_chunk = self.db.execute(text(query), params).fetchall()
                except exc.OperationalError as e:
                    self.db.rollback()
                    try_count += 1
                    logger.warning(f"Try number {try_count} failed. Retrying again. Error: {e}")
                    continue
                break

            # convert to list of dict[user_id, data]
            result_chunk = self._convert_to_dict_tree(result_chunk)
            # sum all chunks by user_id
            for user_id, data in result_chunk.items():
                if user_id not in result:
                    result[user_id] = data
                else:
                    data_keys = tuple(key for key in data.keys() if key != "user_id")
                    for data_key in data_keys:
                        result[user_id][data_key] += result_chunk[user_id][data_key]
        return result

    def get_users_data(self, cashier_id, statistic_type, date_from, date_to):
        result_users = list()
        db_result = self.db.execute(text(queries.GET_USERS_BY_CASHIER),
                                    {
                                        "date_from": date_from,
                                        "date_to": date_to,
                                        "statistic_type": statistic_type,
                                        "cashier_id": cashier_id
                                    }).fetchall()
        users = self._convert_to_dict_tree(db_result)
        for user_id, user_data in users.items():
            user_data['sub_users'] = None
            result_users.append(user_data)
        return result_users

    def get_cashier_only(self, admin_id, statistic_type, date_from, date_to):
        db_result = self.db.execute(text(queries.GET_CASHIERS_BY_ADMIN),
                                    {
                                        "date_from": date_from,
                                        "date_to": date_to,
                                        "statistic_type": statistic_type,
                                        "admin_id": admin_id
                                    }).fetchall()
        cashiers = self._convert_to_dict_tree(db_result)
        return cashiers

    def get_cashiers_data(self, admin_id, statistic_type, date_from, date_to):
        result_cashiers = list()
        cashiers = self.get_cashier_only(admin_id, statistic_type, date_from, date_to)
        for cashier_id, cashier_data in cashiers.items():
            users = self.get_users_data(cashier_id, statistic_type, date_from, date_to)
            cashier_data['sub_users'] = users
            result_cashiers.append(cashier_data)
        return result_cashiers

    def get_admins_only(self, suadmin_id: int, statistic_type: int, date_from: str, date_to: str):
        db_result = self.db.execute(text(queries.GET_ADMINS_BY_SUADMIN),
                                    {
                                        "date_from": date_from,
                                        "date_to": date_to,
                                        "statistic_type": statistic_type,
                                        "suadmin_id": suadmin_id
                                    }).fetchall()
        admins = self._convert_to_dict_tree(db_result)
        return admins

    def get_admins_data(self, suadmin_id, statistic_type, date_from, date_to):
        result_admins = list()
        admins = self.get_admins_only(suadmin_id, statistic_type, date_from, date_to)
        for admin_id, admin_data in admins.items():
            cashiers = self.get_cashiers_data(admin_id, statistic_type, date_from, date_to)
            admin_data['sub_users'] = cashiers
            result_admins.append(admin_data)
        return result_admins

    def get_super_admins_data(self, statistic_type, date_from, date_to):
        result = self.db.execute(text(queries.GET_ALL_SUPER_ADMINS),
                                 {
                                     "date_from": date_from, "date_to": date_to,
                                     "statistic_type": statistic_type,
                                 }).fetchall()
        return self._convert_to_dict_tree(result)

    def get_full_tree(self, statistic_type, date_from, date_to):
        result_tree = list()
        statistic_type = StatisticTypes.STATS_NAMES.get(statistic_type)
        super_admins = self.get_super_admins_data(statistic_type, date_from, date_to)
        for su_admin_id, su_admin_data in super_admins.items():
            admins = self.get_admins_data(su_admin_id, statistic_type, date_from, date_to)
            su_admin_data['sub_users'] = admins
            result_tree.append(su_admin_data)
        return result_tree

    def get_transfers_by_filters(self, statistic_type, user_id, count, page, date_from, date_to):
        user_role = UserModel.get_by_id(self.db, user_id).role
        q = queries.get_queries_for_transfers(user_role, statistic_type)
        tt = self.get_transfer_types_by_statistic_type(statistic_type)
        result = self.db.execute(text(q), {
            "date_from": date_from,
            "date_to": date_to,
            "u_id": user_id,
            "in_transfer_types": tt.get('in'),
            "out_transfer_types": tt.get('out'),
            "count_on_page": count,
            "page_offset": count * page
        }).fetchall()
        return self._convert_to_dict_common(result)

    def get_statistic_by_user_and_date(
            self,
            user: UserModel,
            username: str = None,
            date_from: Union[str, datetime] = None,
            date_to: Union[str, datetime] = None,
            skip: int = 0,
            limit: int = 20,
            is_direct_only: bool = True
    ):
        user_subq = UserModel\
            .get_list_users_by_entity_user_subq(
                db=self.db,
                entity_user=user,
                username=username,
                is_direct_structure=is_direct_only
        )

        user_ids = self.db.query(user_subq.c.id)

        user_statistics, total_count = OwnerStatisticModel\
            .get_statistic_by_user_ids_and_date(
                db=self.db,
                user_ids=user_ids,
                types=[StatisticTypes.BALANCE],
                date_from=date_from,
                date_to=date_to,
                skip=skip,
                limit=limit
            )

        return user_statistics, total_count

    def get_total_deposits_by_user_id(self, user_id):
        total_deposits = OwnerStatisticModel.get_total_deposits_by_user_id(self.db, user_id)
        return total_deposits
    
    def remove_stats(self, date_from, date_to):
        OwnerStatisticModel.remove_by_date_in_portions(
            self.db, date_from, date_to, options.OWNER_STAT_DELETE_CHUNK_SIZE
        )
    
    def get_total_by_agent_ids_and_date(
        self,
        entity_user: UserModel,
        target_role: str,
        date_from: Union[datetime, str],
        date_to: Union[datetime, str],
        username: str = None,
        is_direct_structure: bool = False,
        is_higher_transaction_only: bool = False,
        is_withdrawal_transfers: bool = True,
        is_deposit_transfers: bool = True,
        is_bonus_deposits: bool = False
    ):
        users_subq = UserModel.get_descendant_by_ltree_path_subq(
            db=self.db,
            is_direct_structure=is_direct_structure,
            ltree_path=entity_user.structure_path,
            source_entity_id=entity_user.id,
            target_role=target_role,
            username=username
        )
        result = OwnerStatisticModel.prepare_query_for_agent_structure_total(
            db=self.db,
            users_subq=users_subq,
            date_from=date_from,
            date_to=date_to,
            is_higher_transaction_only=is_higher_transaction_only,
            is_bonus_deposits=is_bonus_deposits,
            is_deposit_transfers=is_deposit_transfers,
            is_withdrawal_transfers=is_withdrawal_transfers
        ).first()

        if is_bonus_deposits:
            is_deposit_transfers = True

        return {
            "deposits_sum": result.deposits_sum if is_deposit_transfers else 0,
            "withdrawals_sum": result.withdrawals_sum if is_withdrawal_transfers else 0,
        }
