from bookmakers.services.commands import CommandFactory

factory = CommandFactory(globals())


def add_command(name):
    return factory.add_command(name)


WriteWorkerMetric = "WriteWorkerMetric"
WriteWebMetric = "WriteWebMetric"
GetMetrics = "GetMetrics"
