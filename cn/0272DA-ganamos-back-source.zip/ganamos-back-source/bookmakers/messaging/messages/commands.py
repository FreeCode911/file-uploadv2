from uuid import UUID, uuid4
from bookmakers.messaging.messages.common import Message, create_class


class Command(Message):
    class Id(UUID):
        @classmethod
        def random(cls):
            return uuid4()

    def __init__(self, *args, **kwargs):
        super(Command, self).__init__(*args, **kwargs)
        self.id = None

    def __str__(self):
        return f'{self.__class__.__name__}(id={self.id})'


class Result(Message):
    def __init__(self, *args, **kwargs):
        super(Result, self).__init__(*args, **kwargs)
        self.command_id = None

    def __str__(self):
        return f'{self.__class__.__name__}(command_id={self.command_id})'


def _create_command_class(*args):
    return create_class(Command, *args)


def _create_result_class(command_class, *args):
    result_class = create_class(Result, *args)
    command_class.RESULT = result_class
    return result_class


LoadGameListCommand = _create_command_class("LoadGameListCommand")
LoadGameListResult = _create_result_class(LoadGameListCommand,
                                          "LoadGameListResult", "games")

LoadGameCommand = _create_command_class("LoadGameCommand", "game_id")
LoadGameResult = _create_result_class(LoadGameCommand, "LoadGameResult",
                                      "game")

CreateBetCommand = _create_command_class("CreateBetCommand", "user_id",
                                         "bet_type", "odds", "money")
CreateBetResult = _create_result_class(CreateBetCommand, "CreateBetResult",
                                       "status")
