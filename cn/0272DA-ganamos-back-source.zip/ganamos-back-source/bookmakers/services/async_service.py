from bookmakers.services.abstract_service import AbstractRMQService
from betronic_core.db.database import DataBase
from betronic_core.db.get_engine import init_db_pool


class AsyncService(AbstractRMQService):
    __db = None
    __documents = None

    async def configure(self):
        await super(AsyncService, self).configure()

        self.__db = DataBase.get()
        await init_db_pool()