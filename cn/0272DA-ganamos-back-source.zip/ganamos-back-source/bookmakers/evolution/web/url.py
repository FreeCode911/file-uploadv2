from .handlers.evo_proxy_handlers import GetGameListHandler,OpenFrameHandler


url_prefix = r"/api/evolution"

urls = [
    (r"/get_game_list", GetGameListHandler),
    (r"/open_frame", OpenFrameHandler)
]
