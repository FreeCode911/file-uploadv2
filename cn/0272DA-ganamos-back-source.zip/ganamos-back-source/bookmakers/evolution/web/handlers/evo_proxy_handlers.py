import json
from logging import getLogger

import ujson
from tornado.httpclient import AsyncHTTPClient, HTTPError
from tornado.options import options
from tornado.web import RequestHandler

from betronic_core.cache_manager.manager import CacheManager
from betronic_core.constants import RESULT_STATUS_OK, RESULT_STATUS_ERROR
from bookmakers.evolution.web.handlers.schemas.get_game_list import GetGameListSchema
from bookmakers.evolution.web.handlers.schemas.open_frame import OpenFrameSchema
from bookmakers.user.service import commands
from bookmakers.user.service.service_connector import UserServiceConnector
from bookmakers.services.service import AbstractResult
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from util.redis import AsyncRedisWrapperLocal, RedisBaseTypes

logger = getLogger(__name__)


class GetGameListHandler(RequestHandler, GetRequestArgsMixin):
    get_params_model = GetGameListSchema
    PROXY_API_EVO_URL = options.PROXY_API_EVO_URL

    @result_decorator
    async def get(self):
        args = self.get_args_dict()
        game_type = args.game_type
        project = options.EVO_PROXY_PROJECT_NAME
        # url = options.PROXY_API_EVO_URL + f"/api/game_list?project_name={options.EVO_PROXY_PROJECT_NAME}"
        url = self.PROXY_API_EVO_URL + f"/api/game_list?project_name={project}&game_type={game_type}"
        try:
            http_response = await AsyncHTTPClient().fetch(
                url,
                method="GET",
                headers={"Auth-Token": options.EVO_PROXY_SERVER_TOKEN}
            )
            response_body = ujson.loads(http_response.body)
        except HTTPError as http_exc:
            if http_exc.response.body:
                response_body = ujson.loads(http_exc.response.body)
            else:
                return AbstractResult(status=RESULT_STATUS_ERROR,
                                      result=None,
                                      error_message="Unknown Evolution Error")
        return AbstractResult(status=response_body["status"],
                              result=response_body["result"],
                              error_message=response_body["error_message"])


class OpenFrameHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    get_params_model = OpenFrameSchema
    @result_decorator
    async def get(self, *args, **kwargs):
        args = self.get_args_dict()
        user = await self.get_user_required()
        if not user['changed_password']:
            return AbstractResult(-1, None, "You cannot place bets")
        args.user_ip = self.request.headers.get("X-Real-IP")
        args.user_id = user["id"]

        cache_key = CacheManager.get_user_balance_key(user['id'])
        data_from_redis = await AsyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get(cache_key)

        if data_from_redis:
            data_from_redis = json.loads(data_from_redis)
        else:
            connector = await UserServiceConnector.get_instance()
            result = await connector.execute_command(commands.GetBalanceByUserId, args.dict())
            data_from_redis = {
                "balance": result.result["balance"]
            }

        req_data = {
            "login": user["email"],
            "currency": user["currency"],
            "project_name": options.EVO_PROXY_PROJECT_NAME,
            "user_id": user["id"],
            "user_ip": args.user_ip,
            "language": args.language,
            "page_id": args.page_id,
            "balance": data_from_redis["balance"],
            "is_mobile": args.is_mobile,
            "game_type": args.game_type,
            "system": args.system
        }

        req_url = options.PROXY_API_EVO_URL + "/api/open_frame"
        http_client = AsyncHTTPClient()
        try:
            http_response = await http_client.fetch(
                req_url,
                body=ujson.dumps(req_data),
                method="POST",
                follow_redirects=False,
                headers={"Auth-Token": options.EVO_PROXY_SERVER_TOKEN}
            )
        except HTTPError as http_exc:
            if http_exc.code == 302:  # If follow_redirects = False, 302 is considered an exception,
                # catch it there and just send location to front, so they can redirect it themselves
                return AbstractResult(status=RESULT_STATUS_OK,
                                      result={'launch_url': http_exc.response.headers['Location']})
            if http_exc.response.body:
                response_body = ujson.loads(http_exc.response.body)
            return AbstractResult(status=response_body["status"],
                                  result=response_body["result"],
                                  error_message=response_body["error_message"])

        return AbstractResult(status=RESULT_STATUS_OK,
                              result={'launch_url': http_response.response.headers['Location']})
