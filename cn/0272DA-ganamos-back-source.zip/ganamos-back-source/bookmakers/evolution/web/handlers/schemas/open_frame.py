from pydantic import BaseModel


class OpenFrameSchema(BaseModel):
    language: str = "en"
    page_id: int
    is_mobile: bool = False
    system: str = None
    user_ip: str = None
    user_id: int = None
    game_type: str = "live-casino"
