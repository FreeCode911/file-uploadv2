from pydantic import BaseModel
from pydantic import validator


class GetGameListSchema(BaseModel):
    game_type: str = "live-casino"
