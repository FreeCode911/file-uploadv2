import threading
from logging import getLogger

from tornado.options import options

from bookmakers.evolution.service.handlers.evo_proxy_handlers import GetUserDataForFrameHandler
from bookmakers.services.service import Service
from util.messaging import check_db_online, check_broker_online
from . import commands

logger = getLogger(__name__)


class EvolutionService(Service):
    def __init__(self):
        super().__init__(commands)

    def register_commands(self):
        self.handle_command(commands.GetUserDataForFrame, GetUserDataForFrameHandler)


def start():
    check_broker_online()
    check_db_online()
    for i in range(options.DEFAULT_WORKER_POOL):
        service = EvolutionService()
        thread = threading.Thread(target=service.start)
        thread.start()
        thread.join()
