from bookmakers.services.service import ServiceConnector
from . import commands


class EvolutionServiceConnector(ServiceConnector):
    def __init__(self):
        super().__init__(commands)
