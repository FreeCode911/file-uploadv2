from logging import getLogger

from tornado.options import options

from betronic_core.db.models.user import UserModel
from bookmakers.services.abstract_handler import IServiceHandler

logger = getLogger(__name__)


class GetUserDataForFrameHandler(IServiceHandler):
    def set_result(self):
        user_id = self.get_arg("user_id")
        user = UserModel.get_by_id(self.db, user_id)

        req_data = {
            "login": user.email_auth.email,
            "currency": user.currency,
            "project_name": options.EVO_PROXY_PROJECT_NAME,
            "user_id": user.id,
            "user_ip": self.get_arg("user_ip"),
            "language": self.get_arg("language") or "en",
            "page_id": self.get_arg("page_id"),
            "balance": user.balance,
            "is_mobile": self.get_arg("is_mobile", False),
            "game_type": self.get_arg("game_type", "live-casino"),
            "system": self.get_arg("system", None)
        }
        self.result = req_data
