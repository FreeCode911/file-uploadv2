from typing import Optional

from pydantic import BaseModel


class Slot(BaseModel):
    id: str
    gameId: str
    description: Optional[str]
    gameName: str
    tab: Optional[list]
    provider: str
    imageUrl: str
    routeProvider: Optional[str]
    system: str = None
    isFavorite: Optional[bool]
    link: Optional[str]
    needFavorite: Optional[bool]
    isLiveGame: Optional[bool]
    format: Optional[str]
    isMobile: Optional[int]
    haveTwoVersion: Optional[bool]


class FavoriteSlotsAddRequestModel(BaseModel):
    slot: Slot
    user_id: int


class FavoriteSlotsGetListRequestModel(BaseModel):
    user_id: int


class FavoriteSlotsRemoveRequestModel(BaseModel):
    id: str
    user_id: int
