from tornado.options import options

from betronic_core.db.async_database import session
from betronic_core.favorite_slots_manager.async_manager import AsyncFavoriteSlotsManager
from bookmakers.favorite_slots.models import FavoriteSlotsAddRequestModel
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.redis import AsyncRedisWrapperLocal


class FavoriteSlotsAdd(AbstractDirectServiceHandler):
    data_model = FavoriteSlotsAddRequestModel

    @classmethod
    async def execute(cls, data: FavoriteSlotsAddRequestModel) -> dict:
        games = {f"slot{data.slot.id}": data.slot.dict()}
        async with session.begin() as transaction:
            user_favorite_slots = await AsyncFavoriteSlotsManager.get_favorite_games_by_user_id(
                user_id=data.user_id,
                connection=transaction.session,
            )
            if user_favorite_slots:
                user_favorite_slots = await AsyncFavoriteSlotsManager.update_user_favorite_games(
                    user_id=user_favorite_slots.user_id,
                    favorite_games=games | user_favorite_slots.favorite_games,
                    connection=transaction.session
                )
            else:
                user_favorite_slots = await AsyncFavoriteSlotsManager.add_user_favorite_slots(
                    user_id=data.user_id,
                    favorite_games=games,
                    connection=transaction.session
                )

        await AsyncRedisWrapperLocal(
            db=options.REDIS_FAVORITE_SLOTS_DB,
            connection_data=options.REDIS_REVOLUTION
        ).delete(user_favorite_slots.user_id)

        return {
            "result": user_favorite_slots.favorite_games
        }
