from .add import FavoriteSlotsAdd
from .get_list import FavoriteSlotsGetlist
from .remove import FavoriteSlotsRemove
