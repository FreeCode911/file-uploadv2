import ujson as json
from tornado.options import options

from betronic_core.favorite_slots_manager.async_manager import AsyncFavoriteSlotsManager
from bookmakers.favorite_slots.models import FavoriteSlotsGetListRequestModel
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.redis import AsyncRedisWrapperLocal


class FavoriteSlotsGetlist(AbstractDirectServiceHandler):
    data_model = FavoriteSlotsGetListRequestModel

    @classmethod
    async def execute(cls, data: FavoriteSlotsGetListRequestModel) -> dict:
        user_favorite_slots = await AsyncFavoriteSlotsManager.get_favorite_games_by_user_id(
            user_id=data.user_id,
        )

        if user_favorite_slots:
            await AsyncRedisWrapperLocal(
                db=options.REDIS_FAVORITE_SLOTS_DB,
                connection_data=options.REDIS_REVOLUTION
            ).set(key=user_favorite_slots.user_id,
                  value=json.dumps(user_favorite_slots.favorite_games))

        return {
            "favorite_slots": user_favorite_slots.favorite_games if user_favorite_slots else {}
        }
