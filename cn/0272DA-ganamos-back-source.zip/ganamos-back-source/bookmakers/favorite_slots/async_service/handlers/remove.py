from tornado.options import options

from betronic_core.db.async_database import session
from betronic_core.favorite_slots_manager.async_manager import AsyncFavoriteSlotsManager
from bookmakers.favorite_slots.models import FavoriteSlotsRemoveRequestModel
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.redis import AsyncRedisWrapperLocal


class FavoriteSlotsRemove(AbstractDirectServiceHandler):
    data_model = FavoriteSlotsRemoveRequestModel

    @classmethod
    async def execute(cls, data: FavoriteSlotsRemoveRequestModel) -> dict:
        async with session.begin() as transaction:
            user_favorite_slots = await AsyncFavoriteSlotsManager.get_favorite_games_by_user_id(
                user_id=data.user_id,
            )
            if not user_favorite_slots:
                return {"result": {}}

            user_favorite_slots.favorite_games.pop(f"slot{data.id}", None)
            
            updated_user_favorite_slots = await AsyncFavoriteSlotsManager.update_user_favorite_games(
                user_id=user_favorite_slots.user_id,
                favorite_games=user_favorite_slots.favorite_games,
                connection=transaction.session
            )

        await AsyncRedisWrapperLocal(
            db=options.REDIS_FAVORITE_SLOTS_DB,
            connection_data=options.REDIS_REVOLUTION
        ).delete(updated_user_favorite_slots.user_id)

        return {
            "result": updated_user_favorite_slots.favorite_games
        }
