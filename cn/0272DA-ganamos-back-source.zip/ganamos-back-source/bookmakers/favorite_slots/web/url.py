from .handlers.fs_getlist import FavoriteSlotsGetlistHandler
from .handlers.fs_add import FavoriteSlotsAddHandler
from .handlers.fs_remove import FavoriteSlotsRemoveHandler


url_prefix = r"/api/favorite_slots"

urls = [
    (r'/add', FavoriteSlotsAddHandler),
    (r'/remove', FavoriteSlotsRemoveHandler),
    (r'/get_list', FavoriteSlotsGetlistHandler),

]
