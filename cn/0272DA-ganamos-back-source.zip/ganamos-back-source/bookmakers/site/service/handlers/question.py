from logging import getLogger

from betronic_core.site_manager.manager import SiteManager
from bookmakers.services.abstract_handler import IServiceHandler

logger = getLogger(__name__)


class SendQuestionHandler(IServiceHandler):
    def set_result(self):
        question = SiteManager(self.db).send_question(self.args)
        self.result = question.auto_dict
