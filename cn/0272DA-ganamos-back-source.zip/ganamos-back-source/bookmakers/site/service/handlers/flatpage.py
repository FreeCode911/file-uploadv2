from logging import getLogger

from betronic_core.site_manager.manager import SiteManager
from bookmakers.services.abstract_handler import IServiceHandler

logger = getLogger(__name__)


class GetFlatPageListHandler(IServiceHandler):
    def set_result(self):
        lang = self.get_arg("lang")
        logger.info("Get flatpage list")
        manager = SiteManager(self.db)
        pages_list = manager.get_flatpage_list(lang=lang)

        self.result = pages_list


class GetFlatPageDetailHandler(IServiceHandler):
    def set_result(self):
        name = self.get_arg("name")
        lang = self.get_arg("lang")
        logger.info("Get flatpage by name u:{}".format(name))
        manager = SiteManager(self.db)
        page = manager.get_flatpage_by_name_by_lang(name, lang)

        self.result = {
            "name": page.name,
            "id_name": page.id_name,
            "text": page.text,
        }
