from bookmakers.services.service import ServiceConnector
from . import commands

from logging import getLogger
logger = getLogger(__name__)


class SiteServiceConnector(ServiceConnector):
    def __init__(self):
        super(SiteServiceConnector, self).__init__(commands)
