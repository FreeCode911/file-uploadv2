import threading
from tornado.options import options
from util.messaging import check_broker_online, check_db_online

from logging import getLogger

from bookmakers.services.service import Service
from . import commands
from .handlers.healthcheck import HealthCheckHandler
from .handlers.flatpage import GetFlatPageDetailHandler, GetFlatPageListHandler
from .handlers.question import SendQuestionHandler
from .handlers.ads import GetAdsHandler
from .handlers.slide import GetSlidesHandler
from .handlers.get_categories import GetCategoriesHandler

logger = getLogger(__name__)


class SiteService(Service):
    def __init__(self):
        super(SiteService, self).__init__(commands)

    def register_commands(self):
        self.handle_command(commands.HealthCheck, HealthCheckHandler)
        self.handle_command(commands.GetFlatPageList, GetFlatPageListHandler)
        self.handle_command(commands.GetFlatPageDetail, GetFlatPageDetailHandler)
        self.handle_command(commands.SendQuestion, SendQuestionHandler)
        self.handle_command(commands.GetAdsList, GetAdsHandler)
        self.handle_command(commands.GetSlidesList, GetSlidesHandler)
        self.handle_command(commands.GetCategories, GetCategoriesHandler)


def start():
    check_broker_online()
    check_db_online()
    for i in range(options.DEFAULT_WORKER_POOL):
        service = SiteService()
        thread = threading.Thread(target=service.start)
        thread.start()
        thread.join()

