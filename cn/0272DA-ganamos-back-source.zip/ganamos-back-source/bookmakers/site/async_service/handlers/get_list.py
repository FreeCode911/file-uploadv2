import ujson as json
from tornado.options import options

from betronic_core.db.async_database import session
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.settings import SettingsModel
from betronic_core.settings_manager.async_manager import AsyncSettingsManager
from bookmakers.site.models import SettingsGetByNameRequestModel, \
    SettingsGetMaxBonusRequestModel
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.redis import AsyncRedisWrapperLocal
from util.redis import RedisBaseTypes


class SettingsGetByName(AbstractDirectServiceHandler):
    data_model = SettingsGetByNameRequestModel

    @classmethod
    async def execute(cls, data: SettingsGetByNameRequestModel) -> dict:
        async with session.begin() as transaction:
            site_settings: SettingsModel = await AsyncSettingsManager.get_setting_by_name(data.name, transaction.session)

            if site_settings:
                await AsyncRedisWrapperLocal(
                    db=RedisBaseTypes.SITE_SETTINGS,
                    connection_data=options.REDIS
                ).set(key=site_settings.name,
                      value=json.dumps(site_settings.data))

                return site_settings.data
            else:
                return {}


class SettingsGetMaxBonus(AbstractDirectServiceHandler):
    data_model = SettingsGetMaxBonusRequestModel

    @classmethod
    async def execute(cls, data: SettingsGetMaxBonusRequestModel) -> dict:

        max_bonus = {}
        for currency in options.AVAILABLE_CURRENCIES:
            max_bonus[currency] = await cls.get_max_bonus(currency, data.bonus_settings)
        await AsyncRedisWrapperLocal(
            db=RedisBaseTypes.SITE_SETTINGS,
            connection_data=options.REDIS
        ).set_with_ttl(key="MaxBonus",
                       value=json.dumps(max_bonus),
                       time=180)

        return max_bonus

    @staticmethod
    async def get_max_bonus(currency, setting):
        not_convert_value = setting['max_bonus_size']
        convert_value = await CurrencyRateModel.async_convert(not_convert_value, 'USD', currency)
        return convert_value
