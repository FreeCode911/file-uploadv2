import random

from tornado.options import options

from betronic_core.db.converters import user_to_dict
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.notification_manager.manager import EmailNotificationManager
from betronic_core.payment_manager.manager import PaymentManager
from betronic_core.user_manager import error_codes
from betronic_core.user_manager.manager import UserManager
from bookmakers.services.abstract_handler import IServiceHandler
from bookmakers.user.service.handlers.auth import logger
from util.error import InvalidRequestData
from util.smsc_api import SendSms


class RegisterUserWithUsernameHandler(IServiceHandler):
    def set_result(self):
        username = self.get_arg("username").lower()
        password = self.get_arg("password")
        currency = self.get_arg("currency")
        is_user = self.get_arg("is_user", True)

        extra_email = self.get_arg("email", None)
        first_name = self.get_arg("first_name", None)
        last_name = self.get_arg("last_name", None)

        logger.info("Start register user by username with args: {}".format(self.args))

        user = UserManager(self.db).register_user_by_username(
            username, password, currency, is_user=is_user,
            first_name=first_name, last_name=last_name, email=extra_email
        )

        self.result = {
            "user_id": user.id, "username": user.email_auth.email
        }


class RegisterUserWithEmailHandler(IServiceHandler):
    def set_result(self):
        username = self.get_arg("username").lower()
        email = self.get_arg("email")
        name = self.get_arg("name")
        password = self.get_arg("password")
        domain = self.get_arg("domain")
        currency = self.get_arg("currency")
        lang = self.get_arg("lang", "ru-RU").lower()
        document_number = self.get_arg("document_number", None)
        logger.info("Start register user by email with args: {}".format(self.args))
        referral_id: int = self.get_arg("referral_id", None)
        need_activation: bool = self.get_arg('need_activation', False)
        money_manager = MoneyManager(self.db)
        is_user = self.get_arg("is_user", False)

        logger.info("Start register user with args: {}".format(self.args))

        if UserModel.get_by_nickname(self.db, username):
            raise InvalidRequestData(
                error_codes.USER_ALREADY_EXIST,
                f"User with username: {username} - already exist"
            )

        user = UserManager(self.db).register_user_by_email(
            username=username,
            email=email,
            password=password,
            currency=currency,
            name=name,
            referral_id=referral_id,
            document_number=document_number,
            lang=lang,
            need_activation=need_activation,
            is_user=is_user
        )

        if options.NEED_ACTIVATION_EMAIL and need_activation:
            EmailNotificationManager(self.db)\
                .create_verification_email_to_user(user, url=domain)
        if user.referral_id and not options['NEED_ACTIVATION_EMAIL']:
            referral = user.referral
            money_manager.partner_take_registration_money(referral)

        self.result = {"user_id": user.id, "user_email": user.email_auth.email}


class RegisterUserWithPhoneHandler(IServiceHandler):
    def set_result(self):
        phone = self.get_arg("phone")
        phone = phone.strip().strip("+")
        code = self.get_arg("code")
        UserManager(self.db).verify_phone_auth_code(phone, code)
        name = self.get_arg("name")
        surname = self.get_arg("surname", None)
        if surname:
            name = name + ' ' + surname
            # If surname is sent, concatenate it with name (it will be splitted further)
        password = self.get_arg("password")
        domain = self.get_arg("domain")
        currency = self.get_arg("currency")
        lang = self.get_arg("lang", "ru-RU").lower()
        logger.info("Start register user by phone with args: {}".format(self.args))
        referral_id: int = self.get_arg("referral_id", None)
        need_activation: bool = self.get_arg('need_activation', False)
        money_manager = MoneyManager(self.db)

        logger.info("Start register user with args: {}".format(self.args))

        user = UserManager(self.db).register_user_by_phone(
            phone, password, name, currency, lang, referral_id)

        if options.NEED_ACTIVATION_EMAIL and need_activation:
            EmailNotificationManager(self.db)\
                .create_verification_email_to_user(user, url=domain)
        if user.referral_id and not options['NEED_ACTIVATION_EMAIL']:
            referral = user.referral
            money_manager.partner_take_registration_money(referral)

        self.result = {"user_id": user.id, "user_phone": user.email_auth.email}


class CreateBetrouteUserHandler(IServiceHandler):
    def set_result(self):
        user_id = self.get_arg("user_id")
        logger.info("Create betroute user by user_id: %s" % user_id)
        betroute_user = UserManager(self.db).create_betroute_user(user_id)
        self.result = {
            "email": betroute_user.remote_email,
            "password": betroute_user.get_remote_password(),
            "cash_id": betroute_user.cash_id,
            "currency": betroute_user.user.get_currency
        }


class SetBetrouteUserHandler(IServiceHandler):
    def set_result(self):
        user_id = self.get_arg("user_id")
        remote_email = self.get_arg("remote_email")
        remote_password = self.get_arg("remote_password")
        cash_id = self.get_arg("cash_id")
        logger.info("Set betroute user by user_id: %s" % user_id)
        betroute_user = UserManager(self.db).\
            set_old_betroute_user(user_id, remote_email,
                                  remote_password, cash_id)
        self.result = {
            "email": betroute_user.remote_email,
            "password": betroute_user.get_remote_password(),
            "cash_id": betroute_user.cash_id,
            "currency": betroute_user.user.get_currency
        }


class ChangeEmailHandler(IServiceHandler):
    def set_result(self):
        user_id = self.get_arg("user_id")
        domain = self.get_arg("domain")
        password = self.get_arg("password")
        new_email = self.get_arg("new_email")
        user_manager = UserManager(self.db)
        user = user_manager.get_user_by_id(user_id)
        logger.info("Change email request from user {}: to {}".format(user_id, new_email))
        current_email = user.email_auth.email
        user_manager.change_email_request(current_email, new_email, password)
        notification = EmailNotificationManager(self.db).create_change_email_to_user(user, new_email, domain)

        self.result = {
            "request_id": notification.id,
            "user_email": notification.email
        }


class SocialRegisterHandler(IServiceHandler):
    def set_result(self):
        email = self.get_arg("email").lower()
        password = self.get_arg("password")
        name = self.get_arg("name")
        currency = self.get_arg("currency")
        uid = str(self.get_arg("uid"))
        social_method = int(self.get_arg("social_method"))
        document_number = self.get_arg("document_number", None)
        referral_id: int = self.get_arg("referral_id", None)
        lang = self.get_arg("lang", "ru-RU").lower()

        logger.info("Create social register user with args: %s" % self.args)

        user_manager = UserManager(self.db)
        money_manager = MoneyManager(self.db)

        social = user_manager.get_user_social(social_method, uid)
        user = user_manager.register_user_by_email(email, name, password,
                                                   currency, referral_id,
                                                   document_number, lang)
        if options.FEATURES['bonus_program']:
            money_manager = MoneyManager(self.db)
            payment_manager = PaymentManager(self.db)
            bonus_amount = payment_manager.get_bonus_registration_amount(user)
            if bonus_amount:
                money_manager.registration_bonus(user.id, bonus_amount)

        if user.referral_id and not options['NEED_ACTIVATION_EMAIL']:
            referral = user.referral
            money_manager.partner_take_registration_money(referral)

        user_manager.set_user_social(user, social)
        if referral_id:
            referral = user_manager.get_user_by_id(referral_id)
            money_manager.partner_take_registration_money(referral)

        self.result = {
            "user_id": user.id,
            "user_email": user.email_auth.email,
            "user": user_to_dict(user)
        }


class SendCodeHandler(IServiceHandler):
    def set_result(self):
        code = str(random.randint(1000, 9999))
        phone = self.get_arg("phone").lower()
        smsc = SendSms()
        smsc.send_sms(phone, code)
        manager = UserManager(self.db)
        manager.create_verification_phone_data(phone, code)


class VerifyEmailByCodeHandler(IServiceHandler):
    def set_result(self):
        logger.info("Verify user args: {}".format(self.args))

        code = self.get_arg("code")

        user_manager = UserManager(self.db)
        money_manager = MoneyManager(self.db)

        auth = user_manager.get_email_auth_by_verification_code(code)
        betroute_registration = auth.user.betroute_registration

        user_manager.user_check_can_auth(auth.user)
        user_manager.set_last_visit(auth.user)
        if options.FEATURES['bonus_program']:
            money_manager = MoneyManager(self.db)
            payment_manager = PaymentManager(self.db)
            bonus_amount = payment_manager.get_bonus_registration_amount(
                auth.user)
            money_manager.registration_bonus(auth.user.id, bonus_amount)

        user = auth.user
        if user.referral_id and options['NEED_ACTIVATION_EMAIL']:
            logger.info("Init registration accrual for partner with id {}".format(self.args))
            referral = user.referral
            money_manager.partner_take_registration_money(referral)

        self.result = {
            "user": user_to_dict(auth.user),
            "remote_email": betroute_registration.remote_email,
            "remote_password": betroute_registration.get_remote_password()
        }
