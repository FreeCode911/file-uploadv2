from bookmakers.services.abstract_handler import IServiceHandler
from betronic_core.user_manager.manager import UserManager
from betronic_core.notification_manager.manager import EmailNotificationManager

from logging import getLogger
logger = getLogger(__name__)


class RestorePasswordRequestHandler(IServiceHandler):
    def set_result(self):
        email = self.get_arg("email").lower()
        domain = self.get_arg("domain")
        logger.info("Start restore password with args: {}".format(self.args))
        request, lang = UserManager(self.db).create_restore_password_request(
            email)
        EmailNotificationManager(
            self.db).create_restore_password_email_to_user(
                request, lang, url=domain)

        self.result = {
            "request_id": request.id,
            "user_email": request.email_auth_email
        }


class CheckRestorePasswordHandler(IServiceHandler):
    def set_result(self):
        code = self.get_arg("code")
        logger.info("Start check password with args: {}".format(self.args))
        request = UserManager(
            self.db).get_restore_password_request_by_code(code)

        self.result = {
            "request_id": request.id,
            "user_email": request.email_auth_email
        }


class SetNewPasswordRestorePasswordHandler(IServiceHandler):
    def set_result(self):
        code = self.get_arg("code")
        new_pass = self.get_arg("new_password")
        logger.info("Start check password with args: {}".format(self.args))
        request = UserManager(self.db).set_new_password_by_code(new_pass, code)

        self.result = {
            "request_id": request.id,
            "user_email": request.email_auth_email
        }


# import time
# from logging import getLogger
#
# import sqlalchemy.sql.expression as saex
# from betronic_core.db.models.email_auth import EmailAuthModel
# from betronic_core.db.models.user import UserModel
# from sqlalchemy.sql import func, not_
#
# import util
# from betronic_core.db.models.lost_password_requests import LostPasswordRequest
# from betronic_core.notification_manager.notification import smtp2 as smtp
#
# logger = getLogger(__name__)
#
#
# class LostPasswordHandler:
#     def __init__(self, db):
#         self._db = db
#
#     def send_invite(self, email):
#         try:
#             user = self._db.query(UserModel).filter(UserModel.email == email).first()
#             if not user:
#                 raise NameError
#         except NameError:
#             logger.error("LostPassword: user not found %s", email)
#             return LostPasswordRequest.STATUS_NOT_FOUND
#         vkey = util.hash(email + str(time.time()))
#         lpr = LostPasswordRequest(user=user, verification_key=vkey, timestamp=func.now() + saex.text("interval '1 day'"))
#         try:
#             self._db.add(lpr)
#             self._db.commit()
#         except Exception as e:
#             logger.error("LostPassword: Error on add to database %s", e)
#             self._db.rollback()
#             return LostPasswordRequest.STATUS_REMOTE_ERROR
#         try:
#             smtp.notify(user.email, 'lost_password', {'request_id': vkey})
#         except Exception as e:
#             logger.error("LostPassword: Error on sending mail: %s. Email: %s", (e, email))
#             return LostPasswordRequest.STATUS_REMOTE_ERROR
#         logger.info('Password restore invite sent to %s', email)
#         return LostPasswordRequest.STATUS_OK
#
#
#     def change_passwd(self, newpasswd, user_id, key):
#         if user_id is None and key != "":
#             try:
#                 lpr = (self._db.query(LostPasswordRequest)
#                        .filter(LostPasswordRequest.verification_key == key)
#                        .filter(LostPasswordRequest.timestamp > func.now())
#                        .filter(not_(LostPasswordRequest.used))
#                        .first())
#             except NameError:
#                 logger.warning("Lost password request %s was lost (or timed out)", key)
#                 return "Запрос на восстановление пароля не найден"
#             lpr.used = True
#             user_id = lpr.user_id
#         elif user_id is not None and key == "":
#             pass
#         else:
#             return "Ошибка смены пароля, повторите позже."
#         # Change user password
#         logger.info("Password changer user_id: %s ", user_id)
#         try:
#             userWemail = self._db.query(EmailAuthModel).filter(EmailAuthModel.user_id == user_id).first()
#             if not userWemail:
#                 raise NameError
#             userWemail.clear_verification_key()
#             user = self._db.query(UserModel).filter(UserModel.email == userWemail.email).first()
#             user.is_verified = True
#         except NameError:
#             logger.warning("Password change for unknown user ID: %s", user_id)
#             self._db.rollback()
#             return "Ошибка смены пароля."
#         userWemail.set_password(newpasswd)
#         self._db.commit()
#         return ""
