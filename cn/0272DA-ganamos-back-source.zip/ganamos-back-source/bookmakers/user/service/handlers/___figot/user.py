# from datetime import datetime, timedelta
# import random
#
# from logging import getLogger
# from sqlalchemy.exc import SQLAlchemyError
# from tornado.options import options
#
# from betronic_core.db.models.user import UserModel
# from betronic_core.db.models.localbet import LocalBet
# from betronic_core.db.models.terminal import TerminalModel
# from betronic_core.db.models.money_transfer import MoneyTransferModel
# from betronic_core.db.models.partner import PartnerMoneyTransfer
# from betronic_core.db.models.notifications import Notification
# from betronic_core.db.models.bonus import PromoCodeModel
# from betronic_core.db.models.currency_rate import CurrencyRateModel
# from betronic_core.db.models.bonus_program import BonusProgramTransfer
# from bookmakers.handler.error import HandlerError
# from bookmakers.betsstore.purse_fetcher import Purse, PurseFetcher, PurseFetcherConstants
# from decimal import Decimal
# from bookmakers.web.session_manager import session_manager
# from betronic_core.db.converters import user_to_dict
#
# logger = getLogger(__name__)
#
#
# class StatusCode(object):
#     OK = 0
#     INTEGRITY_ERROR = 1
#     DB_ERROR = 2
#     USER_NOT_FOUND = 3
#     ACCESS_VIOLATION = 4
#     UNKNOWN_ERROR = 5
#
#
# class UserHandlerError(HandlerError):
#     pass
#
#
# class UserHandler():
#     UPDATEABLE_FIELDS = [
#         'nickname',
#         'phone',
#         'preferred_language',
#         'is_partner',
#         'payments'
#     ]
#
#     def __init__(self, db):
#         self._db = db
#
#     def get(self, user_id):
#         try:
#             user = UserModel.get_by_id(self._db, user_id)
#             return user
#         except SQLAlchemyError as e:
#             raise UserHandlerError(e, StatusCode.DB_ERROR)
#
#     def update(self, user_id, *args, **kwargs):
#         try:
#             user = UserModel.get_by_id(self._db, user_id)
#         except SQLAlchemyError as e:
#             raise UserHandlerError(e, StatusCode.DB_ERROR)
#         if not user:
#             raise UserHandlerError('user not found', StatusCode.USER_NOT_FOUND)
#         for key, value in list(kwargs.items()):
#             if key not in self.UPDATEABLE_FIELDS:
#                 raise UserHandlerError(
#                     'field %s is not updateable' % key, StatusCode.ACCESS_VIOLATION)
#             setattr(user, key, value)
#         self._db.add(user)
#
#     def get_user_remote_balance(self, user_id, email=None):
#         """EDIT BY CHILLY"""
#         user = UserModel.get_by_id(self._db, user_id)
#         if not user or (email is not None and user.email != email):
#             return None
#         terminal = TerminalModel.get_by_user_id(self._db, user_id)
#         if terminal:
#             return str(user.real_balance)
#         balance = Purse.get_balance(user.remote_email)
#         logger.info("Remote balance user(e: {}, re: {}), balance: {}".format(
#             email, user.remote_email, balance))
#         return balance
#
#     def get_user_bonus_balance(self, user_id):
#         """CREATE BY LEX"""
#         bon = BonusProgramTransfer.get_bonus_balance_by_user(self._db, user_id)
#         logger.info('return bonus (%s)', bon)
#         return bon
#
#     def get_user_local_balance(self, user_id, email=None):
#         """CREATE BY CHILLY"""
#         user = UserModel.get_by_id(self._db, user_id)
#         logger.info('getting balance')
#         balance = MoneyTransferModel.get_summ_balance_by_user(
#             self._db, user_id)
#         logger.info('summ balance for {}: {}'.format(user_id, balance))
#         user.real_balance = balance
#         self._db.add(user)
#         self._db.commit()
#         if not user or (email is not None and user.email != email):
#             return None
#         terminal = TerminalModel.get_by_user_id(self._db, user_id)
#         if terminal:
#             return str(user.balance)
#         balance = str(balance)
#         return balance
#
#     def get_user_allowed_bet(self, user_id):
#         """CREATE BY CHILLY"""
#         user = UserModel.get_by_id(self._db, user_id)
#         logger.info('getting allowed bet u:{}'.format("user_id"))
#         if not user.original_currency:
#             return True
#         bet_count = LocalBet.get_bet_count(self._db, user_id)
#         if bet_count <= 3:
#             return True
#         return False
#
#     def update_balance(self, user_id):  # local update balance
#         """CREATE BY CHILLY"""
#         user = UserModel.get_by_id(self._db, user_id)
#         balance = MoneyTransferModel.get_summ_balance_by_user(
#             self._db, user_id)
#         user.real_balance = balance
#         self._db.add(user)
#         self._db.commit()
#
#
#     def get_promo_code_by_user(self, user_id):
#         user = UserModel.get_by_id(self._db, user_id)
#         return user.promo_code.code
#
#     def partner_set_promo_code(self, user_id):
#         """CREATE BY BANANA"""
#         flag = True
#         while flag:
#             promo_code = ''.join(
#                 [random.choice(list('123456789')) for x in range(8)])
#             promo_model = PromoCodeModel.get_by_code(self._db, promo_code)
#             if not promo_model:
#                 flag = False
#                 new_promo_model = PromoCodeModel()
#                 new_promo_model.user_id = user_id
#                 new_promo_model.code = promo_code
#                 new_promo_model.bonus_amount_rub = options.PROMOCODE_BONUS
#                 self._db.add(new_promo_model)
#                 self._db.commit()
#         return "OK"
#
#     def _credit_partner_by_register(self, user):
#         PartnerMoneyTransfer.credit_registration_by_user(self._db, user)
#
#     def partner_reg_referral_by_link(self, user_id, referral_id):
#         """CREATE BY BANANA"""
#         user = UserModel.get_by_id(self._db, user_id)
#         if user:
#             if not user.referral_id and user_id != int(referral_id):
#                 user.referral_id = referral_id
#                 self._db.add(user)
#                 self._db.commit()
#                 self._credit_partner_by_register(user)
#                 return True
#         else:
#             return False
#
#     def _credit_partner_by_traffic(self, user):
#         PartnerMoneyTransfer.credit_trafic_by_user(self._db, user)
#
#     def check_partner_traffic_by_user(self, user_id):
#         """CREATE BY BANANA"""
#         user = UserModel.get_by_id(self._db, int(user_id))
#         if user.payments == UserModel.PAYMENTS['TRAFFIC']:
#             return True
#         else:
#             return False
#
#     def partner_traffic_balance_by_user(self, user_id):
#         """CREATE BY BANANA"""
#         user = UserModel.get_by_id(self._db, int(user_id))
#         if user:
#             self._credit_partner_by_traffic(user)
#             return True
#         else:
#             return False
#
#     def ban_user(self, user_id):
#         """CREATE BY BANANA"""
#         user = UserModel.get_by_id(self._db, user_id)
#         if user:
#             if user.is_banned:
#                 return True
#         return False
#
#     def get_partner_balance(self, user_id):
#         user = UserModel.get_by_id(self._db, user_id)
#         currency = user.original_currency or user.currency
#         balance = PartnerMoneyTransfer.get_partner_balance_by_user(
#             self._db, user_id)
#         user.partner_balance = balance
#         self._db.add(user)
#         self._db.commit()
#         profit = 0
#         if user.payments == UserModel.PAYMENTS['GAME']:
#             profit = user.partner_pay_bets
#         if user.payments == UserModel.PAYMENTS['TOP_UP']:
#             profit = CurrencyRateModel.convert(
#                 self._db,
#                 user.partner_pay_top_in,
#                 "RUB",
#                 currency
#             )
#         if user.payments == UserModel.PAYMENTS['REGISTRY']:
#             profit = CurrencyRateModel.convert(
#                 self._db,
#                 user.partner_pay_registration,
#                 "RUB",
#                 currency
#             )
#         if user.payments == UserModel.PAYMENTS['TRAFFIC']:
#             profit = CurrencyRateModel.convert(
#                 self._db,
#                 user.partner_pay_traffic,
#                 "RUB",
#                 currency
#             )
#         return balance, profit
