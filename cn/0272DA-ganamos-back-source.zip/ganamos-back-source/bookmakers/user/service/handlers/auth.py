from logging import getLogger
from betronic_core.db.converters import user_to_dict
from betronic_core.user_manager.manager import UserManager
from betronic_core.host_manager.manager import HostManager
from bookmakers.services.abstract_handler import IServiceHandler
from util.validators import get_request_body_for_security

logger = getLogger(__name__)


class AuthUserWithEmailHandler(IServiceHandler):
    def set_result(self):
        logger.info("Auth user with args: {}".format(self.args))
        request_from = self.get_arg("request_from")
        ip_address = self.get_arg("ip_address")

        email: str = self.get_arg("email", None)
        login: str = self.get_arg("login", None)
        host: str = self.get_arg("host", None)

        email = (email if email else login).lower()
        password = self.get_arg("password")
        user_manager = UserManager(self.db)
        host_manager = HostManager(self.db)
        user = user_manager.auth_email_user(email, password)
        user_manager.check_is_user(user)
        user_manager.user_check_can_auth(user)
        user_manager.set_last_visit(user)
        host_manager.check_is_can_visit_host(user.id, host)

        request_body = get_request_body_for_security(self.args)
        user_manager.security_log(user.id, ip_address, request_from, 'login', request_body)
        self.result = {
            "user": user_to_dict(user),
        }


class AuthUserWithPhoneOrNicknameHandler(IServiceHandler):
    def set_result(self):
        login = self.get_arg("login")
        user_manager = UserManager(self.db)
        email = UserManager(self.db).get_user_email_by_phone_or_nickname(login)
        if not email:
            raise Exception(f"User with  phone or nickname: {login} not exists")
        password = self.get_arg("password")
        user = user_manager.auth_email_user(email, password)
        user_manager.check_is_user(user)
        betroute_registration = user.betroute_registration
        user_manager.user_check_can_auth(user)
        user_manager.set_last_visit(user)
        self.result = {
            "user": user_to_dict(user),
            "remote_email": betroute_registration.remote_email,
            "remote_password": betroute_registration.get_remote_password()
        }


class AuthUserWithUsernameHandler(IServiceHandler):
    def set_result(self):
        logger.info("Auth user with args: {}".format(self.args))
        request_from = self.get_arg("request_from")
        ip_address = self.get_arg("ip_address")

        username = self.get_arg("username").lower()
        password = self.get_arg("password")
        user_manager = UserManager(self.db)
        user = user_manager.auth_email_user(username, password)
        user_manager.check_is_user(user)
        user_manager.user_check_can_auth(user)
        user_manager.set_last_visit(user)

        request_body = get_request_body_for_security(self.args)
        user_manager.security_log(user.id, ip_address, request_from, 'login', request_body)
        self.result = {
            "user": user_to_dict(user),
        }


class AuthUserWithPhoneHandler(IServiceHandler):
    def set_result(self):
        logger.info("Auth user with args: {}".format(self.args))
        phone = self.get_arg("phone")
        phone = phone.strip().strip("+")
        password = self.get_arg("password")
        user_manager = UserManager(self.db)
        user = user_manager.auth_email_user(phone, password)
        user_manager.check_is_user(user)
        betroute_registration = user.betroute_registration
        user_manager.user_check_can_auth(user)
        user_manager.set_last_visit(user)
        self.result = {
            "user": user_to_dict(user),
            "remote_email": betroute_registration.remote_email,
            "remote_password": betroute_registration.get_remote_password()
        }


class AuthSocialHandler(IServiceHandler):
    def set_result(self):
        logger.info("Auth user with args: {}".format(self.args))
        uid = str(self.get_arg("uid"))
        email = str(self.get_arg("email", ''))
        social_method = int(self.get_arg("social_method"))
        user_manager = UserManager(self.db)
        social_user = user_manager.auth_social(social_method, uid)
        user_manager.get_user_by_email_for_social(email, social_user)
        if not social_user.user:
            return
        user = social_user.user
        betroute_registration = user.betroute_registration
        logger.info("betroute_registration: {}".format(betroute_registration))
        UserManager.user_check_can_auth(user)
        user_manager.set_last_visit(user)
        self.result = {
            "user": user_to_dict(user),
            "remote_email": betroute_registration.remote_email,
            "remote_password": betroute_registration.get_remote_password()
        }
