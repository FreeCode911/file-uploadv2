from tornado.web import RequestHandler
from tornado.gen import coroutine

from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, \
    UserMixin
from bookmakers.user.service.service_connector import UserServiceConnector
from bookmakers.user.service import commands
from bookmakers.web.decorators import result_decorator

import bookmakers.user.schemas.profile as profile_schema

class PersonalDataHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    @coroutine
    def get(self):
        user = yield self.get_user_required()
        data = {'user_id': user['id']}
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.GetPersonalData, data)

        return result


class UpdateAdditionalDataHandler(RequestHandler, GetRequestArgsMixin,
                                  UserMixin):
    """
        Arguments POST: 'number_document', 'phone', 'gender', 'birth_date'
    """
    @result_decorator
    async def put(self):
        user = await self.get_user_required()

        body = profile_schema.UpdateProfileSchema(
            user_id=user['id'],
            **self.post_args_dict(),
        )

        connector = await UserServiceConnector.get_instance()
        result = await connector.execute_command(
            commands.UpdateAdditionalData, body.dict())

        return result
