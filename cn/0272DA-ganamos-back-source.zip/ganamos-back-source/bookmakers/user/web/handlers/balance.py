import ujson as json

from betronic_core.cache_manager.manager import CacheManager
from betronic_core.user_manager import error_codes
from bookmakers.services.commands import AbstractResult
from bookmakers.user.service import commands
from bookmakers.user.service.service_connector import UserServiceConnector
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin, LoggedRequestHandler
from bookmakers.web.session_manager import session_manager
from util.redis import AsyncRedisWrapperLocal, RedisBaseTypes

import bookmakers.user.schemas.daily_winnings as daily_winnings_schema


class GetUserLocalBalanceHandler(LoggedRequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self):
        user = await self.get_user_required()

        cache_key = CacheManager.get_user_balance_key(user['id'])

        connector = await UserServiceConnector.get_instance()
        data = await AsyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get(cache_key)

        if data:
            return AbstractResult(result=json.loads(data))

        result = await connector.execute_command(
            commands.GetBalanceByUserId, {'user_id': user['id']})

        if result.status == error_codes.USER_IS_BANNED:
            session_manager.reset(self)

        return result


class DailyWinnings(LoggedRequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self):
        connector = await UserServiceConnector.get_instance()
        user = await self.get_user_required()
        args = daily_winnings_schema.DailyWinningsSchema(
            user_id=user['id'],
            **self.get_args_dict()
        )
        result = await connector.execute_command(
            commands.DailyWinnings, args.dict())

        return result
