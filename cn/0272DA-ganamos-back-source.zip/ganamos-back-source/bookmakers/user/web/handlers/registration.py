from tornado.gen import coroutine
from logging import getLogger

from util.url import get_domain_from_host
from betronic_core.constants import RESULT_STATUS_OK
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin
from bookmakers.user.service.service_connector import UserServiceConnector
from bookmakers.user.service import commands
from bookmakers.web.request_handler_mixins import BaseLoginHandlerMixin
from bookmakers.web.decorators import result_decorator

import bookmakers.user.schemas.signup_auth as signup_auth_schema

logger = getLogger(__name__)


class RegistrationHandler(GetRequestArgsMixin, BaseLoginHandlerMixin):
    @result_decorator
    async def post(self):
        connector = await UserServiceConnector.get_instance()

        body = signup_auth_schema.SignupSchema(
            **self.post_args_dict()
        )
        result = await connector.execute_command(commands.RegisterUserWithUsername, body.dict())

        if result.error_message:
            self.set_status(400)
        return result


class PhoneRegistrationHandler(GetRequestArgsMixin, BaseLoginHandlerMixin):
    @result_decorator
    @coroutine
    def post(self):
        body = self.post_args_dict()
        domain = get_domain_from_host(self.request.host)
        body["domain"] = domain
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.RegisterUserWithPhone, body)

        if result.status != RESULT_STATUS_OK:
            return result

        return result


class UsernameRegistrationHandler(GetRequestArgsMixin, BaseLoginHandlerMixin):
    @result_decorator
    @coroutine
    def post(self):
        body = self.post_args_dict()
        domain = get_domain_from_host(self.request.host)
        body["domain"] = domain
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.RegisterUserWithUsername, body)
        if result.error_message:
            raise Exception(result.error_message)

        return result


class VerifyEmailHandler(BaseLoginHandlerMixin):
    @result_decorator
    @coroutine
    def get(self, code):
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.VerifyEmailByCode, {'code': code})
        user = result.result["user"]

        if result.status == RESULT_STATUS_OK:
            self._authenticate_user(user)
            result.result = "User is auth"

        return result


class SendCodeHandler(BaseLoginHandlerMixin, GetRequestArgsMixin):
    @result_decorator
    @coroutine
    def post(self):
        body = self.post_args_dict()
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.SendCode, body)
        return result
