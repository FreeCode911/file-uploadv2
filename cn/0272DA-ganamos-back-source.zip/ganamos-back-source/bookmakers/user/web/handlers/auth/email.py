from tornado.gen import coroutine

from bookmakers.web.request_handler_mixins import GetRequestArgsMixin
from bookmakers.user.service.service_connector import UserServiceConnector
from bookmakers.web.request_handler_mixins import BaseLoginHandlerMixin
from bookmakers.web.decorators import result_decorator
from bookmakers.user.service import commands
from betronic_core.constants import RESULT_STATUS_OK


class EmailAuthHandler(BaseLoginHandlerMixin, GetRequestArgsMixin):
    @result_decorator
    @coroutine
    def post(self):
        body = self.post_args_dict()
        body['request_from'] = self.request.headers.get('Referer')
        body['ip_address'] = self.request.headers.get("X-Real-IP") or self.request.remote_ip
        body['host'] = self.request.headers.get('Host')
        connector = yield UserServiceConnector.get_instance()
        result = yield connector.execute_command(
            commands.AuthUserWithEmail, body)
        if result.status == RESULT_STATUS_OK:
            user = result.result["user"]
            self._authenticate_user(user, [])
            result.result = "User is auth"

        return result
