from .handlers.blocklist import GetBlocklistHandler
from .handlers.get_slots_history import GetSlotsBetHistoryHandler
from .handlers.registration import RegistrationHandler
from .handlers.auth.username import UsernameAuthHandler
from .handlers.forgot_password import ChangePasswordHandler, RequiredChangePasswordHandler
from .handlers.auth.logout import LogoutHandler
from .handlers.check_user import CheckUserAuth
from .handlers.balance import GetUserLocalBalanceHandler, DailyWinnings
from .handlers.personal_data import PersonalDataHandler, UpdateAdditionalDataHandler
from .handlers.jackpot import JackpotHandler, GetJackpotDataHandler

url_prefix = r"/api/user"

urls = [
    (r'/check', CheckUserAuth),
    (r'/balance', GetUserLocalBalanceHandler),

    (r'/signup', RegistrationHandler),
    (r'/login', UsernameAuthHandler),
    (r'/logout', LogoutHandler),

    (r'/profile', PersonalDataHandler),
    (r'/profile/additional/update', UpdateAdditionalDataHandler),
    (r'/password/change', ChangePasswordHandler),
    (r'/required_change_password', RequiredChangePasswordHandler),

    (r'/getSlotsBetHistory', GetSlotsBetHistoryHandler),
    (r'/jackpot_is_shown', JackpotHandler),
    (r'/jackpot_data', GetJackpotDataHandler),

    (f'/daily_winnings', DailyWinnings),

    (f'/blocklist', GetBlocklistHandler)
]
