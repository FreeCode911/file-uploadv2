from typing import Optional, Union, List
from pydantic import BaseModel
from datetime import datetime


class GetSlotsBetHistorySchema(BaseModel):
    to_date: datetime
    from_date: datetime
    providers: Optional[List[str]]
    statuses: Optional[List[str]]
    types: Optional[List[str]]
    count: Optional[int]
    page: Optional[int]

    user_id: int
