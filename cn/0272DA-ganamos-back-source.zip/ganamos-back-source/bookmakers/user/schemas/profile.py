from typing import Optional, Union
from pydantic import BaseModel
from util.pydantic import DateStr, DateTimeStr


class UpdateProfileSchema(BaseModel):
    first_name: Optional[str]
    last_name: Optional[str]
    birth_date: Union[Optional[DateStr], Optional[DateTimeStr]]
    gender: Optional[str]

    # Data of requestor
    user_id: int
