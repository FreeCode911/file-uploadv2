from typing import List
from logging import getLogger

from betronic_core.notification_manager.manager import EmailNotificationManager
from betronic_core.payment_manager.manager import PaymentManager
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.user_manager.manager import UserManager
from bookmakers.services.abstract_handler import IServiceHandler
from util.date import convert_double_date

logger = getLogger(__name__)


class InitWithdrawalTransactionHandler(IServiceHandler):
    def set_result(self):
        user_id: int = self.get_arg("user_id")
        value: float = float(self.get_arg("value"))
        requisites = self.get_arg("requisites")
        payment_mode = self.get_arg("payment_mode")
        logger.info(
            """Creating withdrawal u:%s, value: %s, 
               paymode: %s, requisites %s""" % (user_id, value,
                                                payment_mode, requisites))

        payment_manager = PaymentManager(self.db)
        money_manager = MoneyManager(self.db)
        email_manager = EmailNotificationManager(self.db)
        user_manager = UserManager(self.db)

        money_manager.check_balance(user_id, value)
        # TODO: check if cashier allowed 4 this user
        payment_manager.check_allow_withdrawal(user_id, value)
        user = user_manager.get_user_by_id(user_id)
        money_manager.check_balance_withdrawal(user, value)

        cashier_id = user.parent_cashier_id

        transfer = money_manager.withdrawal_transfer(user_id, value)
        withdrawal = payment_manager.init_withdrawal(
            user, value, cashier_id, payment_mode, requisites, transfer)

        email_manager.create_withdrawal_email_to_user(withdrawal)
        email_manager.create_withdrawal_email_to_owner(withdrawal)

        self.result = {"withdrawal_id": withdrawal.id}


class CancelWithdrawalTransactionHandler(IServiceHandler):
    def set_result(self):
        user_id: int = self.get_arg("user_id")
        withdrawal_id: int = self.get_arg("withdrawal_id")
        logger.info("Cancel withdrawal u: %s, w_id: %s" % (user_id,
                                                           withdrawal_id))
        payment_manager = PaymentManager(self.db)
        money_manager = MoneyManager(self.db)
        withdrawal = payment_manager.check_close_withdrawal(withdrawal_id)
        transfer = money_manager.withdrawal_transfer_cancel(
            user_id, withdrawal.amount)
        cancel_withdrawal = payment_manager.close_withdrawal(
            user_id, withdrawal_id, transfer)

        self.result = {"withdrawal_id": cancel_withdrawal.id}


class HistoryWithdrawalHandler(IServiceHandler):
    def set_result(self):
        user_id: int = self.get_arg("user_id")

        logger.info("Creating payment u:{}".format(user_id))

        begin = self.get_arg("begin", None)
        end = self.get_arg("end", None)
        begin, end = convert_double_date(begin, end)

        manager = PaymentManager(self.db)

        withdrawals = manager.get_withdrawals(user_id, begin, end)
        fields = ["id", "payment_mode", "purse", "amount", "created_at",
                  "status", "is_closed"]

        self.result = [
            withdrawal.auto_dict_by_fields(fields)
            for withdrawal in withdrawals
        ]


class CashierListHandler(IServiceHandler):
    def set_result(self):
        user_id: int = self.get_arg("user_id")
        user_manager = UserManager(self.db)
        user = user_manager.get_user_by_id(user_id)
        cashier = user.p_cashier

        self.result = []

        cashier_data = {"id": cashier.id, "first_name": cashier.first_name}
        if cashier.additional_data:
            cashier_data['address'] = cashier.additional_data.address
            cashier_data['phone'] = cashier.additional_data.phone
        else:
            cashier_data['address'], cashier_data['phone'] = \
                ['Адрес не указан', 'Телефон не указан']
        self.result.append(cashier_data)
