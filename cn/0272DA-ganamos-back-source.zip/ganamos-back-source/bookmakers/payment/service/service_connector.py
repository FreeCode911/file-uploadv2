from bookmakers.services.service import ServiceConnector
from . import commands


class PaymentServiceConnector(ServiceConnector):
    def __init__(self):
        super(PaymentServiceConnector, self).__init__(commands)
