from tornado.web import RequestHandler
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import UserMixin, GetRequestArgsMixin
from bookmakers.payment.service.service_connector import PaymentServiceConnector
from bookmakers.payment.service import commands
from tornado.gen import coroutine
from tornado.options import options
from betronic_core.promocode_manager import errors as er
from bookmakers.services.commands import AbstractResult

import bookmakers.payment.schemas.payment as payment_schemas


class PromoCodeActivationHandler(RequestHandler,
                                 GetRequestArgsMixin, UserMixin):

    @result_decorator

    async def post(self):
        """
        request_args: code, user_id (*from session)
        response:
        """

        args = self.post_args_dict()
        user = await self.get_user_required()

        body = payment_schemas.PromoCodeActivationSchema(
            user_id=user["id"],
            **self.post_args_dict(),
        )

        connector = await PaymentServiceConnector.get_instance()

        check_promocode_result = await connector.execute_command(commands.CheckPromoCode, body.dict())

        if check_promocode_result.status != 0:
            return check_promocode_result

        check_available_for_user = await connector.execute_command(commands.CheckPromocodeAvailableForUser,
                                                                   body.dict())

        if check_available_for_user.status != 0:
            return check_available_for_user

        activate = await connector.execute_command(commands.PromoCodeActivate,
                                                   body.dict())

        return activate


class FillStobonusHandler(RequestHandler, UserMixin):

    @result_decorator
    @coroutine
    def get(self, *args, **kwargs):
        user = yield self.get_user_required()

        payment_connector = yield PaymentServiceConnector.get_instance()

        check_status = yield payment_connector.execute_command(
            commands.CheckPromocodeAvailableForUser, {
                'code': options.STOBONUS_DEFAULT_PROMOCODE,
                'user_id': user['id']})

        if not check_status.status == \
               er.USER_ALREADY_ACTIVATE_STOBONUS_PROMOCODE:
            return AbstractResult(er.USER_IS_NOT_STOBONUS_MEMBER, None,
                                  'Пользователь не является участником')

        stobonus_info = yield payment_connector.execute_command(
            commands.GetStobonusInfo, {'user_id': user['id']})

        if stobonus_info.result['isBannedByAdmin']:
            return AbstractResult(er.PROMOCODE_IS_BANNED_BY_ADMIN,
                           None, 'Пользователь забанен админом')

        if stobonus_info.result['hasWithdrawals']:
            return AbstractResult(
                er.USER_HAS_WITHDRAWALS_AFTER_PROMOCODE_ACTIVATION, None,
                'Пользователь выводил средства после активации промокода')

        if stobonus_info.result['progress'] < 100:
            return AbstractResult(
                er.USER_PROGRESS_LESS_THAN_100, None,
                'Пользователь еще не выполнил условия бонусной программы')

        fill_result = yield payment_connector.execute_command(
            commands.FillStobonus,
            {'user_id': user['id'],
             'personalBonusAmount':
                 stobonus_info.result['personalBonusAmount']})

        return fill_result
