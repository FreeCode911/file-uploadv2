from tornado.web import RequestHandler

from betronic_core.db.models.user import UserModel
from bookmakers.web.decorators import result_decorator
from bookmakers.payment.service.service_connector import PaymentServiceConnector
from bookmakers.payment.service import commands
from bookmakers.web.request_handler_mixins import UserMixin, GetRequestArgsMixin

import bookmakers.payment.schemas.payment as payment_schemas


role_permission = [UserModel.USER]


class AdminPaymentRequestHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def post(self, user=None):
        user = await self.get_user_required()
        user_role = user['role']

        body = payment_schemas.AdminPaymentRequestCreateSchema(
            user_id=user["id"],
            user_role=user_role,
            **self.post_args_dict(),
        )

        connector = await PaymentServiceConnector.get_instance()
        if user_role in role_permission:
            result = await connector.execute_command(
                commands.CreateAdminPaymentRequest, body.dict())
        else:
            raise Exception("Permission denied")

        return result

    @result_decorator
    async def get(self):
        user = await self.get_user_required()
        user_role = user['role']
        connector = await PaymentServiceConnector.get_instance()

        body = payment_schemas.GetAdminPaymentRequestSchema(
            user_id=user["id"],
            **self.get_args_dict(),
        )

        if user_role in role_permission:
            result = await connector.execute_command(
                commands.GetAdminPaymentRequest, body.dict())
        else:
            raise Exception("Permission denied")

        return result


class AdminPaymentMethodsHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user=None):
        user = await self.get_user_required()
        user_role = user['role']

        body = payment_schemas.AdminPaymenRequisitetRequestSchema(
            user_id=user["id"],
            **self.get_args_dict(),
        )

        connector = await PaymentServiceConnector.get_instance()
        if user_role in role_permission:
            result = await connector.execute_command(
                commands.GetAdminPaymentMethods, body.dict())
        else:
            raise Exception("Permission denied")

        return result
