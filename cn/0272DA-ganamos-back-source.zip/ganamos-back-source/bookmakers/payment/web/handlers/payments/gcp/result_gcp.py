import hashlib

from tornado.web import RequestHandler
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin
from tornado.gen import coroutine, Return
from logging import getLogger
from tornado.options import options

from bookmakers.services.service import ServiceError
from bookmakers.payment.service.service_connector import PaymentServiceConnector
from bookmakers.payment.service import commands

logger = getLogger(__name__)

STATUS_OK = 0
STATUS_TEMPORARY_ERROR_TRY_LATER = 1
STATUS_USER_NOT_FOUND = 5
STATUS_FORBIDDEN = 7
STATUS_OTHER_SERVER_ERROR = 300
STATUS_INVALID_CURRENCY = STATUS_FORBIDDEN

TO_BE_CONFIRMED = -2
PENDING = -1
FAILURE = 0
SUCCESS = 1


class ResultPaymentGlobalCloudPayHandler(RequestHandler, GetRequestArgsMixin):
    PAYMENT = 'GlobalCloudPay'
    pay_sys = options.PAYMENTS.get(PAYMENT)

    @staticmethod
    def _check_sign(args):
        sign = hashlib.sha256("".join([
                args['merNo'],
                args['gatewayNo'],
                args['tradeNo'],
                args['orderNo'],
                args['orderCurrency'],
                args['orderAmount'],
                args['orderStatus'],
                args['orderInfo'],
                options.PAYMENTS.get('GlobalCloudPay').get('sign_key')
            ]).encode("utf-8")).hexdigest()
        if args['signInfo'] == sign.upper():
            return True
        else:
            return False

    @staticmethod
    def _gen_sign(args):
        sign = hashlib.sha256("".join([
                args['merNo'],
                args['gatewayNo'],
                args['tradeNo'],
                args['orderNo'],
                args['orderCurrency'],
                args['orderAmount'],
                args['orderStatus'],
                args['orderInfo'],
                options.PAYMENTS.get('GlobalCloudPay').get('sign_key')
            ]).encode("utf-8")).hexdigest().upper()
        return sign

    @coroutine
    def post(self):
        args = self.get_args_dict()
        logger.info(
            "GlobalCloudPay request results: %s" % args)

        gateway = self.pay_sys.get('merchant_info').get('gateway')
        merchant_no = self.pay_sys.get('merchant_info').get('merchant_no')

        if self._check_sign(args) and args['merNo'] == merchant_no\
                and args['gatewayNo'] == gateway:
            try:
                amount = args['orderAmount']
                transaction_id = args['orderNo']
                body = {
                    'payment_id': transaction_id,
                    'value': amount
                }
                payments_service = yield PaymentServiceConnector.get_instance()
                result = yield payments_service.execute_command(
                    commands.ResultPaymentTransaction, body)
                self.write("OK")
            except ServiceError:
                args['result'] = STATUS_OTHER_SERVER_ERROR  # temporary error
                args['comment'] = "Internal server problem"
                logger.error(
                    'Server error in GlobalCloudPay request processing : %s' % args)
                self.write("NO")
        else:
            logger.error(
                'Not current sign in GlobalCloudPay request processing : %s' % args)
            self.write("NO")
        raise Return()

