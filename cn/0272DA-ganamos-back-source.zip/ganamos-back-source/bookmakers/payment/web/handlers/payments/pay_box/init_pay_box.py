from base64 import b64encode
from urllib.parse import urlencode
from logging import getLogger
from datetime import datetime, timedelta
import hashlib
import random
import collections
import json

from tornado import httpclient
from tornado.web import RequestHandler
from tornado.gen import coroutine
from tornado.options import options
from bookmakers.services.commands import AbstractResult
from bookmakers.payment.service.service_connector \
    import PaymentServiceConnector
from bookmakers.payment.service import commands
from bookmakers.web.request_handler_mixins import UserMixin, \
    GetRequestArgsMixin


logger = getLogger(__name__)

class InitPaymentPaxBoxHandler(RequestHandler, GetRequestArgsMixin,
                                   UserMixin):
    PAYMENT = 'PAY_BOX'

    @classmethod
    def _gen_sign(cls, dictParam, strUrl, secretKey):
        arrSortedParam = collections.OrderedDict(sorted(dictParam.items()))
        resultString = strUrl
        for key in arrSortedParam:
            resultString += str(arrSortedParam[key]) + ";"
        resultString += secretKey
        return hashlib.md5(resultString.encode('utf-8')).hexdigest()

    @classmethod
    def _gen_salt(cls):
        return str(random.randint(0, 181426))

    @coroutine
    def post(self, user=None):
        try:
            body = self.post_args_dict()
            logger.info(
                'Pay_box init processing, args= %s' % body)
            user = yield self.get_user_required()
            body["user_id"] = user["id"]
            connector = yield PaymentServiceConnector.get_instance()
            result = yield connector.execute_command(
                commands.InitPaymentPayBox, body)
            salt = self._gen_salt()
            url = options.PAYMENTS['PAY_BOX']['url']
            script_name = options.PAYMENTS['PAY_BOX']['script_name']

            data = {
                'pg_merchant_id': options.PAYMENTS['PAY_BOX']['id'],
                'pg_amount': result.result['payment_amount'],
                'pg_order_id': result.result['payment_id'],
                'pg_description': 'Пополнение баланса',
                'pg_currency': result.result['payment_currency'],
                'pg_payment_system': result.result.get('payment_mode',
                                                       'EPAYKZT'),
                'pg_salt': salt,
            }
            sign = self._gen_sign(data, script_name, str(
                options.PAYMENTS[self.PAYMENT]['key_pay']))
            data['pg_sig'] = sign
            logger.info('control_sign %s'
                        % (data['pg_sig']))
            response = {'url': url + urlencode(data)}
            response = AbstractResult(0, response, None).to_dict()
        except Exception as e:
            logger.error(
                'PAY_BOX error init processing, '
                'args= %s \n error= %s' % (body, e))
            response = AbstractResult(1, None, "{}".format(e)).to_json()
        self.write(response)
