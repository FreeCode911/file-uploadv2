from bookmakers.agent_admin.web.handlers.blocklist import UserBlocklistHandler
from bookmakers.agent_admin.web.handlers.user import UserHandler, UserDetailHandler
from bookmakers.agent_admin.web.handlers.tree import UserTreeHandler
from bookmakers.agent_admin.web.handlers.payment import UserPaymentHandler, UserPaymentHistoryHandler
from bookmakers.agent_admin.web.handlers.slots import UserSlotsBetHistoryHandler, UserSlotsBetDetailHistoryHandler
from bookmakers.agent_admin.web.handlers.statistic import (UserProviderStatisticHandler, UserPersonalStatisticHandler,
                                                           UserStatisticHandler, UserRankingHandler)
from bookmakers.agent_admin.web.handlers.notifications import AgentNotificationsHandler
from bookmakers.agent_admin.web.handlers.ranking import AgentRankingHandler
from bookmakers.agent_admin.web.handlers.finance import UserFinanceHistoryHandler
from bookmakers.agent_admin.web.handlers.bets import (
    UserBetHistoryHandler,
    UserSportCouponBetsHandler,
    UserSportCouponHistoryHandler,
)


url_prefix = '/api/agent_admin'


urls = [
    (r'/user/', UserHandler),
    (r'/user/(?P<user_id>[0-9]+)/', UserDetailHandler),
    (r'/user/(?P<user_id>[0-9]+)/tree/', UserTreeHandler),
    (r'/user/(?P<user_id>[0-9]+)/payment/', UserPaymentHandler),
    (r'/user/(?P<user_id>[0-9]+)/payment/history/', UserPaymentHistoryHandler),
    (r'/user/(?P<user_id>[0-9]+)/slots/history/', UserSlotsBetHistoryHandler),
    (r'/user/(?P<user_id>[0-9]+)/bets/history/', UserBetHistoryHandler),
    (r'/user/(?P<user_id>[0-9]+)/statistic/', UserStatisticHandler),
    (r'/user/(?P<user_id>[0-9]+)/ranking/', UserRankingHandler),
    (r'/user/(?P<user_id>[0-9]+)/statistic/provider/', UserProviderStatisticHandler),
    (r'/user/(?P<user_id>[0-9]+)/statistic/player/', UserPersonalStatisticHandler),
    (r'/user/(?P<user_id>[0-9]+)/finance/history/', UserFinanceHistoryHandler),
    (r'/user/(?P<user_id>[0-9]+)/blocklist/', UserBlocklistHandler),
    (r'/user/(?P<user_id>[0-9]+)/slots/history/bet/(?P<bet_id>[0-9]+)/', UserSlotsBetDetailHistoryHandler),
    (r"/user/sport/coupon/", UserSportCouponHistoryHandler),
    (r"/user/sport/coupon/(?P<coupon_id>[0-9]+)/bets/", UserSportCouponBetsHandler),
    (r'/notifications', AgentNotificationsHandler),
    (r'/ranking', AgentRankingHandler),
]
