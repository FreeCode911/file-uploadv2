import ujson as json
from tornado.web import RequestHandler
from betronic_core.cache_manager.manager import AsyncCacheManager
from bookmakers.services.commands import AbstractResult
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from util.redis import AsyncRedisWrapperLocal, RedisBaseTypes


class AgentNotificationsHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self):
        agent = await self.get_partner_agent()

        notification_key = await AsyncCacheManager.get_notifications_key()
        data = await AsyncRedisWrapperLocal(RedisBaseTypes.NOTIFICATIONS).get(notification_key)
        if data:
            notifications_dict = json.loads(data)
            available_notifications = []
            if 'notifications' in notifications_dict:
                notifications = notifications_dict['notifications']
                for notification_id, notification_data in notifications.items():
                    if not notification_data['is_closed'] and agent['id'] \
                            not in notification_data['hidden_for_user_ids']:
                        notification_data_without_hidden = {key: value for key, value in notification_data.items() if
                                                            key != 'hidden_for_user_ids'}
                        notification_data_without_hidden['id'] = notification_id
                        available_notifications.append(notification_data_without_hidden)
            return AbstractResult(result=available_notifications[::-1])
        else:
            return AbstractResult(result=[])

    @result_decorator
    async def post(self):
        agent = await self.get_partner_agent()
        args = self.post_args_dict()
        notification_id = args.get("notification_id")
        await AsyncCacheManager.hide_agent_notification_from_cache(agent['id'], str(notification_id))
        return AbstractResult(result='ok')
