from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.schemas import finance as finance_schemas


class UserFinanceHistoryHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        agent = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = finance_schemas.FinanceRequestSchema(
            **self.get_args_dict(),
            admin_id=agent['id'],
            admin_role=agent['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserFinanceHistory, body.dict()
        )

        return result
