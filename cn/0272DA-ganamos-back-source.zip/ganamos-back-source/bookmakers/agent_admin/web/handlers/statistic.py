import logging
from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.schemas import statistic as statistic_schemas


logger = logging.getLogger(__name__)


class UserStatisticHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = statistic_schemas.UserStatisticRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserStatistic, body.dict()
        )

        return result


class UserRankingHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = statistic_schemas.UserStatisticRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserRanking, body.dict()
        )

        return result


class UserProviderStatisticHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = statistic_schemas.UserProviderStatisticRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserProviderStatistic, body.dict()
        )

        return result


class UserPersonalStatisticHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = statistic_schemas.UserPersonalStatisticRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserPersonalStatistic, body.dict()
        )

        return result
