import ujson as json
from tornado.web import RequestHandler
from betronic_core.cache_manager.manager import AsyncCacheManager
from bookmakers.services.commands import AbstractResult
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from util.redis import AsyncRedisWrapperLocal, RedisBaseTypes
from util.validators import get_username_mask
from tornado.options import options


class AgentRankingHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self):
        agent = await self.get_partner_agent()

        agent_ranking_key = await AsyncCacheManager.get_ranking_key()
        data = await AsyncRedisWrapperLocal(RedisBaseTypes.NETWIN_SETTINGS).get(agent_ranking_key)
        if data:
            ranking_list = json.loads(data)

            my_rang = ranking_list.get(str(agent['id']))
            if my_rang:
                my_rang["position"] = list(ranking_list.keys()).index(str(agent['id']))
            agent_ranking = {}
            for key in list(ranking_list.keys())[:options.TOP_AGENTS_COUNT]:
                agent_ranking[key] = ranking_list[key]
                agent_ranking[key]['username'] = get_username_mask(agent_ranking[key]['username'])

            result_data = {
                'agent_ranking': agent_ranking,
                'my_rang': my_rang
            }
            return AbstractResult(result=result_data)
        else:
            return AbstractResult(result=[])
