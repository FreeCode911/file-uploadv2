from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.schemas import blocklist


class UserBlocklistHandler(RequestHandler, GetRequestArgsMixin, UserMixin):

    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = blocklist.GetUserBlocklistSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            user_id=user_id
        )
        result = await connector.execute_command(
            commands.GetBlocklist, body.dict()
        )

        return result

    @result_decorator
    async def post(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = blocklist.UserBlocklistSchema(
            **self.post_args_dict(),
            admin_id=user['id'],
            user_id=user_id
        )
        result = await connector.execute_command_with_timeout(
            commands.ChangeBlocklist, body.dict(), timeout=120
        )

        return result
