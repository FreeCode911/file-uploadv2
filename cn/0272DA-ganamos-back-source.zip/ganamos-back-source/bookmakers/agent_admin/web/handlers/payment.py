import logging
from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands

import bookmakers.agent_admin.schemas.payment as payment_schemas


logger = logging.getLogger(__name__)


class UserPaymentHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def post(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = payment_schemas.PaymentRequestSchema(
            **self.post_args_dict(),
            user_id=user_id,
            admin_id=user['id'],
            admin_role=user['role']
        )

        result = await connector.execute_command(
            commands.CreateUserPayment, body.dict()
        )

        return result


class UserPaymentHistoryHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = payment_schemas.PaymentHistoryRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserPaymentHistory, body.dict()
        )

        return result
