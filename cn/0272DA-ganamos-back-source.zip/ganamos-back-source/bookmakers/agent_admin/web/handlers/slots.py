from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.schemas import slots as slots_schemas


class UserSlotsBetHistoryHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = slots_schemas.SlotsBetHistoryRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        result = await connector.execute_command(
            commands.GetUserSlotsBetHistory, body.dict()
        )

        return result


class UserSlotsBetDetailHistoryHandler(
    RequestHandler,
    GetRequestArgsMixin,
    UserMixin,
):
    @result_decorator
    async def get(self, user_id: int, bet_id: int):
        await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()
        result = await connector.execute_command(
            commands.GetSlotsDetailHistory, dict(bet_id=bet_id)
        )
        return result
