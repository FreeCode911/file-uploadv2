import asyncio
from logging import getLogger
from tornado.web import RequestHandler

from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from betronic_core.cache_manager.manager import AsyncCacheManager

import bookmakers.agent_admin.schemas.user as user_schemas


logger = getLogger(__name__)
loop = asyncio.get_event_loop()


class UserHandler(RequestHandler, GetRequestArgsMixin, UserMixin):

    @result_decorator
    async def post(self):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = user_schemas.CreateUserRequestSchema(
            **self.post_args_dict(),
            admin_id=user['id'],
            admin_role=user['role']
        )

        result = await connector.execute_command(
            commands.CreateUser,
            body.dict()
        )

        return result

    @result_decorator
    async def get(self):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = user_schemas.GetUserListRequestSchema(
            **self.get_args_dict(),
            admin_id=user['id'],
            admin_role=user['role']
        )

        result = await connector.execute_command(
            commands.GetParentUserList,
            body.dict()
        )

        return result


class UserDetailHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = {
            'user_id': user_id,
            'admin_id': user['id'],
            'admin_role': user['role']
        }

        result = await connector.execute_command(
            commands.GetUserData,
            body
        )

        return result

    @result_decorator
    async def patch(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = user_schemas.PatchUserRequestSchema(
            **self.post_args_dict(),
            user_id=user_id,
            admin_id=user['id'],
            admin_role=user['role']
        )

        x_real_ip = self.request.headers.get("X-Real-IP")

        abstract_result = await connector.execute_command(
            commands.ChangeUserData,
            {
                **body.dict(),
                'request_from': self.request.headers.get('Referer'),
                'ip_address': x_real_ip or self.request.remote_ip
            }
        )

        banned_user_ids = abstract_result.get_result() \
            .pop('on_update', {}).get('banned_user_ids', [])

        if banned_user_ids:
            loop.create_task(
                AsyncCacheManager.close_all_sessions_by_user_ids(banned_user_ids)
            )

        return abstract_result
