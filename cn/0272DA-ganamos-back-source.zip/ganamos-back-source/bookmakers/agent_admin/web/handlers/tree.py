import asyncio
import logging
from tornado.web import RequestHandler

from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, UserMixin
from bookmakers.agent_admin.service.service_connector import AgentAdminServiceConnector
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.schemas import tree as tree_schemas
from betronic_core.cache_manager.manager import AsyncCacheManager


logger = logging.getLogger(__name__)
loop = asyncio.get_event_loop()


class UserTreeHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        user = await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()

        body = {
            **self.get_args_dict(),
            'user_id': user_id,
            'admin_id': user['id'],
            'admin_role': user['role']
        }

        result = await connector.execute_command(
            commands.GetUserTree, body
        )

        return result

    @result_decorator
    async def patch(self, user_id: int):
        user = await self.get_partner_agent()
        agent_connector = await AgentAdminServiceConnector.get_instance()

        body = tree_schemas.ChangeUserTreeRequestSchema(
            **self.post_args_dict(),
            admin_id=user['id'],
            admin_role=user['role'],
            user_id=user_id
        )

        abstract_result = await agent_connector.execute_command(
            commands.ChangeUserTree, body.dict()
        )

        banned_user_ids = abstract_result.get_result()\
            .pop('on_update', {}).get('banned_user_ids')

        if banned_user_ids:
            loop.create_task(
                AsyncCacheManager.close_all_sessions_by_user_ids(banned_user_ids)
            )

        return abstract_result
