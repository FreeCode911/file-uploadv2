from datetime import datetime, timedelta

from tornado.web import RequestHandler

from bookmakers.agent_admin.schemas.bets import SportCouponSchema
from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.service.service_connector import (
    AgentAdminServiceConnector,
)
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import (
    GetRequestArgsMixin,
    UserMixin,
)
from util.error import InvalidRequestData


class UserBetHistoryHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, user_id: int):
        args = self.get_args_dict()
        user = await self.get_partner_agent()
        if "date_from" not in args:
            args["date_from"] = datetime.now() - timedelta(days=1)
        if "date_to" not in args:
            args["date_to"] = datetime.now()

        if not isinstance(args["date_from"], str):
            args["date_from"] = args["date_from"].strftime("%Y-%m-%d")
        if not isinstance(args["date_to"], str):
            args["date_to"] = args["date_to"].strftime("%Y-%m-%d")

        if args["date_from"] > args["date_to"]:
            raise InvalidRequestData(-3, "Date To cannot be earlier than Date From")
        body = {
            "username": args.get("username"),
            "date_from": args["date_from"],
            "status": args.get("status"),
            "date_to": args["date_to"],
            "count": args.get("count"),
            "page": args.get("page"),
            "admin_id": user["id"],
            "user_id": user_id,
        }
        connector = await AgentAdminServiceConnector.get_instance()
        result = await connector.execute_command(commands.GetUserBetsHistory, body)
        return result


class UserSportCouponHistoryHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self):
        args = self.get_args_dict()
        user = await self.get_partner_agent()

        body = SportCouponSchema(**args, agent_id=user["id"])

        connector = await AgentAdminServiceConnector.get_instance()
        result = await connector.execute_command(commands.GetSportCoupons, body.dict())
        return result


class UserSportCouponBetsHandler(RequestHandler, GetRequestArgsMixin, UserMixin):
    @result_decorator
    async def get(self, coupon_id: int):
        await self.get_partner_agent()
        connector = await AgentAdminServiceConnector.get_instance()
        result = await connector.execute_command(
            commands.GetCouponBets, {"coupon_id": coupon_id}
        )
        return result
