from typing import Optional, Union
from pydantic import BaseModel, validator
from util.pydantic import DateStr, DateTimeStr
from bookmakers.web.validator import check_null


class SlotsBetHistoryRequestSchema(BaseModel):
    username: Optional[str]
    date_from: Union[Optional[DateStr], Optional[DateTimeStr]]
    date_to: Union[Optional[DateStr], Optional[DateTimeStr]]
    tz: Optional[int]
    provider: Optional[str]
    status: Optional[str]
    game_type: Optional[str]

    page: int = 0
    count: int = 10

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: Optional[int]
    user_login: Optional[str]

    user_login_check_null = validator('user_login', allow_reuse=True)(check_null)
    user_id_check_null = validator('user_id', allow_reuse=True)(check_null)
    username_check_null = validator('username', allow_reuse=True)(check_null)
