from typing import Optional, Union
from datetime import date, datetime, time
from decimal import Decimal
from betronic_core.db.models.user import UserModel

from pydantic import BaseModel, validator


class BaseModel(BaseModel):
    class Config:
        orm_mode = True


class SportCouponSchema(BaseModel):
    id: int
    status: str
    user_id: int
    is_express: bool
    coef: float
    username: Optional[str]
    amount: float
    currency: str
    provider: str
    remote_coupon_id: str
    possible_win_amount: float
    created_at: datetime

    @validator("created_at")
    def datetime_to_string(cls, v: date) -> str:
        return v.isoformat()


class CouponBetSchema(BaseModel):
    event_name: str
    is_live: bool
    country_name: str
    tournament_name: str
    sport_name: str
    outcome: str
    coef: float
    score: str
    status: str
    outcome: str
