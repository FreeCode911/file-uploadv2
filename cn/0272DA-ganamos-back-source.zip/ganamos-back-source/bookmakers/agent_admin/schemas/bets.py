from typing import Optional, Union

from pydantic import validator

from util.pydantic import DateStr
from bookmakers.web.validator import check_null
from datetime import date, datetime, time
from util.schemas import BaseFilterSchema


class BetHistoryRequestSchema(BaseFilterSchema):
    """
    is_direct_structure: user structure if true, else full substructure
    """

    username: Optional[str]
    date_from: Optional[DateStr]
    date_to: Optional[DateStr]
    tz: Optional[int]
    status: Optional[str]
    coupon_id: Optional[str]
    is_direct_structure: bool = False

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: Optional[int]
    user_login: Optional[str]

    user_login_check_null = validator("user_login", allow_reuse=True)(check_null)
    user_id_check_null = validator("user_id", allow_reuse=True)(check_null)
    username_check_null = validator("username", allow_reuse=True)(check_null)
    status_check_null = validator("status", allow_reuse=True)(check_null)
    coupon_id_null = validator("coupon_id", allow_reuse=True)(check_null)


class SportCouponSchema(BaseFilterSchema):
    created_at__gte: Union[datetime, date] = date.today()
    created_at__lte: Union[datetime, date] = datetime.combine(date.today(), time.max)
    amount: Optional[int] = None
    coupon_id: Optional[int] = None
    user_id: Optional[int] = None
    username: Optional[str] = None
    type: Optional[str] = "all"
    status: Optional[str] = "all"

    agent_id: int
