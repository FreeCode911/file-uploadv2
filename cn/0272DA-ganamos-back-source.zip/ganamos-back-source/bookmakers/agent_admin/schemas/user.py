from typing import Optional
from pydantic import BaseModel, validator

from betronic_core.db.models.user import UserModel
from util.pydantic import DateStr


class CreateUserRequestSchema(BaseModel):
    username: str
    password: str
    role: str
    first_name: str = ''
    last_name: str = ''
    email: str = ''
    is_withdrawal_access: bool = True
    is_deposit_access: bool = True
    commission_percent: int = 0
    can_create_only_player: bool = False

    # Data of requestor
    admin_id: int
    admin_role: str

    @validator('role')
    def user_role_validator(cls, role: str):
        if role not in [UserModel.PARTNER_AGENT, UserModel.USER]:
            raise Exception(f'Create role incorrect')

        return role


class GetUserListRequestSchema(BaseModel):
    is_banned: Optional[bool]
    is_direct_structure: Optional[bool]
    user_id: Optional[int]
    username: Optional[str]
    source_username: Optional[str]
    role: Optional[str]
    page: int = 0
    count: int = 20
    order_by: str = None
    date_from: Optional[DateStr]
    date_to: Optional[DateStr]

    # Data of requestor
    admin_id: int
    admin_role: str

    @validator('role')
    def user_role_validator(cls, role: str):
        if role and role not in [UserModel.PARTNER_AGENT, UserModel.USER]:
            raise Exception(f'Request role incorrect')

        return role


class PatchUserRequestSchema(BaseModel):
    # Update fields
    first_name: Optional[str]
    last_name: Optional[str]
    email: Optional[str]
    password: Optional[str]
    is_banned: Optional[bool]
    is_withdrawal_access: Optional[bool]
    is_deposit_access: Optional[bool]
    commission_percent: Optional[int]
    can_create_only_player: bool = False

    # Data of requestor
    user_id: int
    admin_id: int
    admin_role: str
