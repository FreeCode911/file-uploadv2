from typing import Optional
from pydantic import BaseModel


class ChangeUserTreeRequestSchema(BaseModel):
    is_disable: Optional[bool]

    # Data of requestor
    user_id: int
    admin_id: int
    admin_role: str
