from typing import Optional
from pydantic import BaseModel, validator
from tornado.options import options

from util.pydantic import DateStr


class FinanceRequestSchema(BaseModel):
    date_from: Optional[DateStr]
    date_to: Optional[DateStr]
    tz: Optional[int]
    currency: Optional[str]
    only_user_transfers: bool = False
    only_personal_higher_transfers: bool = False
    is_deposit: bool = False
    is_withdrawal: bool = False

    page: int = 0
    count: int = 20

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: int

    @validator('currency')
    def validate_operation(cls, currency: str):
        if currency and currency not in options.AVAILABLE_CURRENCIES:
            raise Exception(f"Currency is not enabled in project")

        return currency
