from typing import Optional, List
from pydantic import BaseModel


class GetUserBlocklistSchema(BaseModel):
    admin_id: int
    user_id: Optional[int]


class UserBlocklistSchema(BaseModel):

    admin_id: int
    user_id: Optional[int]
    action: str
    providers: List
    is_full_branch: bool
    category: Optional[str]
