from typing import Optional
from pydantic import BaseModel, validator

from betronic_core.db.models.user import UserModel
from util.pydantic import DateStr, DateTimeStr

from betronic_core.constants import UserTypePaymentTransfer
from bookmakers.web.validator import check_null


class PaymentRequestSchema(BaseModel):
    user_id: int
    amount: float
    operation: int
    note: Optional[str]
    is_bonus: Optional[bool]
    bonus_amount: Optional[float]
    percent_amount: Optional[float]

    # Data of requestor
    admin_id: int
    admin_role: str

    @validator('operation')
    def validate_operation(cls, operation: str):
        if operation not in [
            UserTypePaymentTransfer.TYPE_DEPOSIT,
            UserTypePaymentTransfer.TYPE_WITHDRAWAL
        ]:
            raise Exception(f"Payment operation '{operation}' incorrect")

        return operation


class PaymentHistoryRequestSchema(BaseModel):
    """
    is_direct_structure: linear user structure if true, else full substructure
    is_higher_transaction_only: return the initiators of payments
    is_withdrawal_transfers: return withdraw types
    is_deposit_transfers: return deposit types
    """

    role: str
    username: Optional[str]
    date_from: Optional[DateTimeStr]
    date_to: Optional[DateTimeStr]
    is_direct_structure: bool = False
    is_higher_transaction_only: bool = False
    is_withdrawal_transfers: bool = True
    is_deposit_transfers: bool = True
    is_bonus_deposits: bool = False

    transfers_only: bool = True

    page: int = 0
    count: int = 20

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: Optional[int]
    user_login: Optional[str]

    user_login_check_null = validator('user_login', allow_reuse=True)(check_null)
    user_id_check_null = validator('user_id', allow_reuse=True)(check_null)
    username_check_null = validator('username', allow_reuse=True)(check_null)


    @validator('role')
    def user_role_validator(cls, role: str):
        if role not in [UserModel.PARTNER_AGENT, UserModel.USER]:
            raise Exception(f'Request role incorrect')

        return role
