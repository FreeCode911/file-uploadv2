from typing import Optional
from pydantic import BaseModel, validator

from util.pydantic import DateStr
from bookmakers.web.validator import check_null


class UserStatisticRequestSchema(BaseModel):
    """
    is_direct_only: linear user structure if true, else full substructure
    """

    date_from: Optional[DateStr]
    date_to: Optional[DateStr]
    tz: Optional[int]
    is_direct_only: bool = False

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: int
    is_user_ranking: bool = False


class UserProviderStatisticRequestSchema(BaseModel):
    """
    is_direct_only: linear user structure if true, else full substructure
    """

    date_from: Optional[DateStr]
    date_to: Optional[DateStr]
    tz: Optional[int]
    is_direct_only: bool = False

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: int


class UserPersonalStatisticRequestSchema(BaseModel):
    """
    is_direct_only: linear user structure if true, else full substructure
    """

    date_from: Optional[DateStr]
    date_to: Optional[DateStr]
    username: Optional[str]
    is_direct_only: bool = False
    page: int = 0
    count: int = 20

    # Data of requestor
    admin_id: int
    admin_role: str
    user_id: Optional[int]
    user_login: Optional[str]

    user_login_check_null = validator('user_login', allow_reuse=True)(check_null)
    user_id_check_null = validator('user_id', allow_reuse=True)(check_null)
