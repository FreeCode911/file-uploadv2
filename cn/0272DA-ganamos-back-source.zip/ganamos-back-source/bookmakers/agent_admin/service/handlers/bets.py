from itertools import chain

from bookmakers.services.abstract_handler import IServiceHandler
from betronic_core.db.models.user import UserModel
from betronic_core.games_history_manager.manager import GamesHistoryManager
from betronic_core.user_manager.manager import UserManager
from bookmakers.agent_admin.schemas.response.sport_history import (
    CouponBetSchema,
    SportCouponSchema,
)
from .slots import UserSlotBetHistoryHandler
from util.validators import get_skip_limit
from util.date import convert_to_required_project_timezone


class UserBetHistoryHandler(IServiceHandler):
    def set_result(self):
        self.args["provider"] = "DIGITAIN"
        slots_handler = UserSlotBetHistoryHandler(self.args, self.db)
        slots_handler.set_result()
        self.result = slots_handler.result


class UserSportCouponHandler(IServiceHandler):
    def set_result(self):
        user_id = self.get_arg("user_id")
        agent_id = self.get_arg("agent_id")
        date_from = self.get_arg("created_at__gte")
        date_to = self.get_arg("created_at__lte")
        coupon_id = self.get_arg("coupon_id")
        username = self.get_arg("username", None)
        type = self.get_arg("type")
        status = self.get_arg("status")
        tz = self.get_arg('tz', default=None)
        page = self.get_arg("page")
        count = self.get_arg("count")

        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)
        skip, limit = get_skip_limit(page, count)

        games_history_manager = GamesHistoryManager(self.db)

        user_manager = UserManager(self.db)
        admin_db = user_manager.get_user_by_id(agent_id)
        if user_id is not None:
            user_manager.get_substructure_user(
                source_user=admin_db, target_user_id=user_id
            )
            coupons, count = games_history_manager.fetch_coupons(
                start_date=date_from,
                end_date=date_to,
                user_id=user_id,
                coupon_id=coupon_id,
                type=type,
                status=status,
                limit=limit,
                offset=skip,
            )

        elif username is not None:
            users_subq = UserModel.get_descendant_by_ltree_path_subq(
                db=self.db,
                source_entity_id=admin_db.id,
                ltree_path=admin_db.structure_path,
                username=username,
                is_direct_structure=False,
                is_source=False
            )

            coupons, count = games_history_manager.fetch_coupons(
                start_date=date_from,
                end_date=date_to,
                user_id=users_subq,
                coupon_id=coupon_id,
                type=type,
                status=status,
                limit=limit,
                offset=skip,
            )

        else:
            users_subq = UserModel.get_list_users_by_entity_user_subq(
                db=self.db,
                entity_user=admin_db,
                target_role=UserModel.USER
            )
            user_ids = self.db.query(users_subq.c.id)

            coupons, count = games_history_manager.fetch_coupons(
                start_date=date_from,
                end_date=date_to,
                user_id=user_ids,
                coupon_id=coupon_id,
                type=type,
                status=status,
                offset=skip,
                limit=limit
            )

        data = []
        for coupon in coupons:
            coupon_dict = SportCouponSchema.from_orm(coupon[0]).dict()
            coupon_dict['username'] = coupon[1]
            data.append(coupon_dict)

        self.result = {"items": data, "count": count}


class UserCouponBetsHandler(IServiceHandler):
    def set_result(self):
        coupon_id = self.get_arg("coupon_id")
        manager = GamesHistoryManager(self.db)
        data = manager.fetch_bets(coupon_id)

        self.result = [CouponBetSchema.from_orm(bet).dict() for bet in data]
