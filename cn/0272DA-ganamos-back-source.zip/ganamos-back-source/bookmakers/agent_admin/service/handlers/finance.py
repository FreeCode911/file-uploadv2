from logging import getLogger
from tornado.options import options

from betronic_core.agent_payment_manager.manager import AgentPaymentStatisticBotManager
from betronic_core.db.models.commission_percents import CommissionBalances
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.user_manager.manager import UserManager
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.constants import TransferTypes as TT
from betronic_core.constants import UserTypePaymentTransfer as UTP
from bookmakers.services.abstract_handler import IServiceHandler

from util.validators import get_skip_limit
from util.date import get_validated_date_with_default, convert_to_required_project_timezone

logger = getLogger(__name__)


class GetUserFinanceHandler(IServiceHandler):
    @staticmethod
    def _get_operation_type(transfer: MoneyTransferModel):
        if transfer.type in TT.WITHDRAWAL_TYPES:
            return UTP.TYPE_WITHDRAWAL
        elif transfer.type in TT.PAYMENT_TYPES + TT.BONUS_USER_DEPOSIT_TYPES:
            return UTP.TYPE_DEPOSIT

        return -1

    @classmethod
    def _get_additional_data(cls, transfer: MoneyTransferModel):
        if cls._get_operation_type(transfer) == UTP.TYPE_WITHDRAWAL:
            balance_before = transfer.additional_data.get('balance_before_from_user', 0.0)
            balance_after = transfer.additional_data.get('balance_after_from_user', 0.0)
        else:
            balance_before = transfer.additional_data.get('balance_before_to_user', 0.0)
            balance_after = transfer.additional_data.get('balance_after_to_user', 0.0)

        return {
            'balance_before': balance_before,
            'balance_after': balance_after
        }

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        date_from = self.get_arg('date_from')
        date_to = self.get_arg('date_to')
        currency = self.get_arg('currency')
        page = self.get_arg('page')
        count = self.get_arg('count')
        only_user_transfers = self.get_arg('only_user_transfers', default=False)
        only_personal_higher_transfers = self.get_arg("only_personal_higher_transfers", default=False)
        is_deposit = self.get_arg("is_deposit", default=False)
        is_withdrawal = self.get_arg("is_withdrawal", default=False)

        tz = self.get_arg('tz', default=None)
        user_manager = UserManager(self.db)
        agent_payment_manager = AgentPaymentStatisticBotManager(self.db)
        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        user_db = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        date_from, date_to = get_validated_date_with_default(
            date_from=date_from,
            date_to=date_to
        )
        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)

        skip, limit = get_skip_limit(
            page=page,
            count=count
        )
        transfer_types = []

        if is_deposit == is_withdrawal:
            transfer_types.extend(TT.AGENT_PAYMENT_TYPES)
            if only_personal_higher_transfers:
                transfer_types += TT.EXTENDED_AGENT_OPERATION_TYPES
        else:
            if is_deposit:
                transfer_types.append(TT.TYPE_AGENT_TO_DESCENDANT_AGENT)
                if only_personal_higher_transfers:
                    transfer_types += TT.EXTENDED_AGENT_PAYMENT_TYPES
            if is_withdrawal:
                transfer_types.append(TT.TYPE_DESCENDANT_AGENT_TO_AGENT)
                if only_personal_higher_transfers:
                    transfer_types += TT.EXTENDED_AGENT_WITHDRAWAL_TYPES

        transfers, total_count, withdrawals_sum, deposits_sum = (
            agent_payment_manager.get_transfers_by_date_and_type_for_single_user(
                user_db=user_db,
                date_from=date_from,
                date_to=date_to,
                currency=currency,
                transfer_types=transfer_types,
                skip=skip,
                limit=limit,
                with_username=True,
                decreasing_by_id=True,
                admin_id=admin_id,
                is_deposit=is_deposit,
                is_withdrawal=is_withdrawal,
                only_user_transfers=only_user_transfers,
                only_personal_higher_transfers=only_personal_higher_transfers
            )
        )

        commission_balance = CommissionBalances.get_commission_balance(db=self.db,
                                                                       date_from=date_from,
                                                                       date_to=date_to,
                                                                       admin_id=user_db.parent_agent_id,
                                                                       user_id=admin_id)

        self.result = {
            'transfers': [
                {
                    'id': transfer.id,
                    'amount': transfer.amount,
                    'operation': self._get_operation_type(transfer),
                    'from_user_id': transfer.from_user_id,
                    'to_user_id': transfer.to_user_id,
                    'from_user': transfer.from_user_username if transfer.from_user_id != -1 else "owner",
                    'to_user': transfer.to_user_username if transfer.to_user_id != -1 else "owner",
                    'currency': transfer.currency if transfer.currency else admin_db.currency,
                    'note': None,
                    'additional_data': {},
                    'created_at': transfer.created_at.strftime(options.DEFAULT_DATETIME_FORMAT)
                } for transfer in transfers
            ],
            'details': {
                'total_count': total_count,
                'total_deposit': deposits_sum,
                'total_withdraw': withdrawals_sum,
                'delta_balance': deposits_sum - withdrawals_sum,
                'commission_balance': commission_balance
            }
        }
