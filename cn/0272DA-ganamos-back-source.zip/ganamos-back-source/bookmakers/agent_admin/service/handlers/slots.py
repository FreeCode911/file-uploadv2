from logging import getLogger

from tornado.options import options

from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager import STATUSES, PROVIDERS, PROVIDERS_TYPES
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.structure_manager.manager import StructureStatisticManager
from betronic_core.user_manager.manager import UserManager
from bookmakers.services.abstract_handler import IServiceHandler
from util.date import get_validated_date_with_default, convert_to_required_project_timezone
from util.error import InvalidRequestData, CustomError
from util.validators import get_skip_limit

logger = getLogger(__name__)


class UserSlotBetHistoryHandler(IServiceHandler):
    @staticmethod
    def _get_username_from_bet(bet: MoneyTransferModel):
        if bet.from_user_id != UserModel.ORGANIZATION_ID:
            username = bet.from_account.nickname
        else:
            username = bet.to_account.nickname

        return username

    @staticmethod
    def _get_user_id_from_bet(bet: MoneyTransferModel):
        if bet.from_user_id != UserModel.ORGANIZATION_ID:
            user_id = bet.from_user_id
        else:
            user_id = bet.to_user_id

        return user_id

    @staticmethod
    def _get_balance_before(bet: MoneyTransferModel):
        if bet.from_user_id != UserModel.ORGANIZATION_ID:
            balance_before = bet.additional_data['balance_before_from_user']
        else:
            balance_before = bet.additional_data['balance_before_to_user']

        return balance_before

    @staticmethod
    def _get_balance_after(bet: MoneyTransferModel):
        if bet.from_user_id != UserModel.ORGANIZATION_ID:
            balance_after = bet.additional_data['balance_after_from_user']
        else:
            balance_after = bet.additional_data['balance_after_to_user']

        return balance_after

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg("user_id", None)
        user_login = self.get_arg("user_login", None)
        username = self.get_arg("username", None)
        date_from = self.get_arg("date_from", None)
        date_to = self.get_arg("date_to", None)
        provider = self.get_arg("provider", None)
        status = self.get_arg("status", None)
        game_type = self.get_arg("game_type", None)
        count = self.get_arg("count", None)
        page = self.get_arg("page", None)
        tz = self.get_arg('tz', default=None)

        if page is not None and page < 0:
            raise InvalidRequestData(-3, "Page number must not be negative")
        if count is not None and count < 0:
            raise InvalidRequestData(-3, "Count must not be negative")

        providers = [provider] if provider else None  # i resign
        game_types = [game_type] if game_type else None
        statuses = [status] if status else None

        user_manager = UserManager(self.db)
        money_manager = MoneyManager(self.db)
        structure_manager = StructureStatisticManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        if user_login:
            user_db = user_manager.get_substructure_user_by_nickname(
                source_user=admin_db,
                target_nickname=user_login
            )
        elif user_id:
            user_db = user_manager.get_substructure_user(
                source_user=admin_db,
                target_user_id=user_id
            )
        else:
            user_db = None

        date_from, date_to = get_validated_date_with_default(
            date_from=date_from,
            date_to=date_to
        )
        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)
        skip, limit = get_skip_limit(
            page=page,
            count=count
        )

        bets, count, user_ids = money_manager.get_users_slots_bet_history(
            source_entity=user_db,
            username=username,
            is_like_username=False,
            from_date=date_from,
            to_date=date_to,
            providers=providers,
            statuses=statuses,
            game_types=game_types,
            skip=skip,
            limit=limit
        )

        bet_count, bet_total, win_total = structure_manager.get_total_statistic(
            user_ids=user_ids,
            date_from=date_from,
            date_to=date_to,
            providers=providers
        )

        result = []
        for bet in bets:
            res_dict = {
                "id": bet.id,
                "amount": bet.value,
                "status": bet.get_slots_bet_status_by_transaction_type(bet.type, STATUSES),
                "provider": bet.get_slots_provider_by_transaction_type(bet.type, PROVIDERS),
                "date": bet.created_at.strftime("%Y-%m-%d %H:%M:%S"),
                "note": bet.note,
                "balance_before": self._get_balance_before(bet),
                "balance_after": self._get_balance_after(bet),
                "user_id": self._get_user_id_from_bet(bet),
                "username": self._get_username_from_bet(bet)
            }

            res_dict["gameType"] = bet.get_provider_type_by_provider(res_dict["provider"], PROVIDERS_TYPES)

            result.append(res_dict)

        result_data = {
            "data": result,
            "detail": {
                "total_bet_count": bet_count,
                "total_bet": bet_total,
                "total_won": win_total,
                "total_income": bet_total - win_total,
            },
            "totalCount": count
        }

        self.result = result_data


class UserSlotsBetDetailHistoryHandler(UserSlotBetHistoryHandler):

    def get_operation(self, bet: MoneyTransferModel) -> str:
        if bet.type in options.ROYALTY_STATISTIC_BET_TYPES:
            return "2"
        return "1"

    def get_amount(self, bet: MoneyTransferModel):
        amount = bet.value
        operation = self.get_operation(bet)

        if operation == "2":
            amount *= -1

        return amount

    def set_result(self):
        bet_id = self.get_arg("bet_id")
        money_manager = MoneyManager(self.db)

        bet = money_manager.get_bet(bet_id)

        if bet is None:
            raise CustomError(404, "No data found!")

        self.result = {
            "provider": bet.get_slots_provider_by_transaction_type(bet.type, PROVIDERS),
            "date": bet.created_at.strftime("%Y-%m-%d %H:%M:%S"),
            "game_name": bet.additional_data.get("game_name", "-"),
            "balance_before": self._get_balance_before(bet),
            "balance_after": self._get_balance_after(bet),
            "user_id": self._get_user_id_from_bet(bet),
            "username": self._get_username_from_bet(bet),
            "operation": self.get_operation(bet),
            "amount": self.get_amount(bet),
            "ref_id": bet.transaction_id,
        }