from logging import getLogger
from typing import Optional, List

from betronic_core.user_manager.manager import UserManager
from betronic_core.db.models.user import UserModel, Ltree
from bookmakers.services.abstract_handler import IServiceHandler


logger = getLogger(__name__)


class GetUserTreeHandler(IServiceHandler):
    @staticmethod
    def _get_search_ltree(source_user_id: int, target_user_id: int, structure_path: Ltree) -> Ltree:
        """
        result:
        [4.8.15.16.23.42]
        """
        start = structure_path.index(str(source_user_id))
        end = structure_path.index(str(target_user_id))
        return structure_path[start:end] if start != end else Ltree(str(target_user_id))

    @classmethod
    def _get_path(cls, admin_id: int, target_user: UserModel, manager: UserManager) -> List:
        """
        result:
        [
            {
                "id": 4,
                "username": "struct1",
                "parent_agent_id": None
            },
            {
                "id": 8,
                "username": "struct1sub",
                "parent_agent_id": 2
            }
        ]
        """
        users = manager.get_users_emails_from_ltree(cls._get_search_ltree(admin_id,
                                                                          target_user.id,
                                                                          target_user.structure_path))
        result = [{
            "id": email.user_id,
            "username": email.email,
            "parent_agent_id": email.user.parent_agent_id
        } for email in users]
        return result

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        username = self.get_arg('username', default=None)

        user_manager = UserManager(self.db)

        admin_db: UserModel = user_manager.get_user_by_id(user_id=admin_id)
        user_db: UserModel = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        if admin_db.can_create_only_player:
            target_role = UserModel.USER
        else:
            target_role = UserModel.PARTNER_AGENT

        if username:
            descendants_users = user_manager.get_list_user_descendants(
                source_entity=user_db,
                username=username,
                target_role=target_role,
                is_like_username=False
            )
            if descendants_users:
                # so _get_path would output whole path
                user_db = descendants_users[0]
        else:
            descendants_users = user_manager.get_list_user_descendants(
                source_entity=user_db,
                max_ltree_level=1,
                target_role=target_role,
            )

        descendants = []
        for descendant_user in descendants_users:
            agent_data = {
                'id': descendant_user.id,
                'username': descendant_user.nickname,
                'child_count': descendant_user.child_count,
                'level': descendant_user.level
            }
            descendants.append(agent_data)

        result = {
            "descendants": descendants,
            "path": self._get_path(admin_id, user_db, user_manager)
        }
        self.result = result


class ChangeUserTreeHandler(IServiceHandler):
    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        is_disable = self.get_arg('is_disable')

        user_manager = UserManager(self.db)

        admin_db: UserModel = user_manager.get_user_by_id(user_id=admin_id)
        user_db: UserModel = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        banned_user_ids = []
        if is_disable is not None:
            _banned_users = user_manager.ban_user_ltree_structure(
                source_entity=user_db,
                ban_status=is_disable
            )
            if is_disable is True:
                banned_user_ids = [banned_user.id for banned_user in _banned_users]

        self.result = {
            'user_tree': {
                'is_banned': is_disable
            },
            'on_update': {
                'banned_user_ids': banned_user_ids
            }
        }
