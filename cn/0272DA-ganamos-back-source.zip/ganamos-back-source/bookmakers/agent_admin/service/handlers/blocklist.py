from logging import getLogger

from betronic_core.blocklist_manager.manager import BlocklistManager
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.manager import UserManager
from bookmakers.services.abstract_handler import IServiceHandler
from betronic_core.cache_manager.manager import CacheManager


logger = getLogger(__name__)


class GetUserBlocklistHandler(IServiceHandler):

    def set_result(self):
        user_id = self.get_arg('user_id')
        blocklist = BlocklistManager.get_blocklist_from_redis(user_id)
        if blocklist is None:
            blocklist = set()
        blocklist_global = BlocklistManager.get_global_providers_block()
        blocklist = list(set(blocklist).union(blocklist_global))
        lock_data = BlocklistManager.get_user_lock_data(user_id)
        self.result = {
            'blocklist': blocklist,
            'lock_data': lock_data
        }


class ChangeUserBlocklistHandler(IServiceHandler):

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        action = self.get_arg('action')
        providers = self.get_arg('providers')
        is_full_branch = self.get_arg('is_full_branch')
        category = self.get_arg('category')
        user_manager = UserManager(self.db)
        blocklist_manager = BlocklistManager(self.db)

        blocklist_manager.check_providers_globally_blocked(providers)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        user_db = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )
        descendants_users = user_manager.get_list_user_descendants(user_db, target_role=UserModel.PARTNER_AGENT)
        sub_users_ids = [user_id]
        for element in descendants_users:
            sub_users_ids.append(element[0])
        blocklist_manager.upsert_full_lock_data(ids=sub_users_ids,
                                                category=category,
                                                is_full_branch=is_full_branch
                                                )
        if is_full_branch:
            logger.info("Blocking category, is_full_branch")
            if action == "remove":
                logger.info("Removing category from branch, category: %s", category)
                blocklist_manager.remove_user_from_lock_data(sub_users_ids, category)
            
            if action == "add" and blocklist_manager.is_full_category(category, providers):
                logger.info("Adding category to branch, category: %s", category)
                blocklist_manager.add_user_to_lock_data(sub_users_ids, category)
        else:
            logger.info("Blocking category, only users")
            sub_users_ids = [user_id]
            if action == "remove":
                blocklist_manager.remove_user_from_lock_data(sub_users_ids, category)
                
            if action == "add" and blocklist_manager.is_full_category(category, providers):
                logger.info("Adding category user %s, category: %s", sub_users_ids, category)
                blocklist_manager.add_user_to_lock_data(sub_users_ids, category)

        blocklist_manager.upsert_provider_lock_data(ids=sub_users_ids,
                                                    providers=providers,
                                                    action=action)
        self.db.commit()
        if action == "add":
            for agent_id in sub_users_ids:
                blocklist_manager.add_providers_to_blocklist(agent_id, providers)
                
            level = None if is_full_branch else 1
            descendants_users = user_manager.get_list_user_descendants(
                user_db,
                target_role=UserModel.USER,
                max_ltree_level=level
            )
            sub_users_ids = [user[0] for user in descendants_users]
            CacheManager.close_all_sessions_by_user_ids(sub_users_ids)

        elif action == "remove":
            for agent_id in sub_users_ids:
                blocklist_manager.remove_providers_from_blocklist(agent_id, providers)
        blocklist = BlocklistManager.get_blocklist_from_redis(user_id)
        self.result = blocklist
