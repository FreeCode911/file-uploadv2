import datetime
from logging import getLogger
from typing import List

from sqlalchemy_utils import Ltree

from tornado.options import options

from betronic_core.admin_panel_manager.manager import AdminPanelManager
from betronic_core.db.models.commission_percents import CommissionPercents
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.permission_details import PermissionDetailsModel
from betronic_core.user_manager.manager import UserManager
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.host_manager.manager import HostManager
from betronic_core.db.models.user import UserModel
from betronic_core.owner_page_manager.manager import OwnerPageManager
from betronic_core.structure_manager.manager import StructureStatisticBotManager
from betronic_core.blocklist_manager.manager import BlocklistManager

from bookmakers.services.commands import AbstractResult
from bookmakers.services.abstract_handler import IServiceHandler
from bookmakers.user.service.handlers.registration import RegisterUserWithUsernameHandler
from util.date import get_validated_date_with_default

from util.error import InvalidRequestData, PermissionsError
from util.validators import get_skip_limit, get_request_body_for_security


logger = getLogger(__name__)


class CreateUserHandler(IServiceHandler):
    def set_result(self):
        admin_id = self.get_arg("admin_id")

        username = self.get_arg("username")
        password = self.get_arg("password")
        role = self.get_arg("role")

        is_withdrawal_access = self.get_arg("is_withdrawal_access")
        is_deposit_access = self.get_arg("is_deposit_access")
        can_create_only_player = self.get_arg("can_create_only_player")

        extra_email = self.get_arg("email", None)
        first_name = self.get_arg("first_name", None)
        last_name = self.get_arg("last_name", None)

        commission_percent = self.get_arg("commission_percent", 0)

        user_manager = UserManager(self.db)
        host_manager = HostManager(self.db)

        admin_db: UserModel = user_manager.get_user_by_id(user_id=admin_id)

        if admin_db.can_create_only_player and role == UserModel.PARTNER_AGENT:
            raise PermissionsError(f"Agent with id {admin_id} does not have permission to create subagents")

        user_manager.check_for_ltree_if_exists(admin_db)

        if options.MAX_USER_CREATING_COUNT_LIMIT_STATE_24H:
            user_manager.check_for_allow_user_creating(admin_db)

        if options.MAX_USER_CREATING_COUNT_LIMIT_STATE_1M:
            user_manager.check_for_allow_user_creating(admin_db, major=False)

        if user_manager.get_user_by_login(username.lower()):
            raise InvalidRequestData(-3, f"User with username: {username} - already exist")

        if role != UserModel.PARTNER_AGENT:
            commission_percent = 0

        user_create_data = {
            "username": username,
            "password": password,
            "currency": admin_db.currency,
            "is_user": True,
            "email": extra_email,
            "first_name": first_name,
            "last_name": last_name
        }

        status, result, error_message, _ = RegisterUserWithUsernameHandler(
            args=user_create_data,
            db=self.db
        ).get_result(with_close_session=False)

        if error_message:
            raise InvalidRequestData(status, error_message)

        user_id = result.get('user_id')
        if not user_id:
            raise Exception(f'User is not created. Response status {status} with result: {result}')

        user_db: UserModel = user_manager.get_user_by_id(user_id)
        user_db.role = role
        user_db.parent_agent_id = admin_id
        user_db.structure_path = admin_db.structure_path + Ltree(str(user_db.id))

        if role == UserModel.PARTNER_AGENT:
            agent_commission = CommissionPercents(
                user_id=user_db.id,
                commission_percent=commission_percent
            )
            self.db.add(agent_commission)
            user_db.changed_password = True

        host_manager.create_parent_permissions_for_user(
            source_user=admin_db,
            target_user=user_db
        )

        if role == UserModel.PARTNER_AGENT:
            blocklist_manager = BlocklistManager(self.db)
            permission_details = blocklist_manager.get_permission_detail(admin_db.id)
            if permission_details:
                if permission_details.is_full_branch:
                    user_permission = PermissionDetailsModel()
                    user_permission.user_id = user_db.id
                    user_permission.providers = permission_details.providers
                    user_permission.categories = permission_details.categories
                    user_permission.is_full_branch = permission_details.is_full_branch
                    self.db.add(user_permission)
            user_db.is_withdrawal_access = is_withdrawal_access
            user_db.is_deposit_access = is_deposit_access
            user_db.can_create_only_player = can_create_only_player
        else:
            user_db.is_withdrawal_access = True
            user_db.is_deposit_access = True

        self.db.add(user_db)
        self.db.commit()

        self.result = {"user_id": user_db.id}


class GetParentUserListHandler(IServiceHandler):

    def set_result(self):
        user_id = self.get_arg("user_id")
        admin_id = self.get_arg("admin_id")
        username = self.get_arg("username", None)
        source_username = self.get_arg("source_username", None)
        role = self.get_arg("role")
        date_from = self.get_arg('date_from')
        date_to = self.get_arg('date_to')
        is_banned = self.get_arg('is_banned', False)
        page = int(self.get_arg("page", 0))
        count = int(self.get_arg("count", 20))
        order_by = self.get_arg('order_by', None)
        is_direct_structure = self.get_arg('is_direct_structure', False)

        user_manager = UserManager(self.db)

        if date_from and date_to:
            date_from, date_to = get_validated_date_with_default(
                date_from=date_from,
                date_to=date_to
            )

        skip, limit = get_skip_limit(
            page=page,
            count=count
        )

        admin_db: UserModel = user_manager.get_user_by_id(user_id=admin_id)
        if user_id:
            user_db: UserModel = user_manager.get_substructure_user(
                source_user=admin_db,
                target_user_id=user_id
            )
            source_user = user_db
        elif source_username:
            user_db: UserModel = user_manager.get_substructure_user_by_nickname(
                source_user=admin_db,
                target_nickname=source_username
            )
            source_user = user_db
        else:
            source_user = admin_db

        result = []
        role_filter = role
        if source_user == admin_db and not username:
            descendants_user, total_count, balance_sum = user_manager.get_list_user_by_parent_agent_id(
                parent_agent=source_user,
                username=username,
                role=role_filter,
                is_banned=is_banned,
                skip=skip,
                limit=limit,
                order_by=order_by,
                date_from=date_from,
                date_to=date_to
            )
        else:
            descendants_user, total_count, balance_sum = user_manager.get_list_user_by_structure_path(
                parent_agent_id=source_user.id,
                structure_path=source_user.structure_path,
                username=username,
                role=role_filter,
                is_banned=is_banned,
                is_direct_structure=is_direct_structure,
                skip=skip,
                limit=limit,
                order_by=order_by,
                date_from=date_from,
                date_to=date_to
            )

        owner_manager = OwnerPageManager(self.db)

        for user in descendants_user:
            if user.role == UserModel.USER:
                total_deposits = owner_manager.get_total_deposits_by_user_id(user.id)
                if user.currency != "USD":
                    total_deposits = CurrencyRateModel.convert(self.db, total_deposits, user.currency, "USD")
            else:
                total_deposits = None

            if user.role == UserModel.PARTNER_AGENT:
                agent_commission = CommissionPercents.get_by_user_id(self.db, user.id)
                commission_percent = agent_commission.commission_percent if agent_commission else None
            else:
                commission_percent = None

            element = {
                "id": user.id,
                "username": user.nickname,
                "role": user.role,
                "balance": user.balance,
                'is_banned': user.is_banned,
                'creation_date': user.first_visit.strftime("%Y-%m-%d %H:%M:%S"),
                "total_deposits": total_deposits,
                "commission_percent": commission_percent,
                'can_create_only_player': user.can_create_only_player,
                'parent_agent': {
                    'id': user.agent_id,
                    'username': user.agent_username,
                    'balance': user.agent_balance
                }
            }
            result.append(element)

        if source_user.role == UserModel.USER:
            total_deposits = owner_manager.get_total_deposits_by_user_id(source_user.id)
            if source_user.currency != "USD":
                total_deposits = CurrencyRateModel.convert(self.db, total_deposits, source_user.currency, "USD")
            commission_percent = None
        else:
            agent_commission = CommissionPercents.get_by_user_id(self.db, source_user.id)
            commission_percent = agent_commission.commission_percent if agent_commission else None
            total_deposits = None

        source_user_result = {
            'id': source_user.id,
            'username': source_user.email_auth.email,
            'balance': source_user.balance,
            'is_banned': source_user.is_banned,
            'role': source_user.role,
            'creation_date': source_user.first_visit.strftime("%Y-%m-%d"),
            "total_deposits": total_deposits,
            'can_create_only_player': source_user.can_create_only_player,
            'commission_percent': commission_percent
        }

        response = {
            "users": result,
            "total_count": total_count,
            "balance_sum": balance_sum,
            "source_user": source_user_result
        }

        self.result = response


class GetUserDataHandler(IServiceHandler):
    @staticmethod
    def _prepare_user_structure_by_usernames(
            user_db: UserModel,
            user_ancestors: List[UserModel]
    ):
        user_ancestors_by_ids = {u.id: u for u in user_ancestors}
        user_structure_by_username = '.'.join(
            [
                user_ancestors_by_ids[int(user_id)].nickname
                for user_id in user_db.structure_path.path.split('.')
            ]
        )

        return user_structure_by_username

    def set_result(self):
        user_id = self.get_arg('user_id')
        admin_id = self.get_arg('admin_id')

        user_manager = UserManager(self.db)

        admin_db: UserModel = user_manager.get_user_by_id(user_id=admin_id)
        user_db: UserModel = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        user_ancestors = user_manager.get_list_user_ancestors(
            source_entity=user_db
        )
        user_structure_by_username = self._prepare_user_structure_by_usernames(
            user_db=user_db,
            user_ancestors=user_ancestors
        )
        result = {
            'user': user_db.serialize,
            'structure': user_structure_by_username
        }
        if user_db.role == UserModel.PARTNER_AGENT:
            agent_commission = CommissionPercents.get_by_user_id(self.db, user_id)
            result['commission_percent'] = agent_commission.commission_percent if agent_commission else 0
        result['ip_list'] = user_manager.get_ip_from_security_log_by_user_id(user_id)

        self.result = result


class ChangeUserDataHandler(IServiceHandler):
    def set_result(self):
        admin_id = self.get_arg('admin_id')
        user_id = self.get_arg('user_id')
        first_name = self.get_arg('first_name')
        last_name = self.get_arg('last_name')
        email = self.get_arg('email')
        password = self.get_arg('password')
        is_banned = self.get_arg('is_banned')
        is_withdrawal_access = self.get_arg('is_withdrawal_access')
        is_deposit_access = self.get_arg('is_deposit_access')
        request_from = self.get_arg("request_from")
        ip_address = self.get_arg("ip_address")
        commission_percent = self.get_arg("commission_percent", 0)
        can_create_only_player = self.get_arg('can_create_only_player', None)

        logger.info(
            f"Change attributes with args: "
            f"target_id={user_id}, "
            f"admin_id={admin_id}"
        )

        user_manager = UserManager(self.db)
        admin_panel_manger = AdminPanelManager(self.db)

        admin_db = user_manager.get_user_by_id(admin_id)
        user_db = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )
        if commission_percent is not None and admin_id != user_db.id:
            # recalculate interval
            date_to = datetime.datetime.utcnow()
            date_from = date_to - datetime.timedelta(weeks=options.RECALCULATE_COMMISSION_INTERVAL)
            agent_commission = CommissionPercents.get_by_user_id(self.db, user_db.id)
            # update commision data
            if agent_commission:
                agent_commission.commission_percent = commission_percent
                admin_panel_manger.recalculate_commissions(date_from, date_to, user_db.id, commission_percent)
            # insert commision data
            else:
                agent_commission = CommissionPercents(
                    user_id=user_db.id,
                    commission_percent=commission_percent
                )
                self.db.add(agent_commission)
                self.db.flush()
                StructureStatisticBotManager(self.db).calculate_agents_commissions_by_from_to_user_id(
                    start_date=date_from,
                    end_date=date_to,
                    to_user_id=user_db.id
                )
        
        if first_name and first_name != user_db.first_name:
            user_db.first_name = first_name

        if last_name and last_name != user_db.last_name:
            user_db.last_name = last_name

        if is_withdrawal_access is not None or is_deposit_access is not None:
            user_manager.set_agent_access(
                user=user_db,
                is_withdrawal_access=is_withdrawal_access,
                is_deposit_access=is_deposit_access,
            )

        if email and email != user_db.additional_data.email:
            user_db.additional_data.email = email

        if can_create_only_player is not None and can_create_only_player != user_db.can_create_only_player:
            user_db.can_create_only_player = can_create_only_player

        if password:
            is_user = user_db.role == UserModel.USER
            user_db.email_auth.set_password(password=password, is_user=is_user)
            CacheManager.close_all_sessions_by_user_id(user_db.id)

            request_body = get_request_body_for_security(self.args)
            request_body["password"] = password
            note = f'The user with ID {admin_id} changed the password for the user with ID {user_id}'
            UserManager(self.db).security_log(
                user_id=user_id,
                ip_address=ip_address,
                request_from=request_from,
                operation="change password",
                request_body=request_body,
                note=note
            )

        banned_user_ids = []
        if is_banned is not None and user_db.is_banned != is_banned:
            user_db.is_banned = is_banned
            _banned_users = user_manager.ban_user_ltree_structure(
                source_entity=user_db,
                ban_status=is_banned
            )
            banned_user_ids = [banned_user for banned_user in _banned_users]

        if is_banned or is_withdrawal_access is False or is_deposit_access is False:
            CacheManager.close_all_sessions_by_user_id(user_db.id)

        user_db.additional_data.updated_at = datetime.datetime.utcnow()
        self.db.add(user_db)
        self.db.commit()

        self.result = {
            "user": user_db.serialize,
            "on_update": {
                'banned_user_ids': banned_user_ids
            }
        }
