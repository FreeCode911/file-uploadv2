from logging import getLogger
from typing import List

from tornado.options import options
from betronic_core.payment_manager.manager import PaymentManager
from betronic_core.constants import TransferTypes as TT
from betronic_core.constants import UserTypePaymentTransfer as UTP
from betronic_core.user_manager.manager import UserManager
from betronic_core.money_manager.manager import MoneyManager
from betronic_core.owner_page_manager.manager import OwnerPageManager
from betronic_core.cache_manager.manager import CacheManager
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from bookmakers.services.abstract_handler import IServiceHandler

from util.date import get_validated_date_with_default, convert_to_required_project_timezone
from util.validators import get_skip_limit, as_decimal
from util.error import InvalidRequestData


logger = getLogger(__name__)


class PaymentUserHandler(IServiceHandler):

    @staticmethod
    def _calculate_bonus_amount(amount: float, bonus_amount: float, percent_amount: int):
        if percent_amount:
            bonus_amount = amount * percent_amount * 0.01
        return bonus_amount

    def set_result(self):
        admin_id = int(self.get_arg("admin_id"))
        target_user_id = int(self.get_arg('user_id'))
        operation = self.get_arg('operation')
        amount = self.get_arg('amount')
        note = self.get_arg('note')
        is_bonus = self.get_arg('is_bonus', False)
        bonus_amount = self.get_arg('bonus_amount', None)
        percent_amount = self.get_arg('percent_amount', None)

        user_manager = UserManager(self.db)
        money_manager = MoneyManager(self.db)
        payment_manager = PaymentManager(self.db)

        if admin_id == target_user_id:
            raise InvalidRequestData(-3, "You can't pay yourself")

        if amount < 1:
            raise InvalidRequestData(-3, "Amount less than 1")

        if is_bonus:
            if bonus_amount is not None:
                if bonus_amount < 1:
                    raise InvalidRequestData(-3, "Bonus amount must be positive and more than 1")

            if percent_amount is not None:
                percent_amount = int(percent_amount)
                if percent_amount < 1:
                    raise InvalidRequestData(-3, "Percent must be positive and more than 1")

        agent_user = user_manager.get_user_by_id(user_id=admin_id)
        target_user = user_manager.get_substructure_user(
            source_user=agent_user,
            target_user_id=target_user_id,
            with_lock=True
        )

        user_manager.check_for_availability_deposit_withdraw(
            user=agent_user,
            operation_type=operation
        )

        if target_user.parent_agent_id == admin_id:
            payment_initiator_user = agent_user
            payment_source_user = agent_user
            payment_target_user = target_user
        else:
            payment_initiator_user = agent_user
            payment_source_user = target_user.parent_agent
            payment_target_user = target_user
            note = (
                f'Agent initiator {admin_id} ID. '
                f'Operation was performed by agent {target_user.parent_agent_id} ID. ' +
                (f'Comment: {note}.' if note else '')
            )

        if operation == UTP.TYPE_DEPOSIT:
            from_user_id, real_from_user_id = payment_source_user.id, payment_initiator_user.id
            to_user_id, real_to_user_id = payment_target_user.id, payment_target_user.id
            transfer_type = TT.TYPE_AGENT_TO_USER if payment_target_user.role == UserModel.USER \
                else TT.TYPE_AGENT_TO_DESCENDANT_AGENT

        elif operation == UTP.TYPE_WITHDRAWAL:
            from_user_id, real_from_user_id = payment_target_user.id, payment_target_user.id
            to_user_id, real_to_user_id = payment_source_user.id, payment_initiator_user.id
            transfer_type = TT.TYPE_USER_TO_AGENT if payment_target_user.role == UserModel.USER \
                else TT.TYPE_DESCENDANT_AGENT_TO_AGENT

        else:
            raise Exception(f'Operation {operation} does not support')

        bonus_amount = self._calculate_bonus_amount(amount, bonus_amount, percent_amount) if is_bonus else 0

        money_manager.check_for_availability_real_money(
            user_id=from_user_id,
            amount=amount + bonus_amount if bonus_amount is not None else amount
        )

        transfer = money_manager.user_move_money(
            from_user_id=from_user_id,
            to_user_id=to_user_id,
            real_from_user_id=real_from_user_id,
            real_to_user_id=real_to_user_id,
            transfer_type=transfer_type,
            value=amount,
            note=note
        )

        if target_user.role == UserModel.USER and operation == UTP.TYPE_DEPOSIT:
            payment_manager.create_completed_payment(transfer)
            money_manager.process_first_deposit_bonus(transfer)
            if is_bonus:
                money_manager.process_deposit_bonus(transfer, bonus_amount, percent_amount)

        elif target_user.role == UserModel.USER and operation == UTP.TYPE_WITHDRAWAL:
            payment_manager.create_completed_withdrawal(transfer)
            money_manager.write_off_bonus(user=target_user, transfer=transfer)

        self.result = {
            'transfer_detail': {
                'from_user_id': transfer.from_user_id,
                'to_user_id': transfer.to_user_id,
                'real_from_user_id': transfer.real_from_user_id,
                'real_to_user_id': transfer.real_to_user_id,
                'amount': transfer.value,
                'additional_data': transfer.additional_data
            }
        }


class UserPaymentHistoryHandler(IServiceHandler):
    @staticmethod
    def _get_operation_type(transfer: MoneyTransferModel):
        if transfer.type in TT.WITHDRAWAL_TYPES:
            return UTP.TYPE_WITHDRAWAL
        elif transfer.type in TT.PAYMENT_TYPES:
            return UTP.TYPE_DEPOSIT
        elif transfer.type == TT.TYPE_BONUS_AGENT_TO_USER:
            return UTP.TYPE_BONUS

        return None

    @staticmethod
    def _get_source_user_from_transfer_and_type(transfer: MoneyTransferModel, type_: int):
        if type_ == UTP.TYPE_WITHDRAWAL:
            return transfer.to_user_username
        elif type_ in [UTP.TYPE_DEPOSIT, UTP.TYPE_BONUS]:
            return transfer.from_user_username

        return None

    @staticmethod
    def _get_target_user_from_transfer_and_type(transfer: MoneyTransferModel, type_: int):
        if type_ == UTP.TYPE_WITHDRAWAL:
            return transfer.from_user_username
        elif type_ in [UTP.TYPE_DEPOSIT, UTP.TYPE_BONUS]:
            return transfer.to_user_username

        return None

    @staticmethod
    def _get_initiator_user_from_transfer_and_type(transfer: MoneyTransferModel, type_: int):
        if type_ == UTP.TYPE_WITHDRAWAL:
            return transfer.real_to_user_username
        elif type_ in [UTP.TYPE_DEPOSIT, UTP.TYPE_BONUS]:
            return transfer.real_from_user_username

        return None

    @staticmethod
    def _prepare_balance_changes_result(transfer: MoneyTransferModel, request_user_id: int, operation_type: int):
        if request_user_id in [transfer.from_user_id, transfer.to_user_id]:
            if request_user_id == transfer.from_user_id:
                balance_from = float(transfer.additional_data.get('balance_before_from_user', 0))
                balance_to = float(transfer.additional_data.get('balance_after_from_user', 0))
            else:
                balance_from = float(transfer.additional_data.get('balance_before_to_user', 0))
                balance_to = float(transfer.additional_data.get('balance_after_to_user', 0))
        else:
            if operation_type == UTP.TYPE_WITHDRAWAL:
                balance_from = float(transfer.additional_data.get('balance_before_to_user', 0))
                balance_to = float(transfer.additional_data.get('balance_after_to_user', 0))

            elif operation_type == UTP.TYPE_DEPOSIT:
                balance_from = float(transfer.additional_data.get('balance_before_from_user', 0))
                balance_to = float(transfer.additional_data.get('balance_after_from_user', 0))
            else:
                balance_from = 0
                balance_to = 0

        return {
            'balance_from': balance_from,
            'balance_to': balance_to
        }

    @classmethod
    def _prepare_transfers_result(cls, transfers: List[MoneyTransferModel], request_user_id: int):
        result = []
        for transfer in transfers:
            operation_type = cls._get_operation_type(transfer)
            amount = transfer.value
            if transfer.additional_data.get('is_percent_bonus_deposit', None):
                amount = f"{transfer.additional_data['percent_amount']}%"
            prepare_data = {
                'id': transfer.id,
                'operation': operation_type,
                'amount': amount,
                'from_user': cls._get_source_user_from_transfer_and_type(transfer=transfer, type_=operation_type),
                'to_user': cls._get_target_user_from_transfer_and_type(transfer=transfer, type_=operation_type),
                'initiator_user': cls._get_initiator_user_from_transfer_and_type(transfer=transfer, type_=operation_type),
                'note': transfer.note,
                'created_at': transfer.created_at.strftime(options.DEFAULT_DATETIME_FORMAT),
                'balance_changes': cls._prepare_balance_changes_result(
                    transfer=transfer, operation_type=operation_type, request_user_id=request_user_id)
            }
            result.append(prepare_data)

        return result

    def set_result(self):
        admin_id = self.get_arg('admin_id')
        user_id = self.get_arg('user_id', None)
        user_login = self.get_arg('user_login', None)
        username = self.get_arg('username')
        target_role = self.get_arg('role')
        is_direct_structure = self.get_arg('is_direct_structure', False)
        is_higher_transaction_only = self.get_arg('is_higher_transaction_only', False)
        is_withdrawal_transfers = self.get_arg('is_withdrawal_transfers', True)
        is_deposit_transfers = self.get_arg('is_deposit_transfers', True)
        transfers_only = self.get_arg('transfers_only', True)
        page = self.get_arg('page')
        count = self.get_arg('count')
        tz = self.get_arg('tz', default=None)
        is_bonus_deposits = self.get_arg('is_bonus_deposits', False)

        date_from, date_to = get_validated_date_with_default(
            date_from=self.get_arg('date_from'),
            date_to=self.get_arg('date_to'),
            is_datetime=True
        )

        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)

        skip, limit = get_skip_limit(
            page=page,
            count=count
        )

        user_manager = UserManager(self.db)
        money_manager = MoneyManager(self.db)
        owner_page_manager = OwnerPageManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        if user_login:
            user_db = user_manager.get_substructure_user_by_nickname(
                source_user=admin_db,
                target_nickname=user_login
            )
        elif user_id:
            user_db = user_manager.get_substructure_user(
                source_user=admin_db,
                target_user_id=user_id
            )
        else:
            user_db = None

        if transfers_only:
            transfers, total_count = money_manager.get_structure_transfers_by_source_user(
                db=self.db,
                source_user=user_db,
                target_role=target_role,
                username=username,
                is_direct_structure=is_direct_structure,
                is_higher_transaction_only=is_higher_transaction_only,
                is_withdrawal_transfers=is_withdrawal_transfers,
                is_deposit_transfers=is_deposit_transfers,
                date_from=date_from,
                date_to=date_to,
                skip=skip,
                limit=limit,
                with_username=True,
                with_real_username=True,
                is_bonus_deposits=is_bonus_deposits
            )

            result = {
                'transfers': self._prepare_transfers_result(transfers=transfers, request_user_id=admin_id),
                'details': {
                    'total_count': total_count
                }
            }
        else:
            total_data = owner_page_manager.get_total_by_agent_ids_and_date(
                entity_user=user_db,
                target_role=target_role,
                date_from=date_from,
                date_to=date_to,
                username=username,
                is_direct_structure=is_direct_structure,
                is_higher_transaction_only=is_higher_transaction_only,
                is_withdrawal_transfers=is_withdrawal_transfers,
                is_deposit_transfers=is_deposit_transfers,
                is_bonus_deposits=is_bonus_deposits
            )

            deposits_sum = as_decimal(total_data.get('deposits_sum', 0))
            withdrawals_sum = as_decimal(total_data.get('withdrawals_sum', 0))

            result = {
                'totals': {
                    'total_deposit': deposits_sum,
                    'total_withdraw': withdrawals_sum,
                    'delta_balance': deposits_sum - withdrawals_sum
                },
                'details': {}
            }

        result['details']['last_calculate_time'] = str(CacheManager.get_owner_collector_last_calc_time())

        self.result = result

