from typing import List
from tornado.options import options
from datetime import datetime
from sqlalchemy_utils import Ltree
from betronic_core.db.models.commission_percents import CommissionPercents
from betronic_core.user_manager.manager import UserManager
from betronic_core.owner_page_manager.manager import OwnerPageManager
from betronic_core.structure_manager.manager import StructureStatisticManager
from betronic_core.structure_manager.utils import (
    prepare_result_agent_statistic_by_query_result, prepare_result_user_statistic_by_query_result,
    prepare_result_agent_total_statistic_by_query_result
)
from betronic_core.cache_manager.manager import SyncRedisWrapperLocal, RedisBaseTypes
from betronic_core.db.models.owner_statistic import OwnerStatisticModel
from betronic_core.db.models.user import UserModel
from bookmakers.services.abstract_handler import IServiceHandler
from util.date import get_validated_date_with_default, convert_to_required_project_timezone
from util.validators import get_skip_limit, as_decimal


class GetUserStatisticHandler(IServiceHandler):
    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        date_from = self.get_arg("date_from", None)
        date_to = self.get_arg("date_to", None)
        is_user_ranking = self.get_arg("is_user_ranking")
        tz = self.get_arg('tz', default=None)

        user_manager = UserManager(self.db)
        structure_manager = StructureStatisticManager(self.db)
        owner_page_manager = OwnerPageManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        user_db = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        date_from, date_to = get_validated_date_with_default(
            date_from=date_from,
            date_to=date_to
        )
        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)

        user_statistic = user_manager.get_total_balance_statistic_for_agent_by_id(user_db)

        structure_statistic = structure_manager.get_total_statistic_for_agent_by_id(
            user_id=user_db.id,
            date_from=date_from,
            date_to=date_to
        )

        structure_statistic_by_date = structure_manager.get_total_statistic_for_agent_by_id_grouped_by_date(
            user_id=user_db.id,
            date_from=date_from,
            date_to=date_to
        )


        if not is_user_ranking:
            ranked_statistic = structure_manager.get_agents_ranked_by_netwin(
                user_db=user_db,
                date_from=date_from,
                date_to=date_to
            )
        else:
            ranked_statistic = user_manager.get_players_ranked_by_netwin(
                user_db=user_db,
                date_from=date_from,
                date_to=date_to
            )

        active_users_count = structure_manager.get_active_users_count(user_db, date_from, date_to)

        total_data = owner_page_manager.get_total_by_agent_ids_and_date(
            entity_user=user_db,
            target_role=UserModel.USER,
            date_from=date_from,
            date_to=date_to,
            username=None,
            is_direct_structure=False,
            is_higher_transaction_only=False,
            is_withdrawal_transfers=False,
            is_deposit_transfers=True,
            is_bonus_deposits=False
        )

        result = prepare_result_agent_total_statistic_by_query_result(
            user_statistic=user_statistic,
            structure_statistic=structure_statistic[0],
            structure_statistic_by_date=structure_statistic_by_date,
            ranked_statistic=ranked_statistic,
            is_user_ranking=is_user_ranking,
            active_users=active_users_count,
            total_deposits=total_data["deposits_sum"],
        )

        self.result = result


class GetUserRankingHandler(IServiceHandler):
    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        date_from = self.get_arg("date_from", None)
        date_to = self.get_arg("date_to", None)
        tz = self.get_arg('tz', default=None)

        user_manager = UserManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        user_db = user_manager.get_substructure_user(
            source_user=admin_db,
            target_user_id=user_id
        )

        date_from, date_to = get_validated_date_with_default(
            date_from=date_from,
            date_to=date_to
        )
        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)

        ranked_statistic = user_manager.get_players_ranked_by_netwin(
            user_db=user_db,
            date_from=date_from,
            date_to=date_to
        )

        ranked_players = [
            {
                "user_id": rank['user_id'],
                "rank": rank['number'],
                "username": rank['username'],
                "bets_count": rank['bets_count'],
                "wins_count": rank['wins_count'],
                "bets_sum": rank['bets_sum'],
                "wins_sum": rank['wins_sum'],
                "netwin": rank['profit']}
            for rank in ranked_statistic]

        self.result = ranked_players


class UserProviderStatisticHandler(IServiceHandler):
    @classmethod
    def _get_date_from_for_transfer_totals_by_structure_path(cls, structure_path: Ltree, date_from: datetime):
        if structure_path.descendant_of(Ltree('64.267449')):
            date_from = max(datetime(year=2024, month=4, day=3), date_from)

        if structure_path.descendant_of(Ltree('64.877')):
            date_from = max(datetime(year=2024, month=4, day=5), date_from)

        return date_from

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id')
        username = self.get_arg("username", None)
        date_from = self.get_arg("date_from", None)
        date_to = self.get_arg("date_to", None)
        is_direct_only = self.get_arg("is_direct_only", True)
        tz = self.get_arg('tz', default=None)

        user_manager = UserManager(self.db)
        structure_manager = StructureStatisticManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)

        if username:
            user_db = user_manager.get_substructure_user_by_nickname(
                source_user=admin_db,
                target_nickname=username
            )
        else:
            user_db = user_manager.get_substructure_user(
                source_user=admin_db,
                target_user_id=user_id
            )

        provider_statistic_date_from, provider_statistic_date_to = (
            get_validated_date_with_default(
                date_from=date_from,
                date_to=date_to
            )
        )

        transfer_total_date_from, transfer_total_date_to = (
            get_validated_date_with_default(
                date_from=date_from,
                date_to=date_to
            )
        )
        transfer_total_date_from = (
            self._get_date_from_for_transfer_totals_by_structure_path(
                structure_path=user_db.structure_path,
                date_from=transfer_total_date_from
            )
        )

        provider_statistic_date_from, provider_statistic_date_to = (
            convert_to_required_project_timezone(
                provider_statistic_date_from,
                provider_statistic_date_to,
                tz
            )
        )

        transfer_total_date_from, transfer_total_date_to = (
            convert_to_required_project_timezone(
                transfer_total_date_from,
                transfer_total_date_to,
                tz
            )
        )

        if user_db.role == UserModel.PARTNER_AGENT:
            provider_statistic = structure_manager.get_provider_statistic_for_agent_by_id(
                user_id=user_db.id,
                date_from=provider_statistic_date_from,
                date_to=provider_statistic_date_to
            )
            result = prepare_result_agent_statistic_by_query_result(
                provider_statistics=provider_statistic,
                is_direct_only=is_direct_only
            )

        elif user_db.role == UserModel.USER:
            provider_statistic = structure_manager.get_provider_statistic_for_user_by_id(
                user_id=user_db.id,
                date_from=date_from,
                date_to=date_to
            )
            result = prepare_result_user_statistic_by_query_result(
                provider_statistics=provider_statistic
            )

        user_commission = CommissionPercents.get_by_user_id(
            self.db,
            user_id=user_db.id
        )

        user_commission_percents = (
            as_decimal(
                user_commission.commission_percent if user_commission else
                options.DEFAULT_COMMISSION_PERCENT
            ) / as_decimal(100)
        )

        result['detail']['commission_balance'] = (
                as_decimal(result['detail']['total_income']) *
                as_decimal(user_commission_percents)
        )
        result['detail']['last_calculate_time'] = str(
            SyncRedisWrapperLocal(RedisBaseTypes.BALANCES).get(
                options.STRUCTURE_LAST_CALCULATE_DATE_KEY
            ).decode('utf-8')
        )

        self.result = result


class UserPersonalStatisticHandler(IServiceHandler):
    @staticmethod
    def _prepare_query_result_personal_statistic(
            user_statistics: List[OwnerStatisticModel],
            total_count: int
    ):
        # amount_in - сумма депозитов за интервал
        # amount_out - сумма выводов за интервал
        # total - текущий баланс юзера, а не разница депозитов и выводов👀
        return {
            'user_statistic': {
                user_statistic.user_id: {
                    'email': user_statistic.email,
                    'amount_in': user_statistic.amount_in,
                    'amount_out': user_statistic.amount_out,
                    'total': user_statistic.total
                } for user_statistic in user_statistics
            },
            'details': {
                'total_count': total_count
            }
        }

    def set_result(self):
        admin_id = self.get_arg("admin_id")
        user_id = self.get_arg('user_id', None)
        user_login = self.get_arg('user_login', None)
        date_from = self.get_arg("date_from", None)
        date_to = self.get_arg("date_to", None)
        username = self.get_arg("username", None)
        is_direct_only = self.get_arg("is_direct_only", False)
        page = self.get_arg("page", 0)
        count = self.get_arg("count", 20)
        tz = self.get_arg('tz', default=None)


        user_manager = UserManager(self.db)
        owner_manager = OwnerPageManager(self.db)

        admin_db = user_manager.get_user_by_id(user_id=admin_id)
        if user_login:
            user_db = user_manager.get_substructure_user_by_nickname(
                source_user=admin_db,
                target_nickname=user_login
            )
        elif user_id:
            user_db = user_manager.get_substructure_user(
                source_user=admin_db,
                target_user_id=user_id
            )
        else:
            user_db = None

        date_from, date_to = get_validated_date_with_default(
            date_from=date_from,
            date_to=date_to
        )
        date_from, date_to = convert_to_required_project_timezone(date_from, date_to, tz)

        skip, limit = get_skip_limit(
            page=page,
            count=count
        )

        user_statistics, total_count = owner_manager.get_statistic_by_user_and_date(
            user=user_db,
            date_from=date_from,
            date_to=date_to,
            username=username,
            skip=skip,
            limit=limit,
            is_direct_only=is_direct_only
        )

        self.result = self._prepare_query_result_personal_statistic(
            user_statistics=user_statistics,
            total_count=total_count
        )
