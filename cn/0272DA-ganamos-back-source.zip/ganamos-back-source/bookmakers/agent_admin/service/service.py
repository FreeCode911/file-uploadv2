import threading
from logging import getLogger
from tornado.options import options
from bookmakers.services.service import Service
from util.messaging import check_broker_online, check_db_online

from bookmakers.agent_admin.service import commands
from bookmakers.agent_admin.service.handlers import (
    user, tree, payment, slots, bets, statistic, finance, blocklist
)


logger = getLogger(__name__)


class AgentAdminService(Service):
    def __init__(self):
        super(AgentAdminService, self).__init__(commands)

    def register_commands(self):
        self.handle_command(commands.CreateUser, user.CreateUserHandler)
        self.handle_command(commands.GetParentUserList, user.GetParentUserListHandler)
        self.handle_command(commands.GetUserTree, tree.GetUserTreeHandler)
        self.handle_command(commands.CreateUserPayment, payment.PaymentUserHandler)
        self.handle_command(commands.GetUserData, user.GetUserDataHandler)
        self.handle_command(commands.ChangeUserData, user.ChangeUserDataHandler)
        self.handle_command(commands.GetUserBetsHistory, bets.UserBetHistoryHandler)
        self.handle_command(commands.GetUserSlotsBetHistory, slots.UserSlotBetHistoryHandler)
        self.handle_command(commands.GetUserPaymentHistory, payment.UserPaymentHistoryHandler)
        self.handle_command(commands.ChangeUserTree, tree.ChangeUserTreeHandler)
        self.handle_command(commands.GetUserStatistic, statistic.GetUserStatisticHandler)
        self.handle_command(commands.GetUserRanking, statistic.GetUserRankingHandler)
        self.handle_command(commands.GetUserProviderStatistic, statistic.UserProviderStatisticHandler)
        self.handle_command(commands.GetUserPersonalStatistic, statistic.UserPersonalStatisticHandler)
        self.handle_command(commands.GetUserFinanceHistory, finance.GetUserFinanceHandler)
        self.handle_command(commands.GetBlocklist, blocklist.GetUserBlocklistHandler)
        self.handle_command(commands.ChangeBlocklist, blocklist.ChangeUserBlocklistHandler)
        self.handle_command(commands.GetSportCoupons, bets.UserSportCouponHandler)
        self.handle_command(commands.GetCouponBets, bets.UserCouponBetsHandler)
        self.handle_command(commands.GetSlotsDetailHistory, slots.UserSlotsBetDetailHistoryHandler)

def start():
    check_broker_online()
    check_db_online()
    for i in range(options.DEFAULT_WORKER_POOL):
        service = AgentAdminService()
        thread = threading.Thread(target=service.start)
        thread.start()
        thread.join()
