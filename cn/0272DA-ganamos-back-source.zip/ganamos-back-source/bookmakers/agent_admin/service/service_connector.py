from logging import getLogger

from bookmakers.services.service import ServiceConnector
from . import commands


logger = getLogger(__name__)


class AgentAdminServiceConnector(ServiceConnector):
    def __init__(self):
        super(AgentAdminServiceConnector, self).__init__(commands)
