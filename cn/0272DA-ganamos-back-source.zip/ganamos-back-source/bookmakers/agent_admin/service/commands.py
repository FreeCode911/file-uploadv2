from bookmakers.services.commands import CommandFactory


factory = CommandFactory(globals())


def add_command(name):
    return factory.add_command(name)


CreateUser = "CreateUser"
GetUserTree = "GetUserTree"
ChangeUserTree = "PatchUserTree"
GetParentUserList = "GetParentUserList"
CreateUserPayment = "CreateUserPayment"
GetUserData = "GetUserData"
ChangeUserData = "ChangeUserData"
GetUserPaymentHistory = "GetUserPaymentHistory"
GetUserSlotsBetHistory = "GetUserSlotsBetHistory"
GetUserBetsHistory = "GetUserBetsHistory"
GetUserStatistic = "GetUserStatistic"
GetUserRanking = "GetUserRanking"
GetUserProviderStatistic = "GetUserProviderStatistic"
GetUserPersonalStatistic = "GetUserPersonalStatistic"
GetUserFinanceHistory = "GetUserFinanceHistory"
GetBlocklist = "GetBlocklist"
ChangeBlocklist = "ChangeBlocklist"
GetSportCoupons = "GetSportCoupons"
GetCouponBets = "GetCouponBets"
GetSlotsDetailHistory = "GetSlotsDetailHistory"
