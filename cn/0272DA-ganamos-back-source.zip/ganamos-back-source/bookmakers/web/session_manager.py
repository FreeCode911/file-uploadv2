from tornado.options import options
from tornado.web import RequestHandler
from util.error import PermissionsError
from betronic_core.cache_manager.manager import AsyncCacheManager
import jwt
import logging
logger = logging.getLogger(__name__)


class RSASessionManager:
    COOKIE_NAME = "session"
    MAX_AGE = 30
    EXPIRES_DAYS = 30

    def _get_data(self, handler: RequestHandler):
        data = handler.get_cookie(self.COOKIE_NAME)
        return data if data else {}

    async def get(self, handler: RequestHandler):
        decoded_data = self._get_data(handler)
        if not decoded_data:
            raise PermissionsError("Unauthorized")
        try:
            user_data = jwt.decode(decoded_data, options.AUTH_RSA_PUBLIC_KEY, algorithms=["RS512"])
            current_cookie_salt = await AsyncCacheManager.get_user_cookie_salt(user_data['id'])
            if user_data['cookie_salt'] != current_cookie_salt:
                raise PermissionsError(f"cookie salt not match for user {user_data['id']}")
            return user_data
        except Exception as exc:
            logger.info(f"Error when trying to decode cookie data: {str(exc)}")
            raise PermissionsError("Unauthorized")

    def set(self, handler: RequestHandler, update_data: dict):
        data = jwt.encode(payload=update_data, key=options.AUTH_RSA_PRIVATE_KEY, algorithm="RS512")
        handler.set_cookie(self.COOKIE_NAME, data, expires_days=self.EXPIRES_DAYS)

    def reset_secret_cookie(self, handler):
        handler.clear_cookie(self.COOKIE_NAME)

    def reset(self, handler):
        handler.clear_cookie('_TOMSK1')
        handler.clear_cookie('.TOMSK1')
        handler.clear_cookie('.BC2016')
        handler.clear_cookie('ASP_NET_SessionId')
        handler.clear_cookie(self.COOKIE_NAME)
        handler.clear_all_cookies(path='/')
        # manually remove cookies without domain because Morsel cookies
        # can not handle multiple cookies with the same name
        cookie_expire_tmpl = '%s=; domain=.betsstore.com; httponly; expires=Mon, 10 Jun 2013 14:49:25 GMT; Path=/'
        handler.add_header('Set-Cookie', cookie_expire_tmpl % '.TOMSK1')
        handler.add_header('Set-Cookie',
                           cookie_expire_tmpl % 'ASP.NET_SessionId')
        handler.add_header('Set-Cookie', cookie_expire_tmpl % '.TOMSK1')
        handler.add_header('Set-Cookie',
                           cookie_expire_tmpl % 'ASP.NET_SessionId')
        handler.add_header('Set-Cookie', cookie_expire_tmpl % self.COOKIE_NAME)
        handler.add_header('Set-Cookie', cookie_expire_tmpl % '_ga')
        handler.add_header('Set-Cookie', cookie_expire_tmpl % '_gat')
        handler.add_header('Set-Cookie', cookie_expire_tmpl % '_ym_uid')


session_manager = RSASessionManager()
