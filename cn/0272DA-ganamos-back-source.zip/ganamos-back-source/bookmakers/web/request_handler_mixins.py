from collections.abc import Sequence
from logging import getLogger
from typing import List, Tuple, Union

from pydantic import create_model
from tornado.httputil import HTTPServerRequest
from tornado.options import options
from tornado.web import RequestHandler
from ujson import loads
from uuid import uuid4
from betronic_core.blocklist_manager.manager import BlocklistManager
from betronic_core.cache_manager.manager import AsyncCacheManager
from betronic_core.db.models.user import UserModel
from betronic_core.error import InvalidRequestData
from betronic_core.payment_manager import error_codes as payment_error_codes
from betronic_core.user_manager import error_codes
from bookmakers.web.session_manager import session_manager
from settings.default.app import trace_log_guid_var
from util.error import InvalidRequestData, PermissionsError, InvalidDataError
from util.url import check_user_allow_to_route

logger = getLogger(__name__)


class GetRequestArgsMixin:
    """Can use only with tornado.web.RequestHandler"""

    get_params_model: create_model = None
    post_params_model: create_model = None
    request: HTTPServerRequest

    def get_args_dict(self) -> Union[dict, create_model]:
        args = {key: value[0].decode() for key, value in self.request.query_arguments.items()}
        return self.get_params_model(**args) if self.get_params_model else args

    def post_args_dict(self) -> Union[dict, create_model]:
        body = loads(self.request.body)
        return self.post_params_model(**body) if self.post_params_model else body

    def get_named_args_dict(self, names: Sequence) -> dict:
        args = self.get_args_dict()
        return {key: value for key, value in args.items() if key in names}


class UserMixin:
    async def get_user(self):
        return await session_manager.get(self)

    async def get_partner_required(self):
        user = await session_manager.get(self)
        if not user:
            raise PermissionsError("Unauthorized")
        if not user['is_partner']:
            raise PermissionsError("User is not a partner")
        return user

    async def get_user_admin_required(self):
        user = await session_manager.get(self)
        if int(user.role) < 3:
            raise PermissionsError("Permission denied")
        return user

    async def get_user_suadmin_required(self):
        suadmin = await session_manager.get(self)
        if not suadmin:
            raise PermissionsError("Unauthorized")
        if suadmin['role'] != '3':
            raise PermissionsError("Permission denied")
        return suadmin

    async def get_user_required(self):
        user = await session_manager.get(self)
        if not user:
            raise PermissionsError("Unauthorized")
        await check_user_allow_to_route(self, user_data=user)
        return user

    async def get_owner_required(self):
        owner = await session_manager.get(self)
        if not owner:
            raise PermissionsError("Unauthorized")
        if owner['role'] != '4':
            raise PermissionsError("Permission denied")
        return owner

    async def get_partner_agent(self):
        agent = await session_manager.get(self)
        if not agent:
            raise PermissionsError("Unauthorized")
        if agent['role'] != UserModel.PARTNER_AGENT:
            raise PermissionsError("Permission denied")
        return agent

    def get_args_pairs_list(self) -> List[Tuple]:
        """
        Возвращает список объектов tuple(ключ, значение) для генерации url
        с массивом параметров с помощью метода tornado.httputil.url_concat
        """
        args = []
        for key, values in self.request.arguments.items():
            if len(values) > 1:
                args.extend([(key, str(val.decode('utf-8'))) for val in values])
                continue
            args.append((key, str(values[0].decode('utf-8'))))
        return args

    def post_args_tuples(self) -> List[Tuple]:
        res = []
        body = loads(self.request.body)
        for key, values in body.items():
            if isinstance(values, list):
                res.extend([(key, val) for val in values])
                continue
            res.append((key, values))
        return res


class PaymentMixin:
    async def check_minimum_pay(self, amount):
        user = await session_manager.get(self)
        min = options.MIN_PAYMENT[user['currency']]
        if float(amount) < float(min):
            raise InvalidRequestData(payment_error_codes.TOP_UP_LESS_MINIMUM,
                                     "Payment is less than the minimum")


class BaseLoginHandlerMixin(RequestHandler):
    def _authenticate_user(self, user_dict, cookies = []):
        if not user_dict:
            return

        session_manager.reset(self)
        session_manager.set(self, user_dict)


class RemoteBSWServicesMixin:
    request: HTTPServerRequest

    async def check_remote_ip(self):
        request_ip = self.request.headers.get("X-Real-IP")
        whitelisted_ips = await AsyncCacheManager.get_from_secrets("BSW_SERVICES_IPS")
        whitelisted_hosts = loads(whitelisted_ips) if whitelisted_ips else None
        if request_ip not in whitelisted_hosts:
            raise InvalidRequestData(-1, "Not whitelisted IP!")


class LoggedRequestHandler(RequestHandler):
    def prepare(self):
        request_id = self.request.headers.get("X-Request-ID", str(uuid4().hex))
        trace_log_guid_var.set(request_id)


class CacheMixin:
    @staticmethod
    async def check_integration_status(raise_exception=True) -> bool:
        return await AsyncCacheManager.get_integration_status(raise_exception)

    @staticmethod
    async def check_user_providers_ban(provider, user_id, parent_agent_id):
        banned_providers = await BlocklistManager.async_check_user_for_blocked_providers(user_id, parent_agent_id)
        provider = options.PROVIDERS_MAP_IN_PERMISSION.get(provider)
        if provider in banned_providers:
            raise InvalidDataError(
                status_code=error_codes.USER_IS_BANNED,
                error_message="You were banned for this provider"
            )
