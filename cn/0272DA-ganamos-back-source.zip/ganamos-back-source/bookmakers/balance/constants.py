class RemoteDepositStatusType:
    CREATED = 0
    WAIT = 1
    CANCELED = 2
    CONFIRM = 3

    @property
    def type(self):
        return [self.CREATED, self.WAIT, self.CANCELED, self.CONFIRM]


class RemoteWithdrawalStatusType:
    CREATED = 0
    WAIT = 1
    CANCELED = 2
    DONE = 3

    @property
    def type(self):
        return [self.CREATED, self.WAIT, self.CANCELED, self.DONE]
