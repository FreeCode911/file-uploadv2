from .handlers.balance_handlers import (
    ChangeBalanceHandler,
    GetBalanceHandler,
    BatchChangeBalanceHandler,
    UpdateTransferHandler,
    UpdateWithdrawalHandler,
    UpdateDepositHandler
)

url_prefix = "/api/balance"

urls = [
    (r"/change_balance", ChangeBalanceHandler),
    (r"/player_balance", GetBalanceHandler),
    (r"/change_balance/batch", BatchChangeBalanceHandler),
    (r"/update_transfer", UpdateTransferHandler),

    (r"/withdrawal", UpdateWithdrawalHandler),
    (r"/deposit", UpdateDepositHandler)
]
