import asyncio
from logging import getLogger

from tornado.options import options

from bookmakers.balance.async_service.handlers import (
    UpdateTransferService,
    UpdateWithdrawalService,
    UpdateDepositService,
    ChangeUserBalance,
    BatchChangeUserBalance,
    GetUserBalance
)
from bookmakers.balance.models import (
    UserBalanceGetData,
    UserChangeBalanceData,
    UpdateTransferData,
    UpdateWithdrawalData,
    UpdateDepositData,
    BatchChangeBalanceData
)
from bookmakers.web.decorators import result_decorator, async_alchemy_context_decorator
from bookmakers.web.request_handler_mixins import GetRequestArgsMixin, LoggedRequestHandler
from util.error import InvalidRequestData

logger = getLogger(__name__)


class RemoteBSWServicesMixin:
    def check_remote_ip(self):
        request_ip = self.request.headers.get("X-Real-IP")
        whitelisted_ips = options.BSW_SERVICES_IPS
        if request_ip not in whitelisted_ips:
            raise InvalidRequestData(-1, "Not whitelisted IP!")


class GetBalanceHandler(LoggedRequestHandler, RemoteBSWServicesMixin, GetRequestArgsMixin):
    get_params_model = UserBalanceGetData

    @async_alchemy_context_decorator
    @result_decorator
    async def get(self):
        self.check_remote_ip()
        body = self.get_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(GetUserBalance.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await GetUserBalance.process(body)
        return result


class ChangeBalanceHandler(LoggedRequestHandler, GetRequestArgsMixin, RemoteBSWServicesMixin):
    post_params_model = UserChangeBalanceData

    @async_alchemy_context_decorator
    @result_decorator
    async def post(self, *args, **kwargs):
        self.check_remote_ip()
        body = self.post_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(ChangeUserBalance.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await ChangeUserBalance.process(body)
        return result


class BatchChangeBalanceHandler(LoggedRequestHandler, GetRequestArgsMixin, RemoteBSWServicesMixin):
    post_params_model = BatchChangeBalanceData

    @async_alchemy_context_decorator
    @result_decorator
    async def post(self, *args, **kwargs):
        self.check_remote_ip()
        body = self.post_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(BatchChangeUserBalance.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await BatchChangeUserBalance.process(body)
        return result


class UpdateTransferHandler(LoggedRequestHandler, GetRequestArgsMixin, RemoteBSWServicesMixin):
    post_params_model = UpdateTransferData

    @async_alchemy_context_decorator
    @result_decorator
    async def post(self, *args, **kwargs):
        self.check_remote_ip()
        body = self.post_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(UpdateTransferService.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await UpdateTransferService.process(body)
        return result


class UpdateWithdrawalHandler(LoggedRequestHandler, GetRequestArgsMixin, RemoteBSWServicesMixin):
    post_params_model = UpdateWithdrawalData

    @async_alchemy_context_decorator
    @result_decorator
    async def patch(self, *args, **kwargs):
        self.check_remote_ip()
        body = self.post_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(UpdateWithdrawalService.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await UpdateWithdrawalService.process(body)
        return result


class UpdateDepositHandler(LoggedRequestHandler, GetRequestArgsMixin, RemoteBSWServicesMixin):
    post_params_model = UpdateDepositData

    @async_alchemy_context_decorator
    @result_decorator
    async def patch(self, *args, **kwargs):
        self.check_remote_ip()
        body = self.post_args_dict()
        if body.provider in options.BALANCE_TIMEOUT_PROVIDERS:
            result = await asyncio.wait_for(UpdateDepositService.process(body), timeout=options.BALANCE_TIMEOUT)
        else:
            result = await UpdateDepositService.process(body)
        return result
