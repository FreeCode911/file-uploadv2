from typing import Optional, List
from pydantic import BaseModel, Extra

from bsw.balance_client.models import BatchTransactionModel, BatchChangeBalanceModel, ChangeBalanceModel


class UserBalanceGetData(BaseModel):
    user_id: int
    provider: str = ''


class UserChangeBalanceData(ChangeBalanceModel):
    project_name: str
    provider: str
    transaction_type: str
    amount: float
    bonus_amount: Optional[float] = 0
    transaction_id: str
    id_transaction_from_duplicates: str = None
    user_id: int

    payment_mode: Optional[str] = ""


class UpdateTransferData(BaseModel):
    original_txn_id: str

    new_txn_id: str
    user_id: int


class UpdateWithdrawalData(BaseModel):
    transaction_id: str
    project_name: str
    provider: str
    status: Optional[int]

    class Config:
        extra = Extra.allow


class UpdateDepositData(BaseModel):
    transaction_id: str
    project_name: str
    provider: str
    status: Optional[int]

    class Config:
        extra = Extra.allow


class BatchTransactionData(BatchTransactionModel):
    id_transaction_from_duplicates: str = None
    bonus_amount: Optional[float] = 0


class BatchChangeBalanceData(BatchChangeBalanceModel):
    transactions: List[BatchTransactionData]
