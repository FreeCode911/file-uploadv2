from typing import Union
from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes

from bookmakers.balance.constants import RemoteDepositStatusType
from betronic_core.db.models.payments import (
    WAIT as WAIT_STATUS_TYPE,
    CANCELED as CANCELED_STATUS_TYPE,
    CONFIRM as CONFIRM_STATUS_TYPE
)

from util.error import InvalidDataError


class ConvertWithdrawalRemoteToLocalStatus:
    _STATUS_TYPE_MAPPER = {
        RemoteDepositStatusType.CREATED: WAIT_STATUS_TYPE,
        RemoteDepositStatusType.WAIT: WAIT_STATUS_TYPE,
        RemoteDepositStatusType.CANCELED: CANCELED_STATUS_TYPE,
        RemoteDepositStatusType.CONFIRM: CONFIRM_STATUS_TYPE
    }

    @classmethod
    def convert(cls, remote_status: Union[RemoteDepositStatusType.type]):
        local_type = cls._STATUS_TYPE_MAPPER.get(remote_status)
        if not local_type:
            raise InvalidDataError(
                status_code=error_codes.UNEXPECTED_ERROR,
                error_message=f"unexpected remote status {remote_status}"
            )

        return local_type


