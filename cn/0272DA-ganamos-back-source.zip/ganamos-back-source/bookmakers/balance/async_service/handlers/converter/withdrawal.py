from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes

from betronic_core.db.models.withdrawal import WithdrawalModel
from bookmakers.balance.constants import RemoteWithdrawalStatusType
from util.error import InvalidDataError


class ConvertWithdrawalRemoteToLocalStatus:
    _STATUS_TYPE_MAPPER = {
        RemoteWithdrawalStatusType.CREATED: WithdrawalModel.CREATED,
        RemoteWithdrawalStatusType.WAIT: WithdrawalModel.PROCESSING,
        RemoteWithdrawalStatusType.CANCELED: WithdrawalModel.CANCELED,
        RemoteWithdrawalStatusType.DONE: WithdrawalModel.DONE
    }

    @classmethod
    def convert(cls, remote_status):
        local_type = cls._STATUS_TYPE_MAPPER.get(remote_status)
        if not local_type:
            raise InvalidDataError(
                status_code=error_codes.UNEXPECTED_ERROR,
                error_message=f"unexpected remote status {remote_status}"
            )

        return local_type


class ConvertWithdrawalStatusLocalToRemote:
    _STATUS_TYPE_MAPPER = {
        WithdrawalModel.CREATED: RemoteWithdrawalStatusType.CREATED,
        WithdrawalModel.PROCESSING: RemoteWithdrawalStatusType.WAIT,
        WithdrawalModel.CANCELED: RemoteWithdrawalStatusType.CANCELED,
        WithdrawalModel.DONE: RemoteWithdrawalStatusType.DONE
    }

    @classmethod
    def convert(cls, local_status):
        remote_type = cls._STATUS_TYPE_MAPPER.get(local_status)
        if not remote_type:
            raise InvalidDataError(
                status_code=error_codes.UNEXPECTED_ERROR,
                error_message=f"unexpected remote status {local_status}"
            )

        return remote_type
