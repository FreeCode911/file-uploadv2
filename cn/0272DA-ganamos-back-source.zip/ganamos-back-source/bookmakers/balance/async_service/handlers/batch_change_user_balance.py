from decimal import Decimal
from typing import Tuple, Union, Optional

from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.async_database import session
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.async_manager import AsyncUserManager
from bookmakers.balance.models import BatchTransactionData, BatchChangeBalanceData
from bookmakers.balance.util.dynamic_transfer_types_detector import transfer_types_by_games_provider
from util.error import IndividualError
from .change_user_balance import ChangeUserBalance
from .strategies import GamesTransactionStrategy


class BatchChangeUserBalance(ChangeUserBalance, GamesTransactionStrategy):
    data_model = BatchChangeBalanceData

    @classmethod
    async def execute(cls, data: BatchChangeBalanceData) -> dict:
        transactions_result = []
        async with session.begin() as db_transaction:
            for transaction in data.transactions:
                user_general_data = await AsyncUserManager.get_user_general_data(
                    user_id=data.user_id,
                    with_lock=True,
                    connection=db_transaction.session,
                )
                transaction.provider = data.provider
                if not user_general_data:
                    raise IndividualError(status_code=error_codes.USER_DOES_NOT_EXIST,
                                          error_message=f"User {data.user_id} does not exist!")

                cls._check_user_access(user_general_data)
                cls._validate_transaction_params(data.provider, transaction.transaction_type)
                await cls._check_user_providers_ban(data.provider, user_general_data, transaction.transaction_type)
                system_transaction_type = transfer_types_by_games_provider[data.provider][transaction.transaction_type]
                result = await GamesTransactionStrategy.process(transaction, user_general_data,
                                                                system_transaction_type=system_transaction_type,
                                                                connection=db_transaction.session)

                specific_result = {
                    "txn_id": result["txn_id"]
                }
                transactions_result.append(specific_result)

        return {
            "balance": result["balance"],
            "transactions_result": transactions_result,
        }

    @staticmethod
    def _validate_transaction_params(provider: str, transaction_type: str):
        return super(BatchChangeUserBalance, BatchChangeUserBalance)\
            ._validate_transaction_params(provider, transaction_type)

    @staticmethod
    def _check_balance_sufficiency(
            data: BatchChangeBalanceData,
            user_data: UserModel):
        return super(BatchChangeUserBalance, BatchChangeUserBalance)._check_balance_sufficiency(data, user_data)

    @classmethod
    async def _check_for_duplicates(cls, id_transaction_from_duplicates: Union[str, int], connection: AsyncSession):
        return await super(BatchChangeUserBalance, BatchChangeUserBalance).\
            _check_for_duplicates(id_transaction_from_duplicates, connection)

    @classmethod
    def _get_txn_id(
            cls,
            transfer: Optional[MoneyTransferModel],
            bonus_transfer: Optional[BonusTransferModel] = None
    ) -> Union[int, None]:
        return super(BatchChangeUserBalance, BatchChangeUserBalance).\
            get_txn_id(transfer=transfer, bonus_transfer=bonus_transfer)
