import logging
from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.payment_manager.async_manager import AsyncPaymentManager
from bookmakers.balance.models import UpdateWithdrawalData
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler

from betronic_core.db.async_database import session
from betronic_core.db.models.withdrawal import WithdrawalModel

from .converter.withdrawal import ConvertWithdrawalRemoteToLocalStatus

from util.error import InvalidDataError

logger = logging.getLogger(__name__)


class UpdateWithdrawalService(AbstractDirectServiceHandler):
    data_model = UpdateWithdrawalData

    @classmethod
    async def _update_status(
            cls,
            withdrawal_db: WithdrawalModel,
            remote_status: int,
            connection: AsyncSession
    ):
        local_status = ConvertWithdrawalRemoteToLocalStatus \
            .convert(remote_status=remote_status)

        if local_status == WithdrawalModel.CREATED:
            logger.info(f'status CREATED not implemented '
                        f'in update withdrawal model')

        elif local_status == WithdrawalModel.CANCELED:
            logger.info(f'status CANCELED not implemented '
                        f'in update withdrawal model')

        elif local_status == WithdrawalModel.PROCESSING:
            await AsyncPaymentManager.processing_withdrawal(
                withdrawal=withdrawal_db,
                connection=connection
            )

        elif local_status == WithdrawalModel.DONE:
            await AsyncPaymentManager.done_withdrawal(
                withdrawal=withdrawal_db,
                connection=connection
            )

        return withdrawal_db

    @classmethod
    async def execute(cls, update_data: UpdateWithdrawalData):
        async with session.begin() as transaction:
            withdrawal_db: WithdrawalModel = await AsyncPaymentManager\
                .get_withdrawal_by_transaction_id(
                    transaction_id=update_data.transaction_id,
                    connection=transaction.session
                )
            if not withdrawal_db:
                raise InvalidDataError(
                    status_code=error_codes.UNEXPECTED_ERROR,
                    error_message=f"withdrawal with transaction ID {update_data.transaction_id} not found"
                )

            if update_data.status is not None:
                withdrawal_db = await cls._update_status(
                    withdrawal_db=withdrawal_db,
                    remote_status=update_data.status,
                    connection=transaction.session
                )

        return {'withdrawal_id': withdrawal_db.id}
