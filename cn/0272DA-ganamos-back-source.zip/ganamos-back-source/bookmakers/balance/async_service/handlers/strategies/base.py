from typing import Optional
from typing import Union

from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.money_manager.async_manager import AsyncMoneyManager
from bookmakers.balance.models import UserChangeBalanceData
from bookmakers.balance.util.dynamic_transfer_types_detector import (
    types_allowed_to_insufficient,
    allow_bonus_transfer_provider
)
from util.error import InvalidDataError


class ChangeBalanceAbstractStrategy:

    @classmethod
    async def process(
            cls,
            data: UserChangeBalanceData,
            user_general_data: UserModel,
            connection: AsyncSession
    ) -> dict:
        pass

    @staticmethod
    def get_txn_id(
            transfer: Optional[MoneyTransferModel],
            bonus_transfer: Optional[BonusTransferModel] = None
    ) -> Union[int, None]:
        if transfer:
            return transfer.id
        elif bonus_transfer:
            return bonus_transfer.id
        else:
            return None

    @classmethod
    async def _check_for_duplicates(cls, id_transaction_from_duplicates, connection):
        transfer = await MoneyTransferModel.async_get_by_transaction_id(
            connection=connection,
            transaction_id=id_transaction_from_duplicates
        )
        if transfer:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_ALREADY_EXIST,
                error_message=f"Transaction {id_transaction_from_duplicates} already exists."
            )
    
    @classmethod
    async def _check_bonus_for_duplicates(cls, id_transaction_from_duplicates, connection):
        transfer = await BonusTransferModel.async_get_by_transaction_id(
            connection=connection,
            transaction_id=id_transaction_from_duplicates
        )
        if transfer:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_ALREADY_EXIST,
                error_message=f"Transaction {id_transaction_from_duplicates} already exists."
            )

    @classmethod
    async def _check_for_exist_transfer_by_txn_id(cls, txn_id: Union[str, int], connection):
        transfer = await MoneyTransferModel.async_get_by_transaction_id(
            connection=connection,
            transaction_id=str(txn_id)
        )
        if not transfer:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_BET_NOT_FOUND,
                error_message=f"Transaction with note {txn_id} doesn't exists."
            )

        return transfer

    @staticmethod
    def _check_balance_sufficiency(data: UserChangeBalanceData, user_data: UserModel):
        if data.transaction_type not in types_allowed_to_insufficient:
            user_balance = user_data.balance

            if data.amount > user_balance:
                raise InvalidDataError(
                    status_code=error_codes.INSUFFICIENT_BALANCE,
                    result={"balance": user_data.balance},
                    error_message=f"User {user_data.id} balance is less than the transaction amount."
                )
