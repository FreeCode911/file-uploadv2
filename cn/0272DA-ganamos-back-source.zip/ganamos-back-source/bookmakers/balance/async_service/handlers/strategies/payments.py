from datetime import datetime, timedelta

from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from sqlalchemy.ext.asyncio import AsyncSession
from tornado.options import options

from betronic_core.db.models.payments import CONFIRM, WAIT
from betronic_core.db.models.user import UserModel
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.money_manager.async_manager import AsyncMoneyManager
from betronic_core.payment_manager.async_manager import AsyncPaymentManager
from bookmakers.balance.models import UserChangeBalanceData
from bookmakers.balance.util.dynamic_transfer_types_detector import (
    transfer_types_by_payment_provider
)
from util.error import InvalidDataError
from util.validators import as_decimal
from .base import ChangeBalanceAbstractStrategy


class PaymentsTransactionStrategy(ChangeBalanceAbstractStrategy):
    @classmethod
    async def process(
            cls,
            data: UserChangeBalanceData,
            user_general_data: UserModel,
            connection: AsyncSession
    ) -> dict:
        method = cls.get_method_by_transaction_type(data.transaction_type)
        transfer, transaction, balance, extra = await method(data, user_general_data, connection)

        return {
            "txn_id": transfer.id,
            "balance": balance,
            "extra": {
                "payment_txn_id": transaction.id,
                **extra
            }
        }

    @classmethod
    def get_method_by_transaction_type(cls, transaction_type: str):
        return getattr(cls, f"_{transaction_type}")

    @classmethod
    async def _check_allow_withdrawal(
            cls, user_data: UserModel, withdrawal_data: UserChangeBalanceData, connection: AsyncSession
    ):
        today_date = datetime.now()
        day_ago = today_date - timedelta(hours=24)
        withdrawals_sum = await AsyncPaymentManager.get_withdrawals_sum_by_period_user_id(
            user_data.id, day_ago, today_date, connection
        )
        if as_decimal(withdrawals_sum) + as_decimal(withdrawal_data.amount) > as_decimal(options.WITHDRAWALS_SUM_PER_DAY):
            raise InvalidDataError(error_codes.INSUFFICIENT_BALANCE, "Daily withdrawals limit has been reached.")

    @classmethod
    def _check_is_auto_withdrawal(cls, withdrawal_data: UserChangeBalanceData):
        if withdrawal_data.amount <= options.MAX_WITHDRAWAL_WITHOUT_ADMIN_ACCEPT:
            return True

        return False

    @classmethod
    async def _deposit(cls, data: UserChangeBalanceData, user_data: UserModel, connection: AsyncSession):
        await cls._check_for_duplicates(data.transaction_id, connection)

        system_transaction_type = transfer_types_by_payment_provider[data.provider][data.transaction_type]
        transfer = await AsyncMoneyManager.user_move_money(
            UserModel.ORGANIZATION_ID, data.user_id, data.amount, system_transaction_type, note=data.transaction_id,
            transaction_id=data.transaction_id, connection=connection
        )
        payment_transaction = await AsyncPaymentManager.create_payment(user_data, data.provider, data.payment_mode,
                                                                       transfer, status=CONFIRM, connection=connection)

        await connection.refresh(user_data)
        user_balance = await AsyncMoneyManager.extract_total_balance(user=user_data)

        return transfer, payment_transaction, user_balance, {}

    @classmethod
    async def _withdrawal(cls, data: UserChangeBalanceData, user_data: UserModel, connection: AsyncSession):
        await cls._check_for_duplicates(data.transaction_id, connection)
        await cls._check_allow_withdrawal(user_data, data, connection)
        cls._check_balance_sufficiency(data, user_data)
        system_transaction_type = transfer_types_by_payment_provider[data.provider][data.transaction_type]
        transfer = await AsyncMoneyManager.user_move_money(
            user_data.id, UserModel.ORGANIZATION_ID, data.amount, system_transaction_type,
            note=data.transaction_id,
            transaction_id=data.transaction_id,
            connection=connection
        )
        is_auto_withdrawal_flag = cls._check_is_auto_withdrawal(data)
        withdrawal_transaction = await AsyncPaymentManager.create_withdrawal(user_data, data.provider,
                                                                             data.payment_mode, transfer,
                                                                             is_auto_withdrawal_flag,
                                                                             connection=connection)
        await connection.refresh(user_data)
        user_balance = await AsyncMoneyManager.extract_total_balance(user=user_data)

        return transfer, withdrawal_transaction, user_balance, {"is_auto_withdrawal": is_auto_withdrawal_flag}

    @classmethod
    async def _cancel_deposit(cls, data: UserChangeBalanceData, user_data: UserModel, connection: AsyncSession):

        payment_transaction = await AsyncPaymentManager.get_payment_by_transaction_id(
            data.transaction_id, connection, with_lock=True
        )
        if not payment_transaction:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_BET_NOT_FOUND,
                error_message="Payment doesn't exist."
            )
        if payment_transaction.status != WAIT:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_ALREADY_EXIST,
                error_message="Payment has already been closed."
            )

        system_transaction_type = transfer_types_by_payment_provider[data.provider][data.transaction_type]
        canceled_transfer = await AsyncMoneyManager.user_move_money(
            data.user_id, UserModel.ORGANIZATION_ID, payment_transaction.user_amount, system_transaction_type,
            note=data.transaction_id,
            transaction_id=data.transaction_id,
            connection=connection
        )
        await AsyncPaymentManager.cancel_payment(payment_transaction, canceled_transfer, connection)

        await connection.refresh(user_data)
        user_balance = await AsyncMoneyManager.extract_total_balance(user=user_data)
        return canceled_transfer, payment_transaction, user_balance, {}

    @classmethod
    async def _cancel_withdrawal(cls, data: UserChangeBalanceData, user_data: UserModel, connection: AsyncSession):
        withdrawal_transaction = await AsyncPaymentManager.get_withdrawal_by_transaction_id(
            data.transaction_id, connection, with_lock=True
        )
        if not withdrawal_transaction:
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_BET_NOT_FOUND,
                error_message="Payment doesn't exist."
            )
        if withdrawal_transaction.status not in (WithdrawalModel.CREATED, WithdrawalModel.PROCESSING):
            raise InvalidDataError(
                status_code=error_codes.TRANSACTION_ALREADY_EXIST,
                error_message="Payment has already been closed."
            )
        system_transaction_type = transfer_types_by_payment_provider[data.provider][data.transaction_type]
        canceled_transfer = await AsyncMoneyManager.user_move_money(
            UserModel.ORGANIZATION_ID, data.user_id, withdrawal_transaction.amount, system_transaction_type,
            note=data.transaction_id,
            transaction_id=data.transaction_id,
            connection=connection
        )
        await AsyncPaymentManager.cancel_withdrawal(withdrawal_transaction, canceled_transfer, connection),
        await connection.refresh(user_data)
        user_balance = await AsyncMoneyManager.extract_total_balance(user=user_data)
        return canceled_transfer, withdrawal_transaction, user_balance, {}
