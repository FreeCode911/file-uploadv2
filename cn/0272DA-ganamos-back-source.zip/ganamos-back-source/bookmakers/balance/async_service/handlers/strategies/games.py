from logging import getLogger
from typing import Tuple, Optional

from asyncpg.exceptions import QueryCanceledError
from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from sqlalchemy.dialects.postgresql.asyncpg import AsyncAdapt_asyncpg_dbapi
from sqlalchemy.exc import TimeoutError, InterfaceError
from sqlalchemy.ext.asyncio import AsyncSession

from betronic_core.cache_manager.manager import AsyncCacheManager
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.user import UserModel
from betronic_core.games_history_manager.async_manager import (
    AsyncGamesHistoryManager,
)
from betronic_core.money_manager.async_manager import AsyncMoneyManager
from bookmakers.balance.models import UserChangeBalanceData
from bookmakers.balance.util.dynamic_transfer_types_detector import (
    transfer_types_by_games_provider,
    from_user_types,
    to_user_types,
    rollback_provider_verify,
    rollback_user_types,
    revenue_block_types,
    types_from_marketing_money,
    bet_provider_check_duplicates,
    pragmatic_transfer_provider
)
from util.error import InvalidDataError
from util.validators import str_or_none
from .base import ChangeBalanceAbstractStrategy

logger = getLogger(__name__)


class GamesTransactionStrategy(ChangeBalanceAbstractStrategy):

    @classmethod
    async def process_real_transfer(
            cls,
            data: UserChangeBalanceData,
            user_general_data: UserModel,
            system_transaction_type: int = None,
            connection: AsyncSession = None
    ) -> Tuple[Optional[MoneyTransferModel], Optional[BonusTransferModel]]:
        transfer, bonus_transfer = None, None

        game_data = cls.get_game_data(data)
        additional_data = game_data

        if data.transaction_type in from_user_types:
            if data.provider in bet_provider_check_duplicates:
                await cls._check_for_duplicates(str_or_none(data.id_transaction_from_duplicates), connection)

            cls._check_balance_sufficiency(
                data=data,
                user_data=user_general_data
            )

            transfer = await AsyncMoneyManager.user_move_money(
                from_user=user_general_data,
                from_user_id=data.user_id,
                to_user_id=UserModel.ORGANIZATION_ID,
                value=data.amount,
                transfer_type=system_transaction_type,
                note=data.transaction_id,
                connection=connection,
                transaction_id=str_or_none(data.id_transaction_from_duplicates or data.transaction_id),
                currency=user_general_data.currency,
                additional_data=additional_data,
            )

        elif data.transaction_type in to_user_types:
            if data.transaction_type in types_from_marketing_money:
                transfer = await AsyncMoneyManager.move_marketing_money(
                    user_id=user_general_data.id,
                    transfer_type=system_transaction_type,
                    value=data.amount,
                    note=data.transaction_id,
                    connection=connection,
                    is_outcome=False,
                    is_bonus=False
                )
            else:
                if data.id_transaction_from_duplicates:
                    await cls._check_for_duplicates(str_or_none(data.id_transaction_from_duplicates), connection)

                transfer = await AsyncMoneyManager.user_move_money(
                    from_user_id=UserModel.ORGANIZATION_ID,
                    to_user=user_general_data,
                    to_user_id=user_general_data.id,
                    value=data.amount,
                    transfer_type=system_transaction_type,
                    note=data.transaction_id,
                    connection=connection,
                    transaction_id=str_or_none(data.id_transaction_from_duplicates or data.transaction_id),
                    currency=user_general_data.currency,
                    additional_data=additional_data,
                )

        return transfer, bonus_transfer

    @classmethod
    async def process(
            cls,
            data: UserChangeBalanceData,
            user_general_data: UserModel,
            system_transaction_type: int = None,
            connection: AsyncSession = None
    ) -> dict:
        system_transaction_type = (
                system_transaction_type or
                transfer_types_by_games_provider[data.provider][data.transaction_type]
        )

        try:
            if data.transaction_type in rollback_user_types:
                if data.transaction_id and (data.provider in rollback_provider_verify):

                    transaction_id = data.transaction_id
                    if data.provider in pragmatic_transfer_provider:
                        transaction_id = data.id_transaction_from_duplicates.replace("refund:", "")

                    await cls._check_for_exist_transfer_by_txn_id(
                        txn_id=transaction_id,
                        connection=connection)

            if (data.transaction_type in revenue_block_types
                    and not await AsyncCacheManager.get_integration_status(raise_exception=False)
                    or not user_general_data.changed_password
            ):
                raise InvalidDataError(
                    status_code=error_codes.INSUFFICIENT_BALANCE,
                    result={"balance": user_general_data.balance},
                    error_message=f"User {user_general_data.id} balance is less than the transaction amount."
                )

            transfer, bonus_transfer = await cls.process_real_transfer(
                data=data,
                user_general_data=user_general_data,
                system_transaction_type=system_transaction_type,
                connection=connection
            )
            await connection.refresh(user_general_data)

            balance = user_general_data.balance

            await AsyncGamesHistoryManager.process_history_data(transfer, data, connection)
        except (TimeoutError, InterfaceError,
                QueryCanceledError,
                AsyncAdapt_asyncpg_dbapi.Error) as timeout_exc:  # алхимия рейзит таймаут классом InterfaceError
            logger.error(f"Got timeout for transaction {data}. Error: {str(timeout_exc)}")
            raise InvalidDataError(status_code=error_codes.CUSTOM_ERROR, error_message="DB transaction is timeout.")
        return {
            "balance": balance,
            "txn_id": cls.get_txn_id(
                transfer=transfer,
                bonus_transfer=bonus_transfer
            )
        }

    @classmethod
    def get_game_data(cls, data: UserChangeBalanceData) -> dict:
        if not hasattr(data, "game_data"):
            return dict()

        if data.game_data is None:
            return dict()

        return {
            "game_name": data.game_data.name
        }