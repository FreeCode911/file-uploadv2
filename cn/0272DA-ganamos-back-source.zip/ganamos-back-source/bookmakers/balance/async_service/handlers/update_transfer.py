from betronic_core.money_manager.async_manager import AsyncMoneyManager
from bookmakers.balance.models import UpdateTransferData
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from betronic_core.db.async_database import session


class UpdateTransferService(AbstractDirectServiceHandler):
    data_model = UpdateTransferData

    @classmethod
    async def execute(cls, data: UpdateTransferData):
        async with session.begin() as transaction:
            result = await AsyncMoneyManager.update_transaction_id(
                original_txn_id=data.original_txn_id,
                new_txn_id=data.new_txn_id,
                user_id=data.user_id,
                connection=transaction.session
            )
        return result
