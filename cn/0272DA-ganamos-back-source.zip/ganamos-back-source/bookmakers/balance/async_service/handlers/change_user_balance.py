from logging import getLogger
from time import monotonic
from typing import Type

from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from tornado.options import options

from betronic_core.blocklist_manager.manager import BlocklistManager
from betronic_core.db.async_database import session
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.async_manager import AsyncUserManager
from bookmakers.balance.models import UserChangeBalanceData
from bookmakers.balance.util.dynamic_transfer_types_detector import (
    transfer_types_by_games_provider,
    transfer_types_by_payment_provider,
    from_user_types,
    to_user_types
)
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.error import InvalidDataError
from util.validators import round_value
from .strategies import ChangeBalanceAbstractStrategy, GamesTransactionStrategy, PaymentsTransactionStrategy

logger = getLogger(__name__)


class ChangeUserBalance(AbstractDirectServiceHandler):
    data_model = UserChangeBalanceData

    @classmethod
    async def execute(cls, data: UserChangeBalanceData) -> dict:
        async with session.begin() as transaction:
            start_user_time = monotonic()
            user_general_data = await AsyncUserManager.get_user_general_data(
                user_id=data.user_id,
                with_lock=True,
                connection=transaction.session
            )
            end_user_time = monotonic() - start_user_time
            if not user_general_data:
                raise InvalidDataError(status_code=error_codes.USER_DOES_NOT_EXIST,
                                       error_message=f"User {data.user_id} does not exist!")

            cls._validate_transaction_params(data.provider, data.transaction_type)
            cls._check_user_access(user_general_data)

            start_cache_time = monotonic()
            await cls._check_user_providers_ban(data.provider, user_general_data, data.transaction_type)
            end_cache_time = monotonic()

            logger.info(f"Lock: {round_value(end_user_time, 6)} | "
                        f"Ban: {round_value(end_cache_time - start_cache_time, 6)}")

            strategy = cls._get_strategy(data.provider)

            result = await strategy.process(
                data, user_general_data, connection=transaction.session,
            )
            return result

    @classmethod
    def _get_strategy(cls, provider: str) -> Type[ChangeBalanceAbstractStrategy]:
        if provider in transfer_types_by_games_provider:
            return GamesTransactionStrategy
        elif provider in transfer_types_by_payment_provider:
            return PaymentsTransactionStrategy

        raise InvalidDataError(status_code=error_codes.UNEXPECTED_ERROR,
                               error_message=f"Strategy of {provider} not implemented")

    @staticmethod
    def _validate_transaction_params(provider: str, transaction_type: str):
        if provider not in transfer_types_by_games_provider and provider not in transfer_types_by_payment_provider:
            raise InvalidDataError(status_code=error_codes.PROVIDER_NOT_IMPLEMENTED,
                                   error_message=f"Provider {provider} not added.")

        if transaction_type not in (from_user_types + to_user_types):
            raise InvalidDataError(status_code=error_codes.TRANSACTION_TYPE_NOT_ADDED,
                                   error_message=f"Transaction type {transaction_type} not implemented.")

        if (transaction_type not in transfer_types_by_games_provider.get(provider, {}).keys() and
                transaction_type not in transfer_types_by_payment_provider.get(provider, {}).keys()):
            raise InvalidDataError(status_code=error_codes.PROVIDER_NOT_SUPPORT_TYPE,
                                   error_message=f"Provider does not support this type {transaction_type}.")

    @staticmethod
    def _check_user_access(user: UserModel):
        if user.is_banned:
            raise InvalidDataError(
                status_code=error_codes.USER_IS_BANNED,
                error_message=f"User {user.id} was banned"
            )

    @staticmethod
    async def _check_user_providers_ban(provider, user, transaction_type: str):
        
        if transaction_type in to_user_types:
            return
        
        banned_providers = await BlocklistManager.async_check_user_for_blocked_providers(user.id, user.parent_agent_id)
        provider = options.PROVIDERS_MAP_IN_PERMISSION.get(provider)
        if provider in banned_providers:
            raise InvalidDataError(
                status_code=error_codes.USER_IS_BANNED,
                error_message=f"User {user.id} has been banned for this provider"
            )
