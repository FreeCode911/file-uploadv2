from betronic_core.payment_manager.async_manager import AsyncPaymentManager
from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes

from betronic_core.db.async_database import session
from betronic_core.db.models.payments import PaymentTransactionModel

from bookmakers.balance.models import UpdateDepositData
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler

from util.error import InvalidDataError


class UpdateDepositService(AbstractDirectServiceHandler):
    data_model = UpdateDepositData

    @classmethod
    async def execute(cls, update_data: UpdateDepositData):
        async with session.begin() as transaction:
            deposit_db: PaymentTransactionModel = await AsyncPaymentManager \
                .get_payment_by_transaction_id(
                    transaction_id=update_data.transaction_id,
                    connection=transaction.session
                )
            if not deposit_db:
                raise InvalidDataError(
                    status_code=error_codes.UNEXPECTED_ERROR,
                    error_message=f"payment with transaction ID {update_data.transaction_id} not found"
                )

        return {'deposit_id': deposit_db.id}
