from bsw.balance_client.models import RemoteStatusTypeEnum as error_codes
from pydantic import create_model

from betronic_core.cache_manager.manager import AsyncCacheManager
from betronic_core.db.models.user import UserModel
from betronic_core.user_manager.async_manager import AsyncUserManager
from bookmakers.balance.models import UserBalanceGetData
from bookmakers.services.abstract_direct_handler import AbstractDirectServiceHandler
from util.error import InvalidDataError


class GetUserBalance(AbstractDirectServiceHandler):
    data_model = UserBalanceGetData

    @classmethod
    async def execute(cls, data: UserBalanceGetData) -> dict:
        if not await AsyncCacheManager.get_integration_status(raise_exception=False):
            cls.log.info(f"Games are not available at the moment")
            return {
                "balance": 0
            }

        cls.log.info(f'Get request: {data} for get user balance in async balance service')
        user_general_data: UserModel = await \
            AsyncUserManager.get_user_general_data(user_id=data.user_id)

        if user_general_data:
            if not user_general_data.changed_password:
                return {
                    "balance": 0
                }

        cls.check_user(user_general_data, data.user_id)

        cls.log.info(f'User balance: {user_general_data.balance}, '
                     f'bonus_balance: {user_general_data.bonus_balance}')

        user_balance = user_general_data.balance

        return {
            "balance": user_balance
        }

    @staticmethod
    def check_user(user_data: create_model, request_user_id: int):
        if not user_data:
            raise InvalidDataError(
                status_code=error_codes.USER_DOES_NOT_EXIST,
                error_message=f'User {request_user_id} does not exist'
            )

        if user_data.is_banned:
            raise InvalidDataError(
                status_code=error_codes.USER_IS_BANNED,
                error_message=f'User {user_data.id} was banned'
            )
