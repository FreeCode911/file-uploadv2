from betronic_core.constants import (
    TransferTypes as TT,
    BalanceServiceProviderName as ProviderName
)

from_user_types = ["debit", "cancel_credit", "bet", "win_from_user", "lost_from_user", "cashed_out_from_user",
                   "returned_from_user", "rollback_outcome", "withdrawal", "cancel_deposit", "frb_bet", "lose"]
to_user_types = ["credit", "cancel_debit", "win", "refund", "win_to_user", "lost_to_user", "rollback",
                 "cashed_out", "cashed_out_to_user", "returned", "returned_to_user", "rollback_income", "deposit",
                 "cancel_withdrawal", "frb_win", "promo", "jackpot_win", "jackpot", "promo_payout",
                 "return_bet", "credit_jackpot", "tournament_credit", "promo_credit"]
rollback_user_types = ['cancel_debit', 'cancel_credit', 'refund', 'rollback', 'returned', 'returned_from_user',
                       'returned_to_user', 'rollback_income', 'rollback_outcome', 'return_bet']

types_allowed_to_insufficient = ["win_from_user", "lost_from_user", "returned_from_user", "cashed_out_from_user",
                                 "cancel_credit", "rollback_outcome"]

revenue_block_types = ["debit", "bet", "cashed_out", "cashed_out_to_user"]

allow_bonus_transfer_provider = []
rollback_provider_verify = [ProviderName.DIGITAIN, ProviderName.PRAGMATIC_SLOTS, ProviderName.PRAGMATIC_BJ,
                            ProviderName.PRAGMATIC_LIVE_CASINO]

bet_provider_check_duplicates = [
    ProviderName.PRAGMATIC_SLOTS,
    ProviderName.PRAGMATIC_BJ,
    ProviderName.PRAGMATIC_LIVE_CASINO
]

pragmatic_transfer_provider = [
    ProviderName.PRAGMATIC_SLOTS,
    ProviderName.PRAGMATIC_BJ,
    ProviderName.PRAGMATIC_LIVE_CASINO
]

transfer_types_by_games_provider = {
    ProviderName.TVBET: {
        "debit": TT.TYPE_TVBET_BET,
        "credit": TT.TYPE_TVBET_PRISE,
        "refund": TT.TYPE_TVBET_ROLLBACK,
        "cancel_debit": TT.TYPE_TVBET_ROLLBACK,
        "credit_jackpot": TT.TYPE_TVBET_JACKPOT,
    },
    ProviderName.DIGITAIN: {
        "debit": TT.TYPE_DIGITAIN_BET,
        "credit": TT.TYPE_DIGITAIN_WIN,
        "cancel_debit": TT.TYPE_DIGITAIN_ROLLBACK_BET,
        "cancel_credit": TT.TYPE_DIGITAIN_ROLLBACK_WIN,
        "lose": TT.TYPE_DIGITAIN_ROLLBACK_LOST,
    },
    ProviderName.SLOTEGRATOR: {
        "win": TT.TYPE_SLOTEGRATOR_WIN,
        "bet": TT.TYPE_SLOTEGRATOR_BET,
        "refund": TT.TYPE_SLOTEGRATOR_REFUND,
        "rollback_income": TT.TYPE_SLOTEGRATOR_ROLLBACK_INCOME,
        "rollback_outcome": TT.TYPE_SLOTEGRATOR_ROLLBACK_OUTCOME
    },
    ProviderName.OUTCOME: {
        "debit": TT.TYPE_OUTCOMEBET_BET,
        "credit": TT.TYPE_OUTCOMEBET_PRIZE,
        "cancel_debit": TT.TYPE_OUTCOMEBET_CANCEL_BET,
        "cancel_credit": TT.TYPE_OUTCOMEBET_CANCEL_PRIZE
    },
    ProviderName.GOLDENRACE: {
        "debit": TT.TYPE_GR_BET,
        "credit": TT.TYPE_GR_WIN,
        "cancel_debit": TT.TYPE_GR_ROLLBACK
    },
    ProviderName.PRAGMATIC_SLOTS: {
        "bet": TT.TYPE_PRAGMATIC_SLOTS_BET,
        "win": TT.TYPE_PRAGMATIC_SLOTS_RESULT,
        "refund": TT.TYPE_PRAGMATIC_SLOTS_REFUND,
        "promo": TT.TYPE_PRAGMATIC_SLOTS_PROMO,
        "jackpot": TT.TYPE_PRAGMATIC_SLOTS_JACKPOT,
        "frb_bet": TT.TYPE_PRAGMATIC_SLOTS_FRB,
        "frb_win": TT.TYPE_PRAGMATIC_SLOTS_FRB_WIN,
    },
    ProviderName.PRAGMATIC_LIVE_CASINO: {
        "bet": TT.TYPE_PRAGMATIC_LC_BET,
        "win": TT.TYPE_PRAGMATIC_LC_RESULT,
        "refund": TT.TYPE_PRAGMATIC_LC_REFUND,
        "promo": TT.TYPE_PRAGMATIC_LC_PROMO,
        "jackpot": TT.TYPE_PRAGMATIC_LC_JACKPOT,
        "frb_bet": TT.TYPE_PRAGMATIC_LC_FRB,
        "frb_win": TT.TYPE_PRAGMATIC_LC_FRB_WIN,
    },
    ProviderName.PRAGMATIC_BJ: {
        "bet": TT.TYPE_PRAGMATIC_BJ_BET,
        "win": TT.TYPE_PRAGMATIC_BJ_RESULT,
        "refund": TT.TYPE_PRAGMATIC_BJ_REFUND,
        "promo": TT.TYPE_PRAGMATIC_BJ_PROMO,
        "jackpot": TT.TYPE_PRAGMATIC_BJ_PROMO,
        "frb_bet": TT.TYPE_PRAGMATIC_BJ_FRB,
        "frb_win": TT.TYPE_PRAGMATIC_BJ_FRB_WIN,
    },
    ProviderName.RUBIPLAY: {
        "debit": TT.TYPE_RUBIPLAY_DEBIT,
        "credit": TT.TYPE_RUBIPLAY_CREDIT,
        "cancel_debit": TT.TYPE_RUBIPLAY_CANCEL_DEBIT,
    },
    ProviderName.EVOLUTION_ORIGINAL: {
        "debit": TT.TYPE_EVOLUTION_ORIGINAL_DEBIT,
        "credit": TT.TYPE_EVOLUTION_ORIGINAL_CREDIT,
        "cancel_debit": TT.TYPE_EVOLUTION_ORIGINAL_CANCEL_DEBIT,
        "promo_payout": TT.TYPE_EVOLUTION_ORIGINAL_CANCEL_DEBIT,
    },
    ProviderName.UNIVERSALRACE: {
        "bet": TT.TYPE_UNIVERSALRACE_BET,
        "win": TT.TYPE_UNIVERSALRACE_WIN,
        "return_bet": TT.TYPE_UNIVERSALRACE_RETURN_BET
    },
    ProviderName.SOFTGAMING_SLOTS: {
        "debit": TT.TYPE_SOFT_SLOTS_DEBIT,
        "credit": TT.TYPE_SOFT_SLOTS_CREDIT,
        "cancel_debit": TT.TYPE_SOFT_SLOTS_CANCEL_DEBIT,
        "cancel_credit": TT.TYPE_SOFT_SLOTS_CANCEL_CREDIT
    },
    ProviderName.EZUGI: {
        "debit": TT.TYPE_EZUGI_BET,
        "credit": TT.TYPE_EZUGI_WIN,
        "cancel_debit": TT.TYPE_EZUGI_ROLLBACK,
    },
    ProviderName.POPOKGAMING: {
        "debit": TT.TYPE_POPOKGAMING_BET,
        "credit": TT.TYPE_POPOKGAMING_WIN,
        "cancel_debit": TT.TYPE_POPOKGAMING_ROLLBACK_BET,
        "tournament_credit": TT.TYPE_POPOKGAMING_TOURNAMENT_WIN,
        "promo_credit": TT.TYPE_POPOKGAMING_PROMO_WIN
    },
    ProviderName.EZUGI_EVOLUTION: {
        "debit": TT.TYPE_EVOLUTION_EZUGI_BET,
        "credit": TT.TYPE_EVOLUTION_EZUGI_WIN,
        "cancel_debit": TT.TYPE_EVOLUTION_EZUGI_ROLLBACK,
    },
    ProviderName.REDRAKE: {
        "debit": TT.TYPE_REDRAKE_DEBIT,
        "credit": TT.TYPE_REDRAKE_CREDIT,
        "cancel_debit": TT.TYPE_REDRAKE_CANCEL_DEBIT,
        "cancel_credit": TT.TYPE_REDRAKE_CANCEL_CREDIT
    }
}

transfer_types_by_payment_provider = {

}

types_from_marketing_money = {
    "frb_win",
}
