from logging import getLogger
from urllib.parse import urlencode

from tornado.options import options

from bookmakers.services.commands import AbstractResult
from bookmakers.web.decorators import result_decorator
from bookmakers.web.request_handler_mixins import RequestHandler, UserMixin, GetRequestArgsMixin, CacheMixin
from bookmakers.xprogaming.service import commands
from bookmakers.xprogaming.service.service_connector import XPGServiceConnector
from bookmakers.xprogaming.util.fetcher import XProGamingFetcher
from bookmakers.xprogaming.web.handlers.schemas.session import XPGCreateUserSessionSchema
from util.error import InvalidDataError

logger = getLogger(__name__)


class XPGCreateUserSession(RequestHandler, UserMixin, GetRequestArgsMixin, CacheMixin):
    get_params_model = XPGCreateUserSessionSchema

    @result_decorator
    async def get(self):
        await self.check_integration_status()
        user = await self.get_user_required()
        await self.check_user_providers_ban("xpg", user['id'], user['parent_agent_id'])
        if not user['changed_password']:
            return AbstractResult(-1, None, "You cannot place bets")
        options_args = self.get_args_dict().dict()

        connector = await XPGServiceConnector.get_instance()
        created_session_data = await connector.execute_command(commands.CreateSession, user)

        body_for_register_token = created_session_data.result
        response_from_register = await XProGamingFetcher.fetch_register_token(body_for_register_token)
        if int(response_from_register.get("errorCode")):
            logger.info(response_from_register)
            raise InvalidDataError(error_message="Bad response from XPG")

        data_for_lobby = {
            "token": response_from_register["description"],
            "username": body_for_register_token["username"],
            "operatorId": body_for_register_token["operatorId"]
        }
        data_for_lobby.update({"LanguageID": options_args["lang"]}) if options_args.get("lang") else None
        urlencoded_data = urlencode(data_for_lobby)
        result_lobby_url = options.XPG_GAME_LOBBY_URL + urlencoded_data

        return AbstractResult(0, result_lobby_url)
