from typing import List, Union

from pydantic import BaseModel
from pydantic import validator


class XPGBalanceSchema(BaseModel):
    Login: str = None
    Logins: List[str] = None


class XPGDebitSchema(BaseModel):
    Login: str
    GameId: int
    RoundId: int
    Sequence: int
    Amount: str
    OperatorId: Union[str, int]
    DebitDetails: Union[str, int]


class XPGCreditSchema(BaseModel):
    Login: str
    GameId: int
    RoundId: int
    Amount: str
    OperatorId: Union[str, int]
    CreditDetails: Union[str, int]


class XPGCancelTransactionSchema(BaseModel):
    ProviderId: int
    TransactionId: str
    Login: str
    GameId: int
    RoundId: int
    Sequence: int
    OperatorId: Union[str, int]


class XPGCancelRoundSchema(BaseModel):
    Logins: List[str]
    GameId: int
    RoundId: int
    OperatorId: Union[str, int]


class XPGExternalDebitSchema(BaseModel):
    Login: str
    GameId: int
    RoundId: int
    TransactionId: str
    ProviderId: int
    Amount: str


class XPGExternalCreditSchema(BaseModel):
    Login: str
    GameId: int
    RoundId: int
    TransactionId: str
    ProviderId: int
    Amount: str


class XPGExternalRefundSchema(BaseModel):
    Login: str
    GameId: int
    RoundId: int
    TransactionId: str
    ProviderId: int
    Amount: str