from logging import getLogger

from tornado.gen import coroutine

from util.error import CustomError
from betronic_core.xprogaming_manager import error_codes

logger = getLogger(__name__)


def xpg_result_decorator(handler):
    """
    :param handler:
    :return: unique response for GoldenRace API
    """

    @coroutine
    def decorator(self, *args, **kwargs):
        response = {}
        try:
            result = yield handler(self, *args, **kwargs)
            response = result.get_xpg_response()
        except CustomError as e:
            custom_error_response = {
                "ErrorCode": e.status_code,
                "HasErrors": True,
                "Message": e.error_message
            }
            response.update(custom_error_response)
        except Exception as e:
            exc_error_response = {
                "ErrorCode": error_codes.UNSPECIFIED_ERROR,
                "HasErrors": False,
                "Message": str(e)
            }
            response.update(exc_error_response)
        finally:
            handler_name = self.__class__.__name__.replace("Handler", "")
            logger.info("Send response from %s with body: %s " % (handler_name, response))
            self.write({"d": response})
    return decorator
