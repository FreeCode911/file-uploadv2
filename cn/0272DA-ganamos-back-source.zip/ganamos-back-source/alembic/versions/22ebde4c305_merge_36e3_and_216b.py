"""merge 36e3 and 216b

Revision ID: 22ebde4c305
Revises: ('36e3f1ccfe', '216b3212514')
Create Date: 2018-04-05 17:40:37.275647

"""

# revision identifiers, used by Alembic.
revision = '22ebde4c305'
down_revision = ('36e3f1ccfe', '216b3212514')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
