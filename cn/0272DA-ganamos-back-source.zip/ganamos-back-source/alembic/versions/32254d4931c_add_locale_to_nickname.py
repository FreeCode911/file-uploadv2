"""“add_locale_to_nickname”

Revision ID: 32254d4931c
Revises: 4baf76dc46f
Create Date: 2024-04-02 14:13:45.953596

"""

# revision identifiers, used by Alembic.
revision = '32254d4931c'
down_revision = '4baf76dc46f'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.execute('ALTER TABLE "user" ALTER COLUMN nickname SET DATA TYPE character varying(60) COLLATE "es-x-icu"')

def downgrade():
    op.execute('ALTER TABLE "user" ALTER COLUMN nickname set data type character varying(60)')

