"""empty message

Revision ID: 3f47d8488a4
Revises: ('32254d4931c', '32c6cb19a67')
Create Date: 2024-04-04 11:36:12.867546

"""

# revision identifiers, used by Alembic.
revision = '3f47d8488a4'
down_revision = ('32254d4931c', '32c6cb19a67')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
