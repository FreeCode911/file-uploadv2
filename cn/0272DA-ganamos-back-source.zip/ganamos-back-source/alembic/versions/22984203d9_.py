"""empty message

Revision ID: 22984203d9
Revises: ('338e0952ba5', '115920b7c9d')
Create Date: 2024-02-27 23:22:35.819570

"""

# revision identifiers, used by Alembic.
revision = '22984203d9'
down_revision = ('338e0952ba5', '115920b7c9d')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
