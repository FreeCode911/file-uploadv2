"""create indexes favorite, additional_data

Revision ID: 1ba01a75d7a
Revises: 55f9dbec2fd
Create Date: 2024-03-07 21:07:29.763149

"""

# revision identifiers, used by Alembic.
revision = '1ba01a75d7a'
down_revision = '55f9dbec2fd'

from alembic import op
from sqlalchemy import text



def upgrade():
    op.execute(text("""CREATE INDEX IF NOT EXISTS favorite_slots_user_id_idx
        ON favorite_slots (user_id);"""))
    op.execute(text("""CREATE INDEX IF NOT EXISTS additional_data_user_id_idx
        ON additional_data (user_id);"""))

def downgrade():
    op.execute(text("""DROP INDEX IF EXISTS favorite_slots_user_id_idx;"""))
    op.execute(text("""DROP INDEX IF EXISTS additional_data_user_id_idx;"""))