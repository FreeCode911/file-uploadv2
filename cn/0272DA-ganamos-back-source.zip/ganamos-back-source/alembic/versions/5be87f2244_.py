"""empty message

Revision ID: 5be87f2244
Revises: ('fd11b703b3', '1a677fbf3c2')
Create Date: 2024-04-24 16:27:29.004178

"""

# revision identifiers, used by Alembic.
revision = '5be87f2244'
down_revision = ('fd11b703b3', '1a677fbf3c2')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
