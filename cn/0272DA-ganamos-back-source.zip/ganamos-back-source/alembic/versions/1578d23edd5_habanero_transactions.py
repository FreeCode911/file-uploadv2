"""habanero_transactions

Revision ID: 1578d23edd5
Revises: 4ce1ffd429f
Create Date: 2020-10-15 15:09:26.606074

"""

# revision identifiers, used by Alembic.
revision = '1578d23edd5'
down_revision = '4ce1ffd429f'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

def upgrade():
    op.create_table('habanero_transactions',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('habanero_transaction_id', sa.String(length=500), nullable=False, unique=True),
    sa.Column('token', sa.String(length=255), nullable=False),
    sa.Column('game_instance_id', sa.String(length=255), nullable=False),
    sa.Column('transfer_id', sa.Integer(), nullable=True),
    sa.Column('user_id', sa.Integer(), nullable=True),
    sa.Column('game_state_mode', sa.SmallInteger(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['transfer_id'], ['transfer.id'], ),
    sa.ForeignKeyConstraint(['user_id'], ['user.id'], ),
    sa.PrimaryKeyConstraint('id')
    )



def downgrade():
    op.drop_table('habanero_transactions')
