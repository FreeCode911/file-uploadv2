"""empty message

Revision ID: 5581808e691
Revises: ('15dbf99dc30', '4da71070de2')
Create Date: 2018-04-14 18:25:29.029196

"""

# revision identifiers, used by Alembic.
revision = '5581808e691'
down_revision = ('15dbf99dc30', '4da71070de2')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
