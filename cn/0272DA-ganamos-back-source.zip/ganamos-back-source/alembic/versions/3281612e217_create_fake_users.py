"""create fake users

Revision ID: 3281612e217
Revises: 3146a39ffd7
Create Date: 2017-03-21 11:39:59.590505

"""

# revision identifiers, used by Alembic.
revision = '3281612e217'
down_revision = '3146a39ffd7'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table

ORGANISATION_ID = -1
PAYMENTS_ID = -2
WITHDRAWAL_ID = -3


def upgrade():
    _add_fake_users()


def downgrade():
    _remove_fake_users()


def _get_users_table():
    users = table(
        'user',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('first_name', sa.String(length=5)),
        sa.Column('currency', sa.String(length=5)), )
    return users


def _add_fake_users():
    users = _get_users_table()
    op.execute(users.insert().values(
        id=ORGANISATION_ID,
        first_name='organisation',
        currency='USD', ))
    op.execute(users.insert().values(
        id=WITHDRAWAL_ID,
        first_name='withdrawal',
        currency='USD', ))
    op.execute(users.insert().values(
        id=PAYMENTS_ID,
        first_name='payments',
        currency='USD', ))


def _remove_fake_users():
    users = _get_users_table()
    op.execute(users.delete().where(users.c.id == ORGANISATION_ID))
    op.execute(users.delete().where(users.c.id == WITHDRAWAL_ID))
    op.execute(users.delete().where(users.c.id == PAYMENTS_ID))
