"""merge

Revision ID: 52eb9644e72
Revises: ('62baf33da1', '88fb76cade')
Create Date: 2017-12-20 16:52:24.087984

"""

# revision identifiers, used by Alembic.
revision = '52eb9644e72'
down_revision = ('62baf33da1', '88fb76cade')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
