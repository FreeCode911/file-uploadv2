"""add_habanero_token_model

Revision ID: 4ce1ffd429f
Revises: 4f54d813648
Create Date: 2020-10-08 18:43:34.654230

"""

# revision identifiers, used by Alembic.
revision = '4ce1ffd429f'
down_revision = '4f54d813648'

from alembic import op
import sqlalchemy as sa


def upgrade():
    op.create_table('habanero_token',
    sa.Column('id', sa.Integer(), nullable=False),
    sa.Column('token', sa.String(length=500), nullable=True),
    sa.Column('user_id', sa.Integer(), nullable=True),
    sa.Column('created_at', sa.DateTime(), nullable=True),
    sa.ForeignKeyConstraint(['user_id'], ['user.id'], ),
    sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('habanero_token')
