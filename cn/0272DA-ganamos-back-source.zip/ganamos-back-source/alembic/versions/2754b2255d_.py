"""empty message

Revision ID: 2754b2255d
Revises: 209384533a8
Create Date: 2023-05-21 20:27:20.579810

"""

# revision identifiers, used by Alembic.
revision = '2754b2255d'
down_revision = '209384533a8'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table

MARKETING_OWNER_ID = -7


def _get_users_table():
    users = table(
        'user',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('first_name', sa.String(length=5)),
        sa.Column('currency', sa.String(length=5)),
        sa.Column('balance', sa.Numeric(precision=10, scale=2)),
        sa.Column('bonus_balance', sa.Numeric(precision=10, scale=2))

    )

    return users


def _add_bonus_owner():
    users = _get_users_table()

    op.execute(
        users.insert().values(
            id=MARKETING_OWNER_ID,
            first_name='marketing_owner',
            currency='ARS',
            balance=0.0,
            bonus_balance=0.0
        )
    )


def _remove_bonus_owner():
    users = _get_users_table()
    op.execute(users.delete().where(users.c.id == MARKETING_OWNER_ID))


def upgrade():
    _add_bonus_owner()


def downgrade():
    _remove_bonus_owner()
