"""merge lang and inbet_date

Revision ID: a57cf5548d
Revises: ('dbc367e65414', '24e3e52248d')
Create Date: 2018-02-26 12:24:10.100190

"""

# revision identifiers, used by Alembic.
revision = 'a57cf5548d'
down_revision = ('dbc367e65414', '24e3e52248d')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
