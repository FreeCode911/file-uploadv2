"""empty message

Revision ID: 677761205518
Revises: ('19fe5115a8e', '4a42cef1916', '88fb76cade')
Create Date: 2018-02-14 18:58:27.189917

"""

# revision identifiers, used by Alembic.
revision = '677761205518'
down_revision = ('19fe5115a8e', '4a42cef1916', '88fb76cade')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
