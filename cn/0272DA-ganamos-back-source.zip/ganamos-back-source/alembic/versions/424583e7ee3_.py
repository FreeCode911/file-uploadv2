"""empty message

Revision ID: 424583e7ee3
Revises: ('1e8ab9e0a9c', '37b6adfa6d7')
Create Date: 2024-03-19 11:01:51.174462

"""

# revision identifiers, used by Alembic.
revision = '424583e7ee3'
down_revision = ('1e8ab9e0a9c', '37b6adfa6d7')

from alembic import op
import sqlalchemy as sa


def upgrade():
    pass


def downgrade():
    pass
