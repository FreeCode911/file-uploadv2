"""caracal revision

Revision ID: c102403fab
Revises: 424583e7ee3
Create Date: 2024-03-18 14:36:51.975743

"""

# revision identifiers, used by Alembic.
revision = 'c102403fab'
down_revision = '3f47d8488a4'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.orm import Session
from scripts.create_indexes_for_referenced_tables import create_indexes_for_referenced
from scripts.recreate_foreign_constraints_with_cascade import create_cascade_constraints_for_referenced
import traceback


def upgrade():
    try:
        bind = op.get_bind()

        session = Session(bind)

        session.execute(sa.text("SET statement_timeout=0;"))
        session.execute(sa.text("SET idle_in_transaction_session_timeout=0;"))

        # Для пустой/локальной бд можно выполнить сразу пачкой, для заполненной - выполняется отдельно и по очереди.

        session.execute(sa.text("""
        set statement_timeout=3000;
        ALTER TABLE withdrawal ADD constraint _withdrawal_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE credit_ticket ADD constraint _credit_ticket_transfer_out_id_fkey foreign KEY (transfer_out_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE xpg_transactions ADD constraint _xpg_transactions_cancel_transfer_id_fkey foreign KEY (cancel_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE inbet_transaction ADD constraint _inbet_transaction_minus_transaction_id_fkey foreign KEY (minus_transaction_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE sport_coupon_history ADD constraint _sport_coupon_history_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE bsw_bet ADD constraint _bsw_bet_bet_transfer_id_fkey foreign KEY (bet_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE bsw_bet ADD constraint _bsw_bet_prize_transfer_id_fkey foreign KEY (prize_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE outcome_transaction ADD constraint _outcome_transaction_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE outcome_transaction_jackpot ADD constraint _outcome_transaction_jackpot_outcome_transaction_id_fkey foreign KEY (outcome_transaction_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE payment_transaction ADD constraint _payment_transaction_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE withdrawal ADD constraint _withdrawal_transfer_cancel_id_fkey foreign KEY (transfer_cancel_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE betgames_transactions ADD constraint _betgames_transactions_local_transaction_id_fkey foreign KEY (local_transaction_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE xpg_transactions ADD constraint _xpg_transactions_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE inbet_transaction ADD constraint _inbet_transaction_plus_transaction_id_fkey foreign KEY (plus_transaction_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE pragmatic_transactions ADD constraint _pragmatic_transactions_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE betroute_local_bet ADD constraint _betroute_local_bet_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE bet_ticket_model ADD constraint _bet_ticket_model_bet_id_fkey foreign KEY (bet_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE promo_codes_activation ADD constraint _promo_codes_activation_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE betroute_local_bet ADD constraint _betroute_local_bet_transfer_win_id_fkey foreign KEY (transfer_win_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE betroute_local_bet ADD constraint _betroute_local_bet_transfer_return_id_fkey foreign KEY (transfer_return_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE bet_content_data ADD constraint _bet_content_data_local_bet_id_fkey foreign KEY (local_bet_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE betroute_local_bet_response ADD constraint _betroute_local_bet_response_bet_id_fkey foreign KEY (bet_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE credit_ticket ADD constraint _credit_ticket_transfer_in_id_fkey foreign KEY (transfer_in_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE line1x_placed_coupon ADD constraint _line1x_placed_coupon_bet_transfer_id_fkey foreign KEY (bet_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE line1x_placed_coupon ADD constraint _line1x_placed_coupon_win_transfer_id_fkey foreign KEY (win_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE line1x_placed_coupon ADD constraint _line1x_placed_coupon_return_transfer_id_fkey foreign KEY (return_transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE line1x_bet_content ADD constraint _line1x_bet_content_local_coupon_id_fkey foreign KEY (local_coupon_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        ALTER TABLE habanero_transactions ADD constraint _habanero_transactions_transfer_id_fkey foreign KEY (transfer_id)references transfer (id) ON DELETE CASCADE NOT VALID;
        """))

        session.execute(sa.text("""
        set statement_timeout = 0;
        ALTER TABLE withdrawal VALIDATE CONSTRAINT _withdrawal_transfer_id_fkey;
        ALTER TABLE credit_ticket VALIDATE CONSTRAINT _credit_ticket_transfer_out_id_fkey;
        ALTER TABLE xpg_transactions VALIDATE CONSTRAINT _xpg_transactions_cancel_transfer_id_fkey;
        ALTER TABLE inbet_transaction VALIDATE CONSTRAINT _inbet_transaction_minus_transaction_id_fkey;
        ALTER TABLE sport_coupon_history VALIDATE CONSTRAINT _sport_coupon_history_transfer_id_fkey;
        ALTER TABLE bsw_bet VALIDATE CONSTRAINT _bsw_bet_bet_transfer_id_fkey;
        ALTER TABLE bsw_bet VALIDATE CONSTRAINT _bsw_bet_prize_transfer_id_fkey;
        ALTER TABLE outcome_transaction VALIDATE CONSTRAINT _outcome_transaction_transfer_id_fkey;
        ALTER TABLE outcome_transaction_jackpot VALIDATE CONSTRAINT _outcome_transaction_jackpot_outcome_transaction_id_fkey;
        ALTER TABLE payment_transaction VALIDATE CONSTRAINT _payment_transaction_transfer_id_fkey;
        ALTER TABLE withdrawal VALIDATE CONSTRAINT _withdrawal_transfer_cancel_id_fkey;
        ALTER TABLE betgames_transactions VALIDATE CONSTRAINT _betgames_transactions_local_transaction_id_fkey;
        ALTER TABLE xpg_transactions VALIDATE CONSTRAINT _xpg_transactions_transfer_id_fkey;
        ALTER TABLE inbet_transaction VALIDATE CONSTRAINT _inbet_transaction_plus_transaction_id_fkey;
        ALTER TABLE pragmatic_transactions VALIDATE CONSTRAINT _pragmatic_transactions_transfer_id_fkey;
        ALTER TABLE betroute_local_bet VALIDATE CONSTRAINT _betroute_local_bet_transfer_id_fkey;
        ALTER TABLE bet_ticket_model VALIDATE CONSTRAINT _bet_ticket_model_bet_id_fkey;
        ALTER TABLE promo_codes_activation VALIDATE CONSTRAINT _promo_codes_activation_transfer_id_fkey;
        ALTER TABLE betroute_local_bet VALIDATE CONSTRAINT _betroute_local_bet_transfer_win_id_fkey;
        ALTER TABLE betroute_local_bet VALIDATE CONSTRAINT _betroute_local_bet_transfer_return_id_fkey;
        ALTER TABLE bet_content_data VALIDATE CONSTRAINT _bet_content_data_local_bet_id_fkey;
        ALTER TABLE betroute_local_bet_response VALIDATE CONSTRAINT _betroute_local_bet_response_bet_id_fkey;
        ALTER TABLE credit_ticket VALIDATE CONSTRAINT _credit_ticket_transfer_in_id_fkey;
        ALTER TABLE line1x_placed_coupon VALIDATE CONSTRAINT _line1x_placed_coupon_bet_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon VALIDATE CONSTRAINT _line1x_placed_coupon_win_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon VALIDATE CONSTRAINT _line1x_placed_coupon_return_transfer_id_fkey;
        ALTER TABLE line1x_bet_content VALIDATE CONSTRAINT _line1x_bet_content_local_coupon_id_fkey;
        ALTER TABLE habanero_transactions VALIDATE CONSTRAINT _habanero_transactions_transfer_id_fkey;
        """))


        session.execute(sa.text("""
        set statement_timeout=3000;
        ALTER TABLE withdrawal DROP CONSTRAINT withdrawal_transfer_id_fkey;
        ALTER TABLE credit_ticket DROP CONSTRAINT credit_ticket_transfer_out_id_fkey;
        ALTER TABLE xpg_transactions DROP CONSTRAINT xpg_transactions_cancel_transfer_id_fkey;
        ALTER TABLE inbet_transaction DROP CONSTRAINT inbet_transaction_minus_transaction_id_fkey;
        ALTER TABLE sport_coupon_history DROP CONSTRAINT sport_coupon_history_transfer_id_fkey;
        ALTER TABLE bsw_bet DROP CONSTRAINT bsw_bet_bet_transfer_id_fkey;
        ALTER TABLE bsw_bet DROP CONSTRAINT bsw_bet_prize_transfer_id_fkey;
        ALTER TABLE outcome_transaction DROP CONSTRAINT outcome_transaction_transfer_id_fkey;
        ALTER TABLE outcome_transaction_jackpot DROP CONSTRAINT outcome_transaction_jackpot_outcome_transaction_id_fkey;
        ALTER TABLE payment_transaction DROP CONSTRAINT payment_transaction_transfer_id_fkey;
        ALTER TABLE withdrawal DROP CONSTRAINT withdrawal_transfer_cancel_id_fkey;
        ALTER TABLE betgames_transactions DROP CONSTRAINT betgames_transactions_local_transaction_id_fkey;
        ALTER TABLE xpg_transactions DROP CONSTRAINT xpg_transactions_transfer_id_fkey;
        ALTER TABLE inbet_transaction DROP CONSTRAINT inbet_transaction_plus_transaction_id_fkey;
        ALTER TABLE pragmatic_transactions DROP CONSTRAINT pragmatic_transactions_transfer_id_fkey;
        ALTER TABLE betroute_local_bet DROP CONSTRAINT betroute_local_bet_transfer_id_fkey;
        ALTER TABLE bet_ticket_model DROP CONSTRAINT bet_ticket_model_bet_id_fkey;
        ALTER TABLE promo_codes_activation DROP CONSTRAINT promo_codes_activation_transfer_id_fkey;
        ALTER TABLE betroute_local_bet DROP CONSTRAINT betroute_local_bet_transfer_win_id_fkey;
        ALTER TABLE betroute_local_bet DROP CONSTRAINT betroute_local_bet_transfer_return_id_fkey;
        ALTER TABLE bet_content_data DROP CONSTRAINT bet_content_data_local_bet_id_fkey;
        ALTER TABLE betroute_local_bet_response DROP CONSTRAINT betroute_local_bet_response_bet_id_fkey;
        ALTER TABLE credit_ticket DROP CONSTRAINT credit_ticket_transfer_in_id_fkey;
        ALTER TABLE line1x_placed_coupon DROP CONSTRAINT line1x_placed_coupon_bet_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon DROP CONSTRAINT line1x_placed_coupon_win_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon DROP CONSTRAINT line1x_placed_coupon_return_transfer_id_fkey;
        ALTER TABLE line1x_bet_content DROP CONSTRAINT line1x_bet_content_local_coupon_id_fkey;
        ALTER TABLE habanero_transactions DROP CONSTRAINT habanero_transactions_transfer_id_fkey;
        """))

        session.execute(sa.text("""
        set statement_timeout=3000;
        ALTER TABLE withdrawal RENAME CONSTRAINT _withdrawal_transfer_id_fkey TO withdrawal_transfer_id_fkey;
        ALTER TABLE credit_ticket RENAME CONSTRAINT _credit_ticket_transfer_out_id_fkey TO credit_ticket_transfer_out_id_fkey;
        ALTER TABLE xpg_transactions RENAME CONSTRAINT _xpg_transactions_cancel_transfer_id_fkey TO xpg_transactions_cancel_transfer_id_fkey;
        ALTER TABLE inbet_transaction RENAME CONSTRAINT _inbet_transaction_minus_transaction_id_fkey TO inbet_transaction_minus_transaction_id_fkey;
        ALTER TABLE sport_coupon_history RENAME CONSTRAINT _sport_coupon_history_transfer_id_fkey TO sport_coupon_history_transfer_id_fkey;
        ALTER TABLE bsw_bet RENAME CONSTRAINT _bsw_bet_bet_transfer_id_fkey TO bsw_bet_bet_transfer_id_fkey;
        ALTER TABLE bsw_bet RENAME CONSTRAINT _bsw_bet_prize_transfer_id_fkey TO bsw_bet_prize_transfer_id_fkey;
        ALTER TABLE outcome_transaction RENAME CONSTRAINT _outcome_transaction_transfer_id_fkey TO outcome_transaction_transfer_id_fkey;
        ALTER TABLE outcome_transaction_jackpot RENAME CONSTRAINT _outcome_transaction_jackpot_outcome_transaction_id_fkey TO outcome_transaction_jackpot_outcome_transaction_id_fkey;
        ALTER TABLE payment_transaction RENAME CONSTRAINT _payment_transaction_transfer_id_fkey TO payment_transaction_transfer_id_fkey;
        ALTER TABLE withdrawal RENAME CONSTRAINT _withdrawal_transfer_cancel_id_fkey TO withdrawal_transfer_cancel_id_fkey;
        ALTER TABLE betgames_transactions RENAME CONSTRAINT _betgames_transactions_local_transaction_id_fkey TO betgames_transactions_local_transaction_id_fkey;
        ALTER TABLE xpg_transactions RENAME CONSTRAINT _xpg_transactions_transfer_id_fkey TO xpg_transactions_transfer_id_fkey;
        ALTER TABLE inbet_transaction RENAME CONSTRAINT _inbet_transaction_plus_transaction_id_fkey TO inbet_transaction_plus_transaction_id_fkey;
        ALTER TABLE pragmatic_transactions RENAME CONSTRAINT _pragmatic_transactions_transfer_id_fkey TO pragmatic_transactions_transfer_id_fkey;
        ALTER TABLE betroute_local_bet RENAME CONSTRAINT _betroute_local_bet_transfer_id_fkey TO betroute_local_bet_transfer_id_fkey;
        ALTER TABLE bet_ticket_model RENAME CONSTRAINT _bet_ticket_model_bet_id_fkey TO bet_ticket_model_bet_id_fkey;
        ALTER TABLE promo_codes_activation RENAME CONSTRAINT _promo_codes_activation_transfer_id_fkey TO promo_codes_activation_transfer_id_fkey;
        ALTER TABLE betroute_local_bet RENAME CONSTRAINT _betroute_local_bet_transfer_win_id_fkey TO betroute_local_bet_transfer_win_id_fkey;
        ALTER TABLE betroute_local_bet RENAME CONSTRAINT _betroute_local_bet_transfer_return_id_fkey TO betroute_local_bet_transfer_return_id_fkey;
        ALTER TABLE bet_content_data RENAME CONSTRAINT _bet_content_data_local_bet_id_fkey TO bet_content_data_local_bet_id_fkey;
        ALTER TABLE betroute_local_bet_response RENAME CONSTRAINT _betroute_local_bet_response_bet_id_fkey TO betroute_local_bet_response_bet_id_fkey;
        ALTER TABLE credit_ticket RENAME CONSTRAINT _credit_ticket_transfer_in_id_fkey TO credit_ticket_transfer_in_id_fkey;
        ALTER TABLE line1x_placed_coupon RENAME CONSTRAINT _line1x_placed_coupon_bet_transfer_id_fkey TO line1x_placed_coupon_bet_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon RENAME CONSTRAINT _line1x_placed_coupon_win_transfer_id_fkey TO line1x_placed_coupon_win_transfer_id_fkey;
        ALTER TABLE line1x_placed_coupon RENAME CONSTRAINT _line1x_placed_coupon_return_transfer_id_fkey TO line1x_placed_coupon_return_transfer_id_fkey;
        ALTER TABLE line1x_bet_content RENAME CONSTRAINT _line1x_bet_content_local_coupon_id_fkey TO line1x_bet_content_local_coupon_id_fkey;
        ALTER TABLE habanero_transactions RENAME CONSTRAINT _habanero_transactions_transfer_id_fkey TO habanero_transactions_transfer_id_fkey;
        """))

        # create_cascade_constraints_for_referenced("transfer", session)
        create_indexes_for_referenced(session, "transfer", concurrently_flag=False)

    except Exception as e:
        session.rollback()
        traceback.print_exc()
    else:
        session.commit()
    finally:
        session.close()


def downgrade():
    pass
