"""add fake user ticket

Revision ID: 0ae41e799204
Revises: ef2372f7bc29
Create Date: 2017-03-27 12:58:13.314120

"""

# revision identifiers, used by Alembic.
revision = '0ae41e799204'
down_revision = 'ef2372f7bc29'

from alembic import op
import sqlalchemy as sa
from sqlalchemy.sql import table

TICKET_USER_ID = -4


def upgrade():
    _add_fake_users()


def downgrade():
    _remove_fake_users()


def _get_users_table():
    users = table(
        'user',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('first_name', sa.String(length=5)),
        sa.Column('currency', sa.String(length=5)), )
    return users


def _add_fake_users():
    users = _get_users_table()
    op.execute(users.insert().values(
        id=TICKET_USER_ID,
        first_name='organisation',
        currency='USD', ))


def _remove_fake_users():
    users = _get_users_table()
    op.execute(users.delete().where(users.c.id == TICKET_USER_ID))
