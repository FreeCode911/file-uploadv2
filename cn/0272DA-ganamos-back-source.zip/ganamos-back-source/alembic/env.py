import sys

import os

sys.path.append(os.getcwd())
from alembic import context
from sqlalchemy import create_engine
from logging.config import fileConfig
from settings.setup_settings import setup_settings


# this is the Alembic Config object, which provides
# access to the values within the .ini file in use.
config = context.config

# Interpret the config file for Python logging.
# This line sets up loggers basically.
fileConfig(config.config_file_name)

setup_settings()

# add your model's MetaData object here
# for 'autogenerate' support
from betronic_core.db.database import DataBase
from betronic_core.db.models.base import BaseModel
from settings.setup_settings import get_all_settings

from betronic_core.db.models.user import UserModel
from betronic_core.db.models.bonus_transfer import BonusTransferModel
from betronic_core.db.models.email_auth import EmailAuthModel
from betronic_core.db.models.betroute_registration import BetrouteRegistrationModel
from betronic_core.db.models.notifications.email_notification import EmailNotification
from betronic_core.db.models.money_transfer import MoneyTransferModel
from betronic_core.db.models.payments import PaymentTransactionModel
from betronic_core.db.models.click import ClickModel
from betronic_core.db.models.currency_rate import CurrencyRateModel
from betronic_core.db.models.withdrawal import WithdrawalModel
from betronic_core.db.models.user_payments_data import UserPaymentsDataModel
from bookmakers.user.service.handlers.restore_password import RestorePasswordRequestHandler
from betronic_core.db.models.flat_page import FlatPageModel
from betronic_core.db.models.terminal.credit_ticket import CreditTicketModel
from betronic_core.db.models.terminal.bet_ticket import BetTicketModel
from betronic_core.db.models.betroute_local_bet import BetrouteLocalBetModel, \
    BetrouteLocalBetResponseModel
from betronic_core.db.models.feedback_form_question import FeedbackFormQuestionModel
from betronic_core.db.models.additional_data import AdditionalData
from betronic_core.db.models.ads import AdsModel
from betronic_core.db.models.slide import Slide
from betronic_core.db.models.social_auth import VkAuthModel, GoogleAuthModel, \
    OdnoklassnikiAuthModel, FacebookAuthModel
from betronic_core.db.models.city import City
from betronic_core.db.models.terminal.terminal_data import TerminalData
from betronic_core.db.models.favorit import FavoritModel
from betronic_core.db.models.promo_code import PromoCodeModel, PromoCodeActivationModel
from betronic_core.db.models.inbet import InbetSessionModel, InbetTransactionModel
from betronic_core.db.models.partner_money_transfer import PartnerMoneyTransfer
from betronic_core.db.models.betgames_session import BetGamesSessionModel
from betronic_core.db.models.betgames_transactions import BetgamesTransactionModel
from betronic_core.db.models.partner_materials import PartnerMaterialsModel
from betronic_core.db.models.category import CategoryModel
from betronic_core.db.models.terminal.bet_ticket import BetTicketModel
from betronic_core.db.models.cashier_data import CashierDataModel
from betronic_core.db.models.outcomebet import OutComeBetSessionModel
from betronic_core.db.models.mascot import MascotSessionModel
from betronic_core.db.models.ezugi_transaction import EzugiTransferModel
from betronic_core.db.models.roulette_stats import RouletteStatsModel
from betronic_core.db.models.tvbet import TvBetSessionModel
from betronic_core.db.models.golden_race_session import GoldenRaceSessionModel
from betronic_core.db.models.golden_race_result_session import GoldenRaceGameCycleModel
from betronic_core.db.models.xpg_session import XPGSessionModel
from betronic_core.db.models.xpg_transaction import XPGTransactionModel
from betronic_core.db.models.pragmatic_models import PragmaticPlaySessionModel, PragmaticTransactionsModel
from betronic_core.db.models.outcome_transactions import OutComeTransactionModel
from betronic_core.db.models.habanero_models import HabaneroTokenModel, HabaneroTransactionsModel
from betronic_core.db.models.owner_statistic import OwnerStatisticModel
from betronic_core.db.models.royalty_statistic import RoyaltyStatisticModel
from betronic_core.db.models.bswgames import BswGamesBetModel
from betronic_core.db.models.favorite_slots import FavoriteSlots
from betronic_core.db.models.security_log import SecurityLogModel
from betronic_core.db.models.line1x.coupon import PlacedCouponLine1xModel
from betronic_core.db.models.line1x.bet import BetsLine1xModel
from betronic_core.db.models.admin_payment import AdminPaymentRequestModel, AdminPaymentRequisiteModel
from betronic_core.db.models.user_provider_statistic import UserProviderStatisticModel
from betronic_core.db.models.agent_structure_statistic import AgentStructureStatisticModel
from betronic_core.db.models.host import Host, UserHostPermission
from betronic_core.db.models.bonus_balance_burn import BonusBalanceBurnModel
from betronic_core.db.models.bonus_royalty_statistic import BonusRoyaltyStatisticModel
from betronic_core.db.models.commission_percents import CommissionBalances, CommissionPercents
from betronic_core.db.models.sport_games_history import SportBetHistoryModel, SportCouponHistoryModel
from betronic_core.db.models.permission_details import ProviderModel
from betronic_core.db.models.notification import NotificationModel
from betronic_core.db.models.settings import SettingsModel
from betronic_core.db.models.agent_payment_statistic import AgentPaymentStatisticModel

target_metadata = BaseModel.metadata


def get_database_url():
    a = get_all_settings().DATABASE
    return "postgresql://{}:{}@{}:{}/{}". \
        format(a["user"], a["password"], a["host"], a["port"], a["name"])


def run_migrations_offline():
    """Run migrations in 'offline' mode.

    This configures the context with just a URL
    and not an Engine, though an Engine is acceptable
    here as well.  By skipping the Engine creation
    we don't even need a DBAPI to be available.

    Calls to context.execute() here emit the given string to the
    script output.

    """
    # url = config.get_main_option("sqlalchemy.url")
    url = get_database_url()
    context.configure(url=url, target_metadata=target_metadata)

    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online():
    """Run migrations in 'online' mode.

    In this scenario we need to create an Engine
    and associate a connection with the context.

    """
    alembic_config = config.get_section(config.config_ini_section)
    # engine = engine_from_config(
    #     alembic_config, prefix='sqlalchemy.', poolclass=pool.NullPool)
    engine = create_engine(get_database_url())

    def include_object(object, name, type_, reflected, compare_to):
        if not reflected and object.info.get("skip_autogenerate", False):
            return False
        else:
            return True

    connection = engine.connect()
    context.configure(
        connection=connection,
        target_metadata=target_metadata,
        include_object=include_object,
        compare_type=True)

    try:
        with context.begin_transaction():
            context.run_migrations()
    finally:
        connection.close()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
