#!/bin/bash

function create_keys_to_file {
  echo "Creating private rsa key: private_key.pem"
  openssl genrsa -out private_key.pem 2048
  echo
  echo "Creating private rsa key: public_key.pem"
  openssl rsa -in private_key.pem -outform PEM -pubout -out public_key.pem
}

function create_keys_to_output {
  openssl genrsa 2048 >> temp.pem
  cat temp.pem
  echo
  openssl rsa -in temp.pem -pubout
  rm -f temp.pem
}

printf "Now will be generated new RSA key pair."
printf "Select one of the options:\n \t 1.Write result to files.\n \t 2.Write result to standard output.\n"

read -rp "Option: "

case $REPLY in
  1) create_keys_to_file ;;
  2) create_keys_to_output ;;
esac