import sys, os
from importlib import import_module
from logging import getLogger

from settings.setup_settings import (
    get_all_settings, setup_sentry, setup_site_settings, setup_ip_whitelist, setup_settings, setup_http_client
)

logger = getLogger(__name__)


def start():
    if len(sys.argv) < 2:
        logger.error("No target specified")
        return
    target = sys.argv[1]

    setup_settings()
    setup_http_client()
    setup_sentry()
    setup_site_settings()
    # setup_ip_whitelist()

    start_ = _get_target_start_function(target)

    if not start_:
        logger.error("Unknown target %s, maybe add this in SERVICES", target)
    else:
        logger.info('Starting target "%s"...', target)
        start_()


def _get_target_start_function(target):
    if target in get_all_settings().SERVICES:
        service = import_module("bookmakers.{}.service.service".format(target))
        return service.start()

    if target == "royalty_statistic_bot":
        from bots.royalty_statistic_bot.royalty_statistic_bot import run
        return run

    if target == "structure_statistic_bot":
        from bots.structure_statistic_bot.structure_statistic_bot import run
        return run

    if target == "agent_commissions_bot":
        from bots.agent_commissions_bot.agent_commissions_bot import run
        return run

    if target == "owner_reports_collector":
        from bots.owner_reports_collector.collector import run
        return run

    if target == "technical_balance_notifier":
        from bots.technical_balance_notificator.bot import run
        return run

    if target == "limit_balances_notifier":
        from bots.limit_balance_notificator.bot import run
        return run

    if target == "send-emails":
        from bots.email.email_sender import run
        return run

    if target == "web":
        from bookmakers.web.application import start
        return start

    if target == 'admin':
        from admin.app import start
        return start

    if target == 'shell':
        return os.system('ipython --ipython-dir=.ipython')

    if target == "bonus_balance_burner_bot":
        from bots.bonus_balance_burner.bot import run
        return run

    if target == "daily_winnings_bot":
        from bots.daily_winnings.daily_winnings_bot import run
        return run

    if target == "autistic_bot":
        from bots.autistic_bot.autistic_bot import run
        return run

    if target == "obosrastic_bot":
        from bots.obosrastic_bot.obosrastic_bot import run
        return run

    if target == "caracal_cleaner":
        from bots.caracal_cleaner.bot import run
        return run

    if target == "agent_payment_bot":
        from bots.agent_payment_bot.agent_payment_bot import run
        return run

    if target == "single_depression_script_bot":
        from scripts.single_script_depression import ScriptBot
        return ScriptBot.start


start()

