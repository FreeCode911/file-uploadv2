# Сервер White Label

Описание api.
Сервер принимает и отдает json. Header выставить **"content/type": "application/json"**

Все запросы возвращают ответ в едином формате:
* status - статус запроса. Если 0 - то запрос прошел успешно
* result - Результат запроса, может содержать строку, объект, массив
* error_message - содержит описание ошибки

```json
{
  "status": 0,
  "result":{},
  "error_message":null
}
```


## Site
### Метод потучения настроек
METHOD GET
**/api/site/settings**
#### Response:
- *currencies* Список используемых валют

```json
{
  "result": {
    "currencies": [
      "RUB", 
      "USD"
    ]
  }
}
```

### Получить все flatPages
METHOD GET
**/api/site/flatpages**
#### Response:
- *name* Наименование страницы
- *id_name* Наименование страницы для выдачи. Только латиницей
- *text* Текст страницы
- *create_at* Дата создания
- *update_at* Дата Обновления

```json
{
  "result": [
    {
      "id":1,
      "name": "Правила",
      "id_name": "rules",
      "text": "Правил нет",
      "created_at": "2017-10-20T00:00:00+00:00",
      "updated_at": "2017-10-20T00:00:00+00:00"
    }
  ]
}
```

### Получить flatPage по имени
METHOD GET
**/api/site/flatpages/\<id_name\>**
#### Response:

```json
{
  "result": {
    "id":1,
    "name": "Правила",
    "id_name": "rules",
    "text": "Правил нет",
    "created_at": "2017-10-20T00:00:00+00:00",
    "updated_at": "2017-10-20T00:00:00+00:00"
  }
}
```

## User

Коды ошибок:
- USER_ALREADY_EXIST = 1
- INVALID_EMAIL = 2
- USER_NOT_EXIST = 3
- INVALID_PASSWORD = 4
- USER_IS_BANNED = 5
- INVALID_VERIFY_KEY = 6
- VERIFY_KEY_IS_EXPIRED = 7
- ALREADY_VERIFIED = 8
- PASSWORD_REQUEST_NOT_EXIST = 9
- PASSWORD_REQUEST_IS_EXPIRED = 10
- USER_IS_NOT_VEREFIED = 11

### Регистрация
METHOD POST
**/api/user/signup**
#### Request:
- name - ФИО через пробел
- password - Пароль
- email - Емайл
- currency - Вылюта

```json
{
  "name": "Anton Shvetsov",
  "password": "qwerty123",
  "email": "fantom0005@yandex.ru",
  "currency": "RUB"
}
```

#### Response:
- user_id - ID нового юзера
- user_email - Email юзера

```json
{
  "result": {
    "user_id": 2,
    "user_email": "fantom00005@yandex.ru"
  }
}
```

### Баланс
METHOD GET
**/api/user/balance**

#### Response:
- balance - Баланс пользователя
- currency - Валюта пользователя

```json
{
  "result": {
    "balance": 0,
    "currency": "RUB"
  }
}
```

### Получить персональные данные
METHOD GET
**/api/user/profile**
#### Response:
- personal - персональная информация
    - id - номер счета
    - name - имя
    - last_name - фамилия
    - middle_name - отчетсво
    - currency - валюта
- additional - дополнительная информация
    - yandex - Яндекс кошелек
    - user - ID пользователя
    - number_document - Номер документа
    - card - Номер карты
    - address - Адрес
    - phone - Номер телефона
    - id - ID персональных данных

```json
{
  "result": {
      "personal":{
        "first_name": "Aleksandr",
        "last_name": "Usov",
        "middle_name": "Andreevich",
        "id": "10",
        "currency": "RUB",
        "balance": 0
      },
      "additional":{
          "yandex":"3242354353453",
          "number_document":"10213",
          "user":1,
          "card":"120234 20324 023423 0324",
          "address":"asdasdada",
          "phone":"79992349239",
          "id":22
      }
  }
}
```

### Получить персональные данные
METHOD PUT
**/api/user/profile/additional/update**
#### Request:
- yandex - Яндекс кошелек
- number_document - Номер документа
- card - Номер карты
- address - Адрес
- phone - Номер телефона

```json
{
    "yandex":"3242354353453",
    "number_document":"10213",
    "card":"120234 20324 023423 0324",
    "address":"Address",
    "phone":"79992349239"
}
```

#### Response:

```json
{
    "result": {
        "yandex":"3242354353453",
        "number_document":"10213",
        "user":1,
        "card":"120234 20324 023423 0324",
        "address":"Address",
        "phone":"79992349239",
        "id":22
    }
}
```

### Смена пароля
METHOD POST
**/api/user/password/change**
#### Request:
- password - пароль
- new_password - новый пароль

```json
{
    "password":"3242354353453",
    "new_password":"10213"
}
```

#### Response:

```json
{
    "result": "ok"
}
```
